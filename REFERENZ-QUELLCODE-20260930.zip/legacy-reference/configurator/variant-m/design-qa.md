# Design-QA – 24.09.2026

Referenz: Christophers freigegebene Desktop-/Mobilbilder 53364/53365 und der danach
besprochene Funktionsplan. Ziel: gleiche Anordnung, kompakte Schriftwahl, große
Bedienelemente, einheitliches Grün; der echte editierbare Renderer bleibt maßgeblich.

Geprüft im lokalen Browser bei 1280 × 960 und 390 × 844. Kein Deployment.

## Korrigiert während des Vergleichs

- Übernommene mobile Grid-Zuordnung setzte den Warenkorbknopf auf eine zweite Zeile:
  explizite Spalten-/Zeilenzuordnung, Preis/Menge/Button nebeneinander.
- Alte Spaltenrichtung machte die Desktop-Preisfläche unnötig hoch: waagerecht.
- Feste Vorschauhöhe verzerrte die verfügbare Querformatfläche: Produktcontainer
  orientiert sich an der nutzbaren Fläche und behält das Seitenverhältnis.
- Native Materialprofile dürfen keine AOSU-Rahmenbilder zeigen: gezielt ausgeblendet.
- Normalansicht ohne große schwebende Textwerkzeuge; vollständige Bearbeitung im
  Vollbild und in Meine Inhalte. Dort bleibt Hilfe erreichbar.
- Maßzahl wurde zunächst noch um 3 px von der unteren Maßlinie berührt: größerer
  vertikaler Abstand und entsprechender Platz unter der Produktfläche.
- Fontdialog mobil: acht gut lesbare Proben mit echten Pfaden, große Seitentasten,
  keine zusätzliche Scrollfläche bei 390 × 844.

## Bewusste Abweichungen von der Illustration

- Technische interaktive Produktvorschau statt eines statischen Hauswandfotos.
- Speichermeldung nennt den tatsächlichen lokalen Sitzungsstand. Keine unbelegte
  Aussage „Dein Entwurf bleibt gespeichert“ für ein noch unverbundenes Kundenkonto.
- Keine unbelegten Trust-/Lieferbehauptungen aus der Illustration übernommen.
- Kauf bleibt im Prüfstand deaktiviert; ein grüner Button ist kein Checkoutnachweis.

Die globale visuelle Abnahme bleibt **teilweise offen**: große Gesamtliste aller
Material-/Designkombinationen, echte Touchgeräte, Screenreader und kleine Querformate
wurden nicht vollständig geprüft. Siehe UX-VERIFICATION.md für funktionale Grenzen.

