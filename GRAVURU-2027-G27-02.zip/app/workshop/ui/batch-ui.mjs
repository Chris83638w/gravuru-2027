import {readImport} from './batch-reader.mjs';
const $=s=>document.querySelector(s),escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let prepared=null,csrf=null,busy=false,hasErrors=false;
async function api(path,data){if(data&&!csrf)csrf=(await api('/api/workshop/session')).csrfToken;const res=await fetch(path,{method:data?'POST':'GET',headers:data?{'Content-Type':'application/json','X-Gravuru-CSRF':csrf}:{},...(data?{body:JSON.stringify(data)}:{})});const body=await res.json();if(!res.ok)throw Error(body.error?.message||'Aktion fehlgeschlagen.');return body;}
function status(message,error=false){$('#status').textContent=message;$('#status').style.color=error?'#a32828':'#183e35';}
function disabled(value){busy=value;$('#check').disabled=value;$('#master').disabled=value;$('#file').disabled=value;$('#skip-errors').disabled=value;$('#import').disabled=value||!prepared||hasErrors&&!$('#skip-errors').checked;}
function invalidate(){prepared=null;hasErrors=false;$('#skip-errors').checked=false;$('#partial-label').hidden=true;$('#review').hidden=true;$('#result').hidden=true;$('#import').disabled=true;status('');}
$('#skip-errors').addEventListener('change',()=>disabled(busy));
$('#file').addEventListener('change',invalidate);$('#master').addEventListener('change',invalidate);
$('#check').addEventListener('click',async()=>{
 if(busy)return;invalidate();disabled(true);
 try{
  const option=$('#master').selectedOptions[0];if(!option)throw Error('Bitte zuerst eine Mastervorlage anlegen.');
  const data={rows:await readImport($('#file').files[0]),masterId:option.value,masterRevision:Number(option.dataset.revision)};
  const plan=await api('/api/workshop/batch/plan',data);$('#review').hidden=false;
  const errors=plan.report.filter(r=>r.status==='error').length,existing=plan.report.filter(r=>r.status==='existing').length;
  hasErrors=errors>0;$('#partial-label').hidden=!hasErrors||!plan.token;
  $('#summary').textContent=`${plan.report.length} Produkte · ${errors} Fehler · ${existing} bereits vorhanden`;
  $('#rows').innerHTML=plan.report.map(row=>'<tr><td>'+row.row+'</td><td>'+escape(row.key)+'</td><td>'+escape(row.name)+'</td><td>'+money(row.prices?.small)+'</td><td>'+money(row.prices?.large)+'</td><td>'+escape(row.message||(row.status==='existing'?'Bereits angelegt':'Bereit'))+'</td></tr>').join('');
  if(plan.token)prepared={...data,token:plan.token};
  status(plan.valid?'Prüfung abgeschlossen. Du kannst die Serie jetzt anlegen.':'Noch nichts angelegt. Fehler korrigieren oder ausdrücklich nur gültige Datensätze anlegen.',!plan.valid);
 }catch(error){status(error.message,true);}finally{disabled(false);}
});
const money=cents=>Number.isInteger(cents)?new Intl.NumberFormat('de-DE',{style:'currency',currency:'EUR'}).format(cents/100):'–';
$('#import').addEventListener('click',async()=>{if(busy||!prepared||hasErrors&&!$('#skip-errors').checked)return;disabled(true);try{const result=await api('/api/workshop/batch/commit',{...prepared,skipErrors:$('#skip-errors').checked});$('#result').hidden=false;$('#result-list').innerHTML=result.products.map(item=>'<p><a href="/werkstatt/?configuration='+encodeURIComponent(item.id)+'">'+escape(item.key)+'</a> · <code>'+escape(item.id)+'</code> · '+(item.created?'Neu angelegt':'Bereits vorhanden')+'</p>').join('');status(`${result.products.filter(p=>p.created).length} neue Konfigurationen gespeichert. ${result.errors?.length||0} fehlerhafte Datensätze bleiben zur Korrektur offen.`);prepared=null;}catch(error){status(error.message,true);}finally{disabled(false);}});
try{const {products}=await api('/api/workshop/products');$('#master').innerHTML=products.filter(p=>p.kind==='master').map(p=>'<option value="'+escape(p.id)+'" data-revision="'+p.revision+'">'+escape(p.name)+' · Stand '+p.revision+'</option>').join('');if(!$('#master').options.length)status('Lege in der Produktverwaltung zunächst eine Mastervorlage an.',true);}catch(error){status(error.message,true);}
