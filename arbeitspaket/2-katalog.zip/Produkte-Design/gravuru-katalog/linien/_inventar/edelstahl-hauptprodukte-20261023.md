# Hauptprodukte Edelstahl Türschilder · aus FancyCustomizationIDs.csv

105 Zeilen, **93 eingetragen**, 3 schon vorhanden, 9 offen, 0 Warnungen. Geschrieben.

| CustomizationID | Hauptdesign | Unterkategorie | Startdesign | Größe | Name |
| --- | --- | --- | --- | --- | --- |
| 1600000 | TRE-V2A-8x5-D30 | familienschilder | TRE-V2A-8x5-D30 | GR-ES-RE-80X53P3-T15 | Türschild Edelstahl personalisiert – Hund 8×5 cm |
| 2500000 | TRE-V2A-5x2-D1 | familienschilder | TRE-V2A-5x2-D1 | GR-ES-RE-50X20-T15 | Türschild Edelstahl V2A personalisiert 5×2 cm |
| 2600000 | TRE-V2A-5x2-D27 | familienschilder | TRE-V2A-5x2-D27 | GR-ES-RE-50X20-T15 | Türschild Edelstahl V2A personalisiert – Brief 5×2 cm |
| 2700000 | TRE-V2A-5x2-D52 | familienschilder | TRE-V2A-5x2-D52 | GR-ES-RE-50X20-T15 | Türschild Edelstahl V2A personalisiert – Herz 5×2 cm |
| 2800000 | TRE-V2A-6x2-D3 | familienschilder | TRE-V2A-6x2-D3 | GR-ES-RE-60X20-T15 | Türschild Edelstahl V2A personalisiert 6×2 cm |
| 2900000 | TRE-V2A-6x2-D23 | familienschilder | TRE-V2A-6x2-D23 | GR-ES-RE-60X20-T15 | Türschild Edelstahl V2A personalisiert – Haus 6×2 cm |
| 3000000 | TRE-V2A-6x2-D42 | familienschilder | TRE-V2A-6x2-D42 | GR-ES-RE-60X20-T15 | Türschild Edelstahl V2A personalisiert – Vogel Silhouette 6×2 cm |
| 3400000 | TRE-V2A-8x2-D2 | familienschilder | TRE-V2A-8x2-D2 | GR-ES-RE-80X20-T15 | Türschild Edelstahl V2A personalisiert 8×2 cm |
| 3500000 | TRE-V2A-8x2-D30 | familienschilder | TRE-V2A-8x2-D30 | GR-ES-RE-80X20-T15 | Türschild Edelstahl V2A personalisiert – Dezentes Symbol 8×2 cm |
| 3600000 | TRE-V2A-8x2-D6 | familienschilder | TRE-V2A-8x2-D6 | GR-ES-RE-80X20-T15 | Türschild Edelstahl V2A personalisiert – Anker 8×2 cm |
| 3700000 | TAE-V2A-8x5-D14 | familienschilder | TAE-V2A-8x5-D14 | GR-ES-AB-80X53P3-T15 | Türschild Abger. Ecken V2A personalisiert – Pusteblume 8×5 cm |
| 3800000 | TAE-V2A-8x5-D33 | familienschilder | TAE-V2A-8x5-D33 | GR-ES-AB-80X53P3-T15 | Türschild Abger. Ecken V2A personalisiert – Pfoten 8×5 cm |
| 3900000 | TRE-V2A-9x6-D55 | familienschilder | TRE-V2A-8x5-D55 | GR-ES-RE-90X60-T15 | Türschild Edelstahl V2A personalisiert – Schnörkel mit Herz 9×6 cm |
| 4000000 | TRE-V2A-9x6-D20 | familienschilder | TRE-V2A-8x5-D20 | GR-ES-RE-90X60-T15 | Türschild Edelstahl V2A personalisiert – Lebensbaum 9×6 cm |
| 4100000 | TAE-V2A-12x8-D8 | familienschilder | TAE-V2A-8x5-D8 | GR-ES-AB-120X80-T15 | Türschild Abger. Ecken V2A personalisiert – Leuchtturm 12×8 cm |
| 4200000 | TAE-V2A-12x8-D10 | familienschilder | TAE-V2A-8x5-D10 | GR-ES-AB-120X80-T15 | Türschild Abger. Ecken V2A personalisiert – Laubbaum 12×8 cm |
| 4300000 | TAE-V2A-15x10-D12 | familienschilder | TAE-V2A-8x5-D12 | GR-ES-AB-150X100-T15 | Türschild Abger. Ecken V2A personalisiert – Pusteblume 15×10 cm |
| 4400000 | TAE-V2A-15x10-D34 | familienschilder | TAE-V2A-8x5-D34 | GR-ES-AB-150X100-T15 | Türschild Abger. Ecken V2A personalisiert – Katze 15×10 cm |
| 4500000 | TAE-V2A-18x12-D32 | familienschilder | TAE-V2A-8x5-D32 | GR-ES-AB-180X120-T15 | Türschild Abger. Ecken V2A personalisiert – Pfoten 18×12 cm |
| 4600000 | TAE-V2A-18x12-D62 | familienschilder | TAE-V2A-8x5-D62 | GR-ES-AB-180X120-T15 | Türschild Abger. Ecken V2A personalisiert – Schlüssel 18×12 cm |
| 4700000 | TAE-V2A-30x20-D65 | familienschilder | TAE-V2A-8x5-D65 | GR-ES-AB-300X200-T15 | Türschild Abger. Ecken V2A personalisiert – Herzen 30×20 cm |
| 4800000 | TAE-V2A-30x20-D24 | familienschilder | TAE-V2A-8x5-D24 | GR-ES-AB-300X200-T15 | Türschild Abger. Ecken V2A personalisiert – Haus mit Herz 30×20 cm |
| 4900000 | TO-V2A-9x6-D1 | familienschilder | TO-V2A-9x6-D1 | GR-ES-OV-90X60-T15 | Türschild Oval Edelstahl V2A personalisiert 9×6 cm |
| 5000000 | TO-V2A-9x6-D24 | familienschilder | TO-V2A-9x6-D24 | GR-ES-OV-90X60-T15 | Türschild Oval Edelstahl V2A personalisiert – Haus mit Herz 9×6 cm |
| 5100000 | TO-V2A-9x6-D7 | familienschilder | TO-V2A-9x6-D7 | GR-ES-OV-90X60-T15 | Türschild Oval Edelstahl V2A personalisiert – Segelboot 9×6 cm |
| 5200000 | TO-V2A-21x14-D25 | familienschilder | TO-V2A-9x6-D25 | GR-ES-OV-210X140-T15 | Türschild Oval Edelstahl V2A personalisiert – Haus 21×14 cm |
| 5300000 | TO-V2A-21x14-D13 | familienschilder | TO-V2A-9x6-D13 | GR-ES-OV-210X140-T15 | Türschild Oval Edelstahl V2A personalisiert – Pusteblume 21×14 cm |
| 5400000 | TO-V2A-21x14-D61 | familienschilder | TO-V2A-9x6-D61 | GR-ES-OV-210X140-T15 | Türschild Oval Edelstahl V2A personalisiert – Herz 21×14 cm |
| 5500000 | TO-V2A-12x4-D48 | familienschilder | TO-V2A-12x4-D48 | GR-ES-EL-120X40-T15 | Türschild Oval Edelstahl V2A personalisiert – Vögel 12×4 cm |
| 5600000 | TO-V2A-12x4-D58 | familienschilder | TO-V2A-12x4-D58 | GR-ES-EL-120X40-T15 | Türschild Oval Edelstahl V2A personalisiert – Herzranke 12×4 cm |
| 5700000 | TO-V2A-12x4-D52 | familienschilder | TO-V2A-12x4-D52 | GR-ES-EL-120X40-T15 | Türschild Oval Edelstahl V2A personalisiert – Herz 12×4 cm |
| 5800000 | TO-V2A-12x4-D12 | familienschilder | TO-V2A-12x4-D12 | GR-ES-EL-120X40-T15 | Türschild Oval Edelstahl V2A personalisiert – Pusteblume 12×4 cm |
| 5900000 | TO-V2A-12x4-D60 | familienschilder | TO-V2A-12x4-D60 | GR-ES-EL-120X40-T15 | Türschild Oval Edelstahl V2A personalisiert – Ornament 12×4 cm |
| 6000000 | TO-V2A-12x4-D31 | familienschilder | TO-V2A-12x4-D31 | GR-ES-EL-120X40-T15 | Türschild Oval Edelstahl V2A personalisiert – Hund Silhouette 12×4 cm |
| 6100000 | TO-V2A-15x8-D47 | familienschilder | TO-V2A-15x8-D47 | GR-ES-OV-150X80-T15 | Türschild Oval Edelstahl V2A personalisiert – Vogelpaar 15×8 cm |
| 6200000 | TO-V2A-15x8-D19 | familienschilder | TO-V2A-15x8-D19 | GR-ES-OV-150X80-T15 | Türschild Oval Edelstahl V2A personalisiert – Rose 15×8 cm |
| 6300000 | TO-V2A-15x8-D10 | familienschilder | TO-V2A-15x8-D10 | GR-ES-OV-150X80-T15 | Türschild Oval Edelstahl V2A personalisiert – Laubbaum 15×8 cm |
| 7200000 | TQ-V2A-8x8-D3 | familienschilder | TQ-V2A-8x8-D3 | GR-ES-QU-80X80-T15 | Türschild Quadrat Edelstahl V2A personalisiert 8×8 cm |
| 7300000 | TQ-V2A-8x8-D53 | familienschilder | TQ-V2A-8x8-D53 | GR-ES-QU-80X80-T15 | Türschild Quadrat Edelstahl V2A personalisiert – Herz 8×8 cm |
| 7400000 | TQ-V2A-8x8-D33 | familienschilder | TQ-V2A-8x8-D33 | GR-ES-QU-80X80-T15 | Türschild Quadrat Edelstahl V2A personalisiert – Pfoten 8×8 cm |
| 7500000 | TQ-V2A-16x16-D12 | familienschilder | TQ-V2A-8x8-D12 | GR-ES-QU-160X160-T15 | Türschild Quadrat Edelstahl V2A personalisiert – Pusteblume 16×16 cm |
| 7600000 | TQ-V2A-16x16-D6 | familienschilder | TQ-V2A-8x8-D6 | GR-ES-QU-160X160-T15 | Türschild Quadrat Edelstahl V2A personalisiert – Anker 16×16 cm |
| 7700000 | TQ-V2A-16x16-D29 | familienschilder | TQ-V2A-8x8-D29 | GR-ES-QU-160X160-T15 | Türschild Quadrat Edelstahl V2A personalisiert – Hundefigur 16×16 cm |
| 7800000 | TRE-V2A-9x6-D5 | familienschilder | TRE-V2A-8x5-D5 | GR-ES-RE-90X60-T15 | Türschild Edelstahl personalisiert 9×6 cm |
| 7900000 | TQ-V2A-20x20-D10 | familienschilder | TQ-V2A-8x8-D10 | GR-ES-QU-200X200-T15 | Türschild Quadrat Edelstahl V2A personalisiert – Laubbaum 20×20 cm |
| 8000000 | TQ-V2A-20x20-D25 | familienschilder | TQ-V2A-8x8-D25 | GR-ES-QU-200X200-T15 | Türschild Quadrat Edelstahl V2A personalisiert – Haus 20×20 cm |
| 8100000 | TQ-V2A-20x20-D7 | familienschilder | TQ-V2A-8x8-D7 | GR-ES-QU-200X200-T15 | Türschild Quadrat Edelstahl V2A personalisiert – Segelboot 20×20 cm |
| 8200000 | TRE-V2A-8x3,5-D4 | familienschilder | TRE-V2A-8x3,5-D4 | GR-ES-RE-80X35-T15 | Türschild Edelstahl V2A personalisiert 8×3,5 cm |
| 8300000 | TRE-V2A-8x3,5-D35 | familienschilder | TRE-V2A-8x3,5-D35 | GR-ES-RE-80X35-T15 | Türschild Edelstahl V2A personalisiert – Katze 8×3,5 cm |
| 8400000 | TRE-V2A-8x3,5-D62 | familienschilder | TRE-V2A-8x3,5-D62 | GR-ES-RE-80X35-T15 | Türschild Edelstahl V2A personalisiert – Schlüssel 8×3,5 cm |
| 8500000 | TRE-V2A-12x5,25-D5 | familienschilder | TRE-V2A-8x3,5-D5 | GR-ES-RE-120X52P5-T15 | Türschild Edelstahl V2A personalisiert 12×5,25 cm |
| 8600000 | TRE-V2A-12x5,25-D18 | familienschilder | TRE-V2A-8x3,5-D18 | GR-ES-RE-120X52P5-T15 | Türschild Edelstahl V2A personalisiert – Pusteblume 12×5,25 cm |
| 8700000 | TRE-V2A-12x5,25-D28 | familienschilder | TRE-V2A-8x3,5-D28 | GR-ES-RE-120X52P5-T15 | Türschild Edelstahl V2A personalisiert – Fußball-Symbol 12×5,25 cm |
| 8800000 | TRE-V2A-16x7-D21 | familienschilder | TRE-V2A-8x3,5-D21 | GR-ES-RE-160X70-T15 | Türschild Edelstahl V2A personalisiert – Sonne 16×7 cm |
| 8900000 | TRE-V2A-16x7-D29 | familienschilder | TRE-V2A-8x3,5-D29 | GR-ES-RE-160X70-T15 | Türschild Edelstahl V2A personalisiert – Hundefigur 16×7 cm |
| 9000000 | TRE-V2A-16x7-D63 | familienschilder | TRE-V2A-8x3,5-D63 | GR-ES-RE-160X70-T15 | Türschild Edelstahl V2A personalisiert – Wimpelkette 16×7 cm |
| 9100000 | TRE-V2A-24x10,5-D71 | familienschilder | TRE-V2A-8x3,5-D71 | GR-ES-RE-240X105-T15 | Türschild Edelstahl V2A personalisiert – Pfeil 24×10,5 cm |
| 9200000 | TRE-V2A-24x10,5-D72 | hinweisschilder | TRE-V2A-8x3,5-D72 | GR-ES-RE-240X105-T15 | Türschild Edelstahl V2A personalisiert – Dreieck 24×10,5 cm |
| 9300000 | TRE-V2A-24x10,5-D29 | familienschilder | TRE-V2A-8x3,5-D29 | GR-ES-RE-240X105-T15 | Türschild Edelstahl V2A personalisiert – Hundefigur 24×10,5 cm |
| 9400000 | TRE-V2A-9x3-D2 | familienschilder | TRE-V2A-9x3-D2 | GR-ES-RE-90X30-T15 | Türschild Edelstahl V2A personalisiert 9×3 cm |
| 9500000 | TRE-V2A-9x3-D33 | familienschilder | TRE-V2A-9x3-D33 | GR-ES-RE-90X30-T15 | Türschild Edelstahl V2A personalisiert – Pfoten 9×3 cm |
| 9600000 | TRE-V2A-9x3-D39 | familienschilder | TRE-V2A-9x3-D39 | GR-ES-RE-90X30-T15 | Türschild Edelstahl V2A personalisiert – Schlichtes Design ohne Motiv 9×3 cm |
| 9700000 | TRE-V2A-24x8-D64 | familienschilder | TRE-V2A-9x3-D64 | GR-ES-RE-240X80-T15 | Türschild Edelstahl V2A personalisiert – Eck-Ornamente 24×8 cm |
| 9800000 | TRE-V2A-24x8-D68 | familienschilder | TRE-V2A-9x3-D68 | GR-ES-RE-240X80-T15 | Türschild Edelstahl V2A personalisiert – Pfeil 24×8 cm |
| 9900000 | TRE-V2A-24x8-D40 | familienschilder | TRE-V2A-9x3-D40 | GR-ES-RE-240X80-T15 | Türschild Edelstahl V2A personalisiert – Vogel Silhouette 24×8 cm |
| 10000000 | TRE-V2A-8x5-D3 | familienschilder | TRE-V2A-8x5-D3 | GR-ES-RE-80X53P3-T15 | Türschild Edelstahl V2A personalisiert 8×5 cm |
| 10100000 | TRE-V2A-8x5-D27 | familienschilder | TRE-V2A-8x5-D27 | GR-ES-RE-80X53P3-T15 | Türschild Edelstahl personalisiert – Brief 8×5 cm |
| 10200000 | TRE-V2A-9x6-D14 | familienschilder | TRE-V2A-8x5-D14 | GR-ES-RE-90X60-T15 | Türschild Edelstahl personalisiert – Pusteblume 9×6 cm |
| 10300000 | TRE-V2A-9x6-D64 | familienschilder | TRE-V2A-8x5-D64 | GR-ES-RE-90X60-T15 | Türschild Edelstahl personalisiert – Eck-Ornamente 9×6 cm |
| 10400000 | TRE-V2A-12x8-D12 | familienschilder | TRE-V2A-8x5-D12 | GR-ES-RE-120X80-T15 | Türschild Edelstahl personalisiert – Pusteblume 12×8 cm |
| 10500000 | TRE-V2A-12x8-D24 | familienschilder | TRE-V2A-8x5-D24 | GR-ES-RE-120X80-T15 | Türschild Edelstahl personalisiert – Haus mit Herz 12×8 cm |
| 10600000 | TRE-V2A-12x8-D49 | familienschilder | TRE-V2A-8x5-D49 | GR-ES-RE-120X80-T15 | Türschild Edelstahl personalisiert – Eulen Familie 12×8 cm |
| 10700000 | TRE-V2A-15x10-D65 | familienschilder | TRE-V2A-8x5-D65 | GR-ES-RE-150X100-T15 | Türschild Edelstahl personalisiert – Herzen 15×10 cm |
| 10800000 | TRE-V2A-15x10-D34 | familienschilder | TRE-V2A-8x5-D34 | GR-ES-RE-150X100-T15 | Türschild Edelstahl personalisiert – Katze 15×10 cm |
| 10900000 | TRE-V2A-15x10-D25 | familienschilder | TRE-V2A-8x5-D25 | GR-ES-RE-150X100-T15 | Türschild Edelstahl personalisiert – Haus 15×10 cm |
| 11000000 | TRE-V2A-18x12-D8 | familienschilder | TRE-V2A-8x5-D8 | GR-ES-RE-180X120-T15 | Türschild Edelstahl personalisiert – Leuchtturm 18×12 cm |
| 11100000 | TRE-V2A-18x12-D15 | familienschilder | TRE-V2A-8x5-D15 | GR-ES-RE-180X120-T15 | Türschild Edelstahl personalisiert – Blütenranke 18×12 cm |
| 11200000 | TRE-V2A-18x12-D58 | familienschilder | TRE-V2A-8x5-D58 | GR-ES-RE-180X120-T15 | Türschild Edelstahl personalisiert – Herzranke 18×12 cm |
| 11300000 | TRE-V2A-21x14-D11 | familienschilder | TRE-V2A-8x5-D11 | GR-ES-RE-210X140-T15 | Türschild Edelstahl personalisiert – Pusteblume 21×14 cm |
| 11400000 | TRE-V2A-21x14-D41 | familienschilder | TRE-V2A-8x5-D41 | GR-ES-RE-210X140-T15 | Türschild Edelstahl personalisiert – Kolibri 21×14 cm |
| 11500000 | TRE-V2A-21x14-D60 | familienschilder | TRE-V2A-8x5-D60 | GR-ES-RE-210X140-T15 | Türschild Edelstahl personalisiert – Ornament 21×14 cm |
| 11600000 | TRE-V2A-24x16-D21 | familienschilder | TRE-V2A-8x5-D21 | GR-ES-RE-240X160-T15 | Türschild Edelstahl personalisiert – Sonne 24×16 cm |
| 11700000 | TRE-V2A-24x16-D22 | familienschilder | TRE-V2A-8x5-D22 | GR-ES-RE-240X160-T15 | Türschild Edelstahl personalisiert – Strich Haus 24×16 cm |
| 11800000 | TRE-V2A-24x16-D31 | familienschilder | TRE-V2A-8x5-D31 | GR-ES-RE-240X160-T15 | Türschild Edelstahl personalisiert – Hund Silhouette 24×16 cm |
| 11900000 | TRE-V2A-30x20-D1 | familienschilder | TRE-V2A-8x5-D1 | GR-ES-RE-300X200-T15 | Türschild Edelstahl personalisiert 30×20 cm |
| 12000000 | TRE-V2A-30x20-D32 | familienschilder | TRE-V2A-8x5-D32 | GR-ES-RE-300X200-T15 | Türschild Edelstahl personalisiert – Pfoten 30×20 cm |
| 12100000 | TRE-V2A-30x20-D10 | familienschilder | TRE-V2A-8x5-D10 | GR-ES-RE-300X200-T15 | Türschild Edelstahl personalisiert – Laubbaum 30×20 cm |
| 12200000 | TRE-V2A-42x28-D6 | familienschilder | TRE-V2A-8x5-D6 | GR-ES-RE-420X280-T15 | Türschild Edelstahl personalisiert – Anker 42×28 cm |
| 12300000 | TRE-V2A-45x30-D69 | familienschilder | TRE-V2A-8x5-D69 | GR-ES-RE-450X300-T15 | Türschild Edelstahl personalisiert – Pfeil 45×30 cm |
| 12400000 | TRE-V2A-45x30-D20 | familienschilder | TRE-V2A-8x5-D20 | GR-ES-RE-450X300-T15 | Türschild Edelstahl personalisiert – Lebensbaum 45×30 cm |
| 12500000 | TRE-V2A-45x30-D33 | familienschilder | TRE-V2A-8x5-D33 | GR-ES-RE-450X300-T15 | Türschild Edelstahl personalisiert – Pfoten 45×30 cm |
| 12600000 | TRE-V2A-42x28-D57 | familienschilder | TRE-V2A-8x5-D57 | GR-ES-RE-420X280-T15 | Türschild Edelstahl personalisiert – Herz-Punkte-Ornament 42×28 cm |
| 12700000 | TRE-V2A-42x28-D72 | hinweisschilder | TRE-V2A-8x5-D72 | GR-ES-RE-420X280-T15 | Türschild Edelstahl personalisiert – Dreieck 42×28 cm |

## Schon vorhanden

- 3100000 (TRE-V2A-7x2-D5)
- 3200000 (TRE-V2A-7x2-D26)
- 3300000 (TRE-V2A-7x2-D35)

## Offen (nicht eingetragen)

- 2000000 TRE-V2A-5x2-D6: Testeintrag „TEST-5x2-V2A_Svenja“ – übersprungen
- 6400000 TR1-V2A-9x6-D57: Bogen TR1-V2A-9x6: Größe fehlt in der Familie (Reihe edelstahl-gravur-retro1-90x60)
- 6500000 TR1-V2A-9x6-D15: Bogen TR1-V2A-9x6: Größe fehlt in der Familie (Reihe edelstahl-gravur-retro1-90x60)
- 6600000 TR2-V2A-9x6-D59: Bogen TR2-V2A-9x6: Größe fehlt in der Familie (Reihe edelstahl-gravur-retro2-91x61)
- 6700000 TR2-V2A-9x6-D6: Bogen TR2-V2A-9x6: Größe fehlt in der Familie (Reihe edelstahl-gravur-retro2-91x61)
- 6800000 TR2-V2A-9x6-D12: Bogen TR2-V2A-9x6: Größe fehlt in der Familie (Reihe edelstahl-gravur-retro2-91x61)
- 6900000 TR2-V2A-9x6-D21: Bogen TR2-V2A-9x6: Größe fehlt in der Familie (Reihe edelstahl-gravur-retro2-91x61)
- 7000000 TR2-V2A-12x8-D16: Bogen TR2-V2A-12x8: Größe fehlt in der Familie (Reihe edelstahl-gravur-retro2-91x61)
- 7100000 TR2-V2A-12x8-D54: Bogen TR2-V2A-12x8: Größe fehlt in der Familie (Reihe edelstahl-gravur-retro2-91x61)
