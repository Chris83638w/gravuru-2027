# Rechteckig ab 8x3,5 – Lieferform 2 (edelstahl-gravur-80x35)

Quelle: Bögen TRE-V2A-8x3,5, TRE-V2A-12x5,25, TRE-V2A-16x7, TRE-V2A-24x10,5 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**73 Designs**, davon 3 mit Produktionsfassung, 19 mit Themenvorschlag (unsicher), 13 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TRE-V2A-8x3,5 | GR-ES-RE-80X35-T15 | 60 | 13 | 3 | 0 |
| TRE-V2A-12x5,25 | GR-ES-RE-120X52P5-T15 | 60 | 13 | 3 | 0 |
| TRE-V2A-16x7 | GR-ES-RE-160X70-T15 | 60 | 13 | 3 | 1 |
| TRE-V2A-24x10,5 | GR-ES-RE-240X105-T15 | 73 | 0 | 0 | 0 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TRE-V2A-8x3,5-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D2 | Zwei Zeilen, versetzt | D2 Niedermeier | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D3 | Zwei Zeilen mit Trennlinie | D3 Schäfer | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D6 | Familie mit Anker | D6 Erdmann | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D7 | Familie mit Segelboot | D7 Fischer | familienschilder, namensschilder |  | 4 |  | Great Vibes |  | motiv-1 um 0.0/-0.5 mm nach innen (stand über die Kante) |
| TRE-V2A-8x3,5-D8 | Zwei Vornamen und Nachname mit Leuchtturm | D8 Meyer | familienschilder, namensschilder |  | 4 |  | Ashley | ja | Produktionsfassung auch auf TRE-V2A-12x5,25, TRE-V2A-16x7 |
| TRE-V2A-8x3,5-D9 | Leuchtturm (ohne Text) | D9 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D10 | Zwei Vornamen und Nachname mit Laubbaum | D10 Altmann | familienschilder, namensschilder |  | 4 |  | Comfortaa | ja | Produktionsfassung auch auf TRE-V2A-12x5,25, TRE-V2A-16x7 |
| TRE-V2A-8x3,5-D11 | Pusteblume (ohne Text) | D11 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D12 | Pusteblume mit Flugsamen (ohne Text) | D12 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D13 | Pusteblume mit Vogelschwarm (ohne Text) | D13 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D14 | Blumenwiese mit Pusteblume (ohne Text) | D14 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D15 | Blumenwiese (ohne Text) | D15 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D16 | Vor- und Nachname mit Rose, Serifenschrift | D16 Laura | familienschilder, namensschilder |  | 4 |  | Libre Baskerville |  |  |
| TRE-V2A-8x3,5-D17 | Familie mit Blütenranke | D17 Schneider | familienschilder, namensschilder |  | 4 |  | Italianno | ja | Produktionsfassung auch auf TRE-V2A-12x5,25, TRE-V2A-16x7 |
| TRE-V2A-8x3,5-D18 | Zwei Namen mit Pusteblume | D18 Felix Becker | familienschilder, namensschilder |  | 4 |  | Allura |  |  |
| TRE-V2A-8x3,5-D19 | Herzlich Willkommen bei Vor- und Nachname mit Rose | D19 Ursel Mayer | familienschilder, namensschilder, willkommensschilder |  | 4 |  | Bellefair, Great Vibes |  |  |
| TRE-V2A-8x3,5-D20 | Lebensbaum (ohne Text) | D20 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D21 | Familie mit Sonne und Spruch | D21 Familie Lehmann | familienschilder, namensschilder |  | 4 |  | Comic Sans MS, Daniel |  | Schrift ohne Datei im Katalog: Comic Sans MS |
| TRE-V2A-8x3,5-D22 | Familie mit Haus-Skizze, Serifenschrift | D22 Familie | familienschilder, namensschilder |  | 4 |  | Libre Baskerville |  |  |
| TRE-V2A-8x3,5-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 4 |  | Rochester |  |  |
| TRE-V2A-8x3,5-D24 | Familie mit Haus und Herz | D24 Familie Hellwig | familienschilder, namensschilder |  | 4 |  | Homage |  |  |
| TRE-V2A-8x3,5-D25 | Hier wohnt Familie mit Haus und Herz | D25 Goldmann | familienschilder, namensschilder |  | 4 |  | Allura, Cinzel |  |  |
| TRE-V2A-8x3,5-D26 | Vor- und Nachname mit Glocke | D26 Zimmermann | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D27 | Zwei Vornamen und Nachname mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D28 | Vor- und Nachname mit Fußball | D28 Schulze | familienschilder, namensschilder |  | 4 |  | Michroma |  |  |
| TRE-V2A-8x3,5-D29 | Familie mit Hundewelpe und Hundename | D29 Familie Kuhlmann | familienschilder, namensschilder, hundeschilder |  | 4 |  | Ashley, Raleway |  |  |
| TRE-V2A-8x3,5-D30 | Familie mit Hundekopf und Hundename | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 4 |  | Raleway |  |  |
| TRE-V2A-8x3,5-D31 | Zuhause von Familie mit Hund-Silhouette | D31 Familie Fischer | familienschilder, namensschilder, hundeschilder |  | 4 |  | Ashley, Cinzel |  |  |
| TRE-V2A-8x3,5-D32 | Familie mit Pfote und Hundename, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 4 |  | Homage, Michroma |  |  |
| TRE-V2A-8x3,5-D33 | Familie mit Pfoten und Hundename | D33 Familie Wegner | familienschilder, namensschilder, hundeschilder |  | 4 |  | Raleway, Sweetie |  |  |
| TRE-V2A-8x3,5-D34 | Willkommen bei Familie mit Katze und Katzenname | D34 Willkommen bei | familienschilder, namensschilder, katzenschilder, willkommensschilder |  | 4 |  | Allura, Libre Baskerville |  |  |
| TRE-V2A-8x3,5-D35 | Zwei Vornamen und Nachname mit Katze und Katzenname | D35 mit Oskar | familienschilder, namensschilder, katzenschilder |  | 4 |  | Michroma, Sweetie |  |  |
| TRE-V2A-8x3,5-D36 | Schnörkel-Ornament (ohne Text) | D36 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D37 | Vor- und Nachname mit Unendlichkeitszeichen | D37 Hannah | familienschilder, namensschilder |  | 4 |  | Great Vibes |  |  |
| TRE-V2A-8x3,5-D38 | Zwei Namen mit Herzen, Schreibschrift | D38 Olivia Sander | familienschilder, namensschilder | hochzeitsschilder | 4 |  | Italianno |  |  |
| TRE-V2A-8x3,5-D39 | Herzlich Willkommen bei Familie mit Schnörkel-Herz | D39 Familie Wolf | familienschilder, namensschilder, willkommensschilder |  | 4 |  | Great Vibes |  |  |
| TRE-V2A-8x3,5-D40 | Willkommen bei Vor- und Nachname mit Eule | D40 Dominik Schröder | familienschilder, namensschilder, willkommensschilder |  | 4 |  | Dancing Script |  |  |
| TRE-V2A-8x3,5-D41 | Familie mit Kolibri | D41 Vogel | familienschilder, namensschilder |  | 4 |  | Ashley, Raleway |  |  |
| TRE-V2A-8x3,5-D42 | Vor- und Nachname mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 4 |  | Homage, Montserrat Light |  |  |
| TRE-V2A-8x3,5-D43 | Familie mit Taubenpaar, Serifenschrift | D43 Familie Krone | familienschilder, namensschilder |  | 4 |  | Libre Baskerville |  |  |
| TRE-V2A-8x3,5-D44 | Zwei Vornamen und Nachname mit Vogelpaar im Herz | D44 Ruprecht | familienschilder, namensschilder | hochzeitsschilder | 4 |  | Allura, Raleway |  |  |
| TRE-V2A-8x3,5-D45 | Hier wohnt Vor- und Nachname mit Vogel | D45 König | familienschilder, namensschilder |  | 4 |  | Cinzel, Rochester |  |  |
| TRE-V2A-8x3,5-D46 | Familie mit Vogelpaar auf Zweig | D46 Vogel | familienschilder, namensschilder |  | 4 |  | Ashley, Raleway |  |  |
| TRE-V2A-8x3,5-D47 | Vogel auf Zweig (ohne Text) | D47 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D48 | Familie mit Schmetterlingen | D48 Schumacher | familienschilder, namensschilder |  | 4 |  | Allura, Raleway |  |  |
| TRE-V2A-8x3,5-D49 | Zwei Eulen auf Zweig (ohne Text) | D49 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D50 | Drei Eulen auf Zweig (ohne Text) | D50 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D51 | Vier Eulen auf Zweig (ohne Text) | D51 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 4 |  | Ashley |  |  |
| TRE-V2A-8x3,5-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 4 |  | Ashley, Montserrat Light |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x3,5-D54 | Familie mit Lilie, Serifenschrift | D54 Kampmann | familienschilder, namensschilder |  | 4 |  | Libre Baskerville |  |  |
| TRE-V2A-8x3,5-D55 | Hier wohnt Familie mit Schnörkel und Herz | D55 Hier wohnt | familienschilder, namensschilder |  | 4 |  | Allura, Montserrat Light |  |  |
| TRE-V2A-8x3,5-D56 | Familie mit Schnörkel-Ornament | D56 Familie | familienschilder, namensschilder |  | 4 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TRE-V2A-8x3,5-D57 | Familie mit Herz-Ranken-Ornament | D57 Pielstädt | familienschilder, namensschilder |  | 4 |  | Cinzel, Italianno |  | Text „Pielstädt“ um 0.0/-3.5 mm nach innen (Textkasten stand über) |
| TRE-V2A-8x3,5-D58 | Familie mit Herzranke | D58 Feldkamp | familienschilder, namensschilder |  | 4 |  | Comfortaa |  |  |
| TRE-V2A-8x3,5-D59 | Zwei Vornamen und Nachname mit Rosen-Ornament | D59 Münstermann | familienschilder, namensschilder |  | 4 |  | Italianno |  |  |
| TRE-V2A-8x3,5-D60 | Familie mit Ornament und Spruch | D60 Familie Hampel | familienschilder, namensschilder, willkommensschilder |  | 4 |  | Allura, Cinzel |  |  |
| TRE-V2A-8x3,5-D61 | Zweige mit Herz (ohne Text) | D61 | familienschilder | namensschilder | 1 | GR-ES-RE-80X35-T15, GR-ES-RE-120X52P5-T15, GR-ES-RE-160X70-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x3,5-D62 | Familie mit Schlüssel und Linie | D62 Schielmann | familienschilder, namensschilder |  | 4 |  | Fineliner Script, Raleway |  | Schrift ohne Datei im Katalog: Fineliner Script |
| TRE-V2A-8x3,5-D63 | Familie mit Wimpelkette, Serifenschrift | D63 Familie Poller | familienschilder, namensschilder |  | 4 |  | Libre Baskerville |  |  |
| TRE-V2A-8x3,5-D64 | Familie mit Eck-Ornamenten, Serifenschrift | D64 Schötter | familienschilder, namensschilder |  | 4 |  | Cinzel |  |  |
| TRE-V2A-8x3,5-D65 | Hier wohnt Familie mit Vornamen und Herzen | D65 Familie Wegner | familienschilder, namensschilder |  | 4 |  | Homage, Raleway |  |  |
| TRE-V2A-8x3,5-D66 | Mr. & Mrs. mit Herzen und Nachname | D66 Westermann | familienschilder, namensschilder, hochzeitsschilder |  | 4 |  | Raleway |  |  |
| TRE-V2A-8x3,5-D67 | Initialen mit Ringen und Nachname | D67 Trautmann | familienschilder, namensschilder, hochzeitsschilder |  | 4 |  | Antic Slab, Great Vibes |  |  |
| TRE-V2A-8x3,5-D68 | Familie mit Pfeil nach links | D68 Familie Reimer | familienschilder, namensschilder | hinweisschilder | 4 |  | Michroma |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x3,5-D69 | Familie mit Pfeil nach rechts, Serifenschrift | D69 Maier | familienschilder, namensschilder | hinweisschilder | 4 |  | Libre Baskerville |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x3,5-D70 | Zwei Vornamen und Nachname mit Pfeil nach oben | D70 Mükmann | familienschilder, namensschilder | hinweisschilder | 4 |  | Cinzel, Italianno |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x3,5-D71 | Familie mit Pfeil nach unten | D71 Kleester | familienschilder, namensschilder | hinweisschilder | 4 |  | Comfortaa |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x3,5-D72 | Achtung Videoüberwachung mit Familie | D72 Familie | hinweisschilder, familienschilder |  | 4 |  | Antic Slab, Cinzel |  |  |
| TRE-V2A-8x3,5-D73 | Kein Eingang mit STOP | D73 Kein | hinweisschilder |  | 4 |  | Lato, Libre Baskerville |  |  |

## Abweichende Doppel (prüfen)

| Bogen | Doppel | von | grün |
| --- | --- | --- | --- |
| TRE-V2A-16x7 | TRE-V2A-16x7-D18-DOPPELT2 | TRE-V2A-16x7-D18 | ja |

## Schriften ohne Datei im Katalog

- Comic Sans MS: 1 Designs (TRE-V2A-8x3,5-D21)
- Fineliner Script: 2 Designs (TRE-V2A-8x3,5-D56, TRE-V2A-8x3,5-D62)
