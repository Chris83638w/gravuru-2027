# Design-Master – verbindlich für alle KIs und alle Aufträge

Entscheidung Chris, 29.10.2026. Gilt für **jede** KI (Claude, ChatGPT/Codex, Astra, Kollegen-Accounts) und für **jeden** heutigen und künftigen Design-Auftrag: Themen-Designs, Umrechnung auf neue Größen, Hochformate, Funkklingeln, Türschilder, Hausnummern, Gedenktafeln, Geschenkartikel.
Technische Lieferregeln bleiben unverändert (Lieferform 2 in [README.md](README.md), Schriften in [../schriften/README.md](../schriften/README.md)). Dieser Master regelt die **Gestaltung**. Jeder Auftrag verweist hierauf; ein Auftrag darf ihn nur mit ausdrücklichem Satz von Chris lockern.

## 1. Vorlage zuerst

1. Vor jedem Design die passende **Katalog-Vorlage** suchen: gleiche Kennung/D-Nummer, gleiches Thema oder Bestandsdesign derselben Linie (`designs/`, `quellen/`, Originale vom Server).
2. **Passt die Vorlage zur Zielgröße/Form** (gleiche Formatreihe, gleiches Seitenverhältnis): **1:1 übernehmen** – Schriften, Motiv, Anordnung und Größenverhältnisse bleiben.
3. **Passt sie nicht** (andere Form, Hochformat, anderes Seitenverhältnis): Vorlage als **sehr starke Referenz** – gleiche Schriften, gleiches Motiv, gleiche Stimmung; nur die Anordnung wird für die neue Fläche neu proportioniert.
4. Gibt es eine Vorlage, wird für dieses Design nicht frei neu erfunden. Nur ohne jede Vorlage frei gestalten; dann im Bericht „ohne Vorlage“ angeben.
5. **Zusätzlich je Serie bzw. Auftrag immer 2–3 ganz neue Designs**, die es im Katalog noch nicht gibt (siehe Abschnitt 5).

## 2. Schriften

1. Auswahl aus **allen 84 freigegebenen Schriften** in `schriften/schriften.json`. Die Themen-Sets in `schriften/sets.json` sind Anregung, keine Grenze. Keine Schrift außerhalb der Liste, keine Schriftdateien ohne Lizenz.
2. **1 bis 3 Schriften je Design, je nach Textmenge:** kurze Texte (Hausnummer, ein Name) 1–2; Name plus Zusatz 2; viel Text (Gedenktafel, Hinweisschild) bis 3.
3. **Variieren:** Innerhalb einer Serie dürfen nicht alle Designs dieselbe Schrift haben. Eine neutrale Standardschrift (z. B. Lato) nur, wenn die Vorlage sie hat oder sie bewusst gewählt ist – nie als Voreinstellung für alles.
4. Passend zum Thema und auf der echten Plattengröße lesbar (Strichstärke, Mindesthöhe der Familie). Text bleibt Text. Fehlt eine Schrift der Vorlage: nur die Ersatztabelle in `schriften/README.md` anwenden, sonst „Schrift fehlt“ markieren – nie still ersetzen.
5. **Arial ist keine gewollte Vorlagenschrift.** Sie ist die Corel-Voreinstellung und steckt in 153 von 177 Hausnummern-Bestandsdesigns (ähnlich in anderen Linien). Wo die Vorlage Arial hat, wählt die KI eine passende Schrift aus den 84 – nicht pauschal Lato. Alle anderen Vorlagenschriften bleiben.

## 3. Motiv

1. Das Motiv der Vorlage **geht nie verloren**: nicht weglassen, nicht austauschen, nicht verzerren (Seitenverhältnis fest), nicht abschneiden.
2. Größe **nach Sicht** – so, dass es zum Gesamtbild passt; Schutzzone zu Rand und Bohrlöchern laut Familie einhalten.
3. **Passen Motiv und Text nicht zusammen auf die Fläche, bleibt das Motiv.** Der Text wird angepasst: umbrechen, umstellen, Zeilen tauschen, kleiner bis zur Mindesthöhe der Familie.
4. Motive einfarbig, aus der Vorlage oder der Bibliothek `motive/`; neue Motive nur für die neuen Designs aus Abschnitt 5.

## 4. Anordnung und Gesamtbild

1. **Nicht automatisch mittig.** Erlaubt ist jede Anordnung: Motiv links oder rechts neben dem Text, darüber oder darunter, in einer Ecke, als Rahmen oder hinter dem Text (Text bleibt klar lesbar).
2. Ziel ist ein **schönes, ausgewogenes Gesamtbild**: klare Rangfolge (Name/Nummer zuerst), gleichmäßiger Weißraum, gemeinsame Ausrichtungsachse, optische statt rechnerischer Mitte.
3. **Hochformat** bekommt eine eigene Anordnung – kein gedrehtes oder gequetschtes Querformat.
4. Eine Serie wirkt als Familie, aber nicht als Kopie: Anordnung, Schrift und Motivplatz dürfen von Design zu Design wechseln.

## 5. Eigene neue Designs und Motive

1. Je Serie bzw. Auftrag erstellt die KI **2–3 ganz neue Designs** ohne Vorlage – eigene Idee, passend zum Thema, nach allen Regeln dieses Masters (Schriften, Motiv, Gesamtbild). Im Bericht „neu“ statt „1:1/Referenz“.
2. Dafür neu gezeichnete **Motive** (Vektor, einfarbig) liegen im Design-Ordner (Lieferform 2) **und** zusätzlich im Katalog unter [`motive-eigene/`](../motive-eigene/README.md) mit Eintrag in `motive-eigene.json`.
3. **Nicht automatisch im Kundenkonfi:** Der Konfigurator bietet als einzelnes Motiv nur an, was in `motive/motive.json` steht. Neue Motive kommen dort **nie** von selbst hinein; Übernahme in die Kundenbibliothek nur auf ausdrücklichen Satz von Chris je Motiv.
4. Die neuen Designs selbst gehen wie alle anderen über Kontaktbogen und Chris' Freigabe.

## 6. Abnahme und Bericht

1. Je Serie ein **Kontaktbogen mit Screenshots 1:1 aus dem echten Konfigurator**, jeweils die Vorlage daneben. Ohne Kontaktbogen keine Abnahme.
2. Je Design im Bericht: Kennung → Vorlage (Pfad/Kennung oder „ohne Vorlage“), Modus **1:1 / Referenz / neu**, Schriften, Motiv-ID (bei neuen Motiven die Kennung aus `motive-eigene.json`), begründete Abweichungen.
3. Die Freigabe (`design.json.freigabe`) setzt nur Chris.
4. Der Operator prüft jeden Kontaktbogen gegen diesen Master, bevor er an Chris geht; Verstöße gehen mit Screenshot zurück an die KI.
