(()=>{
 if(window.__gravuruLoader)return;window.__gravuruLoader=true;
 let pending;
 function load(){
  const elements=[...document.querySelectorAll('gravuru-configurator[data-engine-src]')];
  if(!elements.length||customElements.get('gravuru-configurator'))return;
  if(!pending){
   pending=new Promise((resolve,reject)=>{
    const script=document.createElement('script');script.src=elements[0].dataset.engineSrc;
    script.onload=resolve;script.onerror=reject;document.head.append(script);
   }).catch(()=>{
    pending=null;
    for(const element of elements){const note=document.createElement('p');note.textContent='Der Konfigurator konnte nicht geladen werden. Bitte lade die Seite erneut.';note.setAttribute('role','alert');element.append(note);}
   });
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',load,{once:true});else load();
 document.addEventListener('shopify:section:load',load);
})();

