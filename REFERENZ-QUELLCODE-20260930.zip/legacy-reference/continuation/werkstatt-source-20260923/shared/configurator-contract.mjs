import {validateStainlessAssignment} from './stainless-contract.mjs';
export const PROFILES = {edelstahl:'Edelstahl',schiefer:'Schiefer',holz:'Holz',druck:'Druck'};
export const numericId = value => String(value).split('/').pop();
export function validateAssignment(value, product, preset) {
  if(value?.schemaVersion===2)return validateStainlessAssignment(value,product);
  if (!value || value.schemaVersion !== 1) throw Error('Die Produktzuordnung hat ein unbekanntes Format.');
  if (value.productId !== product.id || value.productHandle !== product.handle) throw Error('Die Zuordnung gehört zu einem anderen Produkt. Bitte neu laden.');
  if (!Object.hasOwn(PROFILES, value.profileKey)) throw Error('Bitte ein gültiges Materialprofil wählen.');
  if (value.catalogRevision !== preset.revision) throw Error('Der Designkatalog hat sich geändert. Bitte die Zuordnung neu laden.');
  if (typeof value.enabled !== 'boolean' || typeof value.orderEnabled !== 'boolean') throw Error('Die Aktivierung ist ungültig.');
  for (const key of ['widthMm','heightMm']) if (!Number.isFinite(value[key]) || value[key] < 10 || value[key] > 600) throw Error('Breite und Höhe müssen zwischen 10 und 600 mm liegen.');
  if (!Number.isFinite(value.cornerRadiusMm) || value.cornerRadiusMm < 0 || value.cornerRadiusMm > Math.min(value.widthMm,value.heightMm)/2) throw Error('Der Eckenradius passt nicht zu den Maßen.');
  if (!Array.isArray(value.designIds) || !value.designIds.length || new Set(value.designIds).size !== value.designIds.length || value.designIds.some(id => !preset.designs.some(d => d.id === id))) throw Error('Bitte mindestens eine gültige Designvorlage auswählen.');
  if (!value.variantMap || Array.isArray(value.variantMap) || typeof value.variantMap !== 'object') throw Error('Die Varianten müssen zugeordnet werden.');
  if (Object.keys(value.variantMap).some(sku => !preset.variants.some(v => v.sku === sku))) throw Error('Unbekannte Variantenregel.');
  const actualIds = new Set(product.variants.map(v => numericId(v.id)));
  const mapped = Object.values(value.variantMap).filter(Boolean);
  if (mapped.some(id => !actualIds.has(id)) || new Set(mapped).size !== mapped.length) throw Error('Jede Shopify-Variante darf nur einmal zugeordnet werden und muss zu diesem Produkt gehören.');
  const holesUsed = preset.variants.some(v => v.holes && value.variantMap[v.sku]);
  if (holesUsed && (!Number.isFinite(value.holeDiameterMm) || value.holeDiameterMm <= 0 || !Number.isFinite(value.holeEdgeMm) || value.holeEdgeMm < value.holeDiameterMm/2 || value.holeEdgeMm + value.holeDiameterMm/2 > Math.min(value.widthMm,value.heightMm)/2)) throw Error('Bitte passende Bohrlochmaße und Randabstände angeben.');
  if (value.orderEnabled && (!value.enabled || !value.productionConfirmed || preset.variants.some(v => !value.variantMap[v.sku]))) throw Error('Bestellungen benötigen eine aktive Zuordnung, bestätigte Produktionsmaße und alle vier Variantenregeln.');
  return value;
}
