# Abgerundete Ecken ab 8x5 – Lieferform 2 (edelstahl-gravur-ab-80x53)

Quelle: Bögen TAE-V2A-8x5, TAE-V2A-9x6, TAE-V2A-12x8, TAE-V2A-15x10, TAE-V2A-18x12, TAE-V2A-30x20 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**73 Designs**, davon 2 mit Produktionsfassung, 10 mit Themenvorschlag (unsicher), 6 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TAE-V2A-8x5 | GR-ES-AB-80X53P3-T15 | 69 | 4 | 2 | 1 |
| TAE-V2A-9x6 | GR-ES-AB-90X60-T15 | 69 | 4 | 2 | 2 |
| TAE-V2A-12x8 | GR-ES-AB-120X80-T15 | 73 | 0 | 2 | 2 |
| TAE-V2A-15x10 | GR-ES-AB-150X100-T15 | 73 | 0 | 2 | 2 |
| TAE-V2A-18x12 | GR-ES-AB-180X120-T15 | 73 | 0 | 2 | 2 |
| TAE-V2A-30x20 | GR-ES-AB-300X200-T15 | 69 | 4 | 1 | 0 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TAE-V2A-8x5-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D2 | Zwei Zeilen, versetzt | D2 Niedermeier | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D3 | Zwei Zeilen mit Trennlinie | D3 Schäfer | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D6 | Familie mit Anker | D6 Erdmann | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D7 | Hier wohnt Familie mit Segelboot | D7 Fischer | familienschilder, namensschilder |  | 6 |  | Great Vibes, Montserrat Light |  |  |
| TAE-V2A-8x5-D8 | Zwei Vornamen und Nachname mit Leuchtturm und Adresse | D8 Meyer | familienschilder, namensschilder |  | 6 |  | Ashley, Cinzel, Raleway | ja | Beispieltext enthält eine Adresse (drittes Textfeld); „Heimathafen …“: Zeilenabstand 5.2 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Produktionsfassung: „Heimathafen …“: Zeilenabstand 5.2 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Produktionsfassung auch auf TAE-V2A-9x6, TAE-V2A-12x8, TAE-V2A-15x10, TAE-V2A-18x12 |
| TAE-V2A-8x5-D9 | Vor- und Nachname mit Leuchtturm | D9 Groner | familienschilder, namensschilder |  | 6 |  | Homage, Raleway |  |  |
| TAE-V2A-8x5-D10 | Zwei Vornamen und Nachname mit Laubbaum und Spruch | D10 Altmann | familienschilder, namensschilder |  | 6 |  | Comfortaa, Homage |  |  |
| TAE-V2A-8x5-D11 | Vor- und Nachname mit Pusteblume, Handschrift | D11 Bellini | familienschilder, namensschilder |  | 6 |  | Sweetie |  |  |
| TAE-V2A-8x5-D12 | Herzlich Willkommen bei Familie mit Pusteblume | D12 Bohlmann | familienschilder, namensschilder, willkommensschilder |  | 6 |  | Homage, Raleway |  |  |
| TAE-V2A-8x5-D13 | Familie mit Pusteblume, Serifenschrift | D13 Neumann | familienschilder, namensschilder |  | 6 |  | Cinzel, Homage |  |  |
| TAE-V2A-8x5-D14 | Familie mit Blumenwiese und Adresse | D14 Wagner | familienschilder, namensschilder |  | 6 |  | Ashley, Libre Baskerville |  | Beispieltext enthält eine Adresse (drittes Textfeld) |
| TAE-V2A-8x5-D15 | Herzlich Willkommen bei Familie mit Blumenwiese | D15 Familie Kuhlmann | familienschilder, namensschilder, willkommensschilder |  | 6 |  | Homage, Raleway | ja | Produktionsfassung auch auf TAE-V2A-9x6, TAE-V2A-12x8, TAE-V2A-15x10, TAE-V2A-18x12, TAE-V2A-30x20 |
| TAE-V2A-8x5-D16 | Willkommen bei Vor- und Nachname mit Rose | D16 Laura | familienschilder, namensschilder, willkommensschilder |  | 6 |  | Libre Baskerville |  |  |
| TAE-V2A-8x5-D17 | Hier wohnt Familie mit Blütenranke | D17 Schneider | familienschilder, namensschilder |  | 6 |  | Cinzel, Italianno |  |  |
| TAE-V2A-8x5-D18 | Zwei Namen mit Pusteblume | D18 Felix Becker | familienschilder, namensschilder |  | 6 |  | Allura |  |  |
| TAE-V2A-8x5-D19 | Herzlich Willkommen bei Vor- und Nachname mit Rose | D19 Ursel Mayer | familienschilder, namensschilder, willkommensschilder |  | 6 |  | Bellefair, Great Vibes |  |  |
| TAE-V2A-8x5-D20 | Familie mit Lebensbaum, Serifenschrift | D20 Familie | familienschilder, namensschilder |  | 6 |  | Libre Baskerville |  |  |
| TAE-V2A-8x5-D21 | Familie mit Sonne, Spruch und Vornamen | D21 Familie Lehmann | familienschilder, namensschilder |  | 6 |  | Comic Sans MS, Daniel |  | „Hier leben, …“: Zeilenabstand 7.0 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Schrift ohne Datei im Katalog: Comic Sans MS; Schrift ohne Datei im Katalog: Comic Sans MS |
| TAE-V2A-8x5-D22 | Familie mit Haus-Skizze und Spruch | D22 Schmittberger | familienschilder, namensschilder |  | 6 |  | Dancing Script, Libre Baskerville |  |  |
| TAE-V2A-8x5-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 6 |  | Rochester |  |  |
| TAE-V2A-8x5-D24 | Zuhause von Familie mit Haus und Herz | D24 Zuhause von | familienschilder, namensschilder |  | 6 |  | Homage, Raleway |  |  |
| TAE-V2A-8x5-D25 | Hier wohnt Familie mit Haus, Herz und Gründungsjahr | D25 Goldmann | familienschilder, namensschilder |  | 6 |  | Allura, Cinzel |  |  |
| TAE-V2A-8x5-D26 | Vor- und Nachname mit Glocke | D26 Zimmermann | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D27 | Zwei Vornamen und Nachname mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D28 | Vor- und Nachname mit Fußball | D28 Schulze | familienschilder, namensschilder |  | 6 |  | Michroma |  |  |
| TAE-V2A-8x5-D29 | Familie mit Hundewelpe und Hundename, Serifenschrift | D29 Trautmann | familienschilder, namensschilder, hundeschilder |  | 6 |  | Libre Baskerville |  |  |
| TAE-V2A-8x5-D30 | Familie mit Hundekopf und Hundename | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 6 |  | Raleway |  |  |
| TAE-V2A-8x5-D31 | Zuhause von Familie mit Hund-Silhouette | D31 Familie Fischer | familienschilder, namensschilder, hundeschilder |  | 6 |  | Ashley, Cinzel |  |  |
| TAE-V2A-8x5-D32 | Familie mit Pfote und Hundename, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 6 |  | Homage, Michroma |  |  |
| TAE-V2A-8x5-D33 | Familie mit Pfoten und Hundename | D33 mit Lucky | familienschilder, namensschilder, hundeschilder |  | 6 |  | Raleway, Sweetie |  |  |
| TAE-V2A-8x5-D34 | Willkommen bei Familie mit Katze und Katzenname | D34 Albrecht | familienschilder, namensschilder, katzenschilder, willkommensschilder |  | 6 |  | Ashley, Libre Baskerville |  |  |
| TAE-V2A-8x5-D35 | Hier leben – zwei Vornamen und Nachname mit Katze und Katzenname | D35 mit Oskar | familienschilder, namensschilder, katzenschilder |  | 6 |  | Michroma, Sweetie |  |  |
| TAE-V2A-8x5-D36 | Schnörkel-Ornament (ohne Text) | D36 | familienschilder | namensschilder | 3 | GR-ES-AB-80X53P3-T15, GR-ES-AB-90X60-T15, GR-ES-AB-300X200-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TAE-V2A-8x5-D37 | Vor- und Nachname mit Unendlichkeitszeichen | D37 Hannah | familienschilder, namensschilder |  | 6 |  | Great Vibes |  |  |
| TAE-V2A-8x5-D38 | Zwei Namen mit Herzen, Schreibschrift | D38 Olivia Sander | familienschilder, namensschilder | hochzeitsschilder | 6 |  | Italianno |  |  |
| TAE-V2A-8x5-D39 | Herzlich Willkommen bei Familie mit Schnörkel-Herz | D39 Herzlich Willkommen | familienschilder, namensschilder, willkommensschilder |  | 6 |  | Great Vibes |  |  |
| TAE-V2A-8x5-D40 | Willkommen bei Vor- und Nachname mit Eule | D40 Willkommen | familienschilder, namensschilder, willkommensschilder |  | 6 |  | Dancing Script |  |  |
| TAE-V2A-8x5-D41 | Familie mit Kolibri | D41 Vogel | familienschilder, namensschilder |  | 6 |  | Ashley, Raleway |  |  |
| TAE-V2A-8x5-D42 | Vor- und Nachname mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 6 |  | Homage, Montserrat Light |  |  |
| TAE-V2A-8x5-D43 | Familie mit Taubenpaar, Serifenschrift | D43 Familie Krone | familienschilder, namensschilder |  | 6 |  | Libre Baskerville |  |  |
| TAE-V2A-8x5-D44 | Zwei Vornamen und Nachname mit Vogelpaar im Herz | D44 Ruprecht | familienschilder, namensschilder | hochzeitsschilder | 6 |  | Allura, Raleway |  |  |
| TAE-V2A-8x5-D45 | Hier wohnt Vor- und Nachname mit Vogel | D45 König | familienschilder, namensschilder |  | 6 |  | Cinzel, Rochester |  |  |
| TAE-V2A-8x5-D46 | Familie mit Vogelpaar auf Zweig | D46 Vogel | familienschilder, namensschilder |  | 6 |  | Ashley, Raleway |  |  |
| TAE-V2A-8x5-D47 | Herzlich Willkommen bei Vor- und Nachname mit Vogel auf Zweig | D47 Carla | familienschilder, namensschilder, willkommensschilder |  | 6 |  | Sweetie |  |  |
| TAE-V2A-8x5-D48 | Familie mit Schmetterlingen | D48 Schumacher | familienschilder, namensschilder |  | 6 |  | Allura, Raleway |  |  |
| TAE-V2A-8x5-D49 | Zwei Eulen auf Zweig (ohne Text) | D49 | familienschilder | namensschilder | 3 | GR-ES-AB-80X53P3-T15, GR-ES-AB-90X60-T15, GR-ES-AB-300X200-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TAE-V2A-8x5-D50 | Drei Eulen auf Zweig (ohne Text) | D50 | familienschilder | namensschilder | 3 | GR-ES-AB-80X53P3-T15, GR-ES-AB-90X60-T15, GR-ES-AB-300X200-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TAE-V2A-8x5-D51 | Vier Eulen auf Zweig (ohne Text) | D51 | familienschilder | namensschilder | 3 | GR-ES-AB-80X53P3-T15, GR-ES-AB-90X60-T15, GR-ES-AB-300X200-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TAE-V2A-8x5-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 6 |  | Ashley |  |  |
| TAE-V2A-8x5-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 6 |  | Ashley, Montserrat Light |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TAE-V2A-8x5-D54 | Familie mit Lilie, Serifenschrift | D54 Kampmann | familienschilder, namensschilder |  | 6 |  | Libre Baskerville |  |  |
| TAE-V2A-8x5-D55 | Hier wohnt Familie mit Schnörkel und Herz | D55 Hier wohnt | familienschilder, namensschilder |  | 6 |  | Allura, Montserrat Light |  |  |
| TAE-V2A-8x5-D56 | Familie mit Schnörkel-Ornament | D56 Lachtermann | familienschilder, namensschilder |  | 6 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TAE-V2A-8x5-D57 | Familie mit Herz-Ranken-Ornament | D57 Pielstädt | familienschilder, namensschilder |  | 6 |  | Cinzel, Italianno |  |  |
| TAE-V2A-8x5-D58 | Familie mit Herzranke und Spruch | D58 Feldkamp | familienschilder, namensschilder |  | 6 |  | Comfortaa, Italianno |  |  |
| TAE-V2A-8x5-D59 | Familie mit Rosen-Ornament, Serifenschrift | D59 Landhagen | familienschilder, namensschilder |  | 6 |  | Libre Baskerville |  |  |
| TAE-V2A-8x5-D60 | Familie mit Ornament und Spruch | D60 Willkommen bei uns | familienschilder, namensschilder, willkommensschilder |  | 6 |  | Allura, Cinzel |  |  |
| TAE-V2A-8x5-D61 | Zwei Vornamen und Nachname mit Zweigen und Herz | D61 Kampmann | familienschilder, namensschilder |  | 6 |  | Montserrat Light, Sweetie |  |  |
| TAE-V2A-8x5-D62 | Familie mit Schlüssel und Linie | D62 Schielmann | familienschilder, namensschilder |  | 6 |  | Fineliner Script, Raleway |  | Schrift ohne Datei im Katalog: Fineliner Script |
| TAE-V2A-8x5-D63 | Familie mit Wimpelkette, Serifenschrift | D63 Poller | familienschilder, namensschilder |  | 6 |  | Libre Baskerville |  |  |
| TAE-V2A-8x5-D64 | Familie mit Eck-Ornamenten, Serifenschrift | D64 Schötter | familienschilder, namensschilder |  | 6 |  | Cinzel |  |  |
| TAE-V2A-8x5-D65 | Hier wohnt Familie mit Vornamen und Herzen | D65 Familie Wegner | familienschilder, namensschilder |  | 6 |  | Homage, Raleway |  |  |
| TAE-V2A-8x5-D66 | Mr. & Mrs. mit Herzen und Nachname | D66 Westermann | familienschilder, namensschilder, hochzeitsschilder |  | 6 |  | Raleway |  |  |
| TAE-V2A-8x5-D67 | Initialen mit Ringen und Nachname | D67 Trautmann | familienschilder, namensschilder, hochzeitsschilder |  | 6 |  | Antic Slab, Great Vibes |  |  |
| TAE-V2A-8x5-D68 | Familie mit Pfeil nach links | D68 Familie | familienschilder, namensschilder | hinweisschilder | 6 |  | Michroma |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TAE-V2A-8x5-D69 | Familie mit Pfeil nach rechts, Serifenschrift | D69 Maier | familienschilder, namensschilder | hinweisschilder | 6 |  | Libre Baskerville |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TAE-V2A-8x5-D70 | Zwei Vornamen und Nachname mit Pfeil nach oben | D70 Mükmann | familienschilder, namensschilder | hinweisschilder | 6 |  | Cinzel, Italianno |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TAE-V2A-8x5-D71 | Familie mit Pfeil nach unten | D71 Kleester | familienschilder, namensschilder | hinweisschilder | 6 |  | Comfortaa |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TAE-V2A-8x5-D72 | Achtung Videoüberwachung mit Familie | D72 Familie Hübner | hinweisschilder, familienschilder |  | 6 |  | Cinzel, Lato |  |  |
| TAE-V2A-8x5-D73 | Kein Eingang mit STOP | D73 Kein | hinweisschilder |  | 6 |  | Lato, Libre Baskerville |  |  |

## Abweichende Doppel (prüfen)

| Bogen | Doppel | von | grün |
| --- | --- | --- | --- |
| TAE-V2A-8x5 | TAE-V2A-8x5-D14-DOPPELT2 | TAE-V2A-8x5-D14 | ja |
| TAE-V2A-9x6 | TRE-V2A-9x6-D18-DOPPELT2 | TRE-V2A-9x6-D18 | ja |
| TAE-V2A-9x6 | TRE-V2A-9x6-D14-DOPPELT2 | TRE-V2A-9x6-D14 | ja |
| TAE-V2A-12x8 | TAE-V2A-12x8-D18-DOPPELT2 | TAE-V2A-12x8-D18 | ja |
| TAE-V2A-12x8 | TAE-V2A-12x8-D14-DOPPELT2 | TAE-V2A-12x8-D14 | ja |
| TAE-V2A-15x10 | TAE-V2A-15x10-D18-DOPPELT2 | TAE-V2A-15x10-D18 | ja |
| TAE-V2A-15x10 | TAE-V2A-15x10-D14-DOPPELT2 | TAE-V2A-15x10-D14 | ja |
| TAE-V2A-18x12 | TAE-V2A-18x12-D18-DOPPELT2 | TAE-V2A-18x12-D18 | ja |
| TAE-V2A-18x12 | TAE-V2A-18x12-D14-DOPPELT2 | TAE-V2A-18x12-D14 | ja |

## Schriften ohne Datei im Katalog

- Comic Sans MS: 1 Designs (TAE-V2A-8x5-D21)
- Fineliner Script: 2 Designs (TAE-V2A-8x5-D56, TAE-V2A-8x5-D62)
