import fs from 'node:fs';
import path from 'node:path';
import {REPO,readJson,writeJson,validateJob,buildPackage,hash,quote} from './lib/core.mjs';
import {adminClient,plan,apply,OPS,productByHandle,verifyListing} from './lib/shopify.mjs';
const [command,file,...args]=process.argv.slice(2);
const flags=Object.fromEntries(args.map(a=>a.replace(/^--/,'').split('=')));
try{
 if(command==='operations'){console.log(JSON.stringify(OPS,null,2));process.exit(0);}
 if(command==='help'||!command){console.log('validate <job.json> | build <job.json> --out=<NEUER Ordner> | quote <job.json> | plan <job.json> --out=<plan.json> | apply <job.json> --plan=<plan.json> --authorized --journal=<journal.json> | verify <job.json>');process.exit(0);}
 const job=readJson(file),root=flags.root?path.resolve(flags.root):REPO;
 const report=validateJob(job,root);
 if(command==='validate'){console.log(JSON.stringify(report,null,2));process.exitCode=report.ok?0:2;}
 else {
   if(!report.ok)throw Error(report.errors.map(e=>e.code+': '+e.message).join('\n'));
   if(command==='build'){
     if(!flags.out||fs.existsSync(flags.out))throw Error('Neuen leeren Ausgabeordner angeben; bestehende Pakete bleiben erhalten.');
     console.log(JSON.stringify(buildPackage(job,root,path.resolve(flags.out)),null,2));
   }else if(command==='quote')console.log(JSON.stringify(quote(job),null,2));
   else{
     const api=adminClient({shop:job.shop,token:process.env.GRAVURU_SHOPIFY_ADMIN_TOKEN});
     if(command==='plan'){if(!flags.out)throw Error('--out=<plan.json> fehlt.');writeJson(flags.out,await plan(job,api));console.log('Plan gespeichert. Keine Shopänderung.');}
     else if(command==='apply'){
       if(!Object.hasOwn(flags,'authorized')||!flags.plan||!flags.journal)throw Error('Auftrag muss autorisiert sein; --plan und --journal erforderlich.');
       if(fs.existsSync(flags.journal))throw Error('Journal existiert. Erst lesen, abgleichen und neu planen; nicht blind wiederholen.');
       console.log(JSON.stringify(await apply(job,readJson(flags.plan),api,{root,journalFile:flags.journal}),null,2));
     }else if(command==='verify'){
       const result=[];for(const p of job.products)result.push({key:p.key,issues:verifyListing(job,p,await productByHandle(api,p.handle))});
       console.log(JSON.stringify({scope:'Katalog; kein Nachweis der Bestellbarkeit',products:result},null,2));process.exitCode=result.some(p=>p.issues.length)?2:0;
     }else throw Error('Unbekannter Befehl.');
   }
 }
}catch(e){console.error(e.message);process.exitCode=1;}
