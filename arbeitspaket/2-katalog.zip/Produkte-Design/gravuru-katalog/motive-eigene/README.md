# Eigene neue Motive (nicht im Kundenkonfi)

Chris, 29.10.2026: Motive, die KIs für ihre **ganz neuen Designs** zeichnen ([Design-Master](../designs/DESIGN-MASTER.md), Abschnitt 5), werden hier gesammelt – **sie erscheinen nicht automatisch im Kundenkonfigurator.** Der Konfi liest als Einzelmotive nur `motive/motive.json`; dieser Ordner wird von keiner Werkstatt-/Konfi-Quelle eingelesen.

- Datei je Motiv: `motive-eigene/<thema>/<kennung>.svg`, Vektor, einfarbig, ohne eingebettete Bitmaps oder Schriften.
- Eintrag in `motive-eigene.json` → `motifs[]`: `key` (Kennung, stabil), `name`, `thema`, `file` (relativ zu diesem Ordner), `sha256`, `herkunft` (KI/Account, Datum, Auftrag), `design` (Kennung des Designs, das es nutzt), `kundenkonfi: false`.
- Das Motiv liegt außerdem im Design-Ordner (Lieferform 2, `motiv-<n>`-Ebene) – dieser Ordner ist die Sammlung, nicht der Ersatz.
- In `motive/` (Kundenbibliothek) wird ein Motiv nur nach ausdrücklichem Satz von Chris übernommen; dann hier `kundenkonfi` mit Datum und Zitat nachtragen.
- Nicht verwechseln mit `motive/_neu/` (alter Icon-Vorschlag, von Chris abgelehnt).
