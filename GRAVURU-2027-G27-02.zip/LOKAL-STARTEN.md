# Gravuru 2027 lokal starten

Voraussetzung: Node.js 24 oder neuer. Keine Paketinstallation nötig. Befehle im Projektordner ausführen, der `package.json` und `app/` enthält.

```powershell
node app/configurator/variant-m/server.mjs --port=8961
```

Danach http://127.0.0.1:8961/?model=acryl öffnen. Das Terminal muss laufen bleiben. Bei belegtem Port vorhandenen Server verwenden oder einen anderen freien Port angeben. Der alte Vergleich auf Port 8951 wird nicht ersetzt.

Werkstatt: http://127.0.0.1:8961/werkstatt/ – Produkte, Profile und Serien. Beim ersten Start wird der Acrylmaster angelegt. Dauerhafte lokale Daten liegen in `.local-data/`; diesen Ordner bei einem Rechnerumzug separat sichern. Er gehört nicht ins Quellrepository. Die Excel-Vorlage ist direkt in der Serienverwaltung herunterladbar.

Der Server baut die Vorschau beim Start. `app/configurator/variant-m/.preview/` ist ein ignoriertes Build-Ergebnis. Referenzarchive müssen für diesen Pilot nicht ausgepackt werden; alle benötigten Ressourcen liegen unter `app/`.

## Prüfungen

```powershell
node --test app/configurator/variant-m/*.test.mjs app/workshop/*.test.mjs
node app/configurator/variant-m/build.mjs
```

Build mit 76 Ressourcen und einem Acrylmodell. Aktueller Funktions- und Prüfstand: `STATUS.md`. `G27-01-PRUEFUNG.md` beschreibt nur die ursprüngliche Kundenoberfläche.

## Grenzen

Dieser Server bindet ausschließlich lokal. Schreibende Werkstattaktionen verwenden Host-/Origin-Prüfung und Sitzungstoken; eine Händleranmeldung für öffentliches Hosting fehlt noch. Shopify und Bestellproduktion sind nicht angeschlossen. Gestaltungen sind keine gespeicherten Bestellungen. Sichtbare Abschluss-/Entwurfsfunktionen des übernommenen Editors belegen keine neue Bestellstrecke. Nicht unverändert öffentlich hosten.
