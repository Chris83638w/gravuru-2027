# Bestandsdesigns Gedenktafeln – aus dem Server-Bestand extrahiert

650 Designs (über Größen und Materialien zusammengefasst), gelesen aus den Corel-Bögen (`[CDR]`) und Konfigurator-Paketen auf `V:\Produkte\Gedenktafeln`. Je Design ein Ordner `Zielgruppe/Unterkategorie/<Schlüssel>/` mit `design.svg` (Text bleibt Text, Motive als Pfade, Maße in mm), `design.json` (Texte, Schriften, Lage, Varianten, Kategorie) und `preview.png`. UV-Designs aus Paketen tragen zusätzlich `product.json` und die Ebenen (`Bild_*.png`, `*.svg`).

**Kategorien sind Vorschläge aus den Texten** – Korrektur in [`GEDENKTAFELN-DESIGNS.xlsx`](GEDENKTAFELN-DESIGNS.xlsx) (gelbe Spalten), Übersichtsbögen je Kategorie in `_uebersicht/`.

| Zielgruppe | Unterkategorie | Designs |
| --- | --- | --- |
| Menschen | Allgemein | 333 |
| Menschen | Freund | 2 |
| Menschen | Kind | 12 |
| Menschen | Mama | 15 |
| Menschen | Opa | 1 |
| Menschen | Papa | 1 |
| Menschen | Partner | 6 |
| Sternenkinder | Sternenkind | 22 |
| Tiere | Allgemein | 202 |
| Tiere | Hund | 39 |
| Tiere | Katze | 11 |
| Tiere | Kleintier | 3 |
| Tiere | Pferd | 3 |

| Reihe | Designs |
| --- | --- |
| Gravur Rechteck/Hochformat (Schiefer, Acryl, Acryl+Edelstahl, Premium Schiefer) | 155 |
| Gravur Schiefer Herz | 90 |
| UV Granit / Premium Schiefer | 72 |
| UV Acryl / Acryl+Edelstahl | 49 |
| Gravur Edelstahl | 46 |
| UV Marmor | 32 |
| UV Marmor Herz liegend | 32 |
| UV Schiefer Rechteck | 24 |
| UV Edelstahl | 23 |
| Gravur Schiefer Stern | 16 |
| UV Schiefer Quadrat | 16 |
| UV Schiefer Stern | 16 |
| Gravur Acryl Herz | 15 |
| UV Alu-Dibond | 15 |
| Gravur Schiefer Knochen | 12 |
| UV Acryl rund | 12 |
| UV Schiefer Herz | 12 |
| UV Schiefer rund | 9 |
| Gravur Sternenkinder (Schiefer) | 4 |

## Regeln

- Eigene Motive dieser Designs bleiben beim Design (keine Übernahme in `motive/`).
- Alte Größen sind nur dokumentiert (`sizesInStock`); welche Größen die Linie künftig hat, entscheidet der Nutzer.
- Texte sind Beispieltexte des Bestands (Kundenfelder im Konfigurator); Schriften sind die im Bestand verwendeten – Ersatz für nicht freigegebene Schriften folgt je Linie.
- Lücken: Designs ohne lesbaren Text (`offen`) stammen aus reinen Bildpaketen; dort hilft nur Sichtprüfung über `preview.png`.
