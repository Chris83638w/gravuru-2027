// Uses an explicitly enabled endpoint in the existing same-origin application.
// Never enabled by a query string, arbitrary URL, local preview, or client price.
export function createCheckoutClient({endpoint,fetcher=fetch,files,draft,quantity,newKey=()=>crypto.randomUUID()}){
 if(endpoint!=='/api/customer-checkout')throw Error('Ungültige Bestellanbindung.');
 let token,pending,attempt;
 const uploaded=new WeakMap();
 async function request(route,body,type='application/json'){
  const response=await fetcher(endpoint+route,{method:'POST',credentials:'same-origin',redirect:'error',headers:{'Content-Type':type,...(token?{Authorization:'Bearer '+token}:{})},body:type==='application/json'?JSON.stringify(body):body});
  let result;try{result=await response.json();}catch{throw Error('Bestellserver antwortet nicht. Bitte später erneut versuchen.');}
  if(!response.ok)throw Error(result.error||'Übertragung fehlgeschlagen.');return result;
 }
 async function upload(blob){
  let item=uploaded.get(blob);if(!item){item=await request('/upload',blob,blob.type);uploaded.set(blob,item);}return item.id;
 }
 async function submit(){
  const design=draft(),count=quantity(),signature=JSON.stringify({draft:design,quantity:count});
  if(!attempt||attempt.signature!==signature)attempt={signature,key:newKey()};
  if(!token)token=(await request('/session',{})).token;
  const photos=[];
  for(const o of design.state.objects.filter(o=>o.uxUploadId&&!o.uxHidden)){
   const source=files.get(o.uxUploadId);if(!source?.file)throw Error('Bitte fehlendes Foto erneut auswählen.');
   const originalId=await upload(source.file),renderedId=source.blob?await upload(source.blob):originalId;
   photos.push({objectId:o.id,kind:o.uxUploadKind,background:o.uxUploadKind==='photo'?(o.uxPhotoBackground||'remove'):undefined,originalId,renderedId});
  }
  return request('/submit',{requestKey:attempt.key,draft:design,quantity:count,photos});
 }
 return {submit(){if(!pending)pending=submit().finally(()=>pending=null);return pending;}};
}
