import fs from 'node:fs';
import {createHash} from 'node:crypto';
const bytes=fs.readFileSync(new URL('./dist/function.wasm',import.meta.url));
if(createHash('sha256').update(bytes).digest('hex')!=="f9360588df38eb108ec77ecd0276f46f4524841949c15a76d9789f332adb7890")throw Error('Prebuilt function checksum mismatch');
console.log('Verified prebuilt function');
