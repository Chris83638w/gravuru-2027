// Schema-validated 2026-09-27. Uses a server-side connection; never browser tokens.
import {createHash} from 'node:crypto';
const QUERY="query WorkbenchProduct($query:String!){shop{myshopifyDomain currencyCode} products(first:2,query:$query){nodes{id handle title descriptionHtml status updatedAt seo{title description} tags collections(first:40){nodes{id} pageInfo{hasNextPage}} source:metafield(namespace:\"gravuru_workbench\",key:\"source_id\"){value} manifest:metafield(namespace:\"gravuru_workbench\",key:\"manifest\"){value} variants(first:40){nodes{id sku price selectedOptions{name value}} pageInfo{hasNextPage endCursor}}} pageInfo{hasNextPage endCursor}}}";
const SET="mutation WorkbenchDraft($input:ProductSetInput!,$identifier:ProductSetIdentifiers){productSet(input:$input,identifier:$identifier,synchronous:true){product{id handle} userErrors{field message code}}}";
const MANIFEST="mutation WorkbenchManifest($metafields:[MetafieldsSetInput!]!){metafieldsSet(metafields:$metafields){metafields{key value} userErrors{field message code}}}";
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function draftInput(pack){const p=pack.product,config=pack.config,data=p.data;
 const manifest={productId:p.id,revision:p.revision,configurator:data.configurator,designs:config.profile.designs.map(d=>({id:d.id,source:p.designs.find(r=>r.id===d.id)?.sha256})),geometry:config.profile.geometry,options:config.profile.optionGroups,customerEnabled:false};
 return {handle:pack.shopify.handle,title:data.title,descriptionHtml:'<p>'+esc(pack.shopify.description).replaceAll('\n','<br>')+'</p>',vendor:'gravuru GmbH',productType:'Personalisiertes Schild',status:'DRAFT',seo:{title:data.seoTitle||'',description:data.seoDescription||''},tags:(data.tags||'').split(',').map(t=>t.trim()).filter(Boolean),collections:pack.shopify.collectionIds||[],
  productOptions:[{name:'Befestigung',position:1,values:config.profile.optionGroups[0].values.map(v=>({name:v.label}))}],
  variants:config.profile.optionGroups[0].values.map(v=>({optionValues:[{optionName:'Befestigung',name:v.label}],sku:(data.sku||p.id)+'-'+v.id,price:((config.basePriceCents+v.priceCents)/100).toFixed(2),taxable:true,inventoryItem:{requiresShipping:true,...(data.weight?{measurement:{weight:{value:data.weight,unit:'GRAMS'}}}:{})}})),
  metafields:[{namespace:'gravuru_workbench',key:'source_id',type:'single_line_text_field',value:p.id},{namespace:'gravuru_workbench',key:'manifest',type:'json',value:JSON.stringify(manifest)}]};}
const fingerprint=p=>createHash('sha256').update(JSON.stringify(p)).digest('hex');
export async function transferDraft(pack,{token,fetcher=fetch,previous,journal=()=>{}}={}){
 if(!token)throw Error('Die dauerhafte Shopify-Verbindung dieser Werkstatt ist noch nicht eingerichtet.');
 if(pack.product.data.categoryId&&!pack.shopify.collectionIds?.length)throw Error('Die gewählte Unterkategorie hat noch keine Shopify-Kollektion. Zuordnung zuerst ergänzen.');
 const desired=draftInput(pack),shop='gravuru-design.myshopify.com';
 async function api(query,variables){const r=await fetcher('https://'+shop+'/admin/api/2026-07/graphql.json',{method:'POST',redirect:'error',headers:{'Content-Type':'application/json','X-Shopify-Access-Token':token},body:JSON.stringify({query,variables}),signal:AbortSignal.timeout(60000)});if(!r.ok)throw Error('Shopify antwortet mit HTTP '+r.status+'. Vor Wiederholung den Stand abgleichen.');const b=await r.json();if(b.errors?.length)throw Error(b.errors.map(e=>e.message).join(' · '));for(const p of Object.values(b.data||{}))if(p?.userErrors?.length)throw Error(p.userErrors.map(e=>e.message).join(' · '));return b.data;}
 async function read(){const d=await api(QUERY,{query:(previous?.id?'id:'+previous.id.split('/').pop()+' OR ':'')+'handle:'+desired.handle});if(d.shop.myshopifyDomain!==shop||d.shop.currencyCode!=='EUR')throw Error('Shop/Währung stimmt nicht.');if(d.products.pageInfo.hasNextPage||d.products.nodes.length>1)throw Error('Produktzuordnung nicht eindeutig.');const p=d.products.nodes[0]||null;if(p&&((p.handle!==desired.handle&&p.id!==previous?.id)||p.variants.pageInfo.hasNextPage))throw Error('Produktdaten unvollständig.');return p;}
 function matches(p){return p&&p.handle===desired.handle&&JSON.stringify([p.seo?.title||'',p.seo?.description||''])===JSON.stringify([desired.seo.title,desired.seo.description])&&JSON.stringify([...(p.tags||[])].sort())===JSON.stringify([...desired.tags].sort())&&!p.collections?.pageInfo.hasNextPage&&desired.collections.every(id=>p.collections?.nodes.some(c=>c.id===id))&&p.status==='DRAFT'&&p.title===desired.title&&p.descriptionHtml===desired.descriptionHtml&&p.source?.value===pack.product.id&&p.manifest?.value===desired.metafields[1].value&&p.variants.nodes.length===desired.variants.length&&desired.variants.every(v=>p.variants.nodes.some(r=>r.sku===v.sku&&Number(r.price)===Number(v.price)&&r.selectedOptions.some(o=>o.name==='Befestigung'&&o.value===v.optionValues[0].name)));}
 let live=await read();
 if(live&&(live.status!=='DRAFT'||live.source?.value!==pack.product.id))throw Error('Vorhandenes Produkt gehört nicht zu diesem Werkstattentwurf oder ist bereits aktiv. Keine Änderung.');
 if(matches(live)){const result={state:'DRAFT_VERIFIED',id:live.id,handle:live.handle,fingerprint:fingerprint(live),revision:pack.product.revision};journal(result);return result;}
 if(live&&(!previous?.fingerprint||previous.fingerprint!==fingerprint(live)))throw Error('Shopify-Entwurf wurde außerhalb dieses Vorgangs geändert oder eine frühere Übertragung ist unklar. Erst den gespeicherten Prüfstand abgleichen.');
 const input=structuredClone(desired);
 if(live){delete input.metafields;for(const v of input.variants){const old=live.variants.nodes.find(o=>o.sku===v.sku);if(old)v.id=old.id;}}
 journal({state:'TRANSFERRING',revision:pack.product.revision,handle:desired.handle,previous:previous||null});
 try{
  const response=await api(SET,{input,identifier:live?{id:live.id}:{handle:desired.handle}});const id=response.productSet.product?.id;if(!id)throw Error('Produktkennung fehlt.');
  if(live)await api(MANIFEST,{metafields:desired.metafields.map(m=>({...m,ownerId:id}))});
  live=await read();if(!matches(live))throw Error('Rückleseprüfung stimmt nicht vollständig mit dem Produktpaket überein.');
  const result={state:'DRAFT_VERIFIED',id:live.id,handle:live.handle,fingerprint:fingerprint(live),revision:pack.product.revision};journal(result);return result;
 }catch(error){journal({state:'NEEDS_RECONCILIATION',message:error.message,handle:desired.handle,previous:previous||null});throw error;}
}
