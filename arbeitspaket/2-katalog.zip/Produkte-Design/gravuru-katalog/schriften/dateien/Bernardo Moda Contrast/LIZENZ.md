# Bernardo Moda Contrast

Lizenz laut Nutzerliste (Schriftarten-Uebersicht-Lizenz, 30.09.2026): Peter Wiegel – 100 % frei.
Datei übernommen am 17.10.2026 aus dem Schriftenordner des Nutzers (`_fpd_pr_fonts`, Fancy-Product-Designer-Bestand der WooCommerce-Seite), Originalname `Bernardo Moda.ttf`.
Lizenztext nicht beigelegt – bei Bedarf vom Anbieter nachreichen.
