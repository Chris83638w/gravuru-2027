import STAINLESS_CATALOG from './stainless-catalog.json' with {type:'json'};
export {STAINLESS_CATALOG};
export function stainlessRules(group) {
  return group.formats.flatMap(f=>STAINLESS_CATALOG.mountingOptions.filter(o=>!o.holeCount||f.holeOptions.some(h=>h.count===o.holeCount)).map(option=>({
    sku:f.key+'-'+option.key,formatKey:f.key,mountingKey:option.key,width_mm:f.widthMm,height_mm:f.heightMm,
    holes:option.holeCount>0,holeCount:option.holeCount,spacers:false,motif_units:0,
    base_cents:f.baseCents,price_cents:f.baseCents+option.surchargeCents
  })));
}
export function validateStainlessAssignment(a,product) {
  const g=STAINLESS_CATALOG.groups.find(g=>g.key===a.groupKey);
  if(!g||a.catalogRevision!==STAINLESS_CATALOG.revision)throw Error('Die Edelstahl-Größentabelle ist nicht aktuell.');
  if(a.productId!==product.id||a.productHandle!==product.handle)throw Error('Die Zuordnung gehört zu einem anderen Produkt.');
  if(a.profileKey!=='edelstahl'||typeof a.enabled!=='boolean'||typeof a.orderEnabled!=='boolean'||typeof a.productionConfirmed!=='boolean')throw Error('Die Edelstahl-Aktivierung ist ungültig.');
  if(!a.variantMap||typeof a.variantMap!=='object'||Array.isArray(a.variantMap))throw Error('Variantenzuordnung fehlt.');
  const rules=stainlessRules(g),skus=new Set(rules.map(r=>r.sku)),ids=new Set(product.variants.map(v=>String(v.id).split('/').pop()));
  const mapped=Object.values(a.variantMap).filter(Boolean);
  if(Object.keys(a.variantMap).some(s=>!skus.has(s))||mapped.some(id=>typeof id!=='string'||!ids.has(id))||new Set(mapped).size!==mapped.length)throw Error('Varianten sind nicht eindeutig oder gehören zu einem anderen Produkt.');
  if(a.orderEnabled&&(!a.enabled||!a.productionConfirmed||rules.some(r=>r.price_cents==null||!a.variantMap[r.sku])))throw Error('Bestellungen benötigen bestätigte Daten, Optionspreise und alle zugeordneten Varianten.');
  return a;
}
