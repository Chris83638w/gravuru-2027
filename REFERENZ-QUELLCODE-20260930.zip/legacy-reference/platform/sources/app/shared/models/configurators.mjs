import {request} from './motifs.mjs';
import {STAINLESS_CATALOG} from '../stainless-contract.mjs';
export const CONFIGURATORS=`query GravuruConfigurators { metaobjects(type:"gravuru_configurator",first:50) { nodes { id handle fields { key value } } pageInfo { hasNextPage endCursor } } }`;
export async function loadConfigurators(){
 const data=await request(CONFIGURATORS);
 if(data.metaobjects.pageInfo.hasNextPage)throw Error('Die Konfiguratorliste wurde erweitert. Bitte die Verwaltung aktualisieren.');
 return data.metaobjects.nodes.map(n=>{const values=Object.fromEntries(n.fields.map(f=>[f.key,f.value]));let config;try{config=JSON.parse(values.configuration)}catch{throw Error('Ungültige Konfiguratordaten: '+n.handle)}
  const expected=STAINLESS_CATALOG.groups.find(g=>g.key===config.group?.key);
  if(config.kind==='layered-doorbell'&&config.profileKey==='funkklingel')return {id:n.id,name:values.name,groupKey:'FK',kind:config.kind,revision:config.revision,geometry:config.geometry,designs:config.designs||[],materials:config.materials,mounting:config.mounting,previewUrl:config.binding?.shop==='gravuru-design.myshopify.com'&&config.binding?.url?.startsWith('https://gravuru-design.myshopify.com/pages/')?config.binding.url:null,orderEnabled:config.features?.orderEnabled===true};
  return {id:n.id,name:values.name,groupKey:config.group?.key,current:!!expected&&config.revision===STAINLESS_CATALOG.revision&&JSON.stringify(config.group)===JSON.stringify(expected)&&JSON.stringify(config.mountingOptions)===JSON.stringify(STAINLESS_CATALOG.mountingOptions)};
 });
}
