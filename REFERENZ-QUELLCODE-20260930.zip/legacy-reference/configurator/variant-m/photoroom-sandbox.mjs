import {createHash} from 'node:crypto';

export const MAX_INPUT=15*1024*1024, MAX_OUTPUT=25*1024*1024;
const fail=(message,status=400)=>Object.assign(new Error(message),{status});
export async function boundedBytes(stream,limit){
  let length=0;const parts=[];
  for await(const part of stream){length+=part.length;if(length>limit)throw fail('Die Datei ist zu groß.',413);parts.push(part);}
  return Buffer.concat(parts);
}
export function imageType(bytes){
  if(bytes.length>=24&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return 'image/png';
  if(bytes.length>=4&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'image/jpeg';
  if(bytes.length>=12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')return 'image/webp';
  throw fail('Bitte eine PNG-, JPG- oder WebP-Datei verwenden.',415);
}
// This adapter deliberately has no production mode. All keys are forced into sandbox mode.
export function createSandbox({fetchImpl=fetch,timeoutMs=60000,maxCalls=20}={}){
  let key='',busy=false,calls=0,generation=0,cacheBytes=0;
  const cache=new Map();
  function clear(){cache.clear();cacheBytes=0;generation++;}
  function configure(value){
    if(busy)throw fail('Bitte den laufenden Fototest abwarten.',409);
    if(typeof value!=='string'||!/^[A-Za-z0-9_-]{20,200}$/.test(value.trim()))throw fail('Bitte den API-Schlüssel vollständig einfügen.');
    key=value.trim().startsWith('sandbox_')?value.trim():'sandbox_'+value.trim();clear();
  }
  function disconnect(){key='';clear();}
  function status(){return {configured:Boolean(key),busy,mode:'sandbox',calls,limit:maxCalls};}
  async function remove(bytes){
    if(!key)throw fail('Bitte zuerst den neuen API-Schlüssel hinterlegen.',409);
    if(bytes.length>MAX_INPUT)throw fail('Maximal 15 MB je Foto.',413);
    const mime=imageType(bytes),hash=createHash('sha256').update(bytes).digest('hex');
    if(cache.has(hash))return cache.get(hash);
    if(busy)throw fail('Ein Foto wird bereits verarbeitet. Bitte kurz warten.',409);
    if(calls>=maxCalls)throw fail('Das lokale Testlimit ist erreicht. Bitte den Testserver neu starten.',429);
    const current=generation;busy=true;calls++;
    try{
      const form=new FormData();form.set('imageFile',new Blob([bytes],{type:mime}),'test-photo.'+({ 'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[mime]));
      form.set('removeBackground','true');form.set('referenceBox','originalImage');form.set('export.format','png');
      const response=await fetchImpl('https://image-api.photoroom.com/v2/edit',{method:'POST',headers:{'x-api-key':key},body:form,signal:AbortSignal.timeout(timeoutMs),redirect:'error'});
      if(!response.ok){await response.body?.cancel();throw fail(response.status===401||response.status===403?'Photoroom akzeptiert den Zugang noch nicht. Bitte Schlüssel und API-Freischaltung im Dashboard prüfen.':response.status===429?'Photoroom meldet ein Testlimit. Bitte später erneut versuchen.':'Photoroom konnte dieses Foto nicht verarbeiten. Das Original bleibt erhalten.',response.status===429?429:502);}
      if(!response.headers.get('content-type')?.startsWith('image/png')){await response.body?.cancel();throw fail('Photoroom hat kein PNG-Bild zurückgegeben.',502);}
      const result=await boundedBytes(response.body,MAX_OUTPUT);
      if(imageType(result)!=='image/png')throw fail('Die Antwort enthält kein gültiges PNG-Bild.',502);
      if(current!==generation)throw fail('Der Testzugang wurde getrennt. Bitte erneut verbinden.',409);
      while(cache.size>=5||cacheBytes+result.length>50*1024*1024){const oldest=cache.keys().next().value;cacheBytes-=cache.get(oldest).length;cache.delete(oldest);}
      cache.set(hash,result);cacheBytes+=result.length;return result;
    }catch(error){
      if(error.status)throw error;
      throw fail('Der Fototest ist gerade nicht erreichbar oder dauert zu lange. Dein Original bleibt erhalten. Bitte bewusst erneut versuchen.',502);
    }finally{busy=false;}
  }
  return {configure,disconnect,status,remove};
}
