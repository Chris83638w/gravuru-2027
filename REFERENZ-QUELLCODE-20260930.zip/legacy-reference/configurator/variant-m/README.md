# Variante M – gemeinsame Produktprofile

Stand: 25.09.2026. **Lokale und öffentliche Testoberfläche, noch keine vollständige Bestellstrecke.**
Aufgabenbranch: `feat/variante-m-profile-20260924`.

Lokaler PDF-Importtest D201 (27.09.2026): [Ergebnis, Grenzen und Start](PDF-PILOT-D201.md).

Separate Testbereitstellung: [PUBLIC-TEST.md](PUBLIC-TEST.md).
[Öffentliche Testversion](https://gravuru-konfigurator-test.netlify.app/) ohne Anmeldung
erreichbar; AOSU-Textänderung, Foto, Hilfe und mobiles Vollbild öffentlich geprüft.

## Neue Oberfläche und Materialprofile

Aktuelle Screenshotkorrekturen und bestätigte Entscheidungen (keine Objektauswahl,
Optionen offen, große feste Mobilvorschau, Designverlauf, Uploadfläche und Druckfarben):
[UX-FEEDBACK-VERIFICATION.md](UX-FEEDBACK-VERIFICATION.md). Dieser Nachweis ersetzt
ältere Angaben zur Canvasüberschrift, kleinen Miniatur und zum Design-Scrollbalken.

Christophers Freigabe „Setze es um“ ist als lokale UX-Fassung umgesetzt. Aktueller
Umfang der Grundfassung: [UX-VERIFICATION.md](UX-VERIFICATION.md). Neuere Änderungen
an Fotovorschau, Bildbearbeitung, Ziehgriffen, Desktop-/Mobilaufteilung und Kategorien:
[UX-REFINEMENT-VERIFICATION.md](UX-REFINEMENT-VERIFICATION.md).
Die anschließenden Korrekturen anhand der mobilen Screenshots (Desktop wieder
nebeneinander, freie Vorschau ohne Auswahl, kompakte Reiter und direkte Bearbeitung)
sind in [UX-COMPACT-VERIFICATION.md](UX-COMPACT-VERIFICATION.md) dokumentiert.
Der aktuelle Nachweis für größere Produktvorschau, vertikale Listen und ganze
Schriftmillimeter mit 0-mm-Randprüfung steht in
[UX-SPACE-VERIFICATION.md](UX-SPACE-VERIFICATION.md). Er ersetzt die älteren Angaben
zu Weiter/Fertig, Schriftseiten und Auswahlreihenfolge.
Der bisherige Nachweis `VERIFICATION.md` bleibt als früherer Prüfstand erhalten.

Fünf Reiter ab Optionen, separate vertikal scrollbare Schriftwahl mit echten Textproben, vollständige
Inhaltsliste mit Sichtbarkeit/Sperren und Bearbeitung, schlankere feste Preisleiste,
Foto-/Logouploads (maximal vier, je 9,99 EUR) und die vorhandene lokale Assistentenhilfe.
Vor Kauf gibt es keinen Kunden-Dateiexport. Dauerhafte Kontospeicherung, bezahlter
PNG-Download und echte Bestellung sind weiterhin nicht verbunden.

Holz braun, Schiefer hell grauweiß, Edelstahl schwarz und UV-Druck mit Farbwähler
verwenden weiterhin dieselben fünf nativen Profil-IDs, einschließlich Acryl. Die
zusätzlichen Materialdemos sind ausdrücklich ohne Artikelpreis oder Shopify-Zuordnung.
Testmaße und Materialstärken dieser Demos sind keine neuen Produktvorgaben.

Neue Dateien: `ux.mjs`, `ux.css`, `ux-model.mjs`, `help.mjs`, `ux.test.mjs`.
Zusätzliche Prüfung: `node --test configurator/variant-m/ux.test.mjs`.

## Entscheidung von Christopher

Ein gemeinsamer Konfigurator mit fünf vorhandenen Bearbeitungsprofilen. Foto ist eine
Produkteinstellung, keine zweite Variante jedes Materialprofils:

| Profil-ID | Vorschau |
| --- | --- |
| `steel-engraving` | dunkle/schwarze Gravur auf Edelstahl |
| `wood-engraving` | braune Gravur auf Holz |
| `slate-engraving` | helle graue Gravur auf Schiefer |
| `acrylic-engraving` | helle grau-weiße Gravur auf Acryl |
| `color-print` | farbiger Druck |

`photo.enabled: false` blendet die Fotobedienung aus. Es werden ausschließlich Vorlagen
ohne Fotofeld angeboten. Bestehen alle Vorlagen aus Pflicht-Fotodesigns, stoppt die
Konfiguration mit einem Hinweis; Pflichtbereiche werden nicht still aus Designs gelöscht.
Bei `true` lassen sich vorhandene `photoSlot`-Elemente mit einem Foto belegen.
Christophers neuere Vorgabe ersetzt die frühere reine Uploadbox: Das ausgewählte Foto
wird jetzt dargestellt und lässt sich zuschneiden und lokal freistellen. Die Vorschau
des Fotos ist keine verbindliche Simulation der späteren Fotogravur.

## Start aus dem Repository

Voraussetzung: Node.js 24; tatsächlich geprüft mit **24.19.0**. Für dieses Paket keine
zusätzliche Paketinstallation, kein Token, keine Datenbank und kein Shopify-Login.
Die bereits bereitgestellten Repository-Ressourcen müssen vorhanden sein.
Alle Befehle aus dem Repository-Hauptordner ausführen:

```powershell
node configurator/variant-m/server.mjs --port=8947
```

Im Browser `http://127.0.0.1:8947/` öffnen. Produkt auswählen, anschließend
„Personalisieren“. „Zur Produktauswahl“ schließt die Ansicht; erneutes Öffnen desselben
Produkts behält den Entwurf in dieser Sitzung. Ein Produktwechsel verwirft die Sitzung.
Die echte Kontospeicherung ist noch nicht angeschlossen. Server mit Strg+C beenden.

```powershell
node --test configurator/variant-m/contract.test.mjs configurator/variant-m/ux.test.mjs configurator/variant-m/image-processing.test.mjs configurator/variant-m/usability.test.mjs automation/product-pipeline/tests/pipeline.test.mjs
node configurator/variant-m/build.mjs
```

Der Build vergleicht 104 Ressourcen gegen das vorhandene Labrador-Inventar. Bei fehlender
oder abweichender Datei stoppen, nicht das Inventar auf neue Werte umschreiben. Siehe
`designs/aosu-labrador/README.md` und `RESOURCE-INVENTORY.json` zur Herkunft.

## Aufbau und Quellen

- `build.mjs`: erzeugt ausschließlich ignorierte Dateien unter `.preview/`. Verwendet
  die vorhandene M-HTML-Referenz mit geprüften, eindeutigen Einhängepunkten. Keine
  Änderung der Originalreferenz, kein Umetikettieren des historischen v3-MASTER.
- `adapter.mjs`: verbindet die bestehende M-Bedienung mit nativer universeller Geometrie,
  Renderfunktion, Optionen, Materialfarben, Textpfaden und Motiven. Produktmaße bestimmen
  normale/große Vorschau und die Position neuer Elemente.
- `contract.mjs`: feste Produkt-/Profil-/Revisionsbindung, Optionen, Centpreise,
  Fotofreigabe, Entwürfe und Geometrieprüfung.
- `index.html`: minimale lokale Produktauswahl. Bibliotheken und Editor erst nach Klick.
- `server.mjs`: ausschließlich Loopback, lesende Ressourcenrouten und lokale CSP.
  Kein Produktionsserver, keine Upload- oder Bestell-API.
- `contract.test.mjs`: relevante Daten-, Preis-, Geometrie- und Entwurfsprüfungen.
- `refinements.mjs` / `.css`: gemeinsame Ziehgriffe, kompakte Reiterleiste, Desktop-/Mobil-
  Aufteilung, Bildminiatur, Maße und Kategorieauswahl.
- `usability.mjs` / `.css`: platzsparende Vorschau, vertikale Listen, Randwarnungen,
  SVG-ID-Trennung und abgeschirmte alte Bedienoberfläche.
- `usability-model.mjs` / `.test.mjs`: ganze Schriftmillimeter, transformierte
  Textgrenzen und bewusst ausgelöste Größenanpassung ohne Verschieben.
- `photo-editor.mjs`: lokale Zuschnitt-/Maskieroberfläche; keine externe Freistell-API.
- `image-processing.mjs` / `.test.mjs`: verbundene Hintergrundflächen entfernen,
  begrenzte Bildauflösung und proportionale Elementskalierung.

Eingänge:

1. `references/aosu-upgrade-2026-09-21/verification/editor-source.html` und
   `profile-source.json`: ausgewählte Variante M/AOSU-Upgrade, Renderer
   `variant-c-funkklingel/v5`, Profilrevision `modelle-live-20260919-v1`.
2. `designs/aosu-labrador/`: bestehendes Labrador-Design, Michroma-Pfade, Motiv,
   Katalogsegmente, Schriften, Motive und Produktbilder.
3. `automation/product-pipeline/jobs/hunde-gedenktafeln.json`: vorhandene zehn Designs,
   Produktmaße, Preise und IDs; `profileForProduct` löst die Bindung auf.
4. `platform/sources/app/shared/models/`: vorhandene native Modelle. Die Module werden
   importiert, nicht als neue abweichende Kopien gepflegt.

## Anschluss weiterer Produkte

Der Adapter bekommt ein aufgelöstes natives Profil, keine frei erfundene Profilnummer:

```js
const config = {
  profile: boundNativeProfile, // inkl. id, revision, binding.productId, geometry, designs
  basePriceCents: 2999,
  extraMotifCents: 169,
  photo: { enabled: true, mode: 'upload-only' }
};
const checked = prepareConfig(config);
```

Preise aus dem Produktauftrag und freigegebenen Optionsgruppen übernehmen. Materialfarbe,
Bearbeitungsprofil, Geometrie und Fotoeinstellung getrennt halten. Bei Fotofreigabe aus
der bestehenden Produktdatenbank diese Einstellung auf `photo.enabled` abbilden; diese
Vorschau legt noch kein neues Datenbankfeld oder Shopify-Metafeld an.

Die lokale Produktauswahl enthält AOSU/Labrador und das erste gebundene Schieferprodukt.
Die zweite Schiefertafel verwendet denselben Adapter, benötigt aber ihre eigene bereits
vorhandene Produkt-/Profilbindung. Sie wird hier nicht als drittes identisches Prüfmodell
angelegt. Benutzerdateien dürfen nicht zur Herstellung einer Beispielkonfiguration in
das Repository kopiert werden.

## Was die lokale Prüfung noch nicht leistet

- Foto wird als Original-`File` und gegebenenfalls bearbeiteter Vorschau-`Blob` nur in
  der geöffneten Seite gehalten. Dateiname bedeutet
  **ausgewählt**, nicht auf dem Server gespeichert. Kein Foto in JSON, localStorage,
  externer URL oder Git. Lokale Blob-URLs bleiben auf die Sitzung begrenzt.
  Beim Öffnen eines Entwurfs Foto neu auswählen.
- Dateityp/Größe werden lokal geprüft. Serverseitige Inhaltsprüfung, private Ablage,
  Zugriffsschutz und Zuordnung zur Bestellung fehlen noch.
- Warenkorb bleibt deaktiviert. Server muss Preise/Optionen aus vertrauenswürdigen
  Quellen neu berechnen und echte Shopify-Varianten für Aufpreise zuordnen. Reine
  Clientpreise oder Line-Item-Texte sind kein abrechenbarer Aufpreis.
- PNG ist eine technische Gestaltungsvorschau. SVG ist ein 1:1-Vektorentwurf mit Texten,
  Motiven und Gestaltungslinien, **ohne Foto und ohne Fertigungsfreigabe**. Es gibt noch
  keine geprüfte Übergabe von Fotogravur und getrennten Fertigungsebenen an die Werkstatt.
- Naturgetreue Schiefertextur und Bruchkanten sind in diesem nativen Vorschau-Renderer
  nicht dargestellt. Er ersetzt keine freigegebenen Produktfotos.
- Native Produktkonturen sind derzeit Rechteck/gerundetes Rechteck und Ellipse.
  Standherzen, Grabkreuze und beliebige Originalkonturen sind hier noch nicht abgenommen.
- Nicht alle vorhandenen M-Interaktionen und nicht alle fünf Profile wurden auf echten
  Mobilgeräten getestet. Der lokale Server ist keine PageSpeed-Messung der Shopseite.

## Nächster begrenzter Schritt

Aktuellen Werkstattserver und den separat gesicherten Werkstattstand eindeutig zuordnen,
bevor private Upload-/Bestellendpunkte verbunden werden. Keine Übernahme eines ganzen
anderen Branches allein wegen eines ähnlich benannten Moduls. Anschließend einen
vollständigen Schiefer-Bestellweg mit Foto, Aufpreisen und Produktionsübergabe prüfen.
Offene Preisfrage: Sind die Bohrlöcher zusätzlich zu Abstandshalter-Sets zu bezahlen?
Bis zur Antwort bleiben die bestehenden Summen 8,98/13,98 EUR unverändert.

Keine Freigabe durch Setzen eines Runtime-Flags vortäuschen. Main, Shopify, Plesk und
historische Referenzen wurden für diese lokale Integration nicht verändert.

