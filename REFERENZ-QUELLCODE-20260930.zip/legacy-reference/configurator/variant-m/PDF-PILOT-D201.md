# Lokaler PDF-Pilot D201

Stand: 27.09.2026. Auftrag: Christopher bestätigt den ersten lokalen Importtest für die Schiefer-Gedenktafel 220 × 140 mm. Quellbasis `acc0a48b1fb6417846edf381d53b333bcf303d3c`, Aufgabenbranch `feat/variante-m-profile-20260924`, vor Bearbeitung über GitHub-Connector bestätigt.

## Ergebnis

Der bestehende Variante-M-Editor lädt D201 aus einem ausdrücklich angegebenen lokalen Datenpaket. Fünf Elemente: austauschbares Foto, Name in Centaur, Datum in Allura, originales Doppelherz, mehrzeiliger Spruch in Allura. Das Herz bleibt ein zusammengesetzter Even-odd-Pfad; seine Innenflächen werden nicht versehentlich gefüllt. Die technische Plattenkontur ist kein löschbares Gestaltungselement.

Die vollständige Bitmapfläche der PDF wird zum Fotofeld. Das Tierbeispiel und seine Upload-Beschriftung werden nicht als Kundeninhalt importiert. Kundendateien bleiben wie bisher ausschließlich in der geöffneten Browsersitzung. Das Verfahren ist ein geprüfter Musterimport für genau D201, kein universeller PDF-/Batch-Konverter.

Die beiden Originalschriften wurden aus vorhandenen lokalen Schriftdateien aufbereitet. Neue lateinische Kundentexte sind möglich; nicht vorhandene Zeichen werden validiert. Die bisherigen globalen Schriftlisten bleiben geschlossen: zusätzliche Schriften werden nur mit ausdrücklich validierten lokalen Ressourcen zugelassen. Originale und Schriftdaten sind nicht in Git enthalten. Vor einem öffentlichen Einsatz müssen vollständige Web-/Schriftnutzungsrechte und Auslieferung geklärt werden.

## Ablage und Start

Produktordner:
`C:/Users/Christopher Koch/Documents/Codex/Gravuru-Produktdaten/01-Produkte/Schiefer/Gedenktafeln/220x140-mm`

- Original: `01-Originale/GT-S-22x14-D201.pdf` (unverändert).
- Aktives Paket: `03-Designs/D201/01-Bearbeitung/v002/pilot.json`.
- Importherkunft: `03-Designs/D201/01-Bearbeitung/v002/IMPORT-NACHWEIS.json`.
- v001 ist der erste lokale Zwischenstand vor der Korrektur des zusammengesetzten Herzpfads. v002 ist die geprüfte Fassung.

Start aus dem bestehenden Repository:

```powershell
node configurator/variant-m/server.mjs --port=8951 '--pilot=C:/Users/Christopher Koch/Documents/Codex/Gravuru-Produktdaten/01-Produkte/Schiefer/Gedenktafeln/220x140-mm/03-Designs/D201/01-Bearbeitung/v002/pilot.json'
```

Aufruf: http://127.0.0.1:8951/?model=d201 → Personalisieren.

Der Pilot verwendet einen eigenen Unterordner unter `.preview/pilots/d201/`. Der normale Build ohne `--pilot` enthält weiterhin sechs vorhandene Prüfmodelle und keine lokalen D201-/Schriftdaten. Der öffentliche Export ruft nur diesen normalen Build auf. Keine Veröffentlichung vorgenommen.

Reproduktion des Imports mit `import-d201.py`: Parameter `--pdf`, `--allura`, `--centaur` und `--output`. Abhängigkeiten: Python, pdfplumber, FontTools (geprüft mit 4.66.0). Schriften: lokale `Allura.ttf` und `CENTAUR.TTF`. Einen neuen Revisionsordner verwenden; der Import überschreibt keine bestehende Revision. FontTools wurde nur in der Arbeitsumgebung bereitgestellt, nicht als vendorte Bibliothek ins Repository kopiert.

## Maße, Optionen und Grenzen

- Bezugsfläche ist die erkannte 220 × 140-mm-Kontur, nicht die etwas größere PDF-Seite.
- Positionen aus der PDF übernommen. Schriftgrößen folgen der bestätigten UI-Regel für ganze Millimeter: 39 mm für den Namen, 7 mm fürs Datum, 8 mm für den Spruch. Deshalb und wegen des bestehenden Text-Renderers sind Zeilenabstände/Schriftlauf nicht als pixelidentische PDF-Reproduktion zugesagt.
- Dieselben acht Befestigungsoptionen und Referenzaufschläge wie bei 300 × 200 mm. Bohrung Ø 5 mm, Mittelpunkt 12 mm vom Rand; zwei Bohrungen mittig links/rechts, vier in den Ecken. Materialstärke 5 mm ist die übernommene lokale Referenzannahme; noch kein eigener Fertigungsnachweis für den Rohling.
- Das quellgetreu große Fotofeld überschneidet den linken Bohrbereich. Im Browser wurde die Warnung bei vier Bohrungen bestätigt; die geometrische Prüfung gilt auch für die übrigen Lochoptionen. Keine automatische Verschiebung/Verkleinerung oder Produktionsfreigabe. Vor Fertigung Foto und Lochbereich abstimmen.
- Grundpreis und zusätzliche Motiv-/Fotoabrechnung sind offen: `null`, Anzeige „Preis noch offen“, Preisberechnung verweigert, Warenkorb deaktiviert. Übernommene Optionsaufschläge sind als Referenzwerte sichtbar.
- Kein Shop-Produkt, keine Shopify-ID, kein dauerhaftes Konto-/Bestell-/Produktionssystem angelegt. D236 und die übrigen 28 Dateien sind noch nicht importiert.

## Prüfung

- 58 automatisierte Tests bestanden, keine übersprungen: bestehender Konfigurator, Bildbearbeitung, UX, Produktpipeline sowie sechs Pilotprüfungen einschließlich der echten externen D201-Datei.
- Pilotprüfungen: Schriftgrenze gegenüber normaler Produktion, aktive Inhalte abweisen, neuer Name und Entwurfs-Rücklesen, Nullpreis bleibt offen, unveränderte Referenzoptionen, auf 220 × 140 mm umgerechnete Bohrpositionen und erkannte Fotofeld-/Lochkollision.
- Build: alle 104 vorhandenen Originalressourcen gegen die bisherigen Hashes geprüft; normaler Build schließt lokale Pilotdaten aus.
- Chrome Desktop: Originaldarstellung, Name Snow → Luna, Spruch geändert, vier Bohrlöcher samt Warnung, zurück ohne Befestigung, technisches Testfoto hochgeladen, durch zweites Foto ersetzt (weiterhin fünf Elemente), quadratischen Zuschnitt übernommen.
- Chrome mit 390 × 844 CSS-Pixeln: Produktansicht, Upload und Vollbild kontrolliert; anschließend Viewport zurückgesetzt. Kein physischer Smartphone-Nachweis.
- Die UI-Teständerungen sind nur Sitzungstests; vor Übergabe wurde wieder die ursprüngliche D201-Vorlage geöffnet.

