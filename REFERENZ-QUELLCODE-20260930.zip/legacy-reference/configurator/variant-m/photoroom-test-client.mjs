const $=id=>document.getElementById(id);
let token='',configured=false,busy=false,photo=null,originalUrl='',resultUrl='',revision=0;
function update(){ $('remove').disabled=!configured||!photo||busy;$('connect').disabled=busy;$('disconnect').disabled=busy;$('photo').disabled=busy;$('disconnect').hidden=!configured; }
async function json(response){const body=await response.json();if(!response.ok)throw Error(body.error||'Der Test konnte nicht abgeschlossen werden.');return body;}
async function refresh(){const status=await json(await fetch('/api/status',{cache:'no-store'}));token=status.token;configured=status.configured;$('connection').textContent=configured?'Schlüssel lokal hinterlegt. Die Prüfung bei Photoroom erfolgt mit deinem Testfoto.':'Noch kein Schlüssel hinterlegt.';update();}
$('connect').addEventListener('click',async()=>{busy=true;update();let key=$('key').value;$('key').value='';try{await json(await fetch('/api/connect',{method:'POST',headers:{'content-type':'application/json','x-gravuru-token':token},body:JSON.stringify({key})}));await refresh();}catch(e){$('connection').textContent=e.message;}finally{key='';busy=false;update();}});
$('disconnect').addEventListener('click',async()=>{try{await json(await fetch('/api/disconnect',{method:'POST',headers:{'x-gravuru-token':token}}));await refresh();$('connection').textContent='Zugang aus dem lokalen Testserver entfernt.';}catch(e){$('connection').textContent=e.message;}});
$('photo').addEventListener('change',async()=>{
 const current=++revision;photo=null;$('original').hidden=true;$('cutout').hidden=true;for(const url of [originalUrl,resultUrl])if(url)URL.revokeObjectURL(url);originalUrl=resultUrl='';$('result-status').textContent='';update();
 const file=$('photo').files[0];if(!file)return;
 if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>15*1024*1024){$('result-status').textContent='Bitte PNG, JPG oder WebP mit maximal 15 MB wählen.';return;}
 try{const bitmap=await createImageBitmap(file);const pixels=bitmap.width*bitmap.height;bitmap.close();if(current!==revision)return;if(pixels>40000000)throw Error('Bitte ein Foto mit höchstens 40 Megapixeln wählen.');photo=file;originalUrl=URL.createObjectURL(file);$('original').src=originalUrl;$('original').hidden=false;$('result-status').textContent='Foto bereit. Es wurde noch nicht an Photoroom gesendet.';}catch(e){if(current===revision)$('result-status').textContent=e.message.startsWith('Bitte')?e.message:'Das Foto konnte nicht geöffnet werden.';}update();
});
$('remove').addEventListener('click',async()=>{
 if(!photo||!configured||busy)return;busy=true;update();$('result-status').textContent='Photoroom stellt dein Foto frei …';
 try{const response=await fetch('/api/remove',{method:'POST',headers:{'content-type':photo.type,'x-gravuru-token':token},body:photo});if(!response.ok)await json(response);const blob=await response.blob();const bitmap=await createImageBitmap(blob);bitmap.close();if(resultUrl)URL.revokeObjectURL(resultUrl);resultUrl=URL.createObjectURL(blob);$('cutout').src=resultUrl;$('cutout').hidden=false;$('result-status').textContent='Freistellung fertig. Vergleiche die Kanten mit deinem Original. Sandbox-Testbild mit Wasserzeichen.';$('connection').textContent='Photoroom-Testzugang erfolgreich geprüft.';}catch(e){$('result-status').textContent=e.message==='Failed to fetch'?'Die Verbindung zum lokalen Testserver fehlt.':e.message;}finally{busy=false;update();}
});
refresh().catch(()=>{$('connection').textContent='Die lokale Testverbindung konnte nicht hergestellt werden. Bitte die Seite neu laden.';});
window.addEventListener('pagehide',()=>{for(const url of [originalUrl,resultUrl])if(url)URL.revokeObjectURL(url);});
