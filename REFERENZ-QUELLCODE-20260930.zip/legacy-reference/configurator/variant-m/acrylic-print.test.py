"""Regression: photos must be CMYK and retain alpha in both ink passes."""
import base64
import importlib.util
import io
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('acrylic_print', Path(__file__).with_name('acrylic-print.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
from PIL import Image
from pypdf import PdfReader
from pypdf.generic import ContentStream

class PrintTest(unittest.TestCase):
    def test_color_white_alpha_and_dimensions(self):
        image = Image.new('RGBA', (12, 8), (200, 20, 70, 255))
        image.putpixel((0, 0), (0, 0, 0, 0))
        source = io.BytesIO(); image.save(source, format='PNG')
        data = base64.b64encode(source.getvalue()).decode()
        svg = f'<svg xmlns="http://www.w3.org/2000/svg"><image x="10" y="10" width="100" height="60" href="data:image/png;base64,{data}"/><path d="M 10 150 L 90 150 L 50 170 Z" fill="#123456"/></svg>'
        for size, dimensions in [('small',(150,200)), ('large',(200,266.7))]:
            raw = module.export_pdf({'schema':'gravuru-acrylic-print/v1','options':{'size':size},'svg':svg})
            reader = PdfReader(io.BytesIO(raw)); page = reader.pages[0]
            self.assertAlmostEqual(float(page.mediabox.width)/module.MM, dimensions[0], places=4)
            self.assertAlmostEqual(float(page.mediabox.height)/module.MM, dimensions[1], places=4)
            images = [x.get_object() for x in page['/Resources']['/XObject'].values()]
            self.assertEqual(len(images), 2)
            self.assertEqual({str(x['/ColorSpace']) for x in images if isinstance(x['/ColorSpace'], str)}, {'/DeviceCMYK'})
            white = next(x for x in images if not isinstance(x['/ColorSpace'], str))
            self.assertEqual(white['/ColorSpace'][1], '/RDG_WHITE')
            self.assertEqual(set(white.get_data()), {255})
            for x in images:
                self.assertEqual((x['/Width'], x['/Height']), (12,8))
                self.assertEqual(x['/SMask'].get_object().get_data()[0], 0)
            operations = ContentStream(page.get_contents(),reader).operations
            self.assertFalse(any(op in (b'rg',b'RG',b'INLINE IMAGE') for args,op in operations))
            mirrored = [args for args,op in operations if op==b'cm' and float(args[0])<0]
            self.assertEqual(len(mirrored), 2) # once for each ink pass
            self.assertIn('/CutContour',page['/Resources']['/ColorSpace'])

    def test_external_content_is_rejected(self):
        for svg in ['<svg><image href="https://example.com/a.png"/></svg>', '<!DOCTYPE svg><svg/>', '<svg><script/></svg>']:
            with self.assertRaises(ValueError): module.sanitized_svg(svg)

if __name__ == '__main__': unittest.main()
