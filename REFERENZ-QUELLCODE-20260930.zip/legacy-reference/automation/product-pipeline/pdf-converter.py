"""Reusable local PDF -> native Gravuru design converter; never changes the input.

Dependencies: pdfplumber, pdfminer.six, pypdfium2, fonttools. No model/API calls.
One uploaded PDF may have several pages. Ambiguities are returned for review.
"""
import argparse, hashlib, json, math, os, re
from io import BytesIO
from pathlib import Path
import pdfplumber
import pypdfium2 as pdfium
from pypdf import PdfReader
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.svgLib.path import parse_path
from pdfminer.pdfdevice import PDFDevice
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.utils import apply_matrix_pt

MM = 25.4 / 72

def norm(value):
    return re.sub(r'[^a-z0-9]', '', re.sub(r'^[A-Z]{6}\+', '', value).lower())

def font_index(extra, cache):
    folders = [Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts',
               Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Microsoft/Windows/Fonts', extra]
    paths = sorted({p for folder in folders if folder.exists() for p in folder.rglob('*') if p.suffix.lower() in ('.ttf', '.otf')})
    signature = hashlib.sha256('\n'.join(str(p)+str(p.stat().st_mtime_ns) for p in paths).encode()).hexdigest()
    if cache.exists():
        previous = json.loads(cache.read_text(encoding='utf-8'))
        if previous.get('signature') == signature:
            return previous['fonts']
    found = {}
    for p in paths:
        try:
            with TTFont(p, lazy=True) as font:
                for record in font['name'].names:
                    if record.nameID in (1, 4, 6, 16):
                        name = norm(record.toUnicode())
                        if name:
                            found.setdefault(name, str(p))
        except Exception:
            continue
    cache.write_text(json.dumps({'signature': signature, 'fonts': found}), encoding='utf-8')
    return found

def font_data(p):
    with TTFont(p) as font:
        gs, cmap, glyphs = font.getGlyphSet(), font.getBestCmap(), {}
        codes = set(range(32, 592)) | set(range(0x2000, 0x2070)) | set(range(0xe000,0xf900)) | {0x20ac, 0x2122}
        for code in sorted(codes & cmap.keys()):
            name = cmap[code]
            pen = SVGPathPen(gs)
            gs[name].draw(pen)
            commands=pen.getCommands()
            if commands or chr(code).isspace():
                glyphs[chr(code)] = {'a': font['hmtx'][name][0], 'd': commands}
        inverse={name:chr(code) for code,name in cmap.items() if 32<=code<127}
        ligatures={}
        if 'GSUB' in font:
            for lookup in font['GSUB'].table.LookupList.Lookup:
                for table in lookup.SubTable:
                    table=getattr(table,'ExtSubTable',table)
                    for first,items in getattr(table,'ligatures',{}).items():
                        for item in items:
                            names=[first]+item.Component
                            if all(name in inverse for name in names):
                                ligatures[item.LigGlyph]=''.join(inverse[name] for name in names)
        aliases={chr(code):ligatures[name] for code,name in cmap.items() if 0xe000<=code<=0xf8ff and name in ligatures}
        return {'category': 'PDF-Import', 'unicodeAliases':aliases, 'regular': {'units': font['head'].unitsPerEm, 'glyphs': glyphs}}

class Paths(PDFDevice):
    """Retain each PDF paint operation, including compound holes, before splitting."""
    def __init__(self, manager):
        super().__init__(manager)
        self.paths = []

    def paint_path(self, state, stroke, fill, evenodd, segments):
        transformed = []
        for segment in segments:
            transformed.append((segment[0], [apply_matrix_pt(self.ctm, (float(x), float(y))) for x, y in zip(segment[1::2], segment[2::2])]))
        self.paths.append({'path': transformed, 'fill': fill, 'stroke': stroke, 'evenodd': evenodd,
                           'width': state.linewidth * math.hypot(self.ctm[0], self.ctm[1])})

def vector_paths(pdf):
    manager = PDFResourceManager()
    device = Paths(manager)
    interpreter = PDFPageInterpreter(manager, device)
    result = []
    with open(pdf, 'rb') as source:
        for page in PDFPage.get_pages(source):
            device.paths = []
            interpreter.process_page(page)
            result.append(device.paths)
    return result

def text_groups(page):
    # Group by real text baseline, face and size. Never merge unrelated columns.
    groups = []
    for char in sorted(page.chars, key=lambda c: (round(c['matrix'][5], 0), c['x0']), reverse=True):
        if not char.get('text'):
            continue
        baseline, size, font = char['matrix'][5], char['size'], char['fontname']
        group = next((g for g in groups if g['font'] == font and abs(g['baseline']-baseline)<.9 and abs(g['size']-size)<.2), None)
        if group is None:
            group = {'font': font, 'baseline': baseline, 'size': size, 'chars': []}
            groups.append(group)
        group['chars'].append(char)
    output = []
    for group in groups:
        segment, previous = [], None
        for char in sorted(group['chars'], key=lambda c: c['x0']):
            gap = char['x0']-previous['x1'] if previous else 0
            if previous and gap > max(10, group['size']):
                output.append({**group, 'chars': segment})
                segment = []
            segment.append(char)
            previous = char
        if segment:
            output.append({**group, 'chars': segment})
    return sorted(output, key=lambda g: (-g['baseline'], g['chars'][0]['x0']))

def convert(pdf_path, out, width, height, extra_fonts):
    from importlib.util import spec_from_file_location, module_from_spec
    spec=spec_from_file_location('working_pdf',Path(__file__).with_name('working-pdf.py'))
    working=module_from_spec(spec);spec.loader.exec_module(working)
    editable=working.read_editable(pdf_path,out,width,height)
    if editable:return editable
    source_hash = hashlib.sha256(pdf_path.read_bytes()).hexdigest()
    index = font_index(extra_fonts, extra_fonts / 'index.json')
    vector_pages = vector_paths(pdf_path)
    rendered = pdfium.PdfDocument(str(pdf_path))
    rows = []
    font_cache = {}
    embedded = {}
    def embedded_fonts(resources, depth=0):
        if depth>8:return
        for value in resources.get('/Font',{}).values():
            f=value.get_object();descendant=f.get('/DescendantFonts',[f])[0].get_object()
            desc=descendant.get('/FontDescriptor',{});desc=desc.get_object() if hasattr(desc,'get_object') else desc
            if '/FontFile2' in desc:
                embedded[norm(str(f.get('/BaseFont','')).lstrip('/'))]=desc['/FontFile2'].get_data()
        for value in resources.get('/XObject',{}).values():
            obj=value.get_object()
            if '/Resources' in obj:embedded_fonts(obj['/Resources'],depth+1)
    reader=PdfReader(pdf_path)
    for pdf_page in reader.pages:embedded_fonts(pdf_page['/Resources'])
    with pdfplumber.open(pdf_path) as pdf:
        if len(pdf.pages)>60:
            raise ValueError('Höchstens 60 Seiten pro PDF.')
        for page_index, page in enumerate(pdf.pages):
            stem = re.sub(r'[^A-Za-z0-9_.-]', '-', pdf_path.stem)[:80].strip('-') or 'Design'
            key = stem + ('-S'+str(page_index+1) if len(pdf.pages)>1 else '')
            issues, errors, objects, motifs, fonts = [], [], [], [], {}
            contours = [c for c in page.curves+page.rects if abs(c['width']*MM-width)<.15 and abs(c['height']*MM-height)<.15]
            positions = {(round(c['x0'], 2), round(c['top'], 2)) for c in contours}
            if len(positions)==1:
                ox, oy = contours[0]['x0'], contours[0]['top']
            elif abs(page.width*MM-width)<.15 and abs(page.height*MM-height)<.15:
                ox, oy = 0, 0
                issues.append('Seitenformat als Produktkontur verwendet. Kontur bitte prüfen.')
            else:
                ox, oy = 0, 0
                errors.append('Keine eindeutige Kontur passend zu den Produktmaßen. Maße oder PDF korrigieren und erneut hochladen.')
            for n, img in enumerate(page.images):
                objects.append({'id':key+'-photo-'+str(n+1),'type':'photoSlot','fieldKey':'photo-'+str(n+1),
                    'photoShape':'rect','required':True,'x':((img['x0']+img['x1'])/2-ox)*MM,
                    'y':((img['top']+img['bottom'])/2-oy)*MM,'w':img['width']*MM,'h':img['height']*MM,
                    'rotation':0,'color':'#e8e9e5','customerEditable':True,'templateOrigin':True})
            if len(page.images)>1:
                issues.append('Mehrere Bitmaps als Fotofelder erkannt. Bitte kontrollieren.')
            groups = text_groups(page)
            for n, group in enumerate(groups):
                chars = group['chars']
                raw = ''
                previous = None
                for char in chars:
                    if previous and char['x0']-previous['x1']>group['size']*.18 and not raw.endswith(' ') and not char['text'].startswith(' '):
                        raw += ' '
                    raw += char['text']
                    previous = char
                raw = raw.strip()
                if not raw:
                    continue
                face = re.sub(r'^[A-Z]{6}\+', '', group['font'])
                font_key = 'PDF-'+re.sub(r'[^A-Za-z0-9_-]', '-', face)
                fp = index.get(norm(face))
                if not fp and norm(face) in embedded:
                    fp='embedded:'+norm(face)
                    if fp not in font_cache:
                        font_cache[fp]=font_data(BytesIO(embedded[norm(face)]))
                    issues.append('Originalschrift '+face+' aus der PDF übernommen. Der Editor prüft neue Zeichen gegen den verfügbaren Zeichensatz.')
                if fp:
                    if fp not in font_cache:
                        font_cache[fp] = font_data(fp)
                    font_key += '-'+hashlib.sha256(json.dumps(font_cache[fp],sort_keys=True).encode()).hexdigest()[:8]
                    fonts[font_key] = font_cache[fp]
                    aliases=fonts[font_key].get('unicodeAliases',{})
                    plain=''.join(aliases.get(ch,ch) for ch in raw)
                    if plain!=raw:
                        issues.append('Verbundene Buchstaben anhand der Schrift-Ligaturtabelle in editierbaren Text aufgelöst. Schriftlauf mit der PDF vergleichen.')
                    raw=plain
                    if any(0xe000<=ord(c)<=0xf8ff for c in raw):
                        issues.append('Nicht auflösbare Schmuckbuchstaben erhalten. Textinhalt im Korrekturfeld prüfen.')
                    f = fonts[font_key]['regular']
                    absent = sorted(set(raw)-f['glyphs'].keys())
                    if absent:
                        errors.append('Schrift '+face+': fehlende Zeichen '+repr(''.join(absent)))
                else:
                    errors.append('Schrift fehlt: '+face+'. Schriftdatei ergänzen und PDF erneut einlesen.')
                    f = None
                size = max(1, min(100, group['size']*MM))
                w = sum(f['glyphs'].get(ch, {'a':0})['a'] for ch in raw)*size/f['units'] if f else (max(c['x1'] for c in chars)-min(c['x0'] for c in chars))*MM
                objects.append({'id':key+'-text-'+str(n+1),'type':'text','fieldKey':'text-'+str(n+1),'text':raw,
                    'font':font_key,'bold':False,'size':size,'x':((min(c['x0'] for c in chars)+max(c['x1'] for c in chars))/2-ox)*MM,
                    'y':(page.height-group['baseline']-oy)*MM-size*.35,'w':max(w,.01),'h':size*1.2,'rotation':0,
                    'color':'#e8e9e5','customerEditable':True,'templateOrigin':True})
                if any(abs(c['matrix'][1])>.01 or abs(c['matrix'][2])>.01 for c in chars):
                    errors.append('Gedrehte oder geneigte Textzeile erkannt. Textausrichtung vor Übernahme korrigieren.')
            fragments, points = [], []
            # PDFDevice and pdfplumber use different MediaBox-origin conventions.
            # Align graphics against the same measured product contour.
            vector_ox, vector_oy = ox*MM, oy*MM
            for paint in vector_pages[page_index]:
                ps = [(x*MM,(page.height-y)*MM) for _,cs in paint['path'] for x,y in cs]
                if ps and abs(max(x for x,y in ps)-min(x for x,y in ps)-width)<.15 and abs(max(y for x,y in ps)-min(y for x,y in ps)-height)<.15:
                    vector_ox,vector_oy=min(x for x,y in ps),min(y for x,y in ps)
                    break
            for paint in vector_pages[page_index]:
                pts = [(x*MM-vector_ox, (page.height-y)*MM-vector_oy) for _, coords in paint['path'] for x,y in coords]
                if not pts or not (paint['fill'] or paint['stroke']):
                    continue
                xs, ys = [p[0] for p in pts], [p[1] for p in pts]
                if abs(min(xs))<.16 and abs(min(ys))<.16 and abs(max(xs)-width)<.16 and abs(max(ys)-height)<.16:
                    continue
                commands = []
                for op, coords in paint['path']:
                    if op=='h':
                        commands.append('Z')
                    elif op in ('m','l','c','v','y'):
                        converted = [(x*MM-vector_ox,(page.height-y)*MM-vector_oy) for x,y in coords]
                        if op=='v':
                            converted = [last]+converted
                        if op=='y':
                            converted = converted+[converted[-1]]
                        commands.append(('C' if op in ('v','y') else op.upper())+' '.join(f'{x:.5f} {y:.5f}' for x,y in converted))
                        last = converted[-1]
                    else:
                        errors.append('Nicht unterstützter Vektoroperator: '+op)
                rule = 'evenodd' if paint['evenodd'] else 'nonzero'
                attrs = 'fill="'+('currentColor' if paint['fill'] else 'none')+'" fill-rule="'+rule+'"'
                if paint['stroke']:
                    attrs += ' stroke="currentColor" stroke-width="'+str(round(max(.01,paint['width']*MM),5))+'"'
                fragments.append('<path d="'+' '.join(commands)+'" '+attrs+'/>')
                points.extend(pts)
            if fragments:
                # Bezier handles are not the visible outline. Use actual extrema.
                pen=BoundsPen(None)
                for fragment in fragments:parse_path(fragment.split('"')[1],pen)
                bx0,by0,bx1,by1=pen.bounds
                xs, ys = [bx0,bx1], [by0,by1]
                x,y,w,h = min(xs),min(ys),max(.01,max(xs)-min(xs)),max(.01,max(ys)-min(ys))
                mk = key+'-pdf-vector'
                motifs.append({'key':mk,'name':key+' · PDF-Grafik','category':'Importierte Vorlagen','bounds':[x,y,w,h],'svgFragment':''.join(fragments)})
                objects.append({'id':mk,'type':'motif','motif':mk,'x':x+w/2,'y':y+h/2,'w':w,'h':h,'rotation':0,'color':'#e8e9e5',
                                'customerEditable':True,'templateOrigin':True,'includedInDesign':True,'slateIncluded':True})
            issues.append('Texte und Zeilenfolge mit der Originalansicht vergleichen. Vektorgrafiken können auch in Kurven umgewandelte Schrift enthalten.')
            if len(groups)<2:
                issues.append('Wenig editierbarer Text erkannt: sichtbare Schrift kann als feste Vektorgrafik vorliegen. Bei Bedarf im Editor ersetzen.')
            if len(objects)>20:
                errors.append('Mehr als 20 Elemente erkannt. Textzeilen vor der Übernahme zusammenfassen.')
            for obj in objects:
                over=max(0,obj['w']/2-obj['x'],obj['h']/2-obj['y'],obj['x']+obj['w']/2-width,obj['y']+obj['h']/2-height)
                if .001<over<=.05 and obj['w']<=width and obj['h']<=height:
                    obj['x']=max(obj['w']/2,min(width-obj['w']/2,obj['x']))
                    obj['y']=max(obj['h']/2,min(height-obj['h']/2,obj['y']))
                    issues.append(f'PDF-Rundungsüberstand von {over:.3f} mm am Rand ausgeglichen: '+obj['id'])
                elif over>.001:
                    issues.append('Element am/über dem Rand: '+obj['id']+'. Position/Größe im Editor prüfen.')
            image = rendered[page_index].render(scale=min(2,1200/page.width)).to_pil()
            image.save(out/(str(page_index+1)+'.png'))
            bundle = {'schema':'gravuru-pdf-import/v1','revision':source_hash[:12]+'-'+str(page_index+1),
                'source':{'file':pdf_path.name,'sha256':source_hash,'page':page_index+1},'geometry':{'width':width,'height':height},
                'design':{'id':key,'name':key,'category':'Importierte Designs','collections':[],'photoEngraving':bool(page.images),'customerEditable':True,'marks':[],'objects':objects},
                'resources':{'scope':'local-review-only','fonts':fonts,'motifs':motifs},'issues':list(dict.fromkeys(issues)),'errors':list(dict.fromkeys(errors))}
            (out/(str(page_index+1)+'.json')).write_text(json.dumps(bundle,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
            rows.append({'id':key,'page':page_index+1,'issues':bundle['issues'],'errors':bundle['errors'],'objects':len(objects),'fonts':list(fonts)})
    rendered.close()
    if hashlib.sha256(pdf_path.read_bytes()).hexdigest()!=source_hash:
        raise ValueError('Quelldatei während Import geändert.')
    return {'sourceHash':source_hash,'pages':rows}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for name in ('pdf','out','fonts'):parser.add_argument('--'+name,required=True)
    for name in ('width','height'):parser.add_argument('--'+name,type=float,required=True)
    args=parser.parse_args()
    out,fonts=Path(args.out),Path(args.fonts)
    out.mkdir(parents=True,exist_ok=True);fonts.mkdir(parents=True,exist_ok=True)
    print(json.dumps(convert(Path(args.pdf),out,args.width,args.height,fonts),ensure_ascii=True))
