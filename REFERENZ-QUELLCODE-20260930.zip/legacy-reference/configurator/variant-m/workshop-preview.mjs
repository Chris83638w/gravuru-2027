// Mounted only after the workshop's existing login and origin checks.
import fs from 'node:fs';
import path from 'node:path';
import {build,HERE,ROOT,OUTPUT} from './build.mjs';
export function createWorkshopPreview({embedded=false}={}){
 const outputDirectory=path.join(OUTPUT,'workbench');build({outputDirectory});
 const aliases={'/produkt-konfigurator.html':path.join(HERE,'index.html'),'/variant-m-models.json':path.join(outputDirectory,'models.json'),'/variant-m-editor.html':path.join(outputDirectory,'editor.html'),'/assistant.js':path.join(outputDirectory,'assistant.js'),'/api/guides':path.join(outputDirectory,'guides.json'),'/labrador/michroma-vectors.json':path.join(ROOT,'designs/aosu-labrador/assets/michroma-vectors.json'),'/labrador/motif.json':path.join(ROOT,'designs/aosu-labrador/motif.json')};
 const prefixes=[['/_runtime/',path.join(ROOT,'designs/aosu-labrador/runtime')],['/platform/sources/app/shared/',path.join(ROOT,'platform/sources/app/shared')],['/configurator/variant-m/',HERE]];
 return (req,res,url)=>{
  let file=aliases[url.pathname];const match=prefixes.find(([prefix])=>url.pathname.startsWith(prefix));if(!file&&!match)return false;
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405).end();return true;}
  if(match){const [prefix,base]=match,rel=decodeURIComponent(url.pathname.slice(prefix.length));if(!rel||rel.split(/[\\/]/).some(s=>s==='..'||s.startsWith('.'))||!(/\.(mjs|js|css)$/.test(rel)||prefix==='/_runtime/')){res.writeHead(404).end();return true;}file=path.resolve(base,rel);const relative=path.relative(fs.realpathSync(base),fs.realpathSync(file));if(relative.startsWith('..')||path.isAbsolute(relative)){res.writeHead(404).end();return true;}}
  let bytes=fs.readFileSync(file);if(url.pathname==='/produkt-konfigurator.html')bytes=Buffer.from(bytes.toString().replaceAll("'/models.json'","'/variant-m-models.json'").replaceAll("'/editor.html'","'/variant-m-editor.html'"));
  const mime={'.html':'text/html','.json':'application/json','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.txt':'text/plain'};
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...(embedded?{}:{'X-Frame-Options':'SAMEORIGIN'})});res.end(req.method==='HEAD'?undefined:bytes);return true;
 };
}

