# Kreuze – Übersicht der Bestandsdesigns

151 Designs (dazu 3 Varianten desselben Designs in anderer Form/Farbe/Material, in der Excel als „Variante von“), vorsortiert nach Zielgruppe und Unterkategorie. Unter jedem Bild: Schlüssel · Sicherheit der Zuordnung · Materialien. Korrekturen in [`KREUZE-DESIGNS.xlsx`](KREUZE-DESIGNS.xlsx).

Sprungmarken: [Allgemein – Allgemein (85)](#allgemein-allgemein) · [Anlass – Geburtstag (1)](#anlass-geburtstag) · [Anlass – Liebe (6)](#anlass-liebe) · [Familie – Kinder (9)](#familie-kinder) · [Familie – Paar (1)](#familie-paar) · [Sprüche – Spruch (19)](#spr-che-spruch) · [Tiere – Hund (6)](#tiere-hund) · [Tiere – Katze (3)](#tiere-katze) · [Tiere – Tiere allgemein (2)](#tiere-tiere-allgemein) · [Trauer – Gedenken (1)](#trauer-gedenken) · [Trauer – Sternenkind (2)](#trauer-sternenkind) · [offen – offen (16)](#offen-offen)

## Allgemein – Allgemein

85 Designs

![Allgemein – Allgemein](_uebersicht/Allgemein-Allgemein-1.png)

![Allgemein – Allgemein](_uebersicht/Allgemein-Allgemein-2.png)

## Anlass – Geburtstag

1 Designs

![Anlass – Geburtstag](_uebersicht/Anlass-Geburtstag.png)

## Anlass – Liebe

6 Designs

![Anlass – Liebe](_uebersicht/Anlass-Liebe.png)

## Familie – Kinder

9 Designs

![Familie – Kinder](_uebersicht/Familie-Kinder.png)

## Familie – Paar

1 Designs

![Familie – Paar](_uebersicht/Familie-Paar.png)

## Sprüche – Spruch

19 Designs

![Sprüche – Spruch](_uebersicht/Sprüche-Spruch.png)

## Tiere – Hund

6 Designs

![Tiere – Hund](_uebersicht/Tiere-Hund.png)

## Tiere – Katze

3 Designs

![Tiere – Katze](_uebersicht/Tiere-Katze.png)

## Tiere – Tiere allgemein

2 Designs

![Tiere – Tiere allgemein](_uebersicht/Tiere-Tiere allgemein.png)

## Trauer – Gedenken

1 Designs

![Trauer – Gedenken](_uebersicht/Trauer-Gedenken.png)

## Trauer – Sternenkind

2 Designs

![Trauer – Sternenkind](_uebersicht/Trauer-Sternenkind.png)

## offen – offen

16 Designs

![offen – offen](_uebersicht/offen-offen.png)

