# Variante M: Platz, Listen und Textgrenzen

Stand: 25.09.2026. Lokale Umsetzung auf `feat/variante-m-profile-20260924`,
Ausgangscommit `4e654aa01c2462c2d480140d351f017dc2f31318`.
Keine Shopify-/Plesk-Änderung, kein Merge nach main oder in den Koordinationsbranch.

## Verbindliche Entscheidungen

- Optionen vor Designs, danach Text, Motive, Foto/Logo. Optionen beim Einstieg aktiv;
  kein Gestaltungsobjekt automatisch ausgewählt.
- Ganze Schriftgrößen von mindestens 4 mm; Minus/Plus verändern um genau 1 mm.
  Gemeint ist die nominale Schriftgröße, nicht die individuelle sichtbare Glyphenhöhe.
- Gravur darf bis an die tatsächliche Gestaltungsfläche reichen: Randabstand 0 mm.
- Der rechte Regler vergrößert die vollständige Produktvorschau durch mehr Canvasplatz;
  keine Änderung von Produktmaßen oder Elementen, kein Ausschnittzoom.
- Weiter/Fertig entfernt. Desktop weiterhin Vorschau und Bedienung nebeneinander.

## Änderungen

- Überschrift im Canvas, kleinere Zurück-/Speichernflächen, kompaktere Textfelder
  bei 16 px Eingabetext auf Mobilgeräten. Hilfslinien links unten im Canvas.
- Designkarten ohne wiederholte Rahmenuntertitel, kleinere Abstände. Die echte
  Rahmenauswahl bleibt in Optionen erhalten. Alle 17 AOSU-Designs vertikal scrollbar.
- Alle 31 Schriften in einer vertikalen Liste, jeweils mit aktueller Textprobe.
- Bestseller und Motivsuche mit begrenzter vertikaler Listenhöhe. Mehr/Weniger als
  schmale Leiste am unteren Rand. Suchmotive werden beim Scrollen nachgeladen.
- Keine Kategoriepfeile; Kategorieauswahl und vorhandener Wischwechsel bleiben.
- Motivzahl aus dem tatsächlich verwendeten Katalog (722 im AOSU-Prüfmodell),
  verständliche Such-Rücksetzung und Vorschläge bei leeren Ergebnissen.
- Motivpreis: enthaltene Vorlagenmotive und zusätzliche Motive (+1,69 EUR) getrennt
  erklärt. Preisdetails zeigen gewählte Optionsnamen statt interner Kennungen.
- Text außerhalb der Fläche wird im Textfeld und Canvas kenntlich gemacht.
  „Text passend verkleinern“ arbeitet nur auf ausdrücklichen Klick, erhält Position
  und Drehung und unterschreitet 4 mm nicht. Passt auch 4 mm nicht, Hinweis zum
  Kürzen/Verschieben. Die alte automatische Größen-/Positionskorrektur wird für
  Texte unterbunden, damit Änderungen und Warnungen nachvollziehbar bleiben.
- Randprüfung verwendet gemessene Textpfade und berücksichtigt Drehung sowie
  rechteckige/elliptische Fläche. AOSU: tatsächliche Acrylfläche des gewählten Rahmens.
- SVG-IDs getrennt für Hauptbild, Miniatur und Karten. Keine doppelten IDs im
  geprüften DOM. Alter ausgeblendeter Wizard bleibt wegen Rendererabhängigkeiten
  vorhanden, aber inert und ohne doppelte Live-/Statusankündigungen.
- Hilfe und Bedienungsdialoge schließen sich gegenseitig; Escape funktioniert.
  Hilfsvorschläge sind Fragen, keine angeblich ausgeführten Gestaltungsaktionen.
  Lokaler Testmodus kennzeichnet die fehlende KI-Verbindung. Kontaktkonfiguration
  vorbereitet, ohne erfundene Telefonnummer, Mailadresse oder WhatsApp-Adresse.

## Tatsächlich ausgeführte Prüfungen

Browser am lokalen Server `http://127.0.0.1:8947/`, Chromium/In-App-Browser:

- 390 × 844: Reihenfolge, Canvasüberschrift, keine anfängliche Objektauswahl,
  vollständiges Produkt. Regler von Anfang bis Ende verändert den Produkthalter von
  etwa 160 × 280 auf 232 × 406 CSS-Pixel, ohne das Produkt zu beschneiden.
- Langer Text „Müller-Lüdenscheidt-Schwarzenberger“ mit 20 mm bleibt zunächst bei
  20 mm und erhält die Randwarnung. Manuelle Anpassung auf 5 mm beseitigt die
  Warnung bei der geprüften Position. Ganzzahlfeld und Minus/Plus bedient.
- Keine horizontale Seitenerweiterung im geprüften mobilen Langtextfall
  (`clientWidth = scrollWidth = 375`).
- Schriftwahl: 31 Einträge in einer Spalte; 464 px sichtbare Höhe und 2328 px
  Inhaltshöhe. Escape schließt die Auswahl. Keine Seitennavigation nötig.
- Designliste und untere Mehr-/Weniger-Leiste geprüft. Motivliste durch reales
  Tastatur-Scrollen von 6 auf 12 von 722 erweitert, ohne Fokus auf erste neue Karte.
- Suchleerzustand und Rücksetzangebot geprüft; klarer zusätzlicher Motivpreis.
- 1280 × 960: Desktop nebeneinander, keine Kategoriepfeile, Preisdetails und
  Escape. Hilfe geöffnet; anschließendes Speichern öffnet nur den Kontodialog und
  schließt den Assistenten. Fragen und Kontaktplatzhalter tatsächlich sichtbar.
- Schieferprofil zusätzlich geöffnet: 300 × 200 mm, 29,99 EUR, bekannte Optionen
  und sieben Inhalte ohne Laufzeitfehler. Kein vollständiger Profil-Regressionslauf.
- Keine neuen Browserfehler in der abschließenden Prüfung nach den Korrekturen.

Automatisch:

```sh
node --test configurator/variant-m/contract.test.mjs configurator/variant-m/ux.test.mjs configurator/variant-m/image-processing.test.mjs configurator/variant-m/usability.test.mjs automation/product-pipeline/tests/pipeline.test.mjs
node configurator/variant-m/build.mjs
```

49 Tests erfolgreich. Build: 104 Originalressourcen gegen bestehende SHA-256-Werte
geprüft. Originalreferenz, Profil-IDs, Produktbindungen und Preisvorgaben unverändert.
Vier zusätzliche Tests sichern Ganzzahlschritte/Mindestgröße, exakte Kante bei
wechselnder Fläche, Rotation/Ellipse und Nicht-Unterschreiten von 4 mm beim Einpassen.

## Grenzen und nächster Schritt

- Lokaler Browsernachweis, kein physisches Smartphone und kein Safari/iOS-Nachweis.
  Nicht pauschal alle Bedienelemente auf 44 px oder alle Materialien neu abgenommen.
- Der Vorschau-Regler ist durch die verfügbare Breite begrenzt; bei bereits maximal
  breiten Produkten kann kein weiterer Größenzuwachs ohne Beschneiden erreicht werden.
- Textgrenzen prüfen die Außenfläche, nicht Bohrungen, Klingelüberdeckung oder alle
  Produktionsregeln. Bei Ellipsen wird konservativ das gedrehte Textrechteck geprüft.
- `el.uxValidateDesign()` liefert clientseitige Textprobleme für einen späteren
  Bestelladapter. Dies ist kein serverseitiger Freigabenachweis. Warenkorb weiterhin
  deaktiviert, Kontospeicherung/geschützte Uploads/PNG nach Kauf noch nicht verbunden.
- Lokale Direkthilfe bleibt regelbasiert. Persönlicher KI-Dienst und echte
  Teamkontaktdaten sind weiterhin offen. Keine neue externe Freistell-API.
- Bestehende Werkzeuge/Originaldateien bleiben erhalten. Keine historischen Backups
  ergänzt. Fremde unversionierte Dateien unter `products/` nicht aufgenommen.

Nächster Schritt: Christopher prüft die überarbeitete lokale Bedienung. Echte
Bestell-/Kontoverbindung und Produktionsprüfung gesondert fortsetzen.

