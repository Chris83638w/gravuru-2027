# Fünf Bearbeitungsprofile zu Produkten zuordnen

Stand: 27.09.2026. Nutzerwunsch: fünf wiederverwendbare Profile, später per Auswahl den Produkten zuordnen. Keine fünf zusätzlichen Konfiguratoren und keine duplizierten Shopify-Produkte erforderlich.

## Vorhandene Umsetzung

Aktueller Quellstand der Produktverwaltung gelesen: `feat/variante-m-profile-20260924`, `cdb598be71e171c51f938c0812c85a68fb28514d`. Die gewünschte Auswahl und dauerhafte Produktzuordnung sind bereits vorhanden. Deshalb wurden weder zusätzliche IDs noch parallele Profilspeicher angelegt.

| Auswahl | Stabile Profil-ID | Standarddarstellung |
|---|---|---|
| Gravur auf Edelstahl | steel-engraving | Dunkel/schwarz, #191919 |
| Gravur auf Holz | wood-engraving | Braun, #49301d |
| Gravur auf Schiefer | slate-engraving | Hellgrau, #e8e9e5 |
| Gravur auf Acrylglas | acrylic-engraving | Grauweiß, #e1e4e5 |
| UV-Druck | color-print | Vollfarbe; Standard #202824 ohne eigene Elementfarbe |

Die zentrale Definition liegt in `platform/sources/app/shared/models/processing-profiles.mjs`. Dies sind Bearbeitungs-/Vorschauprofile, keine Laserleistungs- oder Maschineneinstellungen.

## Verwendung in der Produktverwaltung

1. Bestehende Shopify-App „Gravuru Konfigurator“ öffnen: https://admin.shopify.com/store/gravuru-design/apps/gravuru-konfigurator
2. Ein vorhandenes Produkt öffnen oder ein neues Produkt anlegen.
3. Material wählen, dann im Feld **Bearbeitungsverfahren** das passende Profil auswählen. Die statische Grundseite nennt das Feld zunächst „Material & Verfahren“; die geladene Bibliotheksoberfläche beschriftet es als „Bearbeitungsverfahren“.
4. Produktdaten speichern. Gespeichert wird die Profil-ID in `data.processing`; der Produktkonfigurator erhält daraus `profile.processing.profileId`.
5. Beim Wechsel von Material/Verfahren werden bestehende Designs zur erneuten Prüfung markiert. Produktmaße, Bohrbilder und vorhandene Entwürfe nicht durch Materialdemos ersetzen.

Die Materialbibliothek hat zusätzlich ein Feld **Verfahren** als Standard pro Material. Bei Auswahl dieses Materials wird dieser Standard ins Produktformular übernommen. Dort kann z. B. UV-Druck auf dem gewählten Material eingestellt werden. Gravurprofile müssen zum Material passen; der Server prüft diese Kombination. Foto-Freigabe, Produktgeometrie, Stärke, Befestigung und Designzuordnung bleiben eigene Produktangaben.

## Druckfarben

Vorhandene Palette in `configurator/variant-m/usability-model.mjs`:
- Standard: Schwarz, Weiß, Grau, Rot, Orange, Gelb, Grün, Blau, Violett, Pink, Braun, Türkis.
- Pastell: Rosé, Pfirsich, Vanille, Mint, Salbei, Himmelblau, Lavendel, Sand.
- Zusätzlich eigene Farbe sowie Originalfarben für Motive/Logos.
- Fotos werden nicht durch die Elementfarbauswahl pauschal eingefärbt.

## Prüfnachweis und Grenzen

Aktuelle GitHub-Quellen gezielt gelesen: Produktformular, Formularinitialisierung, Materialbibliothek, Produktvalidierung/Speicherung und Konfigurator-Konfiguration. Die API liefert alle fünf Profiloptionen; das Formular baut die Auswahl daraus auf, und der Backend-Vertrag speichert die gewählte ID. Keine neue Implementierung dafür nötig.

In der bestehenden lokalen Bedienfassung auf Basis `89e6c5dd801400b9eaf6f06215f9b24b6149860c` ausgeführt:

```text
node --test configurator/variant-m/contract.test.mjs configurator/variant-m/usability.test.mjs
```

Ergebnis: **23 Tests bestanden, 0 Fehler**. Darunter Akzeptanz aller fünf Profile unabhängig von Foto-Freigabe, Produkt-/Revisionsbindung, unveränderte Geometrie, Originalfarben und Farbauswahl. Dies ist kein vollständiger Regressionstest des neueren Serverbranches.

Die tatsächliche Produktverwaltungsseite auf gravuru-designwerkstatt.de wurde geöffnet. Sie verlangt den Einstieg über die Shopify-App; der App-Einstieg zeigt aktuell die Anmeldung. Daher in diesem Lauf **keine authentifizierte Live-Auswahl oder Speicherung nachgewiesen**. Keine Produktdatensätze verändert. Nach Anmeldung genau eine passende Produktzuordnung prüfen; keine Testprodukte im echten Katalog anlegen.

Status: vorhandene Umsetzung geprüft und dokumentiert, kein Codewechsel/Deployment erforderlich oder durchgeführt. Keine Änderung von main, Shopify, Plesk, Kundeninhalten oder existierenden lokalen Entwürfen. Der noch offene echte Warenkorb bleibt ein separates Arbeitspaket.

