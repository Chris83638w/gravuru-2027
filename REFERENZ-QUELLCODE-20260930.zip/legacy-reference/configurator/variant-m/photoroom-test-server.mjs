import http from 'node:http';
import {readFileSync} from 'node:fs';
import {randomBytes} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {boundedBytes,createSandbox,MAX_INPUT} from './photoroom-sandbox.mjs';

export function createTestServer({sandbox=createSandbox()}={}){
  const token=randomBytes(32).toString('hex');
  const html=readFileSync(new URL('./photoroom-test.html',import.meta.url)),js=readFileSync(new URL('./photoroom-test-client.mjs',import.meta.url));
  const server=http.createServer(async(req,res)=>{
    const port=server.address().port,origin='http://127.0.0.1:'+port;
    const send=(status,data,type='application/json')=>res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; img-src blob:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"}).end(type==='application/json'?JSON.stringify(data):data);
    try{
      if(req.headers.host!=='127.0.0.1:'+port||req.headers.origin&&req.headers.origin!==origin||req.headers['sec-fetch-site']==='cross-site')return send(403,{error:'Zugriff nur von der lokalen Testseite.'});
      if(req.method==='GET'&&req.url==='/')return send(200,html,'text/html; charset=utf-8');
      if(req.method==='GET'&&req.url==='/client.mjs')return send(200,js,'text/javascript; charset=utf-8');
      if(req.method==='GET'&&req.url==='/api/status')return send(200,{...sandbox.status(),token});
      if(req.method!=='POST')return send(404,{error:'Nicht gefunden.'});
      if(req.headers['x-gravuru-token']!==token)return send(403,{error:'Bitte die Testseite neu laden.'});
      if(req.url==='/api/connect'){
        if(req.headers['content-type']!=='application/json')return send(415,{error:'Falsches Format.'});
        let data;try{data=JSON.parse(await boundedBytes(req,2048));}catch{return send(400,{error:'Die Eingabe konnte nicht gelesen werden.'});}
        sandbox.configure(data.key);return send(200,sandbox.status());
      }
      if(req.url==='/api/disconnect'){sandbox.disconnect();return send(200,sandbox.status());}
      if(req.url==='/api/remove'){
        if(!['image/png','image/jpeg','image/webp'].includes(req.headers['content-type']))return send(415,{error:'Bitte PNG, JPG oder WebP verwenden.'});
        const bytes=await boundedBytes(req,MAX_INPUT),result=await sandbox.remove(bytes);return send(200,result,'image/png');
      }
      return send(404,{error:'Nicht gefunden.'});
    }catch(error){return send(error.status||500,{error:error.status?error.message:'Der Test konnte nicht abgeschlossen werden.'});}
  });
  server.requestTimeout=90000;server.headersTimeout=10000;return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
  const port=Number(process.argv.find(v=>v.startsWith('--port='))?.slice(7)||8965);
  if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Ungültiger Port');
  createTestServer().listen(port,'127.0.0.1',()=>console.log('Photoroom-Testseite: http://127.0.0.1:'+port+'/ (nur Sandbox; Schlüssel und Fotos nur im Arbeitsspeicher)'));
}
