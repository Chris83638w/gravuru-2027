// Read-only verification of the scoped handover, not of unrelated repository work.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(process.argv.find(a=>a.startsWith('--root='))?.slice(7)||path.join(here,'../..'));
const allowFinalNewline=process.argv.includes('--allow-final-newline');
const manifest=JSON.parse(fs.readFileSync(path.join(here,'HANDOVER-SOURCES.json'),'utf8'));
if(manifest.schema!=='gravuru-configurator-handover/v1'||!Array.isArray(manifest.entries))throw Error('Unbekanntes Übergabeinventar.');
const sha=b=>createHash('sha256').update(b).digest('hex');
const failures=[],formatting=[];let exact=0;
for(const item of manifest.entries){
 if(path.isAbsolute(item.path)||item.path.split(/[\\/]/).some(p=>p==='..'||!p))throw Error('Ungültiger Inventarpfad.');
 try{
  const bytes=fs.readFileSync(path.join(root,item.path));
  if(bytes.length===item.bytes&&sha(bytes)===item.sha256){exact++;continue;}
  // Historical targeted downloads appended one LF. Never relax binary checks.
  if(allowFinalNewline&&item.localFormattingOnly&&bytes.length===item.bytes+1&&bytes.at(-1)===10&&sha(bytes.subarray(0,-1))===item.sha256){formatting.push(item.path);continue;}
  failures.push({path:item.path,error:'Größe oder SHA-256 abweichend'});
 }catch(e){failures.push({path:item.path,error:e.code||e.message});}
}
console.log(JSON.stringify({sourceCommit:manifest.sourceCommit,expected:manifest.entries.length,exact,finalNewlineOnly:formatting.length,failures},null,2));
if(failures.length)process.exitCode=1;
