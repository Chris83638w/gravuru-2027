# Auftrag an ChatGPT · Design-Set „Hausnummern- und Namensschilder“ (Acrylglas, Abstandshalter)

Du gestaltest Gravur-Designs für unsere Acrylglas-Schilder mit Abstandshaltern (Familien AA = anthrazit 5 mm, AS = schwarz 5 mm, S/S = satiniert 3 mm mit schwarzer Rückplatte). Alle drei Familien haben **dieselben Plattenmaße und Bohrbilder**; ein Design gilt für alle drei. Form, Größe, Löcher und Preise sind festgelegt – du gestaltest nur Text und Motiv.

## Was mitgeliefert ist
- `briefing-ss/BRIEFING.md` – verbindliche Regeln, Größenliste, Lieferformat (gilt für AA/AS genauso; `briefing-aa/` ohne Rückplatte).
- `briefing-ss/schablonen/<SKU>.svg` – je Größe die Platte in Endmaß mit **allen Bohrbildern** (2 Abstandshalter seitlich und 4 in den Ecken) samt Schutzzonen (gestrichelte Kreise) und gestrichelter blauer Rückplatte. Texte müssen außerhalb **aller** Schutzzonen liegen, weil jede Größe mit 2 oder 4 Abstandshaltern verkauft wird. Motive dürfen über Löcher gehen.
- `briefing-ss/schriften.txt` – die einzigen zugelassenen Schriften, Namen exakt so verwenden.
- `stilreferenz-beispiele.png` – unsere 19 Beispiele (Stil, Aufteilung, Themen). **Nicht übernehmen, sondern neu in den richtigen Formaten aufbauen.** Diese Beispiele waren 190 × 80 mm; diese Größe gibt es nicht.
- Motive: zwei Quellen. (a) Die **eigenen Motive des Nutzers**, die er mit den Designs liefert (wie in den 19 Beispielen: Pusteblume, Baum, Anker, Leuchtturm, Herzen, Haus, Pfoten, Hund, Katze, Familie …) – sie **gehören zum Design** und bleiben als `deko-<name>` darin; sie kommen **nicht** in die allgemeine Bibliothek. (b) Die allgemeine Bibliothek `motive/` im Katalog-Repo (721 Vektoren in 47 Kategorien, Übersicht `motive/INDEX.md`) – unverändert einsetzen, Dateiname nennen. Keine neuen Motive erfinden.

## Was du lieferst
Je Designidee **ein Master pro Formatreihe**, gezeichnet in der kleinsten Größe der Reihe – daraus rechnen wir alle anderen Größen automatisch:

| Reihe | Master-Schablone | ergibt später |
| --- | --- | --- |
| 3:2 (Pflicht) | `SS-RE-150X100.svg` (15 × 10 cm) | 18 × 12, 24 × 16, 30 × 20, 36 × 24, 42 × 28; R5-Varianten; Oval 3:2 und eingezogene Ecken, wenn die Ecken frei bleiben |
| 3:1 (Pflicht) | `SS-RE-210X70.svg` (21 × 7 cm) | 27 × 9, 36 × 12, 45 × 15 |
| 15:8 oval (wenn das Motiv passt) | `SS-OV-150X80.svg` (15 × 8 cm) | 22,5 × 12, 30 × 16 |
| 1:1 (wenn das Motiv passt) | `SS-RE-160X160.svg` (16 × 16 cm) | 20 × 20, 26 × 26, 30 × 30 |

Beim 3:2-Master die **Ecken frei halten** (keine Texte in den äußeren 15 mm der Ecken), dann läuft er auch auf Oval und eingezogene Ecken.

## Lieferform (eine von beiden)
1. **Corel-Bogen** wie `Beispiele.pdf`: eine PDF-Seite je Formatreihe, je Design eine graue Platte im **echten Mastermaß**, dahinter die dunkle Rückplatte (+10 mm rundum), rote Kreise Ø 8 an den Lochpositionen der Schablone, Gestaltung weiß. Wir zerlegen den Bogen automatisch.
2. **Ordner je Design** (`design.svg` mit Ebenen `text-<n>`, `motiv-<n>`, `deko-<n>`; Details im BRIEFING).

## Regeln, die der Testlauf gezeigt hat
- **Text bleibt Text** – nichts in Kurven/Pfade umwandeln. Nur so wird daraus ein Kundenfeld.
- **Straße und Hausnummer als getrennte Textobjekte**, ebenso „Familie“ und Nachname, wenn sie unterschiedlich gesetzt sind.
- Platzhalter: je Design eine **andere Hausnummer**; Namen dürfen gleich bleiben (z. B. Niemann).
- Keine leeren Textobjekte auf der Platte.
- Nur Schriften aus `schriften.txt`. Andere Schriften erst, wenn wir sie freigegeben haben.
- Benennung: je Design eine Kennung `hn-<thema>-<nn>` (z. B. `hn-anker-01`), als Liste `designs.csv` (Kennung; Thema; Reihen) mitliefern oder als kleine Beschriftung **außerhalb** der Platte auf dem Bogen.

## Abnahme
Wir prüfen automatisch: Text als Text, Schriften, Lage zu Schutzzonen, Kontur je Zielgröße (Oval/eingezogene Ecken), und erzeugen je Design eine Übersicht aller Größen. Was „passt nicht“ meldet, kommt mit Begründung zurück.
