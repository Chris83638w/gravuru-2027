"""Bounded Corel PDF pilot. Requires pdfplumber and fonttools; writes local data only."""
import argparse, hashlib, json
from pathlib import Path
import pdfplumber
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen

MM=25.4/72
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def font_data(path):
    f=TTFont(path);glyphset=f.getGlyphSet();cmap=f.getBestCmap();glyphs={}
    # Reusable Latin/European text, punctuation, euro and memorial date symbols.
    codes=set(range(32,592))|set(range(0x2000,0x2070))|{0x20ac,0x2122}
    for code in sorted(codes&cmap.keys()):
        name=cmap[code];pen=SVGPathPen(glyphset);glyphset[name].draw(pen)
        glyphs[chr(code)]={'a':f['hmtx'][name][0],'d':pen.getCommands()}
    return {'category':'Originalvorlage','regular':{'units':f['head'].unitsPerEm,'glyphs':glyphs}}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pdf',required=True);ap.add_argument('--allura',required=True);ap.add_argument('--centaur',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    src=Path(args.pdf);out=Path(args.output)
    if src.stem!='GT-S-22x14-D201':raise ValueError('Dieser geprüfte Musterimport gilt ausschließlich für D201.')
    if out.exists():raise ValueError('Vorhandene Revision nicht überschreiben. Neuen Ausgabeordner verwenden.')
    source_hash=digest(src)
    with pdfplumber.open(src) as pdf:
        if len(pdf.pages)!=1:raise ValueError('Genau eine Seite erwartet.')
        p=pdf.pages[0]
        contours=[c for c in p.curves+p.rects if abs(c['width']*MM-220)<.02 and abs(c['height']*MM-140)<.02]
        if len(contours)!=1 or len(p.images)!=1:raise ValueError('Kontur oder Fotobereich nicht eindeutig.')
        contour=contours[0];ox=contour['x0'];oy=contour['top']
        lines=p.extract_text_lines(return_chars=True)
        if [x['text'] for x in lines]!=['Snow','*20.12.2012 - † 18.05.2019','Danke für Deine Liebe,','dein Vertrauen und deine Treue.','Du wirst so unendlich doll','vermisst, mein Großer.']:raise ValueError('D201-Textaufbau weicht vom geprüften Muster ab.')
        fonts={'Centaur':font_data(args.centaur),'Allura':font_data(args.allura)}
        def text_object(group,key,font):
            first=group[0];size=round(first['chars'][0]['size']*MM)
            baselines=[(p.height-x['chars'][0]['matrix'][5]-oy)*MM for x in group]
            text='\n'.join(x['text'] for x in group)
            for ch in text.replace('\n',''):
                if ch not in fonts[font]['regular']['glyphs']:raise ValueError('Fehlendes Schriftzeichen '+repr(ch))
            o={'id':'GT-S-22x14-D201-'+key,'type':'text','fieldKey':key,'text':text,'font':font,'size':size,'bold':False,'x':round(sum((x['x0']+x['x1'])/2 for x in group)/len(group)*MM-ox*MM,5),'y':round(sum(baselines)/len(group)-size*.35,5),'w':1,'h':len(group)*size*1.2,'rotation':0,'color':'#e8e9e5','customerEditable':True,'templateOrigin':True}
            f=fonts[font]['regular'];o['w']=max(sum(f['glyphs'][ch]['a'] for ch in line) for line in text.split('\n'))*size/f['units']
            return o
        img=p.images[0]
        photo={'id':'GT-S-22x14-D201-photo','type':'photoSlot','fieldKey':'photo-01','photoShape':'rect','required':True,'x':round(((img['x0']+img['x1'])/2-ox)*MM,5),'y':round(((img['top']+img['bottom'])/2-oy)*MM,5),'w':round((img['x1']-img['x0'])*MM,5),'h':round((img['bottom']-img['top'])*MM,5),'rotation':0,'color':'#e8e9e5','customerEditable':True,'templateOrigin':True}
        curves=[c for c in p.curves if c is not contour]
        if len(curves)!=3 or any(not c['fill'] or c['stroke'] for c in curves):raise ValueError('Herzmotiv weicht vom geprüften Muster ab.')
        x0=min(c['x0'] for c in curves);y0=min(c['top'] for c in curves);x1=max(c['x1'] for c in curves);y1=max(c['bottom'] for c in curves)
        fragments=[]
        for c in curves:
            commands=[]
            for segment in c['path']:
                op=segment[0]
                if op=='h':commands.append('Z');continue
                if op not in ('m','l','c'):raise ValueError('Nicht unterstützter Motivpfad.')
                coords=[f'{(pt[0]-ox)*MM:.6f} {(pt[1]-oy)*MM:.6f}' for pt in segment[1:]]
                commands.append(op.upper()+' '.join(coords))
            rule='evenodd' if c.get('evenodd') else 'nonzero'
            fragments.append('<path d="'+' '.join(commands)+'" fill="currentColor" fill-rule="'+rule+'"/>')
        key='GT-S-22x14-D201-double-heart'
        # pdfplumber separates the three subpaths of this one even-odd PDF fill.
        # Keep them compound so the two inner hearts remain transparent holes.
        compound=' '.join(fragment.split('"')[1] for fragment in fragments)
        motif={'key':key,'name':'D201 · Doppelherz','category':'Importierte Vorlagen','bounds':[(x0-ox)*MM,(y0-oy)*MM,(x1-x0)*MM,(y1-y0)*MM],'svgFragment':'<path d="'+compound+'" fill="currentColor" fill-rule="evenodd"/>'}
        heart={'id':'GT-S-22x14-D201-heart','type':'motif','motif':key,'x':((x0+x1)/2-ox)*MM,'y':((y0+y1)/2-oy)*MM,'w':(x1-x0)*MM,'h':(y1-y0)*MM,'rotation':0,'color':'#e8e9e5','customerEditable':True,'templateOrigin':True,'includedInDesign':True,'slateIncluded':True}
        objects=[photo,text_object(lines[:1],'name','Centaur'),text_object(lines[1:2],'dates','Allura'),heart,text_object(lines[2:],'quote','Allura')]
    bundle={'schema':'gravuru-local-pdf-pilot/v1','revision':'D201-20260927-'+out.name,'source':{'file':src.name,'sha256':source_hash,'pdfPageMm':[round(p.width*MM,5),round(p.height*MM,5)],'contourOriginMm':[ox*MM,oy*MM],'fonts':[{'name':n,'sha256':digest(path),'scope':'local-review-only'} for n,path in [('Allura',args.allura),('Centaur',args.centaur)]]},'geometry':{'width':220,'height':140},'design':{'id':src.stem,'name':'D201 · Snow','category':'Gedenktafeln','collections':['22 × 14 cm','Fotogravur'],'photoEngraving':True,'customerEditable':True,'marks':[],'objects':objects},'resources':{'scope':'local-review-only','fonts':fonts,'motifs':[motif]},'notes':['Schriftgrößen gemäß bestehender Bedienregel auf ganze Millimeter gerundet; Zeilenabstand des Spruchs folgt dem bestehenden Renderer.','Fotobeispiel wird nicht übernommen; die ganze Bitmapfläche wird zum austauschbaren Fotofeld.','Schriftressourcen ausschließlich für lokale Prüfung; kein öffentlicher Font-Upload.']}
    if digest(src)!=source_hash:raise ValueError('Originaldatei während Import geändert.')
    out.mkdir(parents=True)
    (out/'pilot.json').write_text(json.dumps(bundle,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    (out/'IMPORT-NACHWEIS.json').write_text(json.dumps({k:v for k,v in bundle.items() if k!='resources'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(out/'pilot.json'),'objects':len(objects),'fonts':list(fonts),'originalUnchanged':True}))
if __name__=='__main__':main()

