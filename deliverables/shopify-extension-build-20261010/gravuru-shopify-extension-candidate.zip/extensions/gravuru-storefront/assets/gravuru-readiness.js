/* Product-scoped readiness, shared by the launcher and its regression tests. */
(function(root){'use strict';
 const isReady=b=>!!b&&b.ready!==false&&/^\d+$/.test(b.productId)&&/^https:\/\/gravuru-designwerkstatt\.de\/produktvorschau\/[a-f0-9]{48}\/$/.test(b.url)&&Array.isArray(b.variants)&&b.variants.length>0&&b.variants.every(id=>/^\d+$/.test(id));
 function readBinding(doc,productId){
  for(const node of doc.querySelectorAll('[data-gravuru-binding]')){
   try{const value=JSON.parse(node.textContent);if(value.productId===productId&&isReady(value))return value;}catch{}
  }
  return null;
 }
 async function waitForBinding({initial,readNext,pause=ms=>new Promise(resolve=>setTimeout(resolve,ms)),attempts=80}){
  if(isReady(initial))return initial;
  for(let attempt=0;attempt<attempts;attempt++){
   await pause(Math.min(3000+attempt*2000,15000));
   try{const next=await readNext();if(next?.productId===initial.productId&&isReady(next))return next;}catch{}
  }
  throw Error('Die Bereitstellung dauert länger als erwartet. Bitte die Produktseite später erneut öffnen.');
 }
 const api={isReady,readBinding,waitForBinding};
 if(typeof module==='object'&&module.exports)module.exports=api;else root.GravuruReadiness=api;
})(typeof window==='undefined'?globalThis:window);
