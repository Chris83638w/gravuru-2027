# Gravuru – verbindliche Arbeitsreferenz für neue Produktbeispiele

Stand: 17.09.2026. Sammlung Revision 5. Bilder mit der integrierten ChatGPT-Bildfunktion (image_gen), keine CLI-Bildgenerierung.

## Maße und Konturen

Die Produkt-Excel und die vorhandenen Produktvorlagen sind maßgeblich. Form, Größe, Rundungen und Bohrungen unverändert übernehmen. 8 mm war nur ein Beispiel, keine allgemeine Bohrlochregel.

## Stärke und Tiefe

Die Kante muss zur tatsächlichen Materialstärke passen. AA/AS-Hochglanzacryl: 3 mm. Klares bedrucktes Acryl: 3 oder 5 mm. Edelstahl: 1,5 mm. Offene Stärken bleiben als Musterannahme sichtbar.

## Weiße Acrylgravur

Schwarz und Anthrazit: weiße Rückseitengravur, hinten spiegelverkehrt gefertigt und vorne lesbar. Sehr feines Laserraster in den Gravurflächen; glänzende Vorderseite bleibt glatt.

## Satiniertes Acryl

Weiße Lasergravur mit feinem Laserraster auf satinierter matter Oberfläche. Kein dunkler Druck und keine UV-Druckpunkte für dieses Muster.

## UV-Direktdruck

Druck auf der Rückseite, hinter dem Acryl. Kleine, feine UV-Druckpunkte innerhalb der Druckflächen berücksichtigen. Bei normaler Betrachtung sauber, bei Vergrößerung dezent sichtbar. Kein grobes Punktemuster und keine Laserlinien.

## Bestätigte Edelstahlstruktur

Gewählte Edelstahlreferenz: genau die von Christopher angehängte Originalfassung mit feiner gleichmäßiger waagerechter Maserung, neutralem Silberton, dünner Materialkante und weichem Schatten. Unverändert übernehmen; keine zusätzliche Verstärkung oder Verfeinerung der Struktur.

## Oberfläche und Schatten

Materialtypische Maserung, Bürstung, Narbung oder Satinerung zeigen. Materialtiefe, saubere Kanten und einen sehr weichen realistischen Schlagschatten erhalten. Frontal, scharf und mit ruhigen Reflexen.

## Vom Muster zur Serie

Produkt im Chat beschreiben, ein Muster gemeinsam ausarbeiten und daraus Designs sowie Größen und Farben ableiten. Fertige Produktbilder mit der ChatGPT-Bildfunktion erstellen. Schnittkontur, Bohrungen und Schablone separat maßhaltig aus den technischen Daten erzeugen.

## Offene Angaben

Holz: 5 mm ist bisher eine unbestätigte Interpretation von „5 m“. Leder: 2 mm ist vorläufig. Satiniertes Acryl: weiße Lasergravur ist vom Nutzer festgelegt. Die Stärke von 3 mm bleibt eine Musterannahme.

## Referenzstatus

Die Bilder sind visuelle Materialbeispiele. Die frühere Anthrazitansicht und die ausdrücklich angehängte Edelstahl-Originalfassung (Bildversion 4) wurden als Bildreferenz vom Nutzer ausdrücklich bestätigt. Die Sammlung ist keine Freigabe neuer Designs oder Produktionsdateien. Materialreferenzen werden als eigene Sammlung archiviert, nicht einer abweichenden technischen Designrevision zugeordnet.

## Bilder

- Acryl · Anthrazit · 3 mm · Weiße Rückseitengravur · acryl-anthrazit-3mm.png
  Bestätigte Bildreferenz. Gravur hinten spiegelverkehrt fertigen, von vorne lesbar.
- Acryl · Schwarz · 3 mm · Weiße Rückseitengravur · acryl-schwarz-3mm.png
  Passendes schwarzes Muster. Glatte glänzende Vorderseite vor weißer Gravur.
- Acryl · Bunter UV-Druck · 3 mm · UV-Direktdruck auf der Rückseite · acryl-uv-bunt-3mm.png
  Farbiger maritimer Entwurf hinter dem klaren Acryl. Dezentes Punktraster innerhalb der bedruckten Flächen.
- Acryl · Bunter UV-Druck · 5 mm · UV-Direktdruck auf der Rückseite · acryl-uv-bunt-5mm.png
  Stärkere klare Materialkante und Rückseitendruck unter der glänzenden Vorderseite.
- Acryl · Satiniert · 3 mm · Weiße Lasergravur · acryl-satiniert-weisse-gravur-v2.png
  Weiße Gravur vom Nutzer festgelegt. Für das Materialmuster weiterhin 3 mm angenommen; die Stärke ist noch offen.
- Acryl · Schwarzer UV-Druck · 3 mm · UV-Direktdruck auf der Rückseite · acryl-uv-schwarz-3mm.png
  Schwarzes Motiv hinter klarem Acryl; das feine Punktraster gehört ausschließlich in die Druckflächen.
- Acryl · Schwarzer UV-Druck · 5 mm · UV-Direktdruck auf der Rückseite · acryl-uv-schwarz-5mm.png
  5-mm-Variante mit stärkerer optischer Tiefe vor dem rückseitigen Druck.
- Edelstahl · 1.5 mm · Dunkle Gravur auf der Vorderseite · edelstahl-gewaehlte-originalfassung-v4.png
  Gewählte Edelstahlreferenz: genau die von Christopher angehängte Originalfassung mit feiner gleichmäßiger waagerechter Maserung, neutralem Silberton, dünner Materialkante und weichem Schatten. Unverändert übernehmen; keine zusätzliche Verstärkung oder Verfeinerung der Struktur.
- Eiche · 5 mm · Dunkle Lasergravur · eiche-5mm-muster.png
  5 mm vorläufig angenommen; die ursprüngliche Angabe „5 m“ wurde als Tippfehler gelesen.
- Kirsche · 5 mm · Dunkle Lasergravur · kirsche-5mm-muster.png
  5 mm vorläufig angenommen; die ursprüngliche Angabe „5 m“ wurde als Tippfehler gelesen.
- Buche · 5 mm · Dunkle Lasergravur · buche-5mm-muster.png
  5 mm vorläufig angenommen; die ursprüngliche Angabe „5 m“ wurde als Tippfehler gelesen.
- Braunes Leder · 2 mm · Dunkle Lasergravur · leder-2mm-muster.png
  Für dieses Bild vorläufig 2 mm angenommen. Die tatsächliche Materialstärke ist noch offen.