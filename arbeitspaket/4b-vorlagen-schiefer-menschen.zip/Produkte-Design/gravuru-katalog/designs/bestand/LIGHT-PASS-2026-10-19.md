# Light-Pass 19.10.2026 – Bilanz je Linie

Quelle: alle Corel-Bögen ≤ 60 MB aus `V:\Produkte\<Linie>\…\[CDR]` (ohne Türklingel, Grabstecker, Archiv, Sicherungskopien), direkt über die Desktop-App vom Server geholt. Bitmaps wurden für den Massenlauf genullt (keine Texturen/Fotos, außer Hausnummern/Standbilder/Namenschilder/Wandbilder aus dem ersten Durchlauf). Bögen > 60 MB (UV/Foto) und 40 zu tief liegende Hinweisschild-Bögen folgen mit den Light-Kopien (`quellen/make-light-copies.ps1`), ebenso die Konfigurator-Pakete (`product.json`/`front.jpg`) aller 37 931 SKUs.

Je Linie: `designs/bestand/<linie>/` mit `designs.json`, `<LINIE>-DESIGNS.xlsx` (gelbe Spalten = Korrektur, Rückimport `build-design-bestand.py --import-xlsx`), `_uebersicht/*.png`, `UEBERSICHT.md`. **Hauptdesign** = ein Design je Design-Nummer über alle Größen; **Variante** = dasselbe Design (gleiche Texte) in einer anderen Reihe (Form/Material/Farbe), in der Excel „Variante von“.

| Linie | Bögen gelesen | Bögen > 60 MB (offen) | Hauptdesigns | Varianten | Ersatzschrift | Musterfotos | Themen (Vorschlag) | Übersichtsseite |
|---|---:|---:|---:|---:|---:|---:|---|---|
| Adventskalender | 2 | 4 | 1 | 0 | 1 | 0 | Anlass 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Anhänger | 21 | 15 | 106 | 0 | 53 | 0 | Allgemein 34, Anlass 32, offen 20, Familie 20 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Autoanhänger | 43 | 13 | 337 | 264 | 149 | 0 | offen 227, Allgemein 99, Familie 4, Trauer 3 | [Seite](https://claude.ai/artifact/HbDy8uv7vzErHVqKEYbbtn) |
| Belohnungstafel | 1 | 0 | 8 | 0 | 8 | 0 | Allgemein 6, Tiere 2 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Bierhammer | 2 | 0 | 6 | 0 | 0 | 0 | offen 5, Allgemein 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Blumenkübel | 1 | 1 | 20 | 0 | 17 | 0 | Sprüche 12, Allgemein 8 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Blumenstecker | 17 | 7 | 19 | 0 | 7 | 0 | Allgemein 11, Familie 5, offen 2, Anlass 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Boxenschilder | 14 | 11 | 61 | 1 | 26 | 0 | Allgemein 36, Tiere 21, Familie 2, Hinweis 2 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Briefkasten | 5 | 0 | 16 | 0 | 1 | 0 | Familie 13, Allgemein 3 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Brotdosen-Set | 9 | 0 | 73 | 3 | 35 | 0 | Allgemein 63, offen 6, Anlass 3, Sprüche 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Cake Topper | 11 | 0 | 24 | 0 | 6 | 0 | offen 12, Familie 6, Allgemein 6 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Erinnerungskiste | 1 | 9 | 5 | 0 | 5 | 0 | Familie 4, Allgemein 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Firmenschilder | 38 | 7 | 29 | 77 | 27 | 0 | Allgemein 19, Beruf 8, Tiere 2 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Flachmann | 6 | 0 | 30 | 0 | 20 | 0 | Allgemein 26, offen 4 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Frühstücksbrettchen | 12 | 5 | 77 | 0 | 30 | 0 | Allgemein 63, Anlass 6, Tiere 2, Sprüche 2 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Gedenkstandbilder | 18 | 34 | 61 | 0 | 26 | 0 | Allgemein 35, offen 9, Sprüche 8, Tiere 4 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| gedenktafeln | 81 (vorher) | 0 | 652 | 0 | 211 | 206 | Menschen 372, Tiere 258, Sternenkinder 22 | [Seite](https://claude.ai/artifact/UTsD2MCmuRsrjrxyNP7ZSZ) |
| Gedenktafeln Sternenkinder | 4 | 0 | 4 | 0 | 1 | 0 | Allgemein 4 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Geldgeschenk | 16 | 6 | 41 | 10 | 7 | 0 | Allgemein 22, Sprüche 8, Anlass 4, Familie 4 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Grillzange | 1 | 0 | 13 | 0 | 1 | 0 | offen 9, Allgemein 4 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Hausnummern | 134 | 32 | 88 | 41 | 30 | 43 | Allgemein 58, Familie 20, offen 9, Tiere 1 | [Seite](https://claude.ai/artifact/PnYexSDbYczsnWqhNFYfZK) |
| Hinweisschilder | 33 | 52 | 166 | 59 | 16 | 0 | offen 95, Hinweis 32, Tiere 21, Allgemein 17 | [Seite](https://claude.ai/artifact/J2FHshPetmTryitC5PFa7C) |
| Hochzeitsschilder | 27 | 0 | 27 | 93 | 18 | 0 | Allgemein 22, Anlass 4, offen 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Kalender | 6 | 9 | 0 | 0 | 0 | 0 |  | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Kordelschilder | 26 | 26 | 131 | 120 | 129 | 0 | Familie 77, Allgemein 36, offen 12, Sprüche 3 | [Seite](https://claude.ai/artifact/ETuFNabBFymEKarnPcBU7m) |
| Kreuze | 5 | 16 | 64 | 0 | 27 | 0 | Allgemein 32, offen 13, Sprüche 8, Tiere 5 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Lesehilfe | 3 | 6 | 7 | 0 | 5 | 0 | Allgemein 7 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Lesezeichen | 1 | 3 | 8 | 0 | 4 | 0 | Allgemein 6, Familie 2 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Lineal | 3 | 1 | 74 | 0 | 12 | 0 | Allgemein 61, offen 13 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Monogramme | 7 | 1 | 53 | 25 | 26 | 0 | Allgemein 49, Tiere 3, offen 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Nachtlichter | 12 | 2 | 20 | 0 | 14 | 0 | Anlass 8, Allgemein 7, Familie 5 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Namenschilder | 109 | 25 | 194 | 622 | 110 | 135 | Familie 181, Allgemein 12, Sprüche 1 | [Seite](https://claude.ai/artifact/Fbi2qTxWVhRTt7P2UruVGD) |
| Postkarte | 2 | 0 | 18 | 0 | 1 | 0 | offen 10, Anlass 5, Sprüche 2, Allgemein 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Schlüsselanhänger | 80 | 33 | 1100 | 142 | 125 | 1 | offen 845, Allgemein 224, Anlass 18, Sprüche 6 | [Seite](https://claude.ai/artifact/GLzTMCZgp9R9Un9vUBJ8F3) |
| Spardose | 1 | 1 | 10 | 0 | 1 | 0 | Allgemein 9, Familie 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Standbilder | 77 | 110 | 245 | 67 | 53 | 38 | offen 113, Allgemein 98, Sprüche 11, Tiere 11 | [Seite](https://claude.ai/artifact/WPcWSL9cA2XSkykGpoX3Yz) |
| Stiftehalter | 1 | 2 | 7 | 0 | 5 | 0 | Allgemein 7 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Tierschilder | 7 | 16 | 14 | 0 | 6 | 0 | Allgemein 8, Tiere 4, Familie 1, Hinweis 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Tierzubehör | 31 | 0 | 54 | 72 | 51 | 0 | Allgemein 46, offen 6, Familie 1, Tiere 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Türkränze | 7 | 13 | 14 | 0 | 2 | 0 | offen 11, Allgemein 2, Familie 1 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Türschilder | 225 | 61 | 298 | 1389 | 408 | 0 | Familie 199, offen 47, Allgemein 40, Hinweis 5 | [Seite](https://claude.ai/artifact/KvvjtjNPZ3Gk3rbbDBmVJe) |
| Untersetzer | 3 | 3 | 3 | 0 | 3 | 0 | Allgemein 3 | [Seite](https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN) |
| Wandbilder | 80 | 161 | 184 | 19 | 68 | 114 | Allgemein 108, offen 57, Anlass 9, Sprüche 7 | [Seite](https://claude.ai/artifact/7c829epimSqphvkZEaZJBw) |
| **Summe** | 1102 | 712 | **4362** | **3004** | | | | |

## Übersichtsseiten (claude.ai, mit Knöpfen Löschen / Fehler / Foto fehlt)

- gedenktafeln: https://claude.ai/artifact/UTsD2MCmuRsrjrxyNP7ZSZ
- hausnummern: https://claude.ai/artifact/PnYexSDbYczsnWqhNFYfZK
- namenschilder: https://claude.ai/artifact/Fbi2qTxWVhRTt7P2UruVGD
- wandbilder: https://claude.ai/artifact/7c829epimSqphvkZEaZJBw
- standbilder: https://claude.ai/artifact/WPcWSL9cA2XSkykGpoX3Yz
- tuerschilder: https://claude.ai/artifact/KvvjtjNPZ3Gk3rbbDBmVJe
- schluesselanhaenger: https://claude.ai/artifact/GLzTMCZgp9R9Un9vUBJ8F3
- autoanhaenger: https://claude.ai/artifact/HbDy8uv7vzErHVqKEYbbtn
- hinweisschilder: https://claude.ai/artifact/J2FHshPetmTryitC5PFa7C
- kordelschilder: https://claude.ai/artifact/ETuFNabBFymEKarnPcBU7m
- weitere-linien: https://claude.ai/artifact/S6kanfqabA4rn1s5Wm4hkN

Markierungen werden regelmäßig ausgelesen (`ArtifactData list markierungen`) und mit `scripts/apply-markierungen.py` umgesetzt; gelöschte Designs stehen in `_geloescht.json` der Linie.

## Bekannte Lücken dieses Durchlaufs

- Texturen/Fotos fehlen in den meisten Linien (Bitmaps genullt) – Platten in Materialfarbe (Edelstahl grau, Acryl/Schiefer dunkel, gezeichnete Platten wie in Corel).
- Ersatzschriften (orange): Originalschriften liegen in `V:\Schriftarten` – nach Verbindung neu rendern.
- Themen sind Stichwort-Vorschläge (Familie, Tiere, Beruf, Hinweis, Anlass, Trauer, Sprüche); „Allgemein“/„offen“ = kein Schlüsselwort oder kein Text (z. B. reine Foto-/Motivdesigns).
- Verfahren „offen“, wo der Serverpfad weder Gravur noch UV nennt (z. B. Wandbilder).
- 241 Bögen ohne erkennbare Designs waren Hilfsdateien (Viewbox, Schablone, Muster, Produktbild-Varianten) – nicht übernommen.
