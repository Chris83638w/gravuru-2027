// Read-only local transport. Authentication for hosted deployments is separate.
export function createLocalMediaHandler(catalog,{origin}){
 const trusted=new URL(origin);
 if(trusted.protocol!=='http:'||!['127.0.0.1','localhost','[::1]'].includes(trusted.hostname))throw Error('Dieser Adapter ist ausschließlich für lokale Prüfungen.');
 return function handle(req,res){
  const pathname=new URL(req.url,origin).pathname;
  if(pathname!=='/api/media'&&!pathname.startsWith('/api/media/'))return false;
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
  const json=(status,value)=>{res.statusCode=status;res.setHeader('Content-Type','application/json; charset=utf-8');res.end(JSON.stringify(value));return true;};
  if(req.headers.host!==trusted.host||(req.headers.origin&&req.headers.origin!==trusted.origin)||req.headers['sec-fetch-site']==='cross-site')return json(403,{error:'Zugriff nur aus der lokalen Werkstatt.'});
  if(req.method!=='GET'){res.setHeader('Allow','GET');return json(405,{error:'Medienkatalog ist schreibgeschützt.'});}
  try{
   const url=new URL(req.url,origin);
   if(pathname==='/api/media'){
    const input={};for(const [key,value] of url.searchParams){if(key in input)throw Error('duplicate');input[key]=['limit','offset'].includes(key)&&/^\d+$/.test(value)?Number(value):value;}
    return json(200,catalog.list(input));
   }
   if(url.search)throw Error('Unexpected query');
   const parts=pathname.slice('/api/media/'.length).split('/');
   if(parts.length<2||parts.length>3||(parts.length===3&&parts[2]!=='content'))throw Error('Bad route');
   const ref={mediaId:parts[0],revisionId:parts[1]},descriptor=catalog.resolve(ref);
   if(parts.length===2)return json(200,descriptor);
   if(!descriptor.previewable)return json(415,{error:'Für diese Datei ist noch keine Bildvorschau verfügbar.'});
   const bytes=catalog.bytes(ref);res.setHeader('Content-Type',descriptor.mimeType);res.setHeader('Content-Length',bytes.byteLength);res.end(bytes);return true;
  }catch{return json(400,{error:'Medien oder Katalogabfrage nicht verfügbar. Bitte Auswahl und Revision prüfen.'});}
 };
}
