import {fitObject} from '../../configurator/variant-m/design-edit.mjs';
import {measureText} from '../../platform/sources/app/shared/models/doorbell-preview.mjs';
import {validateDesignContent,objectIssue} from '../../platform/sources/app/shared/models/design-content.mjs';

export function checkDesign(design,fonts,product,sourceErrors=[]){
 const problems=[];
 const add=(index,field,message,suggestion,patch)=>problems.push({index,field,message,suggestion,patch});
 for(const [index,o] of design.objects.entries()){
  if(o.type==='text'){
   try{measureText(o,fonts);}catch(e){const candidates=['Great Vibes','Allura','Montserrat','Open Sans'].filter(f=>fonts[f]).filter(f=>{try{measureText({...o,font:f},fonts);return true;}catch{return false;}});
    const font=candidates[0];add(index,'font',e.message,font?'„'+font+'“ als Ersatzschrift wählen oder die Originalschrift hochladen.':'Eine vollständige Originalschrift hochladen.',font?{font}:null);}
  }
  try{validateDesignContent({...design,objects:[o]},{universal:true,extraFontIds:[...Object.keys(fonts),o.font].filter(Boolean)});}catch(e){add(index,o.type==='text'?'text':'x',e.message,'Text, Größe und Position dieses Elements prüfen.');}
  const issue=objectIssue(o,{geometry:{width:product.width,height:product.height,shape:product.shape,safeMarginMm:0,holes:[]}});
  if(issue){const fitted=fitObject(o,product),patch=Object.fromEntries(['x','y','w','h',...(o.type==='text'?['size']:[])].map(k=>[k,fitted[k]]));add(index,'x',issue,'Element in die Fläche einpassen und Vorschau kontrollieren.',patch);}
 }
 // Structural/source ambiguities are preserved. Only deterministic font diagnostics are replaceable.
 for(const message of sourceErrors.filter(e=>!/^Schrift (fehlt:|.+: fehlende Zeichen)/.test(e)))add(null,null,message,'Original und Import vergleichen; gegebenenfalls Quelldatei korrigieren und erneut importieren.');
 try{validateDesignContent(design,{universal:true,extraFontIds:[...Object.keys(fonts),...design.objects.map(o=>o.font).filter(Boolean)]});}catch(e){if(!problems.some(p=>p.message===e.message))add(null,null,e.message,'Die markierten Elemente korrigieren.');}
 return problems;
}
