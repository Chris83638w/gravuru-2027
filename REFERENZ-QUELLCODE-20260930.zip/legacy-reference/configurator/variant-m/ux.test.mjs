import test from 'node:test';
import assert from 'node:assert/strict';
import {uploadQuote,validateUpload,customerDraft,pageSlice,additionalMotifCount,canDownloadPurchase} from './ux-model.mjs';
import {PROCESSING_PROFILES,elementColor} from '../../platform/sources/app/shared/models/processing-profiles.mjs';
test('upload price counts visible files once and multiplies quantity',()=>{
 const objects=[{uxUploadId:'a'},{uxUploadId:'b',uxHidden:true}];
 assert.deepEqual(uploadQuote(objects,2),{count:1,unitCents:999,totalCents:1998});
 assert.equal(uploadQuote(objects,1,true).unitCents,1998);
 assert.throws(()=>uploadQuote(objects,0));
});
test('four uploads maximum including hidden files, replacement stays possible',()=>{
 const list=Array.from({length:4},(_,i)=>({uxUploadId:String(i),uxHidden:true}));
 const file={type:'image/png',size:200};assert.throws(()=>validateUpload(file,list),/vier/);
 assert.doesNotThrow(()=>validateUpload(file,list,'0'));
 for(const invalid of [{type:'image/svg+xml',size:10},{type:'image/png',size:0},{type:'image/png',size:16*1024*1024}])assert.throws(()=>validateUpload(invalid,[]));
});
test('template motif with regenerated runtime id stays included exactly once',()=>{
 const source=[{id:'template',type:'motif',motif:'dog'}],object={id:'runtime',cSourceId:'template',type:'motif',motif:'dog'};
 assert.equal(additionalMotifCount([object],source),0);
 assert.equal(additionalMotifCount([object,{...object,id:'copy'}],source),1);
 assert.equal(additionalMotifCount([{...object,motif:'cat'}],source),1);
});
test('font paging shows eight choices and clamps final page',()=>{
 const fonts=Array.from({length:31},(_,i)=>i);assert.equal(pageSlice(fonts,0).items.length,8);
 assert.deepEqual(pageSlice(fonts,99),{items:[24,25,26,27,28,29,30],page:3,pages:4});
});
test('portable account payload omits unknown private fields and raster bytes',()=>{
 const payload=JSON.stringify(customerDraft({designId:'d',token:'secret',personalItems:[{password:'secret'}],objects:[{id:'o',type:'image',uxUploadId:'local-id',original:'secret',processed:'secret',filename:'secret',password:'secret',url:'secret'}]}, {id:'p',revision:'r'}));
 assert.ok(!payload.includes('secret'));assert.ok(payload.includes('local-id'));
});
test('paid download contract does not accept unverified or non-PNG response',()=>{
 assert.equal(canDownloadPurchase({paid:true,format:'png',downloadUrl:'https://example.com/a.png'}),false);
 assert.equal(canDownloadPurchase({authenticated:true,paid:true,format:'svg',downloadUrl:'https://example.com/a.svg'}),false);
});
test('engraving inks fixed; UV allows element colors, photo independent',()=>{
 const expected={'steel-engraving':'#191919','wood-engraving':'#49301d','slate-engraving':'#e8e9e5','acrylic-engraving':'#e1e4e5'};
 for(const [id,ink] of Object.entries(expected))assert.equal(elementColor({processing:{profileId:id}},{color:'#ff0000'}),ink);
 assert.equal(elementColor({processing:{profileId:'color-print'}},{color:'#ff0000'}),'#ff0000');
 assert.equal(PROCESSING_PROFILES.length,5);
});


test('photo background choices survive draft serialization independently per upload',()=>{
 const input={designId:'d',objects:[{id:'a',type:'photoSlot',uxUploadId:'one',uxUploadKind:'photo',uxPhotoBackground:'keep'},{id:'b',type:'photoSlot',uxUploadId:'two',uxUploadKind:'photo',uxPhotoBackground:'remove'}]};
 const draft=customerDraft(input,{id:'p',revision:'r'});
 assert.deepEqual(draft.state.objects.map(o=>o.uxPhotoBackground),['keep','remove']);
 assert.deepEqual(input.objects.map(o=>o.uxPhotoBackground),['keep','remove']);
});
