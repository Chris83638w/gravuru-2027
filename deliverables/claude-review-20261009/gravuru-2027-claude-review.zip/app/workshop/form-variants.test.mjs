import http from 'node:http';
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {once} from 'node:events';import {DatabaseSync} from 'node:sqlite';
import {createWorkshop} from './http.mjs';import {makeFormProduct} from './form-product.mjs';import {addFormDesign} from './form-designs.mjs';import {build} from '../configurator/variant-m/build.mjs';import {createPreviewServer} from '../configurator/variant-m/server.mjs';
import {variantBatchReportData,variantBatchReportWorkbook} from './variant-batch-report.mjs';
import {execFile as asyncExecFile} from 'node:child_process';
import {promisify} from 'node:util';
async function readCorrection(bytes,dir){
 const filename=path.join(dir,'variant-correction.xlsx');fs.writeFileSync(filename,bytes);
 const {stdout}=await promisify(asyncExecFile)('python3',['-c',`import json,sys
from openpyxl import load_workbook
w=load_workbook(sys.argv[1])
def rows(name):
 r=list(w[name].values);return [dict(zip(r[0],[v if v is not None else '' for v in row])) for row in r[1:]]
print(json.dumps({'rows':rows('Gruppen'),'variantRows':rows('Varianten'),'report':rows('Pruefbericht'),'sheets':w.sheetnames,'formulas':sum(c.data_type=='f' for s in w for row in s for c in row)}))`,filename],{timeout:15000});return JSON.parse(stdout);
}

test('saved variant checks and correction workbook resume only three failed groups with all their members',async t=>{
 const f=await fixture(t),input=batchInput(f,100),before=f.w.repository.list();for(const i of [0,1,2])input.variantRows[i*2].product_revision=99;
 const job=f.w.variantBatchJobs.create({name:'100 Ausführungsgruppen',input}),same=f.w.variantBatchJobs.create({name:'Wiederholung',input});assert.equal(same.id,job.id);assert.equal(same.existing,true);
 const opened=f.w.variantBatchJobs.review(job.id);assert.equal(opened.plan.report.filter(r=>r.status==='error').length,3);assert.equal(f.w.variants.commit({...opened.input,token:opened.plan.token,skipErrors:true}).groups.length,97);
 f.restart();const resumed=f.w.variantBatchJobs.review(job.id);assert.equal(resumed.plan.report.filter(r=>r.status==='existing').length,97);assert.equal(resumed.plan.report.filter(r=>r.status==='error').length,3);
 const data=variantBatchReportData(f.w.variants,{...resumed.input,mode:'errors'}),file=await readCorrection(await variantBatchReportWorkbook(data),f.dir);
 assert.deepEqual(file.sheets,['Gruppen','Varianten','Pruefbericht','Anleitung']);assert.equal(file.rows.length,3);assert.equal(file.variantRows.length,6);assert.equal(file.report.length,100);assert.equal(file.formulas,0);assert.equal(file.report[3].correction_excel_row,'');assert.equal(file.report[1].correction_excel_row,3);
 for(const member of file.variantRows)member.product_revision=1;
 const corrected={rows:file.rows,variantRows:file.variantRows},next=f.w.variantBatchJobs.create({name:'Drei korrigiert',input:corrected}),review=f.w.variantBatchJobs.review(next.id);
 assert.equal(review.plan.valid,true,JSON.stringify(review.plan.report));const result=f.w.variants.commit({...review.input,token:review.plan.token});assert.equal(result.groups.filter(g=>g.created).length,3);assert.equal(f.w.variants.list().length,100);
 assert.equal(f.w.variants.commit({...review.input,token:review.plan.token}).groups.filter(g=>g.created).length,0);assert.deepEqual(f.w.repository.list(),before);
 for(const group of result.groups){const d=f.w.variants.get(group.id).document;assert.equal(d.variants.length,2);assert.equal(d.defaultVariantId,'large');assert.equal(f.w.variants.select(group.id,1,'small').basePriceCents,1499);}
 f.w.variantBatchJobs.remove(job.id);assert.equal(f.w.variants.list().length,100);assert.equal(f.w.variantBatchJobs.review(next.id).plan.report[0].status,'existing');
});
test('saved variant review keeps group revisions and reports newly archived products without altering references',async t=>{
 const f=await fixture(t),group=f.w.variants.create(f.input()),input={rows:[{import_key:'update-later',action:'update',group_id:group.id,expected_revision:1,name:'Tabellenänderung'}],variantRows:[]};
 const job=f.w.variantBatchJobs.create({name:'Update',input});f.w.variants.save(group.id,{...group.document,name:'Parallel geändert'},1);f.restart();
 const resumed=f.w.variantBatchJobs.review(job.id);assert.equal(resumed.plan.valid,false);assert.equal(resumed.input.rows[0].expected_revision,1);assert.match(resumed.plan.report[0].message,/inzwischen/);
 const correction=variantBatchReportData(f.w.variants,{...resumed.input,mode:'errors'});assert.equal(correction.rows[0].group_id,group.id);assert.equal(correction.rows[0].expected_revision,1);
 const pending=f.w.variantBatchJobs.create({name:'Neue Zuordnung',input:batchInput(f)});f.w.repository.setArchived(f.products[0].id,{expectedRevision:1,archived:true});assert.equal(f.w.variantBatchJobs.review(pending.id).plan.valid,false);assert.equal(f.w.variants.get(group.id).document.name,'Parallel geändert');
});
test('variant reports preserve literal labels, isolate snapshot types and reject ambiguous workbook data',async t=>{
 const f=await fixture(t),input=batchInput(f);input.rows[0].name='=HYPERLINK("https://example.invalid")';input.variantRows[0].label='+123';
 const before=f.w.variants.list(),file=await readCorrection(await variantBatchReportWorkbook(variantBatchReportData(f.w.variants,{...input,mode:'report'})),f.dir);assert.equal(file.formulas,0);assert.equal(file.rows[0].name,input.rows[0].name);assert.equal(file.variantRows[0].label,'+123');assert.deepEqual(f.w.variants.list(),before);
 const job=f.w.variantBatchJobs.create({name:'Getrennt',input});assert.throws(()=>f.w.batchJobs.review(job.id),/nicht gefunden/);assert.equal(f.w.batchJobs.list().length,0);
 assert.throws(()=>variantBatchReportData(f.w.variants,{...input,mode:'errors'}),/keine fehlerhaften/);
 assert.throws(()=>f.w.variantBatchJobs.create({name:'Token',input:{...input,token:'not-to-store'}}),/Gruppen/);
 for(const patch of [{name:'x'.repeat(32768)},{extra:'column'},{name:'bad\u0000text'}])assert.throws(()=>variantBatchReportData(f.w.variants,{...input,rows:[{...input.rows[0],...patch}],mode:'report'}),/Zellen|Spalten/);
 const orphan=structuredClone(input);orphan.variantRows[0].import_key='orphan';assert.throws(()=>f.w.variantBatchJobs.create({name:'Verwaist',input:orphan}),/keiner Gruppe/);
});
async function fixture(t){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'g27-variants-'));build({outputDirectory:dir});const seed=JSON.parse(fs.readFileSync(path.join(dir,'models.json')))[0],filename=path.join(dir,'workshop.sqlite');let w=createWorkshop({filename,seedConfig:seed.universal,legacy:seed.legacy});t.after(()=>{w.close();fs.rmSync(dir,{recursive:true,force:true});});const products=[];
 for(const [width,material,price] of [[120,'acrylic-clear',1499],[160,'oak',2499]]){
  const contour=await w.contours.import({name:'Form.svg',bytes:Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${width}mm" height="80mm" viewBox="0 0 ${width} 80"><rect width="${width}" height="80" rx="5"/><circle cx="8" cy="40" r="2"/></svg>`).toString('base64')}),asset=await w.assets.import({name:'Design.svg',bytes:Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${width}mm" height="80mm" viewBox="0 0 ${width} 80"><path d="M20 40H${width-20}" stroke="black" stroke-width="2"/></svg>`).toString('base64')});
  let d=addFormDesign(makeFormProduct(contour,'Variante '+material),asset,{name:'Passendes Design '+width,designId:'design-'+width});d.material={id:material,thicknessMm:3,surfaceNotes:''};d.processingMethod='engraving';d.basePriceCents=price;products.push(w.repository.create(d));
 }
 const input=()=>({name:'Unser Schild',archived:false,defaultVariantId:'small',variants:products.map((p,i)=>({id:i?'large':'small',label:i?'Holz · 160 × 80':'Acryl · 120 × 80',productId:p.id,productRevision:1}))});
 return {get w(){return w;},dir,filename,products,input,restart(){w.close();w=createWorkshop({filename,seedConfig:seed.universal,legacy:seed.legacy});}};
}
test('variants keep exact product revisions, prices, holes and matching designs after edits and reopen',async t=>{
 const f=await fixture(t),g=f.w.variants.create(f.input()),options=f.w.variants.options(g.id,1);assert.equal(options.variants[0].basePriceCents,1499);assert.equal(options.variants[1].geometry.widthMm,160);assert.equal(options.variants[1].geometry.holeCount,1);assert.deepEqual(options.variants[0].designs,[{id:'design-120',name:'Passendes Design 120'}]);
 const selected=f.w.variants.select(g.id,1,'large');assert.equal(selected.productId,f.products[1].id);assert.equal(selected.productRevision,1);assert.equal(selected.basePriceCents,2499);const link=new URL(selected.href,'http://localhost');assert.equal(link.pathname,'/');assert.equal(link.searchParams.get('revision'),'1');assert.equal(link.searchParams.get('group'),g.id);assert.equal(link.searchParams.get('groupRevision'),'1');assert.equal(link.searchParams.get('variant'),'large');
 const changed=structuredClone(f.products[1].document);changed.basePriceCents=9999;changed.designs[0].name='Später verändert';f.w.repository.save(f.products[1].id,changed,1);f.restart();assert.deepEqual(f.w.variants.get(g.id),g);assert.equal(f.w.variants.select(g.id,1,'large').basePriceCents,2499);assert.equal(f.w.variants.options(g.id,1).variants[1].currentRevision,2);
 const input=f.input();input.variants[1].productRevision=2;input.defaultVariantId='large';const next=f.w.variants.save(g.id,input,1);assert.equal(next.revision,2);assert.equal(f.w.variants.select(g.id,2).basePriceCents,9999);assert.deepEqual(f.w.variants.get(g.id,1),g);assert.throws(()=>f.w.variants.save(g.id,input,1),e=>e.status===409);
 const raw=new DatabaseSync(f.filename);assert.throws(()=>raw.exec("UPDATE form_variant_revisions SET document='{}'"),/immutable/);assert.throws(()=>raw.exec('DELETE FROM form_variant_members'),/immutable/);raw.close();
});
test('invalid, ambiguous, incomplete and archived variant references cannot be silently accepted',async t=>{
 const f=await fixture(t);
 for(const change of [d=>d.defaultVariantId='absent',d=>d.variants[1].id='small',d=>d.variants[1].label=d.variants[0].label,d=>d.variants[1].productId=d.variants[0].productId,d=>d.variants[0].productRevision=0,d=>d.variants[0].productRevision=99,d=>d.variants[0].basePriceCents=1,d=>d.variants[0].productId=f.w.defaultId,d=>d.extra=true,d=>d.variants=[]]){const d=f.input();change(d);assert.throws(()=>f.w.variants.create(d));assert.equal(f.w.variants.list().length,0);}
 const g=f.w.variants.create(f.input());assert.throws(()=>f.w.variants.select(g.id,1,'unknown'),e=>e.status===422);assert.throws(()=>f.w.variants.select(g.id,undefined,'small'),e=>e.status===422);
 const changed=structuredClone(f.products[0].document);changed.basePriceCents=null;f.w.repository.save(f.products[0].id,changed,1);const incomplete=f.input();incomplete.variants[0].productRevision=2;assert.throws(()=>f.w.variants.save(g.id,incomplete,1),/Material, Stärke/);assert.equal(f.w.variants.get(g.id).revision,1);
 f.w.repository.setArchived(f.products[1].id,{expectedRevision:1,archived:true});assert.equal(f.w.variants.options(g.id,1).variants[1].available,false);assert.throws(()=>f.w.variants.select(g.id,1,'large'),/nicht verfügbar/);assert.equal(f.w.variants.select(g.id,1,'small').basePriceCents,1499);const archived=f.input();archived.archived=true;assert.equal(f.w.variants.save(g.id,archived,1).document.archived,true);assert.throws(()=>f.w.variants.save(g.id,f.input(),2),/aktive freie Formprodukte/);
});
test('archiving a group blocks new selections through historical URLs while retaining its history',async t=>{
 const f=await fixture(t),g=f.w.variants.create(f.input()),d=f.input();d.archived=true;f.w.variants.save(g.id,d,1);assert.equal(f.w.variants.history(g.id).length,2);assert.deepEqual(f.w.variants.get(g.id,1),g);assert.throws(()=>f.w.variants.options(g.id,1,{customer:true}),/nicht verfügbar/);assert.throws(()=>f.w.variants.select(g.id,1),/nicht verfügbar/);
});
test('variant HTTP guards, revision conflicts and selection handoff use existing customer draft validation',async t=>{
 const f=await fixture(t),server=createPreviewServer({workshop:f.w,outputDirectory:f.dir});server.listen(0,'127.0.0.1');await once(server,'listening');t.after(async()=>new Promise(r=>server.close(r)));const base='http://127.0.0.1:'+server.address().port,session=await(await fetch(base+'/api/workshop/session')).json();
 const post=async(route,data,method='POST',extra={})=>fetch(base+route,{method,headers:{'Content-Type':'application/json','X-Gravuru-CSRF':session.csrfToken,...extra},body:JSON.stringify(data)});
 assert.equal((await post('/api/workshop/variants',{document:f.input()},'POST',{'X-Gravuru-CSRF':'wrong'})).status,403);assert.equal((await post('/api/workshop/variants',{document:f.input()},'POST',{'Origin':'https://foreign.invalid'})).status,403);const wrongHost=await new Promise((resolve,reject)=>{const req=http.get(base+'/api/workshop/variants',{headers:{host:'foreign.invalid'}},res=>{res.resume();resolve(res.statusCode);});req.on('error',reject);});assert.equal(wrongHost,403);
 let r=await post('/api/workshop/variants',{document:f.input()});assert.equal(r.status,201);const g=await r.json();r=await post('/api/workshop/variants/'+g.id,{document:f.input(),expectedRevision:8},'PATCH');assert.equal(r.status,409);
 const select=await(await fetch(base+'/api/workshop/variants/'+g.id+'/select?revision=1&variant=large')).json();assert.equal(select.productId,f.products[1].id);r=await post('/api/workshop/customer-drafts',{productId:select.productId,productRevision:select.productRevision,designId:'design-120'});assert.equal(r.status,422);r=await post('/api/workshop/customer-drafts',{productId:select.productId,productRevision:select.productRevision});assert.equal(r.status,201);const draft=await r.json();assert.equal(draft.product.basePriceCents,2499);assert.deepEqual(draft.product.designs,[{id:'design-160',name:'Passendes Design 160'}]);
 for(const url of ['/werkstatt/ausfuehrungen/','/konfigurator/ausfuehrungen/','/workshop-ui/form-variants-ui.mjs','/workshop-ui/form-variant-picker.mjs','/workshop-ui/form-variants.css'])assert.equal((await fetch(base+url)).status,200,url);
});

test('failed group member writes roll back the head revision and immutable history together',async t=>{
 const f=await fixture(t),g=f.w.variants.create(f.input()),raw=new DatabaseSync(f.filename);raw.exec("CREATE TRIGGER variant_failure BEFORE INSERT ON form_variant_members WHEN NEW.revision=2 AND NEW.variant_id='large' BEGIN SELECT RAISE(ABORT,'synthetic failure'); END");const d=f.input();d.name='Geänderte Gruppe';assert.throws(()=>f.w.variants.save(g.id,d,1),/synthetic failure/);assert.deepEqual(f.w.variants.get(g.id),g);assert.equal(f.w.variants.history(g.id).length,1);assert.equal(raw.prepare('SELECT count(*) n FROM form_variant_members WHERE revision=2').get().n,0);raw.close();
});

function batchInput(f,count=1){return {rows:Array.from({length:count},(_,i)=>({import_key:'group-'+i,name:'Gruppe '+i})),variantRows:Array.from({length:count},(_,i)=>f.products.map((p,j)=>({import_key:'group-'+i,variant_id:j?'large':'small',label:j?'Groß':'Klein',product_id:p.id,product_revision:1,default_variant:j?1:0}))).flat()};}
test('Excel group batches review, commit and repeat without duplicating or overwriting later edits',async t=>{
 const f=await fixture(t),input=batchInput(f,3),plan=f.w.variants.plan(input);assert.equal(plan.valid,true,JSON.stringify(plan.report));assert.equal(f.w.variants.list().length,0);const result=f.w.variants.commit({...input,token:plan.token});assert.equal(result.groups.length,3);assert(result.groups.every(g=>g.created));const g=f.w.variants.get(result.groups[0].id);assert.equal(g.document.defaultVariantId,'large');assert.equal(g.document.variants.length,2);
 const changed=structuredClone(g.document);changed.name='Manuell geändert';f.w.variants.save(g.id,changed,1);f.restart();assert(f.w.variants.commit({...input,token:plan.token}).groups.every(g=>!g.created&&!g.updated));assert.equal(f.w.variants.get(g.id).document.name,changed.name);
 const modified=structuredClone(input);modified.rows[0].name='Anders';assert.equal(f.w.variants.plan(modified).report[0].status,'error');
});
test('100 Excel groups retain 97 valid groups and resume three corrected groups atomically',async t=>{
 const f=await fixture(t),input=batchInput(f,100);for(const i of [0,1,2])input.variantRows[i*2].product_revision=99;const p=f.w.variants.plan(input);assert.equal(p.entries.length,97);assert.throws(()=>f.w.variants.commit({...input,token:p.token}));assert.equal(f.w.variants.list().length,0);assert.equal(f.w.variants.commit({...input,token:p.token,skipErrors:true}).groups.length,97);f.restart();for(const i of [0,1,2])input.variantRows[i*2].product_revision=1;const retry=f.w.variants.plan(input);assert.equal(retry.report.filter(r=>r.status==='existing').length,97);assert.equal(f.w.variants.commit({...input,token:retry.token}).groups.filter(g=>g.created).length,3);
 const fresh=batchInput(f,2);fresh.rows.forEach((r,i)=>r.import_key='atomic-'+i);fresh.variantRows.forEach((r,i)=>r.import_key='atomic-'+Math.floor(i/2));const plan=f.w.variants.plan(fresh),raw=new DatabaseSync(f.filename);raw.exec("CREATE TRIGGER fail_group_import BEFORE INSERT ON form_variant_imports WHEN NEW.import_key='atomic-1' BEGIN SELECT RAISE(ABORT,'synthetic import failure'); END");assert.throws(()=>f.w.variants.commit({...fresh,token:plan.token}),/synthetic import failure/);assert.equal(f.w.variants.list().length,100);assert.equal(f.w.variants.importItem('atomic-0'),null);raw.close();
});
test('Excel update merges named variants only and protects group versions and review tokens',async t=>{
 const f=await fixture(t),g=f.w.variants.create(f.input()),input={rows:[{import_key:'edit',action:'update',group_id:g.id,expected_revision:1,name:''}],variantRows:[{import_key:'edit',variant_id:'large',label:'Neuer Name',product_id:f.products[1].id,product_revision:1,default_variant:1}]},p=f.w.variants.plan(input);assert.equal(p.valid,true);const modified=structuredClone(input);modified.variantRows[0].label='Andere Änderung';assert.throws(()=>f.w.variants.commit({...modified,token:p.token}),e=>e.status===409);assert.equal(f.w.variants.commit({...input,token:p.token}).groups[0].updated,true);const saved=f.w.variants.get(g.id);assert.deepEqual(saved.document.variants[0],g.document.variants[0]);assert.equal(saved.document.name,g.document.name);assert.equal(saved.document.defaultVariantId,'large');assert.deepEqual(f.w.variants.get(g.id,1),g);
 const stale=structuredClone(input);stale.rows[0].import_key='stale';stale.variantRows[0].import_key='stale';assert.match(f.w.variants.plan(stale).report[0].message,/inzwischen/);assert.equal(f.w.variants.commit({...input,token:p.token}).groups[0].updated,false);
 const nochange={rows:[{import_key:'noop',action:'update',group_id:g.id,expected_revision:2}],variantRows:[]};assert.equal(f.w.variants.plan(nochange).report[0].status,'unchanged');assert.equal(f.w.variants.plan(nochange).token,null);
});
test('Excel rejects orphan keys, duplicate defaults, unknown fields and ambiguous targets before writes',async t=>{
 const f=await fixture(t),input=batchInput(f);const orphan=structuredClone(input);orphan.variantRows[0].import_key='orphan';assert.throws(()=>f.w.variants.plan(orphan),/keiner Gruppe/);
 for(const change of [d=>d.variantRows[0].default_variant=1,d=>d.variantRows[1].variant_id='small',d=>d.variantRows[0].price=1,d=>d.rows[0].unknown=1,d=>d.rows.push({...d.rows[0]}),d=>d.variantRows[0].product_revision='1.5']){const bad=structuredClone(input);change(bad);assert.equal(f.w.variants.plan(bad).valid,false);assert.equal(f.w.variants.list().length,0);}
});

test('Excel API requires a reviewed token and rejects source archival between review and commit',async t=>{
 const f=await fixture(t),server=createPreviewServer({workshop:f.w,outputDirectory:f.dir});server.listen(0,'127.0.0.1');await once(server,'listening');t.after(()=>new Promise(r=>server.close(r)));const base='http://127.0.0.1:'+server.address().port,session=await(await fetch(base+'/api/workshop/session')).json(),input=batchInput(f);
 const post=(suffix,data,token=session.csrfToken)=>fetch(base+'/api/workshop/variants/batch/'+suffix,{method:'POST',headers:{'Content-Type':'application/json','X-Gravuru-CSRF':token},body:JSON.stringify(data)});
 assert.equal((await post('plan',input,'wrong')).status,403);const r=await post('plan',input);assert.equal(r.status,200);const plan=await r.json();assert.equal(plan.entries,undefined);assert.equal(plan.valid,true);assert.equal((await post('commit',{...input,token:'wrong'})).status,409);assert.equal(f.w.variants.list().length,0);
 f.w.repository.setArchived(f.products[0].id,{archived:true,expectedRevision:1});assert.equal((await post('commit',{...input,token:plan.token})).status,422);assert.equal(f.w.variants.list().length,0);
 const template=await fetch(base+'/api/workshop/variant-import-template');assert.equal(template.status,200);assert.match(template.headers.get('content-disposition'),/Gravuru-Ausfuehrungen.xlsx/);assert.equal(Buffer.from(await template.arrayBuffer()).subarray(0,2).toString(),'PK');
});

// Filled workbook round-trip uses the same XLSX library as an operator download.
import {variantExportData,variantWorkbook} from './variant-export.mjs';
import {execFileSync} from 'node:child_process';
import {importEnvironment} from './design-assets.mjs';
function readExport(bytes){return JSON.parse(execFileSync('python3',['-c',`import sys,io,json
from openpyxl import load_workbook
w=load_workbook(io.BytesIO(sys.stdin.buffer.read()))
def records(name):
 rows=list(w[name].values);return [dict(zip(rows[0],r)) for r in rows[1:] if any(v is not None for v in r)]
print(json.dumps({'rows':records('Gruppen'),'variantRows':records('Varianten'),'products':records('Produktliste'),'sheets':w.sheetnames,'formulas':sum(c.data_type=='f' for s in w for r in s for c in r),'externalLinks':len(w._external_links)}))`],{input:bytes,env:importEnvironment()}).toString());}
test('filled Excel retains historical references, literal names, and round-trips mixed changed and unchanged groups',async t=>{
 const f=await fixture(t),a=f.w.variants.create({...f.input(),name:'=HYPERLINK("https://example.invalid","Test")'}),b=f.w.variants.create({...f.input(),name:'Unverändert'}),next=structuredClone(f.products[0].document);next.name='@Produkt';next.basePriceCents=3999;f.w.repository.save(f.products[0].id,next,1);
 const data=variantExportData(f.w.variants,f.w.repository,{groupIds:[a.id,b.id]}),file=readExport(await variantWorkbook(data));assert.equal(file.formulas,0);assert.equal(file.externalLinks,0);assert.equal(file.rows[0].name,a.document.name);assert.deepEqual(file.sheets,['Gruppen','Varianten','Produktliste','Anleitung']);assert.equal(file.variantRows[0].product_revision,1);assert(file.products.some(p=>p.product_id===f.products[0].id&&p.product_revision===1&&p.current_revision===2&&p.referenced));assert(file.products.some(p=>p.product_id===f.products[0].id&&p.product_revision===2&&p.price_cents===3999));
 const input={rows:file.rows,variantRows:file.variantRows};let p=f.w.variants.plan(input);assert.equal(p.valid,true);assert.equal(p.token,null);assert(p.report.every(r=>r.status==='unchanged'));assert.equal(f.w.variants.get(a.id).revision,1);
 input.rows[0].name='Bearbeitet';p=f.w.variants.plan(input);assert.equal(p.valid,true);assert.equal(p.entries.length,1);const result=f.w.variants.commit({...input,token:p.token});assert.equal(result.groups.length,1);assert.equal(result.groups[0].updated,true);assert.equal(f.w.variants.get(a.id).revision,2);assert.equal(f.w.variants.get(b.id).revision,1);assert.equal(f.w.variants.get(a.id).document.variants[0].productRevision,1);
 assert.equal(f.w.variants.commit({...input,token:p.token}).groups[0].updated,false);
 const fresh=variantExportData(f.w.variants,f.w.repository,{groupIds:[a.id]});assert.notEqual(fresh.rows[0].import_key,data.rows[0].import_key);assert.equal(fresh.rows[0].expected_revision,2);assert.equal(f.w.repository.get(f.products[0].id).revision,2);
});
test('Excel export selection rejects archived, missing, duplicate or excessive groups and marks unavailable products',async t=>{
 const f=await fixture(t),g=f.w.variants.create(f.input());for(const input of [{},{groupIds:[g.id,g.id]},{groupIds:Array(101).fill(g.id)},{groupIds:['absent']},{groupIds:[],unknown:true}])assert.throws(()=>variantExportData(f.w.variants,f.w.repository,input));
 f.w.repository.setArchived(f.products[0].id,{archived:true,expectedRevision:1});const data=variantExportData(f.w.variants,f.w.repository,{groupIds:[g.id]});assert.match(data.products.find(p=>p.product_id===f.products[0].id).availability,/aktive freie/);assert.equal(data.variantRows[0].product_revision,1);
 const archived={...g.document,archived:true};f.w.variants.save(g.id,archived,1);assert.throws(()=>variantExportData(f.w.variants,f.w.repository,{groupIds:[g.id]}),/Archivierte/);const blank=readExport(await variantWorkbook(variantExportData(f.w.variants,f.w.repository,{groupIds:[]})));assert.equal(blank.rows.length,0);assert.equal(blank.variantRows.length,0);assert.equal(blank.products.length,1);assert.equal(blank.products[0].product_id,f.products[1].id);
});
test('Excel export of 100 groups preserves all references and a stale edit never overwrites a newer group',async t=>{
 const f=await fixture(t),input=batchInput(f,100),created=f.w.variants.commit({...input,token:f.w.variants.plan(input).token});const data=variantExportData(f.w.variants,f.w.repository,{groupIds:created.groups.map(g=>g.id)}),file=readExport(await variantWorkbook(data));assert.equal(file.rows.length,100);assert.equal(file.variantRows.length,200);assert.equal(new Set(file.rows.map(r=>r.import_key)).size,100);
 const first=f.w.variants.get(created.groups[0].id);f.w.variants.save(first.id,{...first.document,name:'Parallel geändert'},1);file.rows[0].name='Veralteter Versuch';const p=f.w.variants.plan({rows:file.rows,variantRows:file.variantRows});assert.equal(p.valid,false);assert.match(p.report[0].message,/inzwischen/);assert.equal(p.report.filter(r=>r.status==='unchanged').length,99);assert.equal(f.w.variants.get(first.id).document.name,'Parallel geändert');
});
test('Excel export API is read-only, CSRF/origin guarded and sends a non-cacheable XLSX attachment',async t=>{
 const f=await fixture(t),g=f.w.variants.create(f.input()),server=createPreviewServer({workshop:f.w,outputDirectory:f.dir});server.listen(0,'127.0.0.1');await once(server,'listening');t.after(()=>new Promise(r=>server.close(r)));const base='http://127.0.0.1:'+server.address().port,session=await(await fetch(base+'/api/workshop/session')).json();
 const post=(headers={})=>fetch(base+'/api/workshop/variants/batch/export',{method:'POST',headers:{'Content-Type':'application/json','X-Gravuru-CSRF':session.csrfToken,...headers},body:JSON.stringify({groupIds:[g.id]})});assert.equal((await post({'X-Gravuru-CSRF':'wrong'})).status,403);assert.equal((await post({Origin:'https://foreign.invalid'})).status,403);const r=await post();assert.equal(r.status,200);assert.equal(r.headers.get('cache-control'),'no-store');assert.match(r.headers.get('content-disposition'),/Gravuru-Ausfuehrungen-Bestand.xlsx/);const file=readExport(Buffer.from(await r.arrayBuffer()));assert.equal(file.rows[0].group_id,g.id);assert.deepEqual(f.w.variants.get(g.id),g);assert.equal(f.w.variants.history(g.id).length,1);
});
