import test from 'node:test';
import assert from 'node:assert/strict';
import {createDesignSwitch,switchedEditorPath,switchedModel} from './ui/shop-design-switch.mjs';
const binding={productId:'synthetic-target',productRevision:2,shopifyProductId:'gid://shopify/Product/2',shopifyVariantId:'gid://shopify/ProductVariant/22'};
const data=()=>({editorPath:'/_merchant-editor.html',binding,model:{name:'Target',configuration:{id:binding.productId,revision:2},universal:{profile:{designs:[{id:'design-target'}]}},legacy:{}}});
const result=()=>({token:'gse1.new.signature',binding,designId:'design-target'});
test('new product never inherits previous cart edit IDs; legitimate embedded toolbar remains',()=>{
 assert.equal(switchedEditorPath(data(),new URLSearchParams('embed=1&leiste=b&config=old&rev=8&line=old-line')),'/_merchant-editor.html?leiste=b');
 assert.equal(switchedEditorPath(data(),new URLSearchParams('leiste=b&config=old')),'/_merchant-editor.html');
});
test('switch model must exactly match new session product, variant, revision and existing design',()=>{
 const original=data(),changed=switchedModel(original,result());assert.equal(changed.model.universal.profile.defaultDesignId,'design-target');assert.equal(original.model.universal.profile.defaultDesignId,undefined);
 for(const field of ['productId','productRevision','shopifyProductId','shopifyVariantId'])assert.throws(()=>switchedModel(data(),{...result(),binding:{...binding,[field]:'foreign'}}));
 assert.throws(()=>switchedModel(data(),{...result(),designId:'unknown'}));
});
function fixture({fail=false}={}){
 const listeners=new Set(),frames=[],win={location:{origin:'https://test.example'},history:{replaceState(_s,_t,hash){win.hash=hash;}},addEventListener(_type,fn){listeners.add(fn);},removeEventListener(_type,fn){listeners.delete(fn);},setTimeout,clearTimeout};
 const makeFrame=()=>({style:{},contentWindow:{},remove(){this.removed=true;}}),old=makeFrame();old.photoFile={name:'customer-photo.png'};
 const nextClient={loadModel:async()=>{if(fail)throw Error('target-load-failed');return data();},loadResources:async()=>({target:true})};
 const client={switchDesign:async()=>result(),loadDesignGallery:async()=>[],loadDesignPreview:async()=>new Blob()};
 let active,api;const backAtActivation=[];
 const coordinator=createDesignSwitch({initial:{client,data:{old:true},resources:{old:true},frame:old},fragment:new URLSearchParams('s=gse1.old.signature&config=old-config&rev=2&line=old-line'),container:{append(frame){frames.push(frame);queueMicrotask(()=>{for(const listen of listeners)listen({origin:win.location.origin,source:frame.contentWindow,data:{type:'gravuru-ux-ready'}});});}},activate(entry,gallery){active=entry;api=gallery;backAtActivation.push(gallery.canGoBack());},toDataUrl:async()=>'',win,doc:{createElement:makeFrame},clientFactory:()=>nextClient,timeoutMs:100});
 return {old,frames,win,coordinator,backAtActivation,get api(){return api;},get active(){return active;}};
}
test('successful switch uses new gateway; original live frame/photo survive and Back restores exact cart IDs',async()=>{
 const f=fixture(),oldApi=f.api,photo=f.old.photoFile,transfer={texts:[{fieldKey:'name',text:'Anna'}]};await oldApi.choose('signed-target',transfer);
 assert.deepEqual(f.backAtActivation,[false,true],'Back is visible during the new editor initialization, before its ready message');
 assert.equal(f.old.hidden,true);assert.equal(f.old.style.display,'none');assert.equal(f.old.photoFile,photo);assert.notEqual(f.active.frame,f.old);assert.equal(f.api.hasPendingTransfer(),true);assert.deepEqual(f.api.takeTransfer(),transfer);assert.equal(f.api.hasPendingTransfer(),false);
 assert.ok(!f.win.hash.includes('config='));assert.equal(f.api.canGoBack(),true);assert.throws(()=>oldApi.load());
 const target=f.active.frame;assert.equal(f.api.back(),true);assert.equal(f.active.frame,f.old);assert.equal(f.old.hidden,false);assert.equal(f.old.photoFile,photo);assert.equal(target.removed,true);assert.match(f.win.hash,/config=old-config/);assert.match(f.win.hash,/line=old-line/);
});
test('failed target load leaves original frame, photo, gateway and cart context intact',async()=>{
 const f=fixture({fail:true}),photo=f.old.photoFile;await assert.rejects(f.api.choose('signed-target',{}),/target-load-failed/);assert.equal(f.active.frame,f.old);assert.equal(f.old.photoFile,photo);assert.equal(f.old.removed,undefined);assert.equal(f.api.canGoBack(),false);assert.equal(f.win.hash,undefined);
});
