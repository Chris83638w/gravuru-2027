import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {Workbench,defaultProduct,availableFonts} from '../workbench.mjs';
import {checkDesign} from '../workbench-checks.mjs';
import {surfacePreview} from '../../../configurator/variant-m/material-surface.mjs';
const root=()=>fs.mkdtempSync(path.join(os.tmpdir(),'gravuru-library-'));
test('Kategorien behalten Shop-IDs und Hierarchie; veraltete Stände und Zyklen werden abgewiesen',()=>{
 const dir=root();fs.writeFileSync(path.join(dir,'catalog-snapshot.json'),JSON.stringify({products:[],collections:[{id:'gid://shopify/Collection/3',title:'Tiere'}],menus:[{handle:'main-menu',items:[{id:'gid://shopify/MenuItem/1',title:'Andenken',type:'HTTP',items:[{id:'gid://shopify/MenuItem/2',title:'Tiere',type:'COLLECTION',resourceId:'gid://shopify/Collection/3'}]}]}]}));
 const w=new Workbench({root:dir}),lib=w.library.load();assert.equal(lib.categories[1].parentId,'menu-1');assert.equal(lib.categories[1].collectionId,'gid://shopify/Collection/3');
 assert.throws(()=>w.library.save('categories',{expectedRevision:1,value:{...lib.categories[0],parentId:'menu-2'}}),/unter sich/);
 const next=w.library.save('categories',{expectedRevision:1,value:{name:'Neu',parentId:'menu-2'}});assert.equal(new Workbench({root:dir}).library.load().categories.length,3);
 assert.throws(()=>w.library.save('categories',{expectedRevision:1,value:{name:'Veraltet'}}),/geändert/);
 const p=w.create({...defaultProduct(),categoryId:next.categories[2].id});assert.throws(()=>w.library.save('categories',{expectedRevision:2,value:{...next.categories[2],deleted:true}}),/verwendet/);assert.equal(w.load(p.id).data.categoryId,next.categories[2].id);
});
test('Fehlende Schrift wird am Feld markiert; Ersatz löst alte PDF-Fehlermeldung auf',()=>{
 const fonts=availableFonts(),d={id:'D1',name:'Probe',marks:[],objects:[{id:'t1',type:'text',text:'Sammy',font:'PDF-Missing',size:15,x:110,y:70,w:50,h:18,rotation:0,bold:false}]},p=defaultProduct();
 const problems=checkDesign(structuredClone(d),fonts,p,['Schrift fehlt: Missing. Schriftdatei ergänzen und PDF erneut einlesen.']);assert.equal(problems[0].index,0);assert.equal(problems[0].field,'font');assert(problems[0].patch.font);
 Object.assign(d.objects[0],problems[0].patch);assert.deepEqual(checkDesign(d,fonts,p,['Schrift fehlt: Missing. Schriftdatei ergänzen und PDF erneut einlesen.']),[]);
 d.objects[0].text='Sammy\u{1f984}';assert(checkDesign(d,fonts,p).some(p=>p.field==='font'));
});
test('Materialbilder sind sichere Vorschauressourcen; Bohrgeometrie bleibt erhalten',()=>{
 const base='<svg><defs></defs><rect width="220" height="140"/><g data-object="one"/><circle cx="12" cy="70" r="2.5"/></svg>',url='/api/product-workbench/assets/'+'a'.repeat(64)+'.png',g={width:220,height:140,shape:'rect'};
 const rendered=surfacePreview(base,url,g);assert.match(rendered,/data-material-surface/);assert.match(rendered,/<circle cx="12" cy="70" r="2.5"/);assert.equal(surfacePreview(base,'javascript:alert(1)',g),base);
});
test('Material, SKU, Profile und Kategorien bleiben nach Neustart editierbar',()=>{
 const w=new Workbench({root:root()}),p=w.create({...defaultProduct(),sku:'EINMAL'});assert.throws(()=>w.create({...defaultProduct(),sku:'EINMAL'}),/bereits/);
 assert.throws(()=>w.update(p.id,{expectedRevision:1,data:{...p.data,processing:'steel-engraving'}}),/passen nicht/);
 const lib=w.library.load(),profile=w.library.save('mountings',{expectedRevision:lib.revision,value:{name:'Eigene Schieferbohrung',materialKind:'slate',options:[{id:'B02',label:'Oben',price:4,holeCount:2,edge:10,diameter:4,layout:'top'}]}}).mountings.at(-1);
 w.update(p.id,{expectedRevision:1,data:{...p.data,options:profile.options,mountingProfileId:profile.id,keyword:'Tiergedenktafel',seoTitle:'Persönliche Tiergedenktafel'}});
 const restored=new Workbench({root:w.root});assert.equal(restored.load(p.id).data.options[0].layout,'top');assert.equal(restored.load(p.id).data.seoTitle,'Persönliche Tiergedenktafel');
 w.archive(p.id,{expectedRevision:2,archived:true});w.archive(p.id,{expectedRevision:3,archived:false});assert.equal(w.load(p.id).archived,false);
});
