import sharp from 'sharp';
import fs from 'node:fs';
import path from 'node:path';
import {hash,writeJson} from './lib/core.mjs';
const [sourceDir,targetDir]=process.argv.slice(2);
if(!sourceDir||!targetDir||fs.existsSync(targetDir))throw Error('Quellordner und neuen Ausgabeordner angeben. Originale bleiben erhalten.');
fs.mkdirSync(targetDir,{recursive:true});
const resources=[];
for(const entry of fs.readdirSync(sourceDir,{withFileTypes:true})){
 if(!entry.isFile()||!/^.+\.(png|jpe?g|webp)$/i.test(entry.name))continue;
 const source=path.join(sourceDir,entry.name),original=fs.readFileSync(source);
 for(const width of [600,1200,1600]){
   let result;
   for(const quality of [84,78,72]){
     result=await sharp(original).rotate().resize({width,withoutEnlargement:true}).webp({quality,effort:6}).toBuffer();
     if(result.length<=400000)break;
   }
   if(result.length>400000)throw Error('Bildbudget nicht erreicht: '+entry.name+'. Keine weitere Qualitätsverschlechterung automatisch.');
   const name=path.parse(entry.name).name+'-'+width+'.webp';fs.writeFileSync(path.join(targetDir,name),result);
   resources.push({path:name,purpose:'responsive-product-image',width,bytes:result.length,sha256:hash(result),sourceSha256:hash(original)});
 }
}
if(!resources.length)throw Error('Keine unterstützten Produktbilder vorhanden.');
writeJson(path.join(targetDir,'images.json'),resources);console.log(`${resources.length} Bildgrößen erstellt. Quelle unverändert. Metadaten entfernt.`);
