import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {Workbench,defaultProduct,cents,validateProduct,optionGroups} from '../workbench.mjs';
import {uploadQuote} from '../../../configurator/variant-m/ux-model.mjs';

const root=()=>fs.mkdtempSync(path.join(os.tmpdir(),'gravuru-workbench-'));
test('Preise bleiben offen, Dezimalpreise und physische Optionen werden geprüft',()=>{
 assert.equal(cents('',{optional:true}),null);assert.equal(cents('19,99'),1999);
 assert.throws(()=>cents('19.999'));assert.throws(()=>cents('-1'));
 const p=validateProduct(defaultProduct());assert.equal(p.basePrice,null);
 const groups=optionGroups(p);assert.deepEqual(groups[0].values[1].holes.map(h=>[h.x,h.y]),[[12,70],[208,70]]);
 assert.throws(()=>validateProduct({...p,width:20}));
});
test('Produkte bleiben nach Neustart erhalten; veraltete Revision überschreibt nichts',()=>{
 const dir=root(),w=new Workbench({root:dir});const p=w.create(defaultProduct());
 const changed=w.update(p.id,{expectedRevision:1,data:{...p.data,basePrice:'24,90'}});
 assert.equal(changed.revision,2);assert.throws(()=>w.update(p.id,{expectedRevision:1,data:p.data}),/Zwischenzeitlich/);
 const restored=new Workbench({root:dir}).load(p.id);assert.equal(restored.data.basePrice,24.9);
 assert.equal(fs.readdirSync(path.join(dir,p.id,'revisions')).length,2);
 assert.throws(()=>w.load('../escape'),/Kennung/);
});
test('Preisregel enthält nur die gewählte Zahl Fotos; Logos bleiben zusätzlich',()=>{
 const photos=[{uxUploadId:'a',uxUploadKind:'photo'},{uxUploadId:'b',uxUploadKind:'photo'}];
 assert.equal(uploadQuote(photos,2,false,{includedCount:1,extraPriceCents:599}).totalCents,1198);
 assert.equal(uploadQuote([{uxUploadId:'a',uxUploadKind:'logo'}],1,false,{includedCount:1,extraPriceCents:599}).unitCents,599);
 assert.equal(uploadQuote(photos,1).unitCents,1998);
});
test('Auswahl, Entfernen und Wiederherstellen bewahren frühere Fassungen',()=>{
 const w=new Workbench({root:root()}),p=w.create(defaultProduct());const dir=path.join(w.dir(p.id),'imports','test');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'1.json'),JSON.stringify({design:{id:'D1',name:'Test',objects:[],marks:[]},resources:{fonts:{},motifs:[]},errors:[]}));p.designs=[{id:'D1',importId:'test',page:1,errors:[],selected:true,deleted:false}];w.save(p,1);
 let saved=w.changeDesign(p.id,'D1',{action:'delete',expectedRevision:2});assert.equal(saved.designs[0].deleted,true);
 saved=w.changeDesign(p.id,'D1',{action:'restore',expectedRevision:3});assert.equal(saved.designs[0].deleted,false);assert.equal(saved.designs[0].selected,false);
});
test('Drei echte PDFs automatisch einlesen, Duplikate erkennen und editierbares Paket bauen',{skip:!process.env.GRAVURU_TEST_PDF_DIR},async()=>{
 const w=new Workbench({root:process.env.GRAVURU_TEST_OUTPUT||root()}),p=w.create({...defaultProduct(),basePrice:24.9,description:'Testbeschreibung.'});
 const results=[];
 for(const code of ['D201','D218','D236']){
   const name='GT-S-22x14-'+code+'.pdf',bytes=fs.readFileSync(path.join(process.env.GRAVURU_TEST_PDF_DIR,name));
   const payload={name,base64:bytes.toString('base64'),expectedRevision:w.load(p.id).revision};
   const result=await w.upload(p.id,payload);assert.equal(result.product.designs.length,results.length+1);results.push(result);
   assert.deepEqual(fs.readFileSync(path.join(process.env.GRAVURU_TEST_PDF_DIR,name)),bytes);
 }
 const first=results[0].product.designs[0],current=w.load(p.id),original=fs.readFileSync(path.join(process.env.GRAVURU_TEST_PDF_DIR,first.source));
 const duplicate=await w.upload(p.id,{expectedRevision:current.revision,name:first.source,base64:original.toString('base64')});assert.equal(duplicate.duplicate,true);assert.equal(w.load(p.id).revision,current.revision);
 const report=w.detail(p.id);console.log('PDF-TEST',JSON.stringify({id:p.id,root:w.root,designs:report.designs.map(d=>({id:d.id,errors:d.errors,issues:d.issues}))}));
 const config=w.compile(p.id,{designId:first.id});assert.equal(config.profile.geometry.width,220);assert.equal(config.basePriceCents,2490);assert.equal(config.photo.includedCount,1);assert(config.profile.designs[0].objects.some(o=>o.type==='photoSlot'));assert(config.profile.designs[0].objects.some(o=>o.type==='text'&&o.text==='Snow'));
 for(const d of report.designs){assert.equal(d.errors.length,0,d.id);assert.equal(w.compile(p.id,{designId:d.id}).profile.designs[0].id,d.id);}
 let rev=w.load(p.id).revision;w.changeDesign(p.id,first.id,{action:'review',reviewed:true,expectedRevision:rev});
 rev=w.load(p.id).revision;const active=w.activate(p.id,{expectedRevision:rev,confirm:true});assert(active.activeRevision);assert(active.lastCheck.issues.length>0);
 assert.match(w.csv(p.id),/24.90/);assert.match(w.csv(p.id),/27.89/);
 const pack=w.package(p.id);assert.equal(pack.config.profile.designs.length,1);
 const edited=structuredClone(pack.config.profile.designs[0]);edited.objects.find(o=>o.type==='text').text='Luna';
 w.changeDesign(p.id,first.id,{action:'edit',design:edited,expectedRevision:w.load(p.id).revision});
 assert.equal(w.compile(p.id,{active:true}).profile.designs[0].objects.find(o=>o.type==='text').text,'Snow');
 assert.equal(w.compile(p.id,{designId:first.id}).profile.designs[0].objects.find(o=>o.type==='text').text,'Luna');
 const d236=w.load(p.id).designs.find(d=>d.id.endsWith('D236')),full=w.bundle(p.id,d236).design;
 assert(full.objects.some(o=>o.type==='text'&&o.text==='Molly'));
 const name=full.objects.find(o=>o.type==='text');name.text='Luna';name.font='Montserrat';
 w.changeDesign(p.id,d236.id,{action:'edit',design:full,expectedRevision:w.load(p.id).revision});
 assert(w.compile(p.id,{designId:d236.id}).localResources.fonts.Montserrat);
 const unsafe=structuredClone(full);unsafe.objects[0].x='0)" onload="alert(1)';
 assert.throws(()=>w.changeDesign(p.id,d236.id,{action:'edit',design:unsafe,expectedRevision:w.load(p.id).revision}),/Elementmaße/);
 const selected=w.load(p.id).designs.find(d=>d.id===first.id);
 await w.upload(p.id,{expectedRevision:w.load(p.id).revision,name:first.source,base64:original.toString('base64'),retry:true});
 w.changeDesign(p.id,first.id,{action:'rollback',expectedRevision:w.load(p.id).revision});
 assert.deepEqual(w.bundle(p.id,w.load(p.id).designs.find(d=>d.id===first.id)).design,selected.design);
});
