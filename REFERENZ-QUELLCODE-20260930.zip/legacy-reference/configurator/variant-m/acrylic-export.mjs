import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {acrylicSelection} from './acrylic-product.mjs';
let running=false;
export async function exportAcrylicPDF(payload) {
  acrylicSelection(payload.options);
  if(running)throw Error('Ein Druckexport läuft bereits. Bitte kurz erneut versuchen.');
  running=true;
  try{return await new Promise((resolve,reject)=>{
    const process=spawn(globalThis.process.env.GRAVURU_PYTHON||'python',[fileURLToPath(new URL('./acrylic-print.py',import.meta.url))],{windowsHide:true,env:{...globalThis.process.env,PYTHONIOENCODING:'utf-8'},stdio:['pipe','pipe','pipe']});
    const output=[],errors=[];let length=0;
    const timer=setTimeout(()=>{process.kill();reject(Error('Druckexport hat zu lange gedauert.'));},60000);
    process.stdout.on('data',chunk=>{length+=chunk.length;if(length>180_000_000){process.kill();reject(Error('Druckdatei zu groß.'));}else output.push(chunk);});
    process.stderr.on('data',chunk=>errors.push(chunk));
    process.on('error',error=>{clearTimeout(timer);reject(error);});
    process.on('close',code=>{clearTimeout(timer);if(code===0)resolve(Buffer.concat(output));else reject(Error(Buffer.concat(errors).toString().slice(0,1000)||'Druckexport fehlgeschlagen.'));});
    process.stdin.on('error',()=>{});process.stdin.end(JSON.stringify(payload));
  });}finally{running=false;}
}
