"""Current one-design PDF with an embedded editable Gravuru source, no AI calls.

Artwork uses font outlines for exact rendering; the embedded native source keeps
texts editable when the same PDF is uploaded to the converter again.
"""
import argparse, hashlib, json, math, re
from io import BytesIO
from pathlib import Path
from xml.etree import ElementTree as ET
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from fontTools.pens.reportLabPen import ReportLabPen
from fontTools.svgLib.path import parse_path
from pypdf import PdfReader, PdfWriter
import pypdfium2 as pdfium

ATTACHMENT = 'gravuru-editable-design.json'
SCHEMA = 'gravuru-editable-pdf/v1'
MM = 72 / 25.4

def signature(pdf):
    doc=pdfium.PdfDocument(pdf)
    try:
        image=doc[0].render(scale=1).to_pil().convert('RGB')
        return hashlib.sha256(str(image.size).encode()+image.tobytes()).hexdigest()
    finally: doc.close()

def draw_path(c, data, fill=True, stroke=False, rule='nonzero'):
    target=c.beginPath();target.closePath=target.close
    pen=ReportLabPen(None,target);parse_path(data,pen)
    c.drawPath(pen.path,fill=int(fill),stroke=int(stroke),fillMode=int(rule=='nonzero'))

def create(bundle, target):
    w,h=bundle['geometry']['width'],bundle['geometry']['height']
    out=BytesIO();c=canvas.Canvas(out,pagesize=(w*MM,h*MM),pageCompression=1)
    c.setTitle(bundle['design']['name']);c.setAuthor('Gravuru Werkstatt')
    c.scale(MM,MM);c.translate(0,h);c.scale(1,-1)
    fonts=bundle['resources']['fonts'];motifs={m['key']:m for m in bundle['resources']['motifs']}
    for o in bundle['design']['objects']:
        if o.get('uxHidden'):continue
        c.saveState();c.translate(o['x'],o['y']);c.rotate(o.get('rotation',0))
        color=HexColor(o.get('color','#111111')) if bundle.get('processing')=='color-print' else HexColor('#111111')
        c.setFillColor(color);c.setStrokeColor(color)
        if o['type']=='text':
            family=fonts[o['font']];f=family.get('bold') if o.get('bold') else family['regular'];f=f or family['regular']
            lines=o['text'].split('\n');scale=o['size']/f['units']
            for i,line in enumerate(lines):
                c.saveState();c.translate(0,(i-(len(lines)-1)/2)*o['size']*1.2+o['size']*.35);c.scale(scale,-scale)
                x=-sum(f['glyphs'][ch]['a'] for ch in line)/2
                for ch in line:
                    glyph=f['glyphs'][ch];c.saveState();c.translate(x,0)
                    if glyph['d']:draw_path(c,glyph['d'])
                    c.restoreState();x+=glyph['a']
                c.restoreState()
        elif o['type']=='motif':
            m=motifs[o['motif']];bx,by,bw,bh=m['bounds'];c.translate(-o['w']/2,-o['h']/2);c.scale(o['w']/bw,o['h']/bh);c.translate(-bx,-by)
            for p in ET.fromstring('<svg>'+m['svgFragment']+'</svg>'):
                if p.tag!='path':raise ValueError('Motivpfad nicht unterstützt')
                c.setLineWidth(float(p.get('stroke-width','0.1')))
                draw_path(c,p.attrib['d'],p.get('fill')!='none',p.get('stroke')=='currentColor',p.get('fill-rule','nonzero'))
        elif o['type']=='photoSlot':
            c.setLineWidth(.3);c.setDash(2,1)
            if o.get('photoShape') in ('circle','ellipse'):c.ellipse(-o['w']/2,-o['h']/2,o['w']/2,o['h']/2)
            else:c.rect(-o['w']/2,-o['h']/2,o['w'],o['h'])
            c.setDash();c.scale(1,-1);c.setFont('Helvetica',3);c.drawCentredString(0,0,'Dein Foto')
        elif o['type']=='graphic':
            stroke=o.get('strokeWidth',.5);c.setLineWidth(stroke);fill=int(o.get('filled',False));o={**o,'w':max(0,o['w']-stroke),'h':max(0,o['h']-stroke)}
            if o.get('shape') in ('ellipse','circle'):c.ellipse(-o['w']/2,-o['h']/2,o['w']/2,o['h']/2,fill=fill)
            elif o.get('shape')=='line':c.line(-o['w']/2,0,o['w']/2,0)
            else:c.rect(-o['w']/2,-o['h']/2,o['w'],o['h'],fill=fill)
        else:raise ValueError('Nicht unterstütztes PDF-Element: '+o['type'])
        c.restoreState()
    for mark in bundle['design'].get('marks',[]):
        c.setStrokeColor(HexColor('#111111'));c.setLineWidth(mark['width']);draw_path(c,mark['d'],False,True)
    c.showPage();c.save();raw=out.getvalue()
    payload={'schema':SCHEMA,'pageSignature':signature(raw),'bundle':bundle}
    writer=PdfWriter();writer.append(PdfReader(BytesIO(raw)));writer.add_attachment(ATTACHMENT,json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode())
    with open(target,'wb') as f:writer.write(f)

def read_editable(pdf_path,out,width,height):
    reader=PdfReader(str(pdf_path));attachments=reader.attachments
    if ATTACHMENT not in attachments:return None
    data=attachments[ATTACHMENT]
    if len(data)!=1 or len(data[0])>25*1024*1024:raise ValueError('Ungültige Gravuru-PDF-Quelle')
    payload=json.loads(data[0]);bundle=payload['bundle']
    if payload.get('schema')!=SCHEMA or len(reader.pages)!=1:raise ValueError('Unbekannte Gravuru-Arbeits-PDF')
    if payload.get('pageSignature')!=signature(str(pdf_path)):raise ValueError('PDF wurde außerhalb der Werkstatt verändert. Eingebettete Gestaltung stimmt nicht mehr mit der Seite überein.')
    if bundle['geometry']!={'width':width,'height':height}:raise ValueError('Arbeits-PDF hat andere Produktmaße.')
    key=bundle['design']['id']
    if not re.fullmatch(r'[\w.-]{1,120}',key):raise ValueError('Ungültige Designkennung')
    sha=hashlib.sha256(pdf_path.read_bytes()).hexdigest();bundle['source']={'file':pdf_path.name,'sha256':sha,'page':1};bundle['revision']=sha[:12]+'-1';bundle['editablePdf']=True
    bundle['issues']=['Bearbeitbare Werkstattfassung aus der Arbeits-PDF übernommen.'];bundle['errors']=[]
    (out/'1.json').write_text(json.dumps(bundle,ensure_ascii=False),encoding='utf-8')
    doc=pdfium.PdfDocument(str(pdf_path));doc[0].render(scale=2).to_pil().save(out/'1.png');doc.close()
    return {'sourceHash':sha,'pages':[{'id':key,'page':1,'issues':bundle['issues'],'errors':[], 'objects':len(bundle['design']['objects']),'fonts':list(bundle['resources']['fonts']),'editablePdf':True}]}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--bundle',required=True);parser.add_argument('--out',required=True);args=parser.parse_args()
    create(json.loads(Path(args.bundle).read_text(encoding='utf-8')),args.out)
