﻿<#
Gravuru – volle Original-Corel-Bögen einer Linie + Schriftarten auf den Laptop kopieren (nur LESEN vom Server).

Warum: Die Light-Kopien haben keine Bilder (Bitmaps genullt). Für die Musterprüfung braucht jedes Design seine Motive
und Platzhalter-Fotos, und die Texte brauchen die echten Schriften.

Was passiert:
  1. Jede *.cdr aus den [CDR]-Ordnern der Linie (Liste: <Linie>-cdr.txt neben diesem Skript) wird ungekürzt nach
     C:\katalog-quelle\voll\<Pfad> kopiert (robocopy, liest nur; schon vorhandene gleiche Dateien werden übersprungen).
  2. V:\Schriftarten wird nach C:\katalog-quelle\schriften kopiert (robocopy, liest nur).
  3. Dateien über 380 MB werden zusätzlich in Teile zu 380 MB nach C:\katalog-quelle\voll-teile\<Pfad> geschrieben
     (für die Übertragung zu Claude, max. 390 MB je Datei). Die Originalkopie bleibt.
  4. C:\katalog-quelle\voll\_liste-<Linie>.csv (Pfad; Bytes; Teile)
Auf dem Server wird nichts verändert, verschoben oder gelöscht.

Aufruf:
    powershell -ExecutionPolicy Bypass -File copy-voll-linie.ps1                 # Gedenktafeln
    powershell -ExecutionPolicy Bypass -File copy-voll-linie.ps1 -Linie Hausnummern
#>
param(
    [string]$Linie = "Gedenktafeln",
    [string]$Quelle = "V:\Produkte",
    [string]$Schriften = "V:\Schriftarten",
    [string]$Ziel = "C:\katalog-quelle",
    [switch]$OhneSchriften
)
$ErrorActionPreference = 'Continue'
$teilBytes = 380MB

# Netzlaufwerk V: in dieser Sitzung nicht verbunden? -> UNC-Pfad nehmen
if (-not (Test-Path -LiteralPath $Quelle)) {
    $unc = '\\bi-srv01-fs01.lan.gravuru.de\Neue-Struktur'
    Write-Host "V: nicht erreichbar, nehme $unc"
    $Quelle = Join-Path $unc 'Produkte'; $Schriften = Join-Path $unc 'Schriftarten'
}
$liste = Join-Path $PSScriptRoot "$Linie-cdr.txt"
if (-not (Test-Path -LiteralPath $liste)) { Write-Host "Liste fehlt: $liste"; exit 1 }
$ordner = Get-Content -LiteralPath $liste -Encoding UTF8 | Where-Object { $_.Trim() -ne '' }
$voll = Join-Path $Ziel 'voll'; $teile = Join-Path $Ziel 'voll-teile'
New-Item -ItemType Directory -Force -Path $voll, $teile | Out-Null

$i = 0
foreach ($rel in $ordner) {
    $i++
    $src = Join-Path $Quelle $rel; $dst = Join-Path $voll $rel
    Write-Host ("[{0}/{1}] {2}" -f $i, $ordner.Count, $rel)
    robocopy "$src" "$dst" *.cdr /XF "Sicherungskopie_von_*" /R:3 /W:10 /NP /NJH /NJS /NDL /NC | Out-Null
    if ($LASTEXITCODE -ge 8) { Write-Host "   FEHLER robocopy ($LASTEXITCODE) bei $rel" }
}

if (-not $OhneSchriften) {
    Write-Host "Schriftarten: $Schriften -> $Ziel\schriften"
    robocopy "$Schriften" (Join-Path $Ziel 'schriften') /E /R:3 /W:10 /NP /NJH /NJS /NDL /NC | Out-Null
    if ($LASTEXITCODE -ge 8) { Write-Host "   FEHLER robocopy Schriften ($LASTEXITCODE)" }
}

# große Dateien in Teile schneiden, Liste schreiben
$csv = New-Object System.Collections.Generic.List[string]; $csv.Add('Pfad;Bytes;Teile')
$wurzel = Join-Path $voll $Linie
Get-ChildItem -LiteralPath $wurzel -Recurse -File -Filter *.cdr | ForEach-Object {
    $rel = $_.FullName.Substring($voll.Length).TrimStart('\'); $n = 0
    if ($_.Length -gt $teilBytes) {
        $zdir = Join-Path $teile (Split-Path $rel -Parent); New-Item -ItemType Directory -Force -Path $zdir | Out-Null
        $n = [math]::Ceiling($_.Length / $teilBytes)
        $letzter = Join-Path $zdir ("{0}.part{1:D3}" -f $_.Name, $n)
        if (-not ((Test-Path -LiteralPath $letzter) -and ((Get-Item -LiteralPath $letzter).LastWriteTime -ge $_.LastWriteTime))) {
            Write-Host "   teile $rel ($n Teile)"
            $in = [System.IO.File]::OpenRead($_.FullName); $buf = New-Object byte[] (4MB)
            try {
                for ($k = 1; $k -le $n; $k++) {
                    $out = [System.IO.File]::Create((Join-Path $zdir ("{0}.part{1:D3}" -f $_.Name, $k)))
                    $rest = $teilBytes
                    while ($rest -gt 0) { $r = $in.Read($buf, 0, [math]::Min($buf.Length, $rest)); if ($r -le 0) { break }; $out.Write($buf, 0, $r); $rest -= $r }
                    $out.Close()
                }
            } finally { $in.Close() }
        }
    }
    $csv.Add("$rel;$($_.Length);$n")
}
$csv | Set-Content -LiteralPath (Join-Path $voll "_liste-$Linie.csv") -Encoding UTF8
$sum = (Get-ChildItem -LiteralPath $wurzel -Recurse -File -Filter *.cdr | Measure-Object Length -Sum).Sum
Write-Host ("FERTIG: {0} Bögen, {1:N1} GB. Liste: {2}" -f ($csv.Count - 1), ($sum / 1GB), (Join-Path $voll "_liste-$Linie.csv"))
