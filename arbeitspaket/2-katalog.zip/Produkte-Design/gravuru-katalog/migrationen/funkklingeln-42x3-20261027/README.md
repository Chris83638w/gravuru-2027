# Funkklingeln: lokaler Migrationsstand vom 27.10.2026

42 bekannte Modelle, drei Formate, 126 Hauptprodukte. Der Auftrag vom 27.10.2026 erweitert den früheren Katalogausschluss ausdrücklich. Diese Dateien sind ein vorbereiteter Datenstand; sie behaupten keine Veröffentlichung.

## Dateien
- migration-manifest.json: eigene versionierte Migration, Modelle, Formate, Quellen und offene Importaufgaben.
- main-products-126.json: 42 bestehende Portrait-IDs und 84 neue Einstiege ohne erfundene IDs. 63 Startfarben Schwarz, 63 Anthrazit. Jeder Einstieg behält drei Formate, zwei Farben, vier Rahmen, fünf Befestigungen, beide Positionen und 16 Designs.
- models/: 126 vollständige Profile, ursprüngliche SVG-Geräteschnitte und abgeleitete Gegenpositionen. Alle Maße in mm.
- sources/: 176 bytegleiche Quellkopien einschließlich 42 Modellbildern; source-index.json enthält SHA-256.
- native-inputs/: 42 Adapter-Eingaben mit je drei Profilen und lokalen Dekormotiven. Keine vollständigen freigegebenen Runtime-Konfigurationen.
- native-profiles/: 126 Einzelprofile mit 1.848 verlustfrei übernommenen Dekormarkierungen als native Motif-Objekte.
- variants/: 5.040 bestehende Varianten mit unveränderten IDs, SKUs und Preisen. Neue Varianten erhalten nur einen deterministischen Reihenfolgeplan, keine reservierte Nummer.
- normalization-report.json: jede korrigierte alte Format-Metadatenangabe mit Vorher/Nachher.
- audit.json und static-verification.json: bestandene statische Prüfungen; kein Ersatz für Runtime-, Warenkorb- oder Fertigungsprüfung.

## Erhaltene Geometrie
Gerätebild und sein asymmetrisches lokales Bohr-/Schnittbild werden bei der Gegenposition gemeinsam verschoben: dx=W-2*x-breite, dy=H-2*y-höhe. Es wird nichts gespiegelt oder gedreht. Optionale Eckbohrungen wechseln um die Plattenmitte und bleiben als symmetrische Menge unverändert. Textzentren wechseln zu W-x/H-y und behalten ihre Rotation; Zierlinien dürfen um 180 Grad wechseln, entsprechend dem bisherigen Verhalten.

Alte Querformatdateien enthielten weiterhin 16x28 in Stahlgrößen, Designmaßen, Design-Acrylflächen und optionalCornerPaths. Die Normalisierung benutzt die tatsächliche Formatgeometrie und mounting.holes, genauso wie die bisherigen effektiven Vorschau-/Fertigungsfunktionen. Originaldateien bleiben vollständig erhalten. Historische Profil-ID und Name sind Quellenaliase; exakte Identität ist modelKey plus formatKey.

## Preise und Varianten
16x28: 4.999 Cent; 24x20: 5.999 Cent; 35x18: 6.999 Cent. Befestigung: K00=0, GWS=599, KRA=499, SIL=499, B04S=369 Cent. Jede Hauptproduktseite hat 120 bestellbare Kombinationen. Nach Übernahme ergeben sich 15.120 Varianten: 5.040 bestehende plus 10.080 neue. Positionswechsel und Designwechsel erzeugen keine zusätzliche Shopify-Variante.

SKU-Muster bleibt FK-AV2A-{ausgewähltesFormat}-{fortlaufendeNummer}. Neuvergabe erst nach frischem Live-Abgleich; kein Nummernbereich ist reserviert.

## Importgrenzen
Das strikte gravuru-product-family/v2-Schema bildet diese mehrlagigen Gerätegeometrien nicht ab. Daher wird keine falsche Familie erzeugt. Native Adapter-Eingaben verwenden die mit dem Implementierungsagenten abgestimmte gravuru-doorbell/v1-Struktur.

In den nativen Profilen sind orderEnabled und productionConfirmed absichtlich false. Die historischen true-Werte liegen ausschließlich als Originalbeleg vor. Der Import muss vollständige lizenzierte Schriftressourcen, die weitere Motivbibliothek, neue immutable Revisionen und sämtliche echten Shopify-Bindings auflösen und anschließend Vorschau, Warenkorb und Fertigung prüfen. Native Inputs enthalten noch historische Binding-/Purchasing-Angaben als Quelle; diese nicht als neue Runtime-Bindings einsetzen.

Die acht zusätzlichen, noch nicht eindeutig identifizierten Geräte sind ausgeschlossen. Hier werden ausschließlich die 42 bekannten Modelle übernommen.

Die drei Python-Skripte sind lokale reproduzierbare Arbeitsmittel. Nach den Katalogregeln gehören ausführbare Skripte ins Code-Repo, nicht in das reine Katalog-Repo.

