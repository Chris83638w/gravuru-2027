# Gedenktafeln-sternenkinder – Übersicht der Bestandsdesigns

4 Designs, vorsortiert nach Zielgruppe und Unterkategorie. Unter jedem Bild: Schlüssel · Sicherheit der Zuordnung · Materialien. Korrekturen in [`GEDENKTAFELN-STERNENKINDER-DESIGNS.xlsx`](GEDENKTAFELN-STERNENKINDER-DESIGNS.xlsx).

Sprungmarken: [Allgemein – Allgemein (4)](#allgemein-allgemein)

## Allgemein – Allgemein

4 Designs

![Allgemein – Allgemein](_uebersicht/Allgemein-Allgemein.png)

