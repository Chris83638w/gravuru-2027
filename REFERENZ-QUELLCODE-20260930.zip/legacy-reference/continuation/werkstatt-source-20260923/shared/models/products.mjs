import {request} from './motifs.mjs';
import {validateAssignment,numericId} from '../configurator-contract.mjs';
import {STAINLESS_CATALOG,stainlessRules} from '../stainless-contract.mjs';
import preset from '../preset.json' with {type:'json'};
export {preset};
export function stainlessAssignment(product,groupKey){
 const group=STAINLESS_CATALOG.groups.find(g=>g.key===groupKey);if(!group)throw Error('Konfigurator nicht gefunden.');
 return {schemaVersion:2,groupKey,productId:product.id,productHandle:product.handle,profileKey:'edelstahl',enabled:false,orderEnabled:false,productionConfirmed:false,catalogRevision:STAINLESS_CATALOG.revision,variantMap:Object.fromEntries(stainlessRules(group).map(rule=>[rule.sku,numericId(product.variants.find(v=>v.sku===rule.sku)?.id||'')]))};
}
export const PRODUCT_FIELDS = `id title handle templateSuffix
  assignment: metafield(namespace:"gravuru",key:"configurator") { jsonValue compareDigest type }`;
export const PRODUCTS = `query GravuruProducts($after:String) {
  shop { myshopifyDomain }
  products(first:50,after:$after) { nodes { ${PRODUCT_FIELDS} } pageInfo { hasNextPage endCursor } }
}`;
export const PRODUCT = `query GravuruProduct($id:ID!) {
  product(id:$id) { ${PRODUCT_FIELDS}
    variants(first:250) { nodes { id title sku price } pageInfo { hasNextPage endCursor } }
  }
}`;
export const DEFINITIONS = `query GravuruConfigurationDefinition {
  metafieldDefinitions(ownerType:PRODUCT,namespace:"gravuru",key:"configurator",first:5) {
    nodes { id namespace key type { name } access { storefront } }
    pageInfo { hasNextPage endCursor }
  }
}`;
export const DEFINE = `mutation GravuruConfigurationDefinitionCreate($definition:MetafieldDefinitionInput!) {
  metafieldDefinitionCreate(definition:$definition) { createdDefinition { id } userErrors { field message code } }
}`;
export const ASSIGN = `mutation GravuruAssignProduct($metafields:[MetafieldsSetInput!]!) {
  metafieldsSet(metafields:$metafields) { metafields { jsonValue compareDigest } userErrors { field message code } }
}`;
export async function listProducts(after=null) { return request(PRODUCTS,{after}); }
export async function getProduct(id) {
  const {product}=await request(PRODUCT,{id});
  if (!product) throw Error('Produkt nicht gefunden.');
  if (product.variants.pageInfo.hasNextPage) throw Error('Dieses Produkt hat mehr als 250 Varianten. Bitte ein Produkt mit höchstens 250 Varianten wählen.');
  if (product.assignment && product.assignment.type !== 'json') throw Error('Die gespeicherte Zuordnung hat einen unerwarteten Datentyp.');
  return {...product,variants:product.variants.nodes};
}
export function initialAssignment(product) {
  if (product.assignment) return structuredClone(product.assignment.jsonValue);
  const map=Object.fromEntries(preset.variants.map(rule=>[rule.sku,numericId(product.variants.find(v=>v.sku===rule.sku)?.id||'')]));
  const known=preset.variants.every(rule=>map[rule.sku]);
  return {schemaVersion:1,productId:product.id,productHandle:product.handle,
    profileKey:'edelstahl',enabled:false,orderEnabled:false,productionConfirmed:false,
    catalogRevision:preset.revision,
    widthMm:known?preset.widthMm:null,heightMm:known?preset.heightMm:null,
    cornerRadiusMm:known?preset.cornerRadiusMm:0,
    holeDiameterMm:known?preset.holeDiameterMm:null,holeEdgeMm:known?preset.holeEdgeMm:null,
    designIds:preset.designs.map(d=>d.id),variantMap:map};
}
async function ensureDefinition() {
  const get=async()=> (await request(DEFINITIONS)).metafieldDefinitions.nodes[0];
  let definition=await get();
  if (!definition) {
    // Merchant-owned: shared with the independent production exporter and shop integrations.
    const result=(await request(DEFINE,{definition:{name:'Gravuru Konfigurator',namespace:'gravuru',key:'configurator',ownerType:'PRODUCT',type:'json',description:'Produktzuordnung, Designauswahl und Fertigungsmaße für den Gravuru App-Block.',access:{storefront:'PUBLIC_READ'}}})).metafieldDefinitionCreate;
    if (result.userErrors?.length) {
      definition=await get();
      if(!definition) throw Error(result.userErrors.map(e=>e.message).join(' · '));
    } else definition=await get();
  }
  if (definition?.type?.name!=='json'||definition.access.storefront!=='PUBLIC_READ') throw Error('Die vorhandene Gravuru-Felddefinition ist nicht kompatibel. Sie wurde nicht verändert.');
}
export async function assignProduct(original,draft) {
  validateAssignment(draft,original,preset);
  await ensureDefinition();
  const assignment={...draft,revision:crypto.randomUUID(),savedAt:new Date().toISOString()};
  const result=(await request(ASSIGN,{metafields:[{ownerId:original.id,namespace:'gravuru',key:'configurator',type:'json',value:JSON.stringify(assignment),compareDigest:original.assignment?.compareDigest??null}]})).metafieldsSet;
  if(result.userErrors?.length) throw Error(result.userErrors.map(e=>e.message).join(' · '));
  if(!result.metafields?.length) throw Error('Shopify hat die Zuordnung nicht bestätigt.');
  const verified=await getProduct(original.id);
  if(verified.assignment?.jsonValue?.revision!==assignment.revision) throw Error('Die Zuordnung wurde nicht unverändert zurückgelesen. Bitte neu laden.');
  return verified;
}
