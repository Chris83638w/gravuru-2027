# Kundenwarenkorb – vorbereitete Grundlage, 27.09.2026

## Status und verbindliche Nutzerentscheidung

**Separat vorbereitete, lokal geprüfte Module. Noch nicht in die bestehende Anwendung eingebunden, nicht veröffentlicht und nicht bestellbereit.** Der deaktivierte Warenkorbknopf der lokalen Vorschau wurde nicht freigeschaltet. Keine neue Serverinstanz, keine Änderung an Plesk, Shopify, main oder der öffentlichen Testseite.

Nutzerentscheidung: echter Shopify-Warenkorb; vorhandenen Plesk-Server verwenden; 15 % Rabatt genau auf das zweite identische Exemplar einschließlich Foto-, Motiv- und Befestigungsaufschlägen. Beispiel: Stückpreis 59,98 EUR, zwei Stück 119,96 EUR, Rabatt 9,00 EUR, Summe 110,96 EUR. Aktuelle lokale Rechenregel gewährt auch bei mehr als zwei Stück nur einen solchen Rabatt; keine wiederholten Paarrabatte implementiert. Farben erst anhand von Screenshots abstimmen. Photoroom bleibt verworfen. Pro Foto wird der manuelle Freistellwunsch für die Fertigung erhalten, das Original bleibt verfügbar.

## Ausgangsstände und vorhandener Server

- Aufgabenbranch `task/konfigurator-bedienung-20260927`, vorheriger Bedienstand `c187fb3f172942a665a127be34d751e145688fda`, Arbeitsreservierung `2badfae6e38c1fe9fc571b819a7a7cc222540451`.
- Aktuelle Serverquellen gezielt auf `feat/variante-m-profile-20260924`, Commit `9824e81d647ea538be257fdd3696d7de120ea0c5`, gelesen. Vor jeder späteren Integration erneut den aktuellen Stand prüfen.
- Lokale Arbeitskopie `work/konfigurator-ux-20260927` ist eine gezielte Quellkopie ohne eigenes Git-Verzeichnis. Nicht mit einem aktuellen vollständigen Checkout des Serverbranches verwechseln. Originale und ältere Quellstände wurden nicht ersetzt.
- Vorhandene Anwendung: `https://gravuru-designwerkstatt.de`, Plesk-Anwendungswurzel `/var/www/vhosts/gravuru-designwerkstatt.de/gravuru-werkstatt`, Start `app.cjs`, vorhandener Einstieg `scripts/product-entry.cjs`. Produktquellen werden bereits über `private/product-runtime/current.json` ausgewählt. Diesen Ablauf erweitern, keinen zweiten Listener oder Produktserver starten.
- Die vorhandenen Produktanlage-Routen sind Händlerzugänge. Ein öffentlicher Kundenzugang darf nicht ihre Admin-Berechtigungen übernehmen. Private Kundendaten müssen außerhalb von `webroot` bleiben.

## Enthaltene vollständige Quellen

| Datei | Aufgabe |
|---|---|
| `customer-checkout-store.mjs` | Private SQLite-Ablage mit Sitzungen, Bildbytes, Prüfsummen, unveränderlichen Gestaltungspaketen und Wiederholschutz |
| `customer-checkout-shopify.mjs` | Storefront-Preisprüfung und Cart-Erstellung mit serverseitiger Prüfung der zurückgegebenen Varianten, Mengen, Referenzen, Summe und Checkout-Domain |
| `customer-checkout-service.mjs` | Zusammenspiel und additive HTTP-Routen; keine eigenen Listener; Rabatt-Rechenregel separat geprüft |
| `customer-checkout-resolver.mjs` | Auflösung nativer Universalprofile anhand serverseitiger veröffentlichter Quellen und Preisbindungen |
| `../../configurator/variant-m/checkout-client.mjs` | Noch nicht angeschlossener Browserclient für Original, bearbeitetes Bild, Freistellwunsch und Entwurf |
| `tests/customer-checkout.test.mjs` | Dreizehn automatisierte Tests einschließlich privater Wiederherstellung und Fehlerfällen |

Bildbytes liegen innerhalb derselben privaten SQLite-Datenbank wie ihre Referenzen. Es gibt keine öffentliche Downloadroute. Die Shopify-Zeilen erhalten nur Paketkennung und Prüfsumme, keine Fotos oder kompletten Kundentexte. Shopify-Cart-ID einschließlich Geheimteil bleibt in der privaten Ablage; an den Browser wird die Checkout-URL zurückgegeben. Original und bearbeitetes Bild sind einzeln prüfbar. Unsichere Übertragungen werden gesperrt statt automatisch als weiterer Warenkorb erneut angelegt.

## Tatsächlich ausgeführte Prüfungen

Die lokale Suite bestand vollständig: **13 Tests, 0 Fehler**. Node 24, `node:sqlite`, bestehendes Sharp zum vollständigen Bilddekodieren. SQLite gab den üblichen experimentellen API-Hinweis aus.

Geprüft wurden Wiederherstellung nach Schließen/Öffnen mit identischen Original-/Bearbeitungsbytes und Geometrie/Freistellwunsch; Webroot-Sperre; falsche/defekte/zu große Bilder; Sitzungsisolation; Deduplizierung; Doppelklick und Wiederholung nach Neustart; Mehrdeutigkeit bei Zeitüberschreitung; fehlende Freigaben/Fotos/Preisbindungen; beschädigte Bilddaten; vollständiger Stückpreisrabatt; simulierte Shopify-Preis- und Antwortabweichungen; Browserübertragung; servergebundene Profilrevision/Maße; HTTP-Origin- und Sitzungsprüfung vor dem Lesen großer Anfrageinhalte.

Wiederholung aus dem Repository, mit installierter Sharp-Abhängigkeit des bestehenden Servers oder explizitem Testpfad:

```powershell
$env:GRAVURU_TEST_SHARP = 'ABSOLUTER/PFAD/ZU/node_modules/sharp'
node --test automation/product-pipeline/tests/customer-checkout.test.mjs
```

Zusätzliche echte, ausschließlich lesende Shopify-Prüfungen:

- Shop `gravuru-design.myshopify.com`, Plan `Plus` bestätigt.
- AOSU-Grundvariante `gid://shopify/ProductVariant/57465408291196` im Storefront verfügbar, 49,99 EUR.
- Beide verwendeten Storefront-Operationen mit dem Shopify-Prüfwerkzeug erfolgreich validiert. Storefront-Leseanfrage ohne neuen Zugangsschlüssel erfolgreich.

**Nicht ausgeführt:** echte Cart-Mutation, Rabattfunktion, fertiger Browser-/Server-Durchlauf, Bestellung, Bezahlung, Produktionsübergabe, Live-Deployment oder Wiederherstellung einer produktiven Kundendatenbank. Die Shopify-Cart-Prüfungen innerhalb der Suite verwenden Antworten als Testdaten; daraus folgt kein Live-Nachweis.

## Noch erforderliche Integration – keine Flags auf Verdacht setzen

1. Den aktuellen bestehenden Produktserver gezielt erweitern. `checkoutRoute(...)` muss vor einer ausschließlich für Händler vorgesehenen Zugangssperre kontrolliert eingehängt werden. Same-Origin-HTTPS, vertrauenswürdige Proxy-/Kunden-IP-Zuordnung und begrenzte Sitzungseröffnung sind ausdrücklich einzurichten. `allowNewSessions` ist standardmäßig aus.
2. `CheckoutStore` mit absolutem privatem Verzeichnis außerhalb des tatsächlichen Webroots initialisieren. Übergeordnetes Verzeichnis und Webroot müssen bereits existieren. Sharp vom vorhandenen Host übergeben. Kein Pfad und keine Preisbindung dürfen aus Kundeneingaben stammen.
3. Tatsächlich veröffentlichte Profile, Revisionen, Design-/Motiv-/Schriftbestände und vollständige Shopify-Variantenbindungen laden. `createUniversalResolver` deckt native Profile ab, **nicht** den historischen AOSU-Adapter. Die lokale AOSU-Prüfvorlage ist keine bestellfähige Preisquelle. Befestigungs-/Acryl-/Klingelgeometrie muss aus der passenden Modellrevision kommen. Warnungen, die der Nutzer ignorieren darf, müssen in der Bestellanbindung entsprechend behandelt werden.
4. In der **vorhandenen** Shopify-App eine geprüfte Rabatt- und Warenkorbvalidierung vorbereiten. Sie muss genau das zweite gleiche Exemplar einschließlich aller Aufschläge abdecken und Manipulationen an Zuordnungen, Mengen oder entfernten Aufschlagszeilen verhindern. Frei editierbare Line-Item-Properties allein beweisen weder Identität noch korrekten Preis. `checkoutValidated` und `cartIntegrityValidated` sind Freigabesperren, keine Ersatzimplementierung dieser Shopify-Prüfung. Sie bleiben aus, bis der vollständige Ablauf nachgewiesen ist.
5. Erst danach Service und Browserclient verbinden und die erwartete rabattierte Shopify-Summe prüfen. Der derzeitige Service vergleicht die **unrabattierte** Summe und aktiviert die separat getestete Rabattberechnung nicht automatisch. Die Cart-Operation erstellt einen neuen Storefront-Cart; Übernahme eines vorhandenen Shop-Warenkorbs, spätere Mengenänderungen und Ablauf/Erneuerung von Sitzungen sind noch offen.
6. Bezahlte Shopify-Bestellungen verifiziert mit dem privaten Paket verknüpfen und für die Werkstatt abrufbar machen; signierte Webhooks, Berechtigung, wiederholte Zustellung und Fertigungsabruf nachweisen. Die Paketreferenz allein ist noch keine abgeschlossene Produktionsanbindung.
7. Aufbewahrung/Bereinigung, Missbrauchsbegrenzung und konsistente SQLite-Backups in den vorhandenen privaten Sicherungsweg einbinden. Aktuelle Speicherobergrenzen begrenzen Testbetrieb, ersetzen keine Betriebsstrategie. Keine laufende Datenbankdatei einfach kopieren.

## Lokale Werkzeuggrenze

Das offizielle Shopify-CLI wurde getrennt im Arbeitsverzeichnis installiert; dessen Hilfe funktioniert. Der ursprüngliche pnpm-Weg scheiterte an Windows-EPERM. Anschließend wurde npm 12.1.0 aus der offiziellen Registry bezogen und dessen SHA-512-Integrität vor dem Entpacken geprüft. Diese lokalen Werkzeuge und Abhängigkeiten gehören nicht in GitHub.

Der CLI-Aufruf zur Erzeugung der Rabatt-Erweiterung scheiterte anschließend konkret an `EPERM` beim Anlegen von `C:\Users\Mikail Erdem\AppData\Roaming\shopify-cli-app-nodejs\Config`. Die angefragte Schreibfreigabe für die Shopify-CLI-Einstellungsordner wurde nicht erteilt. Deshalb existiert **keine erzeugte, gebaute oder ausgerollte Shopify Function**. Kein manuell erfundenes Ersatzgerüst wurde als fertige Function ausgegeben. Nächster Werkzeugschritt ist die Freigabe/Einrichtung des vorhandenen Shopify-CLI-Zugangs auf diesem Rechner oder die Ausführung durch die bestehende zuständige App-Umgebung, anschließend CLI-Gerüst, Implementierung, Build und Tests.

Die isolierte lokale App-Staging-Kopie enthält nur bestehende öffentliche App-Konfiguration und Paketbeschreibung als Vorbereitung. Sie ist keine vollständige App-Übergabe und darf nicht zur Veröffentlichung verwendet werden. Insbesondere schränkt die bestehende Studio-Konfiguration `extension_directories` ein; vorhandene Storefront-Erweiterung und neue Functions müssen bei der späteren Integration gemeinsam erhalten bleiben.

## Private Daten und Übergabe

Keine echten Kundendateien, Datenbanken, Shopify-Geheimnisse oder Tokens sind Bestandteil dieses Pakets. Tests verwenden erzeugte Bilddaten und temporäre getrennte Datenbanken. Diese Ergänzungen auf dem Aufgabenbranch sichern; danach den aktuellen Koordinationswegweiser aktualisieren. Ein frischer Checkout kann die Tests mit passenden Node-/Sharp-Abhängigkeiten ausführen, startet damit aber **keinen vollständigen Kundenwarenkorb**. Vor jedem nächsten Schritt die aktuellen gemeinsamen GitHub-Einstiege lesen; andere Chats werden nicht automatisch synchronisiert.
