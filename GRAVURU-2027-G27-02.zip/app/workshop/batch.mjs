import {createHash} from 'node:crypto';
import {validateProductDocument} from './product-model.mjs';

export const IMPORT_COLUMNS=['import_key','name','master_id','master_revision','category_ids','price_small_eur','price_large_eur','heading','names','place','date','slogan','seo_title','seo_description'];
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const text=value=>value===undefined||value===null?'':String(value).trim();
const fail=message=>{throw new Error(message);};
function cents(value){
  const match=/^(\d+)(?:[.,](\d{1,2}))?$/.exec(text(value));
  if(!match)fail('Preise als Eurobetrag eingeben, beispielsweise 14,99.');
  const result=Number(match[1])*100+Number((match[2]||'').padEnd(2,'0'));
  if(!Number.isSafeInteger(result)||result>10000000)fail('Preis außerhalb des erlaubten Bereichs.');
  return result;
}
export function planBatch(repository,{rows,masterId,masterRevision}={}){
  if(!Array.isArray(rows)||!rows.length||rows.length>100)fail('Bitte 1 bis 100 Produktzeilen auswählen.');
  const keys=new Set(), entries=[],report=[];
  const counts=new Map();for(const row of rows){const key=text(row?.import_key);counts.set(key,(counts.get(key)||0)+1);}
  for(const [index,row] of rows.entries()){
    let key='';
    try{
      if(!row||Array.isArray(row)||typeof row!=='object')fail('Ungültige Produktzeile.');
      for(const column of Object.keys(row))if(!IMPORT_COLUMNS.includes(column))fail(`Unbekannte Spalte: ${column}`);
      key=text(row.import_key);
      if(!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(key)||keys.has(key)||counts.get(key)>1)fail('Importschlüssel fehlt, ist ungültig oder kommt mehrfach vor.');
      keys.add(key);
      if(text(row.master_id)&&text(row.master_id)!==masterId&&!text(row.master_revision))fail('Bei einer anderen Master-ID muss auch deren Masterversion angegeben werden.');
      const id=text(row.master_id)||masterId,version=text(row.master_revision)||masterRevision;
      if(!/^[1-9][0-9]*$/.test(String(version)))fail('Bitte einen gespeicherten Masterstand auswählen.');
      const master=repository.get(id,{revision:Number(version)}),current=repository.get(id);
      if(master.document.kind!=='master'||current.status==='archived'||current.document.kind!=='master')fail('Die Vorlage muss ein aktiver Master sein.');
      const document=structuredClone(master.document);
      document.kind='product';document.masterId=id;document.name=text(row.name);
      if(!document.name)fail('Produktname fehlt.');
      if(text(row.category_ids))document.categoryIds=[...new Set(text(row.category_ids).split(',').map(v=>v.trim()).filter(Boolean))];
      for(const [column,size] of [['price_small_eur','small'],['price_large_eur','large']])if(text(row[column]))document.config.acrylic.pricing.sizes[size]=cents(row[column]);
      for(const field of ['heading','names','place','date','slogan'])if(text(row[field])){
        let replaced=false;
        for(const design of document.config.profile.designs)for(const object of design.objects||[])if(object.type==='text'&&object.fieldKey===field){object.text=text(row[field]);replaced=true;}
        if(!replaced)fail(`Der Master besitzt kein Textfeld „${field}“.`);
      }
      for(const field of ['title','description'])if(text(row['seo_'+field]))document.seo[field]=text(row['seo_'+field]);
      const validated=validateProductDocument(document);
      const fingerprint=hash({masterId:id,masterRevision:Number(version),document:validated});
      const existing=repository.importItem(key);
      if(existing&&existing.fingerprint!==fingerprint)fail('Dieser Importschlüssel ist schon mit anderen Daten verknüpft. Neuen Schlüssel verwenden oder bestehenden Artikel bearbeiten.');
      entries.push({key,fingerprint,document:validated});
      report.push({row:index+1,key,name:validated.name,status:existing?'existing':'ready',id:existing?.id,masterId:id,masterRevision:Number(version),prices:validated.config.acrylic.pricing.sizes});
    }catch(error){report.push({row:index+1,key,name:text(row?.name),status:'error',message:error.message});}
  }
  const valid=report.every(row=>row.status!=='error');
  return {valid,report,token:entries.length?hash({rows,masterId,masterRevision,entries:entries.map(e=>({key:e.key,fingerprint:e.fingerprint}))}):null,entries};
}
export function commitBatch(repository,input){
  const plan=planBatch(repository,input);
  if(!plan.entries.length||!plan.valid&&input.skipErrors!==true)throw Object.assign(Error('Die Serie enthält Fehler. Bitte die markierten Zeilen korrigieren oder ausdrücklich nur gültige Datensätze anlegen.'),{status:422,code:'batch_invalid'});
  if(!input.token||input.token!==plan.token)throw Object.assign(Error('Die Importdaten haben sich geändert. Bitte erneut prüfen.'),{status:409,code:'batch_changed'});
  return {products:repository.importBatch(plan.entries),errors:plan.report.filter(row=>row.status==='error')};
}
