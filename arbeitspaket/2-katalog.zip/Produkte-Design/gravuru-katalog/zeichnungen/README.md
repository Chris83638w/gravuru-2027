# Zeichnungen

Corel-Quellen (PDF, möglichst auch CDR) mit SHA-256 und maschinell gelesenem Plattenbericht (`scripts/read-corel-plates.py`). Konvention: rot = Platte und Löcher, cyan = Rückplatte, Kreise Ø 8 = Abstandshalter; Spalten = Formatreihe/Befestigung, von oben nach unten aufsteigend.

- `hausnummer-namenschilder-2026/` – Acryl AA/AS/S/S, 37 Platten in 8 Spalten (17.10.2026). Offene Rückfragen: 20 × 20 mit 10 mm Rand; 21 × 14 nur oval/eingezogen; 24 × 7 Einzelformat.
- `edelstahl-schilder-2027/` – Edelstahl-Türschilder 2027: `geometrie.json` = maschinell gelesene Excel `Edelstahlschilder_final_CDR_2.xlsx` (Chris, P:) + Zeichnung `EDELSTAHL_SCHILDER_NEUE_GROESSEN_v2.svg` (beide mit SHA-256 in der Datei; 81 Zeilen: Form, Maße, Grundpreis, Gewicht, Löcher, Optionen, Kontur-Pfad, Quellhinweis). Übernommen aus der lokalen Codex-Werkstatt vom 21.10.2026; Abgleich mit der Familie per `scripts/katalog-edelstahl-serie.py` (gravuru-2027), Bericht `familien/edelstahl/quellen/edelstahl-serie-2027-abgleich.md`. Offen: Retro 1/2 (freie Konturen, im Familienschema v2 nicht abbildbar), Grundpreise Rund 8,5/12/16/20 (nur Vorschlag).
