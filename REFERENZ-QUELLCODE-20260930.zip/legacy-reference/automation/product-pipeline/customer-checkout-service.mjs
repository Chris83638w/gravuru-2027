// Additive module for the existing server; no listener, no Admin credentials.
const fail=(message,status=400)=>{throw Object.assign(Error(message),{status});};
export function secondCopyPrice(unitCents,quantity){
 if(!Number.isSafeInteger(unitCents)||unitCents<0||!Number.isInteger(quantity)||quantity<1||quantity>99||!Number.isSafeInteger(unitCents*quantity))fail('Ungültige Preisberechnung.');
 const discountCents=quantity>=2?Math.round(unitCents*15/100):0;
 return {subtotalCents:unitCents*quantity,discountCents,totalCents:unitCents*quantity-discountCents};
}
export function checkResolved(resolved,photos){
 if(resolved?.release?.checkoutValidated!==true)fail('Dieses Produkt ist noch nicht zum Bestellen freigegeben.',503);
 const {snapshot,lines,totalCents}=resolved;
 if(!snapshot?.geometry||!snapshot.profileId||!snapshot.profileRevision||!Array.isArray(snapshot.design?.objects)||!Number.isInteger(snapshot.quantity)||snapshot.quantity<1||snapshot.quantity>99)fail('Vollständige modellgebundene Gestaltung fehlt.');
 if(!Array.isArray(lines)||!lines.length||lines.length>20||new Set(lines.map(l=>l.variantId)).size!==lines.length)fail('Ungültige verbindliche Variantenbindung.');
 let sum=0;for(const l of lines){if(!/^gid:\/\/shopify\/ProductVariant\/\d+$/.test(l.variantId)||!Number.isInteger(l.quantity)||l.quantity<1||l.quantity>999||!Number.isSafeInteger(l.unitCents)||l.unitCents<0)fail('Ungültige Preisbindung.');sum+=l.quantity*l.unitCents;}
 if(!Number.isSafeInteger(totalCents)||sum!==totalCents)fail('Vollständige serverseitige Preisbindung fehlt. Rabatt erst nach Shopify-Funktionsanbindung aktivieren.');
 // Fail closed until checkout validation protects addon/quantity edits in Shopify.
 if(resolved.release.cartIntegrityValidated!==true)fail('Warenkorbprüfung ist noch nicht freigegeben.',503);
 const visible=snapshot.design.objects.filter(o=>!o.uxHidden),uploads=visible.filter(o=>o.uxUploadId);
 if(uploads.length!==photos.length)fail('Fotozuordnung ist unvollständig.');
 for(const o of uploads){const p=photos.find(p=>p.objectId===o.id);if(!p||p.kind!==o.uxUploadKind||(p.kind==='photo'&&p.background!==(o.uxPhotoBackground||'remove')))fail('Foto oder Freistellwunsch passt nicht zur Gestaltung.');}
 for(const o of visible)if(o.type==='photoSlot'&&o.required&&!o.uxUploadId)fail('Ein erforderliches Foto fehlt.');
 return resolved;
}
export function createCheckoutService({store,resolveDesign,storefront,validateImage}){
 if(!store||typeof resolveDesign!=='function'||!storefront||typeof validateImage!=='function')throw Error('Bestehende Serverdienste müssen vollständig angebunden sein.');
 return {
  authorize:token=>store.authorize(token),
  session:()=>store.session(),
  upload:(token,bytes,mime)=>store.upload(token,bytes,mime,validateImage),
  async submit(token,{requestKey,draft,quantity,photos},buyerIp){
   store.authorize(token);
   if(!Array.isArray(photos)||photos.length>4||!Number.isInteger(quantity)||quantity<1||quantity>99)fail('Ungültige Bestellung.');
   // Resolver reads the pinned published profile, fonts, motifs and price binding
   // from private product-data. It must never use client-supplied prices/geometry.
   const resolved=checkResolved(await resolveDesign(draft,quantity),photos);
   if(resolved.snapshot.quantity!==quantity)fail('Menge stimmt nicht mit der geprüften Gestaltung überein.');
   const record=store.prepare(token,requestKey,{...resolved.snapshot,price:{lines:resolved.lines,totalCents:resolved.totalCents,currency:'EUR'}},photos);
   if(record.status==='ready')return {packageId:record.id,checkoutUrl:record.cart.checkoutUrl,totalCents:record.cart.subtotalCents};
   await storefront.verify(resolved.lines,buyerIp);
   const claim=store.claim(token,record.id);
   if(!claim.claimed)return {packageId:claim.id,checkoutUrl:claim.cart.checkoutUrl,totalCents:claim.cart.subtotalCents};
   try{
    const cart=await storefront.create({lines:resolved.lines,packageId:record.id,fingerprint:record.sha256,expectedCents:resolved.totalCents},buyerIp);
    store.finish(record.id,cart);
    return {packageId:record.id,checkoutUrl:cart.checkoutUrl,totalCents:cart.subtotalCents};
   }catch(e){store.uncertain(record.id);throw e;}
  }
 };
}

export function checkoutRoute(service,{origin,buyerIp,allowNewSessions=false}={}){
 if(new URL(origin).protocol!=='https:'||typeof buyerIp!=='function')throw Error('HTTPS und bestehende vertrauenswürdige Proxy-IP-Zuordnung erforderlich.');
 const prefix='/api/customer-checkout';
 return async(req,res,url)=>{
  if(!url.pathname.startsWith(prefix+'/'))return false;
  const send=(data,status=200)=>res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}).end(JSON.stringify(data));
  try{
   if(req.method!=='POST'||req.headers.origin!==origin)fail('Anfrage nicht erlaubt.',403);
   const route=url.pathname.slice(prefix.length),token=/^Bearer ([A-Za-z0-9_-]{43})$/.exec(req.headers.authorization||'')?.[1];
   if(route==='/session'){if(!allowNewSessions)fail('Kundenanbindung noch nicht freigegeben.',503);send({token:service.session()});return true;}
   service.authorize(token);
   // Reject oversized requests before buffering. No file/URL paths are accepted.
   const limit=route==='/upload'?15*1024*1024:2_000_000;
   if(Number(req.headers['content-length'])>limit)fail('Datei zu groß.',413);
   let size=0;const chunks=[];for await(const c of req){size+=c.length;if(size>limit)fail('Datei zu groß.',413);chunks.push(c);}const bytes=Buffer.concat(chunks);
   if(route==='/upload')send(await service.upload(token,bytes,req.headers['content-type']));
   else if(route==='/submit'){
    if(req.headers['content-type']!=='application/json')fail('JSON erwartet.',415);
    let input;try{input=JSON.parse(bytes);}catch{fail('Ungültige Gestaltung.');}
    send(await service.submit(token,input,buyerIp(req)));
   }else fail('Nicht gefunden.',404);
  }catch(e){send({error:e.status?e.message:'Übertragung konnte nicht bestätigt werden. Bitte erneut prüfen oder die Werkstatt kontaktieren.'},e.status||502);}
  return true;
 };
}
