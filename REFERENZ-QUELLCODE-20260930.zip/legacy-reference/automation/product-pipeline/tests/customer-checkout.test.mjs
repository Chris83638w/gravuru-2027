import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createRequire} from 'node:module';
import {CheckoutStore,imageValidator} from '../customer-checkout-store.mjs';
import {createCheckoutService,checkoutRoute,secondCopyPrice} from '../customer-checkout-service.mjs';
import {createStorefront,cents} from '../customer-checkout-shopify.mjs';
import {createCheckoutClient} from '../../../configurator/variant-m/checkout-client.mjs';
import {createUniversalResolver} from '../customer-checkout-resolver.mjs';
import {readJson,librariesFromRepository,profileForProduct,REPO} from '../lib/core.mjs';

const require=createRequire(import.meta.url),sharp=require(process.env.GRAVURU_TEST_SHARP||'sharp');
const validate=imageValidator(sharp);
const variantId='gid://shopify/ProductVariant/1';
async function fixture(t){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'gravuru-checkout-'));fs.mkdirSync(path.join(root,'webroot'));
 const options={directory:path.join(root,'private'),webroot:path.join(root,'webroot')};let store=new CheckoutStore(options);
 t.after(()=>{store.close();fs.rmSync(root,{recursive:true,force:true});});
 const token=store.session(),image=await sharp({create:{width:20,height:12,channels:3,background:'#336699'}}).png().toBuffer();
 const asset=await store.upload(token,image,'image/png',validate);
 const photos=[{objectId:'photo-1',kind:'photo',background:'keep',originalId:asset.id,renderedId:asset.id}];
 const snapshot={profileId:'model-m',profileRevision:'r1',geometry:{width:160,height:280,holes:[{x:5,y:5,r:2}]},material:'steel-acrylic',quantity:1,design:{objects:[{id:'photo-1',type:'photoSlot',uxUploadId:'local-id',uxUploadKind:'photo',uxPhotoBackground:'keep',x:50,y:40,w:20,h:12}]}};
 const resolved={snapshot,release:{checkoutValidated:true,cartIntegrityValidated:true},lines:[{variantId,quantity:1,unitCents:5998}],totalCents:5998};
 return {root,options,get store(){return store;},token,image,photos,resolved,reopen(){store.close();store=new CheckoutStore(options);return store;}};
}
test('original, edited image, geometry and keep/remove survive database reopen with hashes',async t=>{
 const f=await fixture(t),edited=await sharp(f.image).rotate(90).png().toBuffer(),a=await f.store.upload(f.token,edited,'image/png',validate);f.photos[0].renderedId=a.id;
 const record=f.store.prepare(f.token,'request-restore-0001',f.resolved.snapshot,f.photos);
 f.reopen();const restored=f.store.restore(record.id);
 assert.deepEqual(restored.snapshot.geometry,f.resolved.snapshot.geometry);assert.equal(restored.photos[0].background,'keep');
 assert.deepEqual(restored.photos[0].original.bytes,f.image);assert.deepEqual(restored.photos[0].rendered.bytes,edited);
 assert.notEqual(restored.photos[0].original.sha256,restored.photos[0].rendered.sha256);
});
test('private directory in webroot, false MIME, corrupt images and oversized files rejected',async t=>{
 const f=await fixture(t);assert.throws(()=>new CheckoutStore({directory:path.join(f.root,'webroot','bad'),webroot:path.join(f.root,'webroot')}),/Webroot/);
 await assert.rejects(f.store.upload(f.token,f.image,'image/jpeg',validate));await assert.rejects(f.store.upload(f.token,Buffer.from('<svg/>'),'image/png',validate));
 await assert.rejects(f.store.upload(f.token,Buffer.alloc(15*1024*1024+1),'image/png',validate));
});
test('another session cannot reference private images; repeated identical upload deduplicated',async t=>{
 const f=await fixture(t),other=f.store.session();assert.throws(()=>f.store.prepare(other,'request-other-0001',f.resolved.snapshot,f.photos),/anderen Sitzung/);
 assert.equal((await f.store.upload(f.token,f.image,'image/png',validate)).id,f.photos[0].originalId);
});
test('same request immutable, double submit creates at most one cart, ready response reusable after reopen',async t=>{
 const f=await fixture(t);let creates=0;const sf={verify:async()=>{},create:async()=>{creates++;await new Promise(r=>setTimeout(r,10));return {id:'secret-cart-id',checkoutUrl:'https://gravuru.de/checkouts/test',subtotalCents:5998};}};
 const service=createCheckoutService({store:f.store,resolveDesign:async()=>structuredClone(f.resolved),storefront:sf,validateImage:validate}),input={requestKey:'request-double-0001',draft:{},quantity:1,photos:f.photos};
 const results=await Promise.allSettled([service.submit(f.token,input,'127.0.0.1'),service.submit(f.token,input,'127.0.0.1')]);assert.equal(creates,1);assert.equal(results.filter(r=>r.status==='fulfilled').length,1);
 const good=results.find(r=>r.status==='fulfilled').value;assert.equal('id' in good,false);assert.equal(JSON.stringify(good).includes('secret-cart-id'),false);
 f.reopen();const again=createCheckoutService({store:f.store,resolveDesign:async()=>structuredClone(f.resolved),storefront:sf,validateImage:validate});assert.deepEqual(await again.submit(f.token,input,'127.0.0.1'),good);assert.equal(creates,1);
 f.resolved.snapshot.quantity=2;await assert.rejects(again.submit(f.token,{...input,quantity:2},'127.0.0.1'),/anderen Gestaltung/);
});
test('ambiguous Shopify timeout stays uncertain across retries, never creates a duplicate',async t=>{
 const f=await fixture(t);let count=0;const service=createCheckoutService({store:f.store,resolveDesign:async()=>f.resolved,storefront:{verify:async()=>{},create:async()=>{count++;throw Error('timeout');}},validateImage:validate});
 const input={requestKey:'request-timeout-0001',draft:{},quantity:1,photos:f.photos};await assert.rejects(service.submit(f.token,input,'127.0.0.1'));await assert.rejects(service.submit(f.token,input,'127.0.0.1'));assert.equal(count,1);
});
test('incomplete photo choices, missing release and price inconsistencies block checkout',async t=>{
 const f=await fixture(t);let creates=0;const service=createCheckoutService({store:f.store,resolveDesign:async()=>f.resolved,storefront:{verify:async()=>{},create:async()=>{creates++;}},validateImage:validate});
 const input={requestKey:'request-invalid-001',draft:{},quantity:1,photos:f.photos};
 await assert.rejects(service.submit(f.token,{...input,photos:[]},'127.0.0.1'));f.resolved.release.cartIntegrityValidated=false;await assert.rejects(service.submit(f.token,input,'127.0.0.1'));f.resolved.release.cartIntegrityValidated=true;f.resolved.totalCents=1;await assert.rejects(service.submit(f.token,input,'127.0.0.1'));assert.equal(creates,0);
});
test('tampered image blob fails restoration checksum',async t=>{const f=await fixture(t),r=f.store.prepare(f.token,'request-corrupt-001',f.resolved.snapshot,f.photos);f.store.db.prepare('UPDATE assets SET bytes=? WHERE id=?').run(Buffer.from('bad'),f.photos[0].originalId);assert.throws(()=>f.store.restore(r.id),/Bildprüfsumme/);});
test('full second-copy price includes all extras, discount applies to one copy and rounds to cents',()=>{assert.deepEqual(secondCopyPrice(5998,2),{subtotalCents:11996,discountCents:900,totalCents:11096});assert.equal(secondCopyPrice(5998,1).discountCents,0);assert.equal(secondCopyPrice(5998,3).discountCents,900);assert.throws(()=>secondCopyPrice(99,0));});
test('Storefront price, availability and money validation reject mismatches',async()=>{
 assert.equal(cents({amount:'49.99',currencyCode:'EUR'}),4999);assert.throws(()=>cents({amount:'49.999',currencyCode:'EUR'}));
 const sf=createStorefront({fetcher:async()=>({ok:true,json:async()=>({data:{nodes:[{id:variantId,availableForSale:true,price:{amount:'1.00',currencyCode:'EUR'}}]}})})});await assert.rejects(sf.verify([{variantId,unitCents:5998}],'127.0.0.1'),/geändert/);
});
test('Shopify returned price, attributes and checkout host must match',async()=>{
 const cart={id:'secret',checkoutUrl:'https://gravuru.de/checkouts/test',cost:{subtotalAmount:{amount:'59.98',currencyCode:'EUR'}},lines:{nodes:[{id:'line',quantity:1,merchandise:{id:variantId},attributes:[{key:'_gravuru_package',value:'p'},{key:'_gravuru_snapshot',value:'h'}]}],pageInfo:{hasNextPage:false}}};
 const sf=createStorefront({fetcher:async()=>({ok:true,json:async()=>({data:{cartCreate:{cart,userErrors:[]}}})})}),input={lines:[{variantId,quantity:1}],packageId:'p',fingerprint:'h',expectedCents:5998};
 assert.equal((await sf.create(input,'127.0.0.1')).subtotalCents,5998);cart.checkoutUrl='https://evil.example/';await assert.rejects(sf.create(input,'127.0.0.1'));cart.checkoutUrl='https://gravuru.de/checkouts/test';cart.cost.subtotalAmount.amount='0.00';await assert.rejects(sf.create(input,'127.0.0.1'));
});
test('client uploads original and edited bytes, carries no client price, concurrent clicks share one request',async()=>{
 const file=new Blob(['original'],{type:'image/png'}),blob=new Blob(['edited'],{type:'image/png'}),files=new Map([['u',{file,blob}]]),calls=[];
 const client=createCheckoutClient({endpoint:'/api/customer-checkout',files,draft:()=>({state:{objects:[{id:'p',uxUploadId:'u',uxUploadKind:'photo',uxPhotoBackground:'keep'}]}}),quantity:()=>2,newKey:()=> 'request-client-0001',fetcher:async(url,args)=>{calls.push({url,args});return {ok:true,json:async()=>url.endsWith('/session')?{token:'session'}:url.endsWith('/upload')?{id:'asset'+calls.length}:{packageId:'p'}};}});
 const a=client.submit(),b=client.submit();assert.equal(a,b);await a;assert.equal(calls.filter(c=>c.url.endsWith('/upload')).length,2);const input=JSON.parse(calls.at(-1).args.body);assert.equal(input.photos[0].background,'keep');assert.equal(input.quantity,2);assert.equal(input.price,undefined);await client.submit();assert.equal(calls.filter(c=>c.url.endsWith('/upload')).length,2);
});
test('resolver uses pinned profile geometry and server prices; injected dimensions/revisions/options rejected',async()=>{
 const job=readJson(REPO+'/automation/product-pipeline/jobs/hunde-gedenktafeln.json'),profile=profileForProduct(job,job.products[0].productId,job.products[0].handle),libs=librariesFromRepository();
 const source={config:{profile,basePriceCents:2999,extraMotifCents:169,photo:{enabled:true,mode:'upload-only'}},bindings:{base:{variantId,unitCents:2999},options:{}},release:{checkoutValidated:false,cartIntegrityValidated:false}};
 for(const group of profile.optionGroups){source.bindings.options[group.id]={};for(const value of group.values)source.bindings.options[group.id][value.id]={variantId:'gid://shopify/ProductVariant/2',unitCents:value.priceCents};}
 const resolve=createUniversalResolver({loadPublished:async()=>source,...libs});
 const draft={schema:'gravuru-customer-design/v2',profileId:profile.id,profileRevision:profile.revision,productId:profile.binding.productId,state:{designId:profile.designs[0].id,objects:structuredClone(profile.designs[0].objects),width:profile.geometry.width,height:profile.geometry.height}};
 const result=await resolve({...draft,price:1,geometry:{width:1}},1);assert.deepEqual(result.snapshot.geometry.width,profile.geometry.width);assert.equal(result.totalCents>=2999,true);assert.equal(result.release.checkoutValidated,false);
 await assert.rejects(resolve({...draft,profileRevision:'old'},1));await assert.rejects(resolve({...draft,state:{...draft.state,width:1}},1));await assert.rejects(resolve({...draft,state:{...draft.state,mOptions:{unknown:'cheap'}}},1));
});
test('HTTP adapter denies foreign origins and unauthenticated uploads before reading bodies',async()=>{
 let consumed=false;const service={authorize:()=>{throw Object.assign(Error('Sitzung fehlt'),{status:401});}},route=checkoutRoute(service,{origin:'https://gravuru-designwerkstatt.de',buyerIp:()=> '127.0.0.1'});
 for(const origin of ['https://evil.example','https://gravuru-designwerkstatt.de']){let status;const req={method:'POST',headers:{origin},async *[Symbol.asyncIterator](){consumed=true;yield Buffer.from('x');}},res={writeHead(s){status=s;return this;},end(){}};
 assert.equal(await route(req,res,new URL('https://gravuru-designwerkstatt.de/api/customer-checkout/upload')),true);assert.equal(status,origin.includes('evil')?403:401);}
 assert.equal(consumed,false);
});
