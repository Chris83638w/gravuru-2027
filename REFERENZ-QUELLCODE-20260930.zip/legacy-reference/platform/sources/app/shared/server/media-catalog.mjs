import {inspectMedia} from './media-inspect.mjs';

const roles=new Set(['original-vector','original-photo','font','product-preview','amazon-overlay','thumbnail','photo-mask','mounting-diagram','production-vector']);
const kinds=new Set(['all','image','font','vector','document']);
const rasters=new Set(['image/png','image/jpeg','image/webp']);
const uuid='[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}';
const mediaIdPattern=new RegExp('^media-'+uuid+'$','i');
const revisionIdPattern=new RegExp('^revision-'+uuid+'$','i');
const compare=(a,b)=>a<b?-1:a>b?1:0;
const normalized=value=>value.normalize('NFKC').toLocaleLowerCase('de-DE');
function reference(value){
 if(!value||typeof value!=='object'||Array.isArray(value)||typeof value.mediaId!=='string'||typeof value.revisionId!=='string'||!mediaIdPattern.test(value.mediaId)||!revisionIdPattern.test(value.revisionId))throw Error('Ungültige Medienreferenz. Medienkennung und exakte Revision werden benötigt.');
 return {mediaId:value.mediaId,revisionId:value.revisionId};
}
function query(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Katalogabfrage muss ein Objekt sein.');
 if(Object.keys(input).some(k=>!['search','role','limit','offset','kind'].includes(k)))throw Error('Unbekannter Katalogfilter.');
 const {search='',role='',limit=24,offset=0,kind='all'}=input;
 if(typeof search!=='string'||search.length>200||/[\x00-\x1f\x7f]/.test(search))throw Error('Suchtext darf höchstens 200 Zeichen ohne Steuerzeichen enthalten.');
 if(typeof role!=='string'||role!==''&&!roles.has(role))throw Error('Unbekannte Medienrolle.');
 if(!kinds.has(kind))throw Error('Unbekannte Medienart.');
 if(!Number.isInteger(limit)||limit<1||limit>100)throw Error('Seitengröße muss eine ganze Zahl von 1 bis 100 sein.');
 if(!Number.isInteger(offset)||offset<0||offset>1000000)throw Error('Seitenposition muss eine ganze Zahl von 0 bis 1000000 sein.');
 return {search:normalized(search.trim()),role,limit,offset,kind};
}
function matchesKind(mime,kind){
 return kind==='all'||kind==='image'&&rasters.has(mime)||kind==='font'&&mime.startsWith('font/')||kind==='vector'&&mime==='image/svg+xml'||kind==='document'&&mime==='application/pdf';
}

/**
 * Read-only adapter over an already opened MediaStore. It neither owns nor
 * closes the store, registers files, changes revisions, nor performs uploads.
 * All revisions remain explicit. Only PNG/JPEG/WebP are browser previews.
 */
export function createMediaCatalog(store){
 if(!store||!['list','get','readBytes'].every(name=>typeof store[name]==='function'))throw Error('Für den Medienkatalog fehlt eine geöffnete Medienablage.');
 function checked(row){
  let bytes;
  try{bytes=store.readBytes(reference(row));}
  catch(error){if(error?.code)throw Error('Mediendatei ist nicht lesbar.');throw error;}
  const inspected=inspectMedia(bytes,row.mimeType);
  return {bytes:inspected.bytes,metadata:inspected.metadata};
 }
 function descriptor(row){
  const {metadata}=checked(row),previewable=rasters.has(row.mimeType);
  return {
   mediaId:row.mediaId,revisionId:row.revisionId,label:row.label,role:row.role,
   mimeType:row.mimeType,byteLength:row.byteLength,sha256:row.sha256,
   width:previewable?metadata.widthPx:null,height:previewable?metadata.heightPx:null,
   previewable
  };
 }
 return Object.freeze({
  list(input={}){
   const q=query(input);
   const rows=store.list().filter(row=>(!q.role||row.role===q.role)&&matchesKind(row.mimeType,q.kind)&&(!q.search||normalized(row.label).includes(q.search)))
    .sort((a,b)=>compare(a.key,b.key)||compare(b.createdAt,a.createdAt)||compare(b.revisionId,a.revisionId));
   const items=rows.slice(q.offset,q.offset+q.limit).map(descriptor);
   return {items,total:rows.length,hasMore:q.offset+items.length<rows.length};
  },
  resolve(ref){return descriptor(store.get(reference(ref)));},
  bytes(ref){return checked(store.get(reference(ref))).bytes;}
 });
}
