# Übergabe an ChatGPT · Gedenktafeln: neue Designs und neue Motive (19.10.2026)

## Wer wir sind und worum es geht
Gravuru (gravuru GmbH) fertigt personalisierte Gedenktafeln: Lasergravur auf Schiefer, Granit, Acrylglas, Edelstahl und UV-Druck auf Granit, Marmor, Acryl, Aludibond. Der Kunde wählt im Konfigurator ein Design, tauscht Name, Daten, Spruch und (bei Fotodesigns) das Foto. Wir haben 653 Bestandsdesigns ausgelesen; sie sind zu 80 % „allgemein“ oder für Hunde. Für Oma, Opa, Papa, Eltern, Partner, Geschwister, Freund, Katzen, Pferde, Kleintiere und Sternenkinder fehlen Designs – und die Motivbibliothek (721 Motive) hat genau dort Lücken.

Du bekommst deshalb **zwei Aufträge**, die zusammengehören. Arbeite sie in dieser Reihenfolge:

| Nr. | Auftrag | Ergebnis | Datei |
| --- | --- | --- | --- |
| 1 | **Motive** (Priorität 1 zuerst: 70 Motive) | einfarbige Vektoren/PNGs für Bibliothek und Designs | `../2026-10-19-motive/AUFTRAG.md`, `motivliste.csv`, `stilreferenz-motive.png` |
| 2 | **Designs für unterbesetzte Zielgruppen** (104 Designs) | je Design `design.svg` + `design.json` (oder Bogen) | `AUFTRAG.md`, `zielgruppen.csv`, `schablonen/`, `schriften.txt`, `sprueche-bestand.md`, `stilreferenz/` |

Die Motive aus Auftrag 1 setzt du in den Designs aus Auftrag 2 ein (als `deko-<name>`), damit beides zusammenpasst. Motive der Priorität 2 und 3 kannst du nach den Designs liefern.

## Feste Regeln (gelten für beide Aufträge)
1. **Text bleibt Text.** In Designs nie in Kurven umwandeln; Schriften nur aus `schriften.txt`, Namen exakt so.
2. **Einfarbig.** Schwarz auf Weiß gestalten; wir stellen Gravur (hell auf dunkel) und UV-Druck dar. Keine Graustufen, Verläufe, Schatten.
3. **Rechtefrei.** Sprüche selbst formulieren oder gemeinfrei (Autor vor 1955 gestorben, Quelle nennen). Motive neu zeichnen, keine Nachzeichnungen bekannter Figuren, Logos oder fremder Illustrationen. Fahrzeuge markenneutral.
4. **Nichts erfinden, was festgelegt ist:** Plattenmaße, Formen, Materialien, Preise, Bohrungen kommen von uns (Schablonen). Du gestaltest Text, Motiv, Fotofläche.
5. **Würdevoll und ruhig.** Wenige Elemente, ein Motiv je Design, höchstens zwei Schriften. Bei Tieren liebevoll, nicht kitschig; bei Sternenkindern sehr behutsam.
6. **Benennung und Struktur wie vorgegeben** (Kennungen aus den CSV-Listen, Ordner je Design/Kategorie, Begleit-CSV). Wir lesen alles automatisch ein – Abweichungen kosten einen Rücklauf.
7. **Lieber weglassen als halb liefern.** Was im Stil nicht gelingt, in der Bemerkung erklären.

## Was in den Stilreferenzen zu sehen ist
- `stilreferenz/gravur-menschen.png`, `gravur-tiere.png`, `gravur-herz.png`, `sternenkinder.png`: unsere Bestandsdesigns auf Schiefer (Gravur hell, Musterfotos, typische Aufteilung: Foto links oder rechts, Name groß in Schreibschrift oder Versalien, Daten darunter, Spruch 2–6 Zeilen, ein Motiv).
- `stilreferenz/uv-granit-menschen.png`: UV-Druck auf Granit (weiße Gestaltung, Foto freigestellt).
- `../2026-10-19-motive/stilreferenz-motive.png`: 24 Motive der Bibliothek – so sollen Flächen, Binnenlinien und Detailtiefe wirken.
**Nicht kopieren**, sondern in derselben Qualität Neues für die genannten Zielgruppen machen.

## Wo alles liegt
GitHub-Repo `Chris83638w/gravuru-katalog.` (mit Punkt am Ende), Branch `main`, Ordner `auftraege/2026-10-19-gedenktafeln-zielgruppen/` und `auftraege/2026-10-19-motive/`. Die Motivbibliothek zum Nachschlagen: `motive/INDEX.md` (721 Motive, Kontaktbögen in `motive/_uebersicht/`). Nichts anderes im Repo ändern.

## Rückgabe
Entweder als ZIP oder – bevorzugt – als Branch `auftrag/2026-10-19-gedenktafeln` im selben Repo mit einem Ordner `auftraege/2026-10-19-lieferung/` (darin `motive/…` für Auftrag 1 und `designs/…` für Auftrag 2) samt den Begleit-CSVs und Kontaktbögen; keinen Merge nach `main`, das machen wir nach der Prüfung. **Wenn beide Aufträge geliefert und von uns übernommen sind, werden die Auftragsordner gelöscht** – sie sind Arbeitsmaterial, nicht Teil des Katalogs. Wir prüfen automatisch (Text als Text, Schriften, Lage im Gestaltungsrand, Schwarz/Weiß, Mindestlinienstärke, Dubletten) und melden zurück, was nicht passt. Fragen bitte gesammelt stellen, nicht je Motiv.
