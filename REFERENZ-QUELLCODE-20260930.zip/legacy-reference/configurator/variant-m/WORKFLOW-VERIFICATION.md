# Zweite Bedienrunde – lokaler Prüfstand, 27.09.2026

## Ausgangsbasis und Umfang
Aufgabenbranch: `task/konfigurator-bedienung-20260927`. Basis: `fc376c8185a4e28777259eee2d1703203898a627`; Reservierung: `c3cb60f7db645c927e1d37484eab587c91f57944`.
Die lokale Arbeitskopie enthält gezielt heruntergeladene Quellen und geprüfte Ressourcen, keinen vollständigen Git-Clone. Der Aufgabenbranch enthält die vollständige geerbte Repository-Basis. Keine Änderungen an main, Shopify, Plesk oder öffentlicher Netlify-Vorschau.

## Änderungen
- Abwählen auf leerer Plattenfläche und außerhalb, auch im Vollbild; 26-px-Griffe mit größerer unsichtbarer Trefferfläche, roter Papierkorb.
- Automatische Ausrichthilfen ohne Schalter: Plattenmitte und Textkanten während der Geste; beim Loslassen verschwinden sie. Einzel- und Gruppenausrichtung links/rechts/mittig.
- Ebenenverwaltung, Ausführungen, Zoom-Beschriftung, klarere Befestigungsbeschriftung; unnötiger Klingelschildhinweis entfernt.
- Designwechsel fragt bei veränderten Texten nach Übernahme. Eindeutige fieldKey-Zuordnung übernimmt Inhalte in neue Typografie/Positionen; nicht zuordenbare Texte bleiben als eigene Elemente erhalten und werden genannt. Beispieltexte/Abbrechen sind Alternativen.
- Designvorschau per Hover sowie eigenem Vorschau-Bedienelement. Designliste gibt Scrollen am Ende an die Seite weiter.
- Doppelklick/Doppeltippen führt zum Textfeld. Autofit bei Inhalts-, Schrift-, Größen- oder Rahmenänderung anhand tatsächlicher Vektor-Glyphengrenzen, Rotation und Oberfläche; Hundertstel-mm-Schriftgröße. Keine Größenänderung allein beim Verschieben. Mindestgröße 4 mm im Kundenmodus; unmögliche Fälle melden sich.
- Neue Texte, Motive und Uploads suchen freie Stellen und meiden die vorhandenen Elemente und die modellgebundene Klingel. Bei Platzmangel Hinweis statt Verschieben bestehender Inhalte.
- Motivbrowser mit Suche/Kategorien, automatisch nachgeladenen Blöcken, mobilem Vollbild; Suchtext wird beim Kategorienwechsel gelöscht. Suchzustand und Scrollposition bleiben beim Wiederöffnen erhalten.

## Reproduktion
Node 24 verwenden. Im Repository-Hauptordner:
```sh
node configurator/variant-m/server.mjs --port=8963
```
Vorschau: http://127.0.0.1:8963/ . Ohne privaten Workbench-Schalter und ohne Datenbank.
```sh
node --test configurator/variant-m/contract.test.mjs configurator/variant-m/ux.test.mjs configurator/variant-m/image-processing.test.mjs configurator/variant-m/usability.test.mjs configurator/variant-m/customer-tools.test.mjs configurator/variant-m/workflow.test.mjs automation/product-pipeline/tests/pipeline.test.mjs
node configurator/variant-m/export-public.mjs
```
63 Prüfungen bestanden. Export lokal erzeugt, nicht veröffentlicht: 100 Dateien, 27 Module, 104 Originalressourcen per Prüfsumme bestätigt. Fünf neue Modelltests decken Randpassung, Rotation/Mindestgröße, Platzierung/Klingel, Textzuordnung/Mehrdeutigkeit und Gruppenausrichtung ab.

## Browserprüfung
Desktop und 390 × 844: Oberfläche lädt ohne Fehler; Motive öffnen, Suche Hund, Kategorie Anker löscht Suche, Motiv hinzufügen schließt Browser. Automatisches Nachladen von 24 auf 36 Motive beim Scrollen geprüft. Auswahl im mobilen Vollbild durch Tippen auf leere Plattenfläche aufgehoben, Griffe optisch geprüft. Vergrößerte Designvorschau ohne vorzeitigen Designwechsel; Textübernahme Labrador → Strichdesign mit verändertem Namen geprüft. Langer Name automatisch auf 5,73 mm eingepasst.

## Grenzen und nächste Abnahme
Browsermessung in Modell-mm ist keine zusätzliche Zusage einer physischen Fertigungstoleranz. Freiplatzsuche nutzt konservative Objektgrenzen und kann bei dichtem Layout eine manuelle Platzierung verlangen. Echte iOS-/Android-Geräte, sämtliche Schriften/Designkombinationen und Langzeitsitzungen sind noch nicht vollständig geprüft. Fertigungs-/Bestellanbindung und private Werkstattdaten bleiben außerhalb dieser Bedienrunde. Nächster Schritt: Nutzerabnahme dieser lokalen Fassung, danach koordinierter Abgleich vor einer separaten Veröffentlichung.

Nachprüfung: Doppeltippen auf Müller im mobilen Vollbild schließt das Vollbild und fokussiert Zeile 2. Nach Verschieben sind keine Hilfslinien mehr im DOM. Keine Browserfehler festgestellt.
