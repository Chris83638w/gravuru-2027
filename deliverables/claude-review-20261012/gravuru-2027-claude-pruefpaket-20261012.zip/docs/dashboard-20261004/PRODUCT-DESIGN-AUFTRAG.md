# Kopierauftrag: Product Design – bestehende UV-Designserie vorbereiten

Vorbereitet am 04.10.2026. **Funktionspilot bestanden, Serienauftrag noch nicht gestartet:** Der Import und die Kundenbearbeitung von „18 – Unser kleines Glück“ sind geprüft; Druckausgabe und visuelle Nutzerfreigabe sind weiterhin offen. Product Design unterstützt die visuelle Arbeit; es garantiert weder automatische Ebenenextraktion noch druckfertige Separationen. Die technische Übernahme und Abnahme verbleiben in der bestehenden Mikail-Codex-Cloud-Aufgabe.

## Aktuelle Sperre für die Serienvorbereitung

Nutzerkorrektur: 1:1 zum Originalmockup, Beispielbild und ursprüngliche Beispielnamen erhalten; Foto per Klick austauschen, Texte vom Kunden ändern. Untere 7 mm beim massiven Holzsockel verdeckt. Der aktuelle Funktionspilot erfüllt noch keine visuelle 1:1-Abnahme. ZIP-Basis enthält bereits rekonstruierte Teile und eine ähnliche Ersatzschrift; deshalb vor dem nächsten Design zuerst diese Abweichungen klären. Siehe [UV-ORIGINAL-KORREKTUR.md](UV-ORIGINAL-KORREKTUR.md).

## Diesen Text nach bestandenem Pilot übergeben

> @Product Design
>
> Bereite unsere bereits gestaltete UV-Druck-Serie für die bestehende Gravuru-2027-Werkstatt vor. Ziel sind wiederverwendbare Designbestandteile für personalisierbare Acrylglasbilder. Wir erhalten die vorhandenen Motive und ihre Gestaltung. Erstelle keine neue Dashboard-Oberfläche, keine Website und keine ungefragten Designalternativen.
>
> **Verbindliche Eingaben:** die tatsächlich zugänglichen Originalbilder/-pakete, die freigegebene Vorlage „18 – Unser kleines Glück“ und der dazu bestandene technische Importvertrag aus unserer Codex-Cloud-Aufgabe. Lies und betrachte die Originale vor der Bearbeitung. Beginne mit einer Liste der wirklich vorhandenen Designs. Die Nummer 18 allein belegt nicht, dass alle 18 Originale vorliegen. GitHub-Text oder kleine Kontaktübersichten ersetzen keine hochauflösenden Originale. Fehlt eine Quelle oder die Pilotfreigabe, benenne genau diese Lücke; keine Ersatzmotive erfinden und keine fertige Serienübergabe behaupten.
>
> **Arbeitsweise je Design:**
> 1. Vorhandene SVG-/PDF-Ebenen und getrennte Foto-/Dekorationsdateien zuerst wiederverwenden. Bildanalyse oder Rekonstruktion nur einsetzen, wo keine geeigneten Bestandteile vorliegen. Das Original unverändert behalten.
> 2. Originalgestaltung, Farben, Proportionen und Ebenenfolge bewahren. Druckmotiv von Produktszene, Sockel, Schatten und Hintergrund unterscheiden. Benötigte Entzerrung oder ergänzte, zuvor verdeckte Bildteile ausdrücklich als Rekonstruktion kennzeichnen.
> 3. Feste Dekoration und austauschbares Foto voneinander trennen. Transparenz als echten Alphakanal liefern. Rasterdekoration als Raster kennzeichnen. Fotoform und Maskierung aus der Referenz übernehmen; Bogen/Kreis nicht stillschweigend durch ein Rechteck ersetzen.
> 4. Titel, Namen, Datum und Spruch nach dem freigegebenen Pilot getrennt zuordnen. Festlegen, was der Kunde ändern darf. Vorlagentexte dürfen nicht zusätzlich im Hintergrundbild verbleiben. Unbekannte Schrift und unsichere Erkennung markieren; keine erfundenen Schriftdateien oder Nutzungsrechte.
> 5. Eine Vergleichsvorschau Original/aufbereiteter Entwurf sowie eine Vorschau mit anderen Testnamen und anderem Testfoto liefern. Prüfen: keine doppelten Texte, alten Fotoreste, abgeschnittenen Buchstaben oder Motivteile; richtige Maske, Transparenz und Reihenfolge. Vorschau als Vorschau kennzeichnen.
>
> **Übergabe pro Design:** Originalreferenz und stabile Design-ID; tatsächlich erzeugte Dekorations-/Bilddateien; Masken-/Feldzuordnung mit Maßen in mm und freigegebenen Schriften gemäß Pilotvertrag; Vergleichsvorschauen; kurze Liste der Rekonstruktionen, Unsicherheiten und noch fehlenden Bestandteile. Nur vorhandene Dateien verlinken. Wenn deine Werkzeuge keine echten getrennten Ebenen oder das benötigte Dateiformat erzeugen können, liefere die visuelle Vorlage und eine klare Zuordnung als Zwischenstand, nicht als fertiges Importpaket.
>
> **Technische Grenze:** Bildgenerierung allein erzeugt keine verlässlich editierbaren SVG-Text-/Fotoobjekte, kein geprüftes CMYK und keine Roland-Separationen. SVG/PNG/PDF nicht durch bloßes Umbenennen oder Einbetten als Vektor-/Druckdatei ausgeben. Codex übernimmt die echte Objektzuordnung, Validierung, automatisierte Variantenverarbeitung, Dashboard-Integration und Produktionsprüfung mit dem bestätigten Druckprofil. Ungeklärte Weiß-/Spiegelungsregeln nicht raten.
>
> Arbeite ausschließlich mit den freigegebenen Cloudquellen. Keine Laptopdateien voraussetzen, keine privaten Bilder/Bestandsdaten/Secrets in GitHub oder veröffentlichte Snapshots übernehmen, nichts live veröffentlichen. Erst einen weiteren Entwurf nach dem Pilot bearbeiten und technisch abnehmen lassen; danach die verbleibende Serie im selben Format vorbereiten. Keine Modelle selbstständig auswählen oder neue Chats/Umgebungen anlegen.

## Beizulegende Quellen

- [Pilotstand und Quellennachweise](UV-DESIGN-PILOT.md), einschließlich bestätigter Designs 13–18, geprüftem Masterpaket für Design 18 und noch fehlenden weiteren Originaldateien.
- [Geprüftes Vorlagenformat und Prüfkommando](VORLAGENFORMAT.md), [Rollenzuordnung für den Pilot](uv-pilot-mapping.json), `scripts/prepare-layered-design.py` und [tatsächlicher Prüfbericht](UV-PILOT-PRUEFUNG.md). Das erzeugte Referenzpaket enthält Originaldekoration und liegt deshalb ausschließlich privat in der laufenden Cloud-Aufgabe; es muss ausdrücklich privat übergeben oder aus dem Masterpaket reproduziert werden.
- Originale über eine autorisierte private Cloud-Dateiübergabe, keine Vorschau als Original ausgeben. Die Übergabe zwischen Chats erfolgt ausdrücklich; kein automatisches gemeinsames Dateisystem oder Chatgedächtnis voraussetzen.
