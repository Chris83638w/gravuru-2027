# Gravuru 2027 – Prüfung vom 12.10.2026

Zuerst `docs/reviews/PROJEKTUEBERBLICK-CLAUDE-20261012.md` lesen. Sie enthält Ziele, Entscheidungen, Soll/Ist, Fehlerhistorie, Belege, Grenzen und den Prüfauftrag an Claude.

Quellenbasis: 9d388e3e9f8e7cb5aa63e7a50d163cf1ca7d5e3a. Installierter Anwendungscode: 7a168bc66adc9718bc9b0fefad97c338e546c57d. `main` ist veraltet. Die beiden neuen Übergabedateien sind als zusätzliche Dateien mit eigenen Hashes im Manifest gekennzeichnet.

Enthalten: aktive App mit Ressourcen und Tests, Betriebs- und Prüfscripte, Anforderungen, textbasierte aktuelle/historische Belege. Nicht enthalten: Git-Historie, private Datenbanken, private Original-Uploads, Zugangsdaten, historische Liefer-ZIPs und die Bild-/PDF-Belege aus docs/. Die Liste ausgeschlossener docs-Dateien liegt im Manifest. Keine unabhängige Prüfung wurde bereits durchgeführt.

Historische README-/Status-/Release-Aussagen nicht als heutige Freigaben lesen. Normale Entwicklungsbefehle stehen in package.json; Node >=24 und passende Python-Abhängigkeiten vorausgesetzt. Tests nur in frischer isolierter Ablage. Keine Liveänderung, Veröffentlichung, echte Bestellung oder kostenpflichtige KI-Anfrage aus dem Prüfauftrag ableiten.
