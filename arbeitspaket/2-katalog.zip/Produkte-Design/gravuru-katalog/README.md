# Gravuru-Katalog

> **Projektstand, Regeln und offene Entscheidungen:** [STAND.md](STAND.md) – zuerst lesen.

Die **eine Quelle** für alles, was Gravuru verkauft: Materialien, Rohling-Familien mit Größen, Formen, Bohrbildern und Preisen, Zeichnungen, Designs, Schriften – und die Produktlinien, in denen das alles verkauft wird. Werkstatt, Konfigurator, Shop-Exporte und die KI-Designstrecke lesen von hier. **Gepflegt wird hier, nicht im Shop und nicht in Excel-Kopien.**

Gesamtübersicht zum Lesen im Browser: [KATALOG.md](KATALOG.md) (wird erzeugt).

## Werkstattstruktur und genaue Formserien

[Struktur und Hauptprodukte](struktur.json) bilden die bestätigten Produktlinien, Unterkategorien und geprüften Shopify-Entwürfe ab. Mitarbeiter planen Anzahlen und Zuordnungen in der Werkstatt. Das ist keine Veröffentlichung und keine automatische Produktanlage.

Die neuen [Acryl-](serien/acryl-tuerschilder-2027.json) und [Edelstahl-Formserien](serien/edelstahl-tuerschilder-2027.json) speichern exakte Konturen, Kennungen, Revisionen und Preise. Sie werden nicht in das einfachere Familienmodell gepresst. Das Familienmodell und ältere Quellen bleiben separat erhalten. [Hunde-Serie 22×14](serien/hunde-gedenktafeln-22x14-2027.json) verweist auf die vier aktuellen Hauptprodukte mit je 48 Kombinationen.

[Übergabe für den neuen Konfigurator](UEBERGABE-KONFIGURATOR.md). Die Kundenanbindung ist zurückgestellt. Bestehende PDF-/Excel-Ableitungen wurden bei diesem Metadatenabgleich nicht neu erzeugt und können älter sein; maßgeblich sind die JSON-Quellen und die neu erzeugte KATALOG.md.

## Logik in fünf Ebenen

| Ebene | Was es ist | Ordner | Beispiel |
| --- | --- | --- | --- |
| **1 Material** | Werkstoff mit Stärke, Verfahren (Gravur/Druck), Farbe der Gravur, Gravurseite | `materialien/` | Acrylglas schwarz 5 mm, Gravur von hinten |
| **2 Familie** (Rohling) | ein Material in **allen** Größen und Formen, mit Bohrbildern je Größe, Zubehör, Rückplatte, Preisen, erlaubten Schriften. **Eine Familie = ein Konfigurator-Produktmodell.** | `familien/<material>/<familie>.json` | `acryl-ss-abstandshalter` (33 Größen, 4 Bohrbilder) |
| **3 Formatreihe** (abgeleitet) | Größen gleichen Seitenverhältnisses (±1 %) innerhalb einer Familie – darauf skalieren Designs automatisch | wird aus 2 berechnet | 3:2 = 15 × 10 … 42 × 28 |
| **4 Design** | Gestaltung eines **Formats** (Reihe + Verfahren + Thema), nicht eines Materials. Master in der kleinsten Größe der Reihe, umgerechnet und geprüft je Zielgröße und Familie | `designs/<reihe>/<design-id>/` | `hausnummer-anker` auf 3:2 → AA, AS, S/S, Edelstahl |
| **5 Linie → Unterkategorie** | Linie = physisches Produkt (Familien, Größen, Optionen, Preise); Unterkategorie = Thema/Zielgruppe darin (Schrift-Set, Designs, Motive, abweichende Preise). Shop-Name „Linie – Unterkategorie“. | `linien/<linie>.json`, Themen in `themen.json` | Edelstahl Türschilder – Hundeschilder |

Dazu quer: `zeichnungen/` (Corel-Quellen mit Prüfsumme und maschinell gelesenem Plattenbericht – die Zeichnung ist das Maß, nicht die Erinnerung), `motive/` (Motivbibliothek: 721 einfarbige Vektoren in 47 Kategorien mit Kontaktbögen, siehe [motive/INDEX.md](motive/INDEX.md)) und `schriften/` (Schriftbibliothek der Werkstatt, Freigabe je Familie, Lizenznachweis).

## Preise – drei Ebenen

1. **Grundpreis je Größe** (`sizes[].baseCents`) und **Aufpreis je Befestigung** (`mountingRules[].priceCents`) in der Familie.
2. **Optionen** (`options[]`): optionales Zubehör und Varianten je Familie – Gruppe (z. B. Abstandshalter-Set, Schraubenset, Geschenkverpackung), Art Zubehör/Variante, Auswahl eine/mehrere, je Option Aufpreis und SKU-Endung. Pflege im Blatt „Optionen“ der Stammdaten-Excel.
3. **Je Linie (Unterkategorie)** können Größen-, Befestigungs- und Optionspreise überschrieben werden (`linien/<linie>.json` → `priceOverrides`); ohne Eintrag gilt der Familienpreis. So kann dieselbe Platte als Hundeschild anders bepreist sein als als Firmenschild.

Alle Preise in Cent, `null` = offen; offene Preise sperren das Erzeugen.

## Regeln

1. **JSON ist die Quelle.** Excel, PDF-Kataloge, PNGs und `KATALOG.md` werden daraus **erzeugt** (`scripts/build-katalog.py`, `family-excel.py`, `plate-catalog-pdf.py` im Repo `gravuru-2027`) und nie von Hand geändert. Excel-Rückimport nur über das Skript mit Prüfung.
2. **Offen bleibt offen.** Unbekannte Preise, Stärken, Randabstände stehen als `null`/„offen“ – nichts wird geraten. Erzeugen eines Produkts ist gesperrt, solange etwas offen ist.
3. **Bohrbilder werden je Größe berechnet** (Lage, Anzahl, Ø, Randabstand in mm), nie mit dem Design skaliert.
4. **Designs gehören zu Formaten.** Ein Design wird je Reihe einmal gezeichnet, Text bleibt Text (Kundenfelder), Motive einfarbig; Umrechnung und Prüfung per Skript (passt / prüfen / passt nicht).
5. **Schriften sind Stammdaten.** Nur Schriften aus der Bibliothek, Namen exakt, Lizenz dokumentiert; das Skript ersetzt nie eine Schrift. Im Design bleibt Text **Text** (Kundenfeld); erst die Fertigungsausgabe bei der Bestellung wandelt jeden Text mit den hinterlegten Schriftkonturen in **Pfade** um (je Textfeld ein zusammengesetzter Vektor). Deshalb braucht die Werkstatt vollständige Schriftdateien, keine Teilmengen.
6. **Jede Änderung ist ein Commit** (wer, wann, warum). Live-Systeme (Shopify, Amazon) sind Ziele von Exporten, nie Quelle.
7. **Kennungen** sind stabil: Familien-ID, SKU-Schlüssel `<Präfix>-<Form>-<BxH>-<Befestigung>`, Design-ID. Alles verweist über Kennungen, nie über Namen.

## Ablauf

![Ablauf](ABLAUF.png)

```
Zeichnung (Corel)  →  Lesebericht (Skript)  →  Familie.json  →  Katalog/Excel zum Prüfen  →  Freigabe
                                                                      ↓
Design-Master je Reihe (ChatGPT/Corel)  →  Zerlegen  →  Umrechnen + Prüfen  →  Freigabe  →  Werkstatt-Import  →  Shop-Export
```

## Stand

Siehe [KATALOG.md](KATALOG.md). Übernommen aus `gravuru-2027` (Branch `task/steel-master-data-20261016`): Edelstahl-Türschilder (61 Größen, Shop-Abgleich 0 Abweichungen), Acryl AA/AS/S/S (33 Größen aus der Zeichnung vom 17.10.2026), fünf Gedenktafel-Familien 30 × 20, Zeichnung mit Lesebericht, Testlauf-Designs. Die Werkstatt liest die Familien derzeit noch aus `gravuru-2027/app/designs/`; die Umstellung auf dieses Repo ist [Auftrag #5](https://github.com/Chris83638w/gravuru-2027/issues/5).
