import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomBytes} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {build,HERE,ROOT} from './build.mjs';
import {prepareConfig} from './contract.mjs';
import {validateCommerce} from './commerce-model.mjs';

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
// A review gallery can include every remaining imported design without setting
// its approval flag, activating a new product revision or changing Shopify data.
export function compileProductPreview(workbench,id,{allDesigns=false,active=true}={}){
 const cfg=workbench.compile(id,{active,strict:true});
 if(!allDesigns)return cfg;
 const product=workbench.load(id);
 if(String(product.revision)!==cfg.profile.revision)throw Error('Produktstand seit der Übertragung geändert. Vorschau zuerst abgleichen.');
 const records=product.designs.filter(d=>!d.deleted),seen=new Set(cfg.profile.designs.map(d=>d.id));
 const fonts=cfg.localResources.fonts,motifs=new Map(cfg.localResources.motifs.map(m=>[m.key,m]));
 for(const record of records){
  if(seen.has(record.id))continue;
  if(!cfg.photo.enabled&&workbench.bundle(id,record).design.objects.some(o=>o.type==='photoSlot'))continue;
  const part=workbench.compile(id,{designId:record.id}); // Native editor diagnostics remain mandatory.
  for(const [key,font] of Object.entries(part.localResources.fonts)){if(fonts[key]&&JSON.stringify(fonts[key])!==JSON.stringify(font))throw Error('Abweichende Schriftressource: '+key);fonts[key]=font;}
  for(const motif of part.localResources.motifs){if(motifs.has(motif.key)&&JSON.stringify(motifs.get(motif.key))!==JSON.stringify(motif))throw Error('Abweichende Motivressource: '+motif.key);motifs.set(motif.key,motif);}
  cfg.localResources.photoPlaceholders??=[];
  cfg.localResources.photoPlaceholders.push(...(part.localResources.photoPlaceholders||[]));
  cfg.profile.designs.push(...part.profile.designs);seen.add(record.id);
 }
 cfg.localResources.motifs=[...motifs.values()];cfg.previewDesignScope='all-current-designs';
 return prepareConfig(cfg);
}
export function exportProductPreview({config,directory,shopifyProductId,resolveSurface,resolvePlaceholder,commerce,token=randomBytes(24).toString('hex')}){
 if(!/^[a-f0-9]{48}$/.test(token)||!/^gid:\/\/shopify\/Product\/\d+$/.test(shopifyProductId))throw Error('Ungültige Produktvorschau-Zuordnung.');
 const cfg=prepareConfig(config);
 if(!cfg.reviewOnly||cfg.profile.features.orderEnabled!==false)throw Error('Nur eine ausdrücklich gesperrte Produktvorschau exportieren.');
 delete cfg.workbench;cfg.productPreview=true;
 if(commerce){validateCommerce(cfg,commerce);if(commerce.productId!==shopifyProductId)throw Error('Abweichende Warenkorb-Produktbindung.');}
 const base='/produktvorschau/'+token+'/',destination=path.join(directory,token);
 let surface;
 if(cfg.materialSurface){
  const asset=cfg.materialSurface.match(/^\/api\/product-workbench\/assets\/([a-f0-9]{64})\.(png|jpg|webp)$/);
  if(asset){const bytes=resolveSurface?.(asset[1]+'.'+asset[2]);if(!Buffer.isBuffer(bytes)||sha(bytes)!==asset[1])throw Error('Materialbild-Prüfsumme abweichend.');surface={name:'material/'+asset[1]+'.'+asset[2],bytes};cfg.materialSurface=base+surface.name;}
  else if(!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(cfg.materialSurface))throw Error('Materialoberfläche ist nicht lokal gebunden.');
 }
 if(fs.existsSync(destination))throw Error('Vorschau existiert bereits. Neue Fassung separat erzeugen.');
 fs.mkdirSync(destination,{recursive:true});
 const generated=fs.mkdtempSync(path.join(directory,'.build-'));
 const result=build({outputDirectory:generated}),files=[];
 function write(relative,bytes){
  if(path.isAbsolute(relative)||relative.split(/[\\/]/).includes('..'))throw Error('Ungültiger Exportpfad.');
  if(/\.(mjs|js|html|css|json)$/.test(relative)){
   let source=Buffer.isBuffer(bytes)?bytes.toString('utf8'):String(bytes);
   for(const prefix of ['/_runtime/','/platform/sources/app/shared/','/configurator/variant-m/','/materialreferenzen/','/assistant.js','/api/guides','/policies/shipping-policy'])source=source.replaceAll(prefix,(match,offset)=>source[offset-1]==='.'?match:base+prefix.slice(1));
   source=source.replace('<base href="/" target="_self">','<base href="'+base+'" target="_self">');
   bytes=Buffer.from(source);
  }
  const target=path.join(destination,relative);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);files.push({path:relative,bytes:Buffer.byteLength(bytes),sha256:sha(bytes)});
 }
 const copy=(file,relative)=>write(relative,fs.readFileSync(file));
 for(const raster of cfg.localResources?.rasters||[]){
  const name=raster.assetId+'.png',bytes=resolveSurface?.(name);
  if(!Buffer.isBuffer(bytes)||sha(bytes)!==raster.sha256)throw Error('Rastermotiv-Prüfsumme abweichend.');
  raster.url=base+'raster/'+name;
  write('raster/'+name,bytes);
 }
 const copiedPlaceholders=new Set();
 for(const asset of cfg.localResources?.photoPlaceholders||[]){
  const bytes=resolvePlaceholder?.(asset.sha256);
  if(!Buffer.isBuffer(bytes)||sha(bytes)!==asset.sha256)throw Error('Fotoplatzhalter-Prüfsumme abweichend.');
  const name='photo-placeholders/'+asset.sha256+'.png';
  asset.url=base+name;
  if(!copiedPlaceholders.has(asset.sha256)){write(name,bytes);copiedPlaceholders.add(asset.sha256);}
 }
 const modules=new Set();
 function moduleFile(relative){
  if(modules.has(relative))return;
  if(!/^(configurator\/variant-m|platform\/sources\/app\/shared)\/.+\.mjs$/.test(relative)||/\.(test|spec)\.mjs$/.test(relative))throw Error('Unerwartetes Browsermodul: '+relative);
  modules.add(relative);const source=fs.readFileSync(path.join(ROOT,relative),'utf8');write(relative,source);
  for(const match of source.matchAll(/(?:from\s*|import\s*\()\s*['"]([^'"]+)['"]/g)){
   if(!match[1].startsWith('.'))throw Error('Unerwartete Modulabhängigkeit: '+match[1]);
   moduleFile(path.posix.normalize(path.posix.join(path.posix.dirname(relative),match[1])));
  }
 }
 for(const file of ['adapter.mjs','ux.mjs'])moduleFile('configurator/variant-m/'+file);
 for(const file of ['ux.css','refinements.css','usability.css','customer-tools.css','workflow.css','completion.css'])copy(path.join(HERE,file),'configurator/variant-m/'+file);
 copy(path.join(generated,'assistant.js'),'assistant.js');
 // Decode the verified legacy libraries at export time, once. The browser used
 // to fetch more than forty chunks in serial batches before showing a design.
 let editor=fs.readFileSync(path.join(generated,'editor.html'),'utf8').replace(/<title>[^<]*<\/title>/,'<title>Produkt personalisieren · Gravuru</title>');
 const urls=JSON.parse(editor.match(/id="preview-urls"[^>]*>([\s\S]*?)<\/script>/)[1]);
 const runtimeFile=url=>fs.readFileSync(path.join(ROOT,'designs/aosu-labrador/runtime',path.basename(url)),'utf8');
 const catalogBase=JSON.parse(runtimeFile(urls.catalog));
 const catalog=catalogBase.format==='gravuru-catalog-parts-v1'?JSON.parse(catalogBase.parts.map(runtimeFile).join('')):catalogBase;
 const decode=parts=>JSON.parse(gunzipSync(Buffer.from(parts.map(runtimeFile).join(''),'base64')));
 Object.assign(catalog.fonts,decode(urls.fonts));
 const entries=decode(urls.parts);
 if(Object.keys(catalog.fonts).length!==30||entries.length!==703||Object.keys(catalog.motifs).length!==18)throw Error('Vorschaubibliothek unvollständig.');
 const categories={'Montserrat':'Schlicht & modern','Ubuntu':'Schlicht & modern','Lora':'Klassisch & elegant','Lora Italic':'Klassisch & elegant','Dancing Script':'Geschwungen & festlich','Source Code Pro':'Schreibmaschine'};
 for(const [name,category] of Object.entries(categories))catalog.fonts[name].category=category;
 // These historic product designs are replaced by this product's profile.
 catalog.designs=catalog.designs.slice(0,1);
 write('library.json',JSON.stringify({catalog,entries}));
 const start=editor.indexOf('    const base=JSON.parse(await fetchText(urls.catalog));'),end=editor.indexOf('    if(!window.parent.UniversalConfig){Object.assign',start);
 if(start<0||end<0)throw Error('Bibliotheks-Ladeanker fehlt.');
 editor=editor.slice(0,start)+'    ({catalog,entries}=window.parent.GravuruPreviewLibrary);\n'+editor.slice(end);
 const legacyThumbnail="const item=designs.find(d=>d.id===card.dataset.cDesign);card.querySelector('small').textContent=frame(this).name;card.querySelector('svg').outerHTML=thumb(this,item);";
 if(editor.split(legacyThumbnail).length!==2)throw Error('Miniatur-Ladeanker fehlt.');
 editor=editor.replace(legacyThumbnail,'if(!window.parent.UniversalConfig){'+legacyThumbnail+'}');
 write('editor.html',editor);
 if(surface)write(surface.name,surface.bytes);
 copy(path.join(generated,'guides.json'),'api/guides.json');
 const models=JSON.parse(fs.readFileSync(path.join(generated,'models.json'))),legacy=models.find(m=>m.key==='schiefer').legacy;
 legacy.designs=cfg.profile.designs;legacy.purchasing.basePriceCents=cfg.basePriceCents;legacy.purchasing.bellModel=cfg.profile.name;
 write('models.json',JSON.stringify([{key:'product',name:cfg.profile.name,legacy,universal:cfg}]));
 if(commerce)write('commerce.json',JSON.stringify(commerce));
 copy(path.join(HERE,'product-preview.html'),'index.html');
 for(const item of JSON.parse(fs.readFileSync(path.join(ROOT,'designs/aosu-labrador/RESOURCE-INVENTORY.json'))).filter(v=>v.path.startsWith('designs/aosu-labrador/runtime/')))copy(path.join(ROOT,item.path),item.path.replace('designs/aosu-labrador/runtime/','_runtime/'));
 const manifest={schema:'gravuru-product-preview/v1',shopifyProductId,sourceProductId:cfg.profile.id,revision:cfg.profile.revision,designScope:cfg.previewDesignScope||'active-selection',designIds:cfg.profile.designs.map(d=>d.id),createdAt:new Date().toISOString(),orderEnabled:false,commerceTransport:commerce?'shopify-parent-multipart':null,files};
 // Manifest is deliberately outside the served directory. No product storage is exposed.
 fs.writeFileSync(path.join(directory,token+'.json'),JSON.stringify(manifest,null,2),{flag:'wx'});
 return {token,path:base,files:files.length,bytes:files.reduce((n,v)=>n+v.bytes,0),verifiedResources:result.verifiedResources,...Object.fromEntries(['shopifyProductId','sourceProductId','revision','designIds'].map(k=>[k,manifest[k]]))};
}

