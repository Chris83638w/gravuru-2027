// Shared product workbench mounted by the existing workshop and M preview server.
// Private data stays outside the source tree; changes have optimistic revisions.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID,createHash} from 'node:crypto';
import {ProductLibrary,slug} from './workbench-library.mjs';
import {roundDesign} from '../../configurator/variant-m/design-edit.mjs';
import {checkDesign} from './workbench-checks.mjs';
import {surfacePreview} from '../../configurator/variant-m/material-surface.mjs';
import {gunzipSync} from 'node:zlib';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {prepareConfig} from '../../configurator/variant-m/contract.mjs';
import {profileForProduct} from './lib/core.mjs';
import {measureText,textPaths} from '../../platform/sources/app/shared/models/doorbell-preview.mjs';
import {validateDesignContent,objectIssue,escapeXml} from '../../platform/sources/app/shared/models/design-content.mjs';
import {validateGeometryHoles} from '../../platform/sources/app/shared/models/design-content.mjs';
import {validateOptionGroups} from '../../platform/sources/app/shared/models/universal-elements.mjs';
import {PROCESSING_PROFILES,MATERIAL_COLORS} from '../../platform/sources/app/shared/models/processing-profiles.mjs';
import {transferDraft} from './workbench-shopify.mjs';
import {localFontIds} from '../../configurator/variant-m/local-pilot.mjs';

const HERE=path.dirname(fileURLToPath(import.meta.url)),ROOT=path.resolve(HERE,'../..');
const run=promisify(execFile),clone=structuredClone;
const json=f=>JSON.parse(fs.readFileSync(f,'utf8').replace(/^\uFEFF/,''));
const hash=b=>createHash('sha256').update(b).digest('hex');
let standardFonts;
export function availableFonts(){
 if(!standardFonts){const dir=path.join(ROOT,'designs/aosu-labrador/runtime');const unpack=names=>{const raw=names.map(n=>fs.readFileSync(path.join(dir,n),'utf8')).join('');return JSON.parse(raw.startsWith('{')?raw:gunzipSync(Buffer.from(raw,'base64')).toString());};
 const catalog=unpack(json(path.join(dir,'gravuru-catalog-51fa7e857d52.json')).parts);const extra=unpack(fs.readdirSync(dir).filter(n=>/^gravuru-entwurf-fonts-\d+\.txt$/.test(n)).sort());standardFonts={...catalog.fonts,...extra};}return standardFonts;
}
const fail=(m,status=400)=>{throw Object.assign(Error(m),{status});};
const safe=s=>{if(typeof s!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}$/.test(s)||s.includes('..'))fail('Ungültige Kennung.');return s;};
const atomic=(file,data)=>{fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+randomUUID()+'.tmp';fs.writeFileSync(temp,JSON.stringify(data,null,2),'utf8');fs.renameSync(temp,file);};
export function cents(value,{optional=false}={}){if(value===null||value===undefined||value===''){if(optional)return null;fail('Preis fehlt.');}if(typeof value==='string'&&!/^\d+(?:[.,]\d{1,2})?$/.test(value))fail('Preis bitte mit höchstens zwei Nachkommastellen eingeben.');const amount=Number(String(value).replace(',','.'));if(!Number.isFinite(amount)||amount<0||amount>1000000)fail('Ungültiger Preis.');return Math.round(amount*100);}
export const VERSIONS=[{id:'variant-m',name:'Variante M',available:true},{id:'variant-a',name:'Variante A',available:false},{id:'variant-b',name:'Variante B',available:false},{id:'variant-c',name:'Variante C',available:false}];
export function defaultProduct(){return {title:'Gedenktafel aus Schiefer mit Foto',width:220,height:140,thickness:5,weight:null,shape:'rect',processing:'slate-engraving',configurator:'variant-m',basePrice:null,extraMotifPrice:0,extraPhotoPrice:9.99,includedPhotos:1,description:'',sku:'',categoryId:'',materialId:'schiefer',mountingProfileId:'',templateId:'',keyword:'',seoTitle:'',seoDescription:'',handle:'',tags:'',imageName:'',imageAlt:'',options:[
 {id:'OHNE',label:'Ohne Befestigung',price:0,holeCount:0,edge:12,diameter:5},
 {id:'B02',label:'Zwei Bohrungen',price:2.99,holeCount:2,edge:12,diameter:5},
 {id:'B04',label:'Vier Bohrungen',price:3.99,holeCount:4,edge:12,diameter:5},
 {id:'B02-AH02',label:'Zwei Bohrungen mit Abstandshaltern',price:8.98,holeCount:2,edge:12,diameter:5},
 {id:'B04-AH04',label:'Vier Bohrungen mit Abstandshaltern',price:13.98,holeCount:4,edge:12,diameter:5},
 {id:'STKLAR',label:'Acrylglasständer klar',price:12.99,holeCount:0,edge:12,diameter:5},
 {id:'STSCHWARZ',label:'Acrylglasständer schwarz',price:14.99,holeCount:0,edge:12,diameter:5},
 {id:'SILIKON',label:'Silikon',price:4.99,holeCount:0,edge:12,diameter:5}]};}
export function optionGroups(p){return [{id:'mounting',name:'Befestigung',required:true,defaultValueId:p.options[0]?.id,values:p.options.map(o=>{
 const e=Number(o.edge),d=Number(o.diameter),w=p.width,h=p.height;
 const holes=o.holeCount===2?(o.layout==='top'?[[e,e],[w-e,e]]:o.layout==='vertical'?[[w/2,e],[w/2,h-e]]:[[e,h/2],[w-e,h/2]]):o.holeCount===4?[[e,e],[w-e,e],[w-e,h-e],[e,h-e]]:[];
 return {id:o.id,label:o.label,priceCents:cents(o.price),currency:'EUR',holes:holes.map(([x,y])=>({x,y,diameter:d}))};})}];}
export function validateProduct(input){
 const p=clone(input);delete p.id;
 if(typeof p.title!=='string'||!p.title.trim()||p.title.length>200)fail('Produktname fehlt oder ist zu lang.');
 for(const [key,max] of Object.entries({categoryId:120,materialId:120,mountingProfileId:120,templateId:120,keyword:160,seoTitle:200,seoDescription:500,handle:180,tags:4000,imageName:180,imageAlt:1000})){p[key]=p[key]??'';if(typeof p[key]!=='string'||p[key].length>max)fail('Feld '+key+' prüfen.');}
 if(p.handle&&!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(p.handle))fail('URL nur mit Kleinbuchstaben, Zahlen und Bindestrichen.');
 for(const k of ['width','height','thickness']){p[k]=Number(p[k]);if(!Number.isFinite(p[k])||p[k]<=0||p[k]>(k==='thickness'?100:2000))fail('Maße und Stärke prüfen.');}
 if(p.width<10||p.height<10||!['rect','ellipse'].includes(p.shape))fail('Form und Maße prüfen.');
 if(!PROCESSING_PROFILES.some(v=>v.id===p.processing))fail('Bearbeitungsverfahren fehlt.');
 if(!VERSIONS.some(v=>v.id===p.configurator))fail('Unbekannte Konfiguratorversion.');
 for(const k of ['basePrice','extraPhotoPrice','extraMotifPrice']){const v=cents(p[k],{optional:k==='basePrice'});p[k]=v===null?null:v/100;}
 if(!Number.isInteger(p.includedPhotos)||p.includedPhotos<0||p.includedPhotos>4)fail('Enthaltene Fotos: 0 bis 4.');
 if(p.weight!==null&&p.weight!==''){p.weight=Number(p.weight);if(!Number.isFinite(p.weight)||p.weight<=0)fail('Gewicht muss positiv sein.');}else p.weight=null;
 if(typeof p.description!=='string'||p.description.length>20000||typeof p.sku!=='string'||p.sku.length>80)fail('Beschreibung/SKU prüfen.');
 if(!Array.isArray(p.options)||!p.options.length||p.options.length>40)fail('Bitte 1 bis 40 Optionen anlegen.');
 for(const o of p.options){safe(o.id);if(![0,2,4].includes(o.holeCount))fail('Bohrbild: 0, 2 oder 4 Bohrungen.');if(o.layout&&!['side','top','vertical'].includes(o.layout))fail('Bohrlochposition prüfen.');if(!Number.isFinite(o.edge)||o.edge<0||!Number.isFinite(o.diameter)||o.diameter<=0)fail('Randabstand und Bohrdurchmesser prüfen.');}
 const groups=optionGroups(p);validateOptionGroups(groups);
 for(const v of groups[0].values){validateGeometryHoles({geometry:{width:p.width,height:p.height,shape:p.shape,holes:v.holes}});for(let i=0;i<v.holes.length;i++)for(let j=i+1;j<v.holes.length;j++)if(Math.hypot(v.holes[i].x-v.holes[j].x,v.holes[i].y-v.holes[j].y)<(v.holes[i].diameter+v.holes[j].diameter)/2)fail('Bohrlöcher überlappen sich. Maße und Randabstand prüfen.');}
 return p;
}
export function describe(p){const proc=PROCESSING_PROFILES.find(v=>v.id===p.processing),mat={slate:'Schiefer',wood:'Holz',steel:'Edelstahl',acrylic:'Acrylglas',other:'dem gewählten Material'}[proc?.materialKind]||'dem gewählten Material';return `${p.title}\n\nGestalte dein persönliches Erinnerungsstück aus ${mat}. Wähle eine Vorlage und ergänze dein Foto sowie deine individuellen Texte.\n\nFormat: ${p.width} × ${p.height} mm. Materialstärke: ${p.thickness} mm. ${p.includedPhotos} Foto(s) sind im Grundpreis enthalten.\n\nWähle die passende Befestigung oder das gewünschte Zubehör. Der Lieferumfang richtet sich nach deiner gewählten Ausführung. Für Fotogravuren eignet sich ein scharfes, gut belichtetes Foto mit deutlich erkennbarem Motiv.\n\nBitte prüfe Texte, Schreibweisen und Gestaltung vor der Bestellung.`;}
export class Workbench{
 constructor({root,python,pythonPath,converter,previewPath="/"}={}){if(!root)throw Error('Explizite private Produktablage erforderlich.');this.previewPath=previewPath;this.root=path.resolve(root);fs.mkdirSync(this.root,{recursive:true});this.python=python||process.env.GRAVURU_PDF_PYTHON||'python';this.pythonPath=pythonPath||process.env.GRAVURU_PDF_PYTHONPATH;this.converter=converter||path.join(HERE,'pdf-converter.py');this.pending=new Map();this.library=new ProductLibrary(this.root,defaultProduct().options);}
 dir(id){return path.join(this.root,safe(id));}
 load(id){const file=path.join(this.dir(id),'product.json');if(!fs.existsSync(file))fail('Produkt nicht gefunden.',404);return json(file);}
 list(){return fs.readdirSync(this.root,{withFileTypes:true}).filter(d=>d.isDirectory()&&fs.existsSync(path.join(this.root,d.name,'product.json'))).map(d=>this.summary(this.load(d.name)));}
 summary(p){return {id:p.id,revision:p.revision,title:p.data.title,updatedAt:p.updatedAt,activeRevision:p.activeRevision||null,categoryId:p.data.categoryId||'',materialId:p.data.materialId||'',sku:p.data.sku||'',basePrice:p.data.basePrice,archived:!!p.archived,designCount:p.designs.filter(d=>!d.deleted).length,deletedCount:p.designs.filter(d=>d.deleted).length};}
 save(p,expected){const target=path.join(this.dir(p.id),'product.json');if(fs.existsSync(target)&&this.load(p.id).revision!==expected)fail('Zwischenzeitlich geändert. Neu laden; deine Eingaben wurden nicht überschrieben.',409);p.revision=(expected||0)+1;p.updatedAt=new Date().toISOString();atomic(path.join(this.dir(p.id),'revisions',p.revision+'.json'),p);atomic(target,p);return p;}
 validateData(input,id){const data=validateProduct(input),lib=this.library.load();if(data.categoryId&&!lib.categories.some(c=>c.id===data.categoryId&&!c.deleted))fail('Unterkategorie fehlt.');const material=lib.materials.find(m=>m.id===data.materialId&&!m.deleted);if(!material)fail('Bitte ein Material auswählen.');const processing=PROCESSING_PROFILES.find(p=>p.id===data.processing);if(processing.materialKind&&processing.materialKind!==material.kind)fail('Material und Bearbeitungsverfahren passen nicht zusammen.');if(data.sku&&this.list().some(p=>p.id!==id&&p.sku===data.sku&&!p.archived))fail('Diese Artikelnummer wird bereits verwendet.');return data;}
 create(data){const id='P-'+randomUUID();return this.save({id,data:this.validateData(data),designs:[],createdAt:new Date().toISOString()},0);}
 update(id,body){const p=this.load(id),data=this.validateData(body.data,id);const geometryChanged=['width','height','shape','processing','materialId'].some(k=>p.data[k]!==data[k]);if(geometryChanged)for(const d of p.designs){d.reviewed=false;d.selected=false;}p.data=data;const saved=this.save(p,body.expectedRevision);if(geometryChanged)for(const d of p.designs){const file=path.join(this.dir(id),'aktuelle-designs',safe(d.id)+'.pdf');if(fs.existsSync(file))fs.unlinkSync(file);}return saved;}
 archive(id,b){const p=this.load(id);p.archived=!!b.archived;return this.save(p,b.expectedRevision);}
 diagnostics(p,d,design){const bundle=this.bundle(p.id,d);return checkDesign(clone(design||bundle.design),{...availableFonts(),...bundle.resources.fonts},p.data,bundle.errors||[]);}
 check(id,designId,b){const p=this.load(id),d=p.designs.find(d=>d.id===designId);if(!d)fail('Design fehlt.',404);const design=roundDesign(b.design),problems=this.diagnostics(p,d,design);let svg=null;try{svg=this.svg(id,designId,design);}catch{}return {problems,svg,revision:p.revision};}

 bundle(id,d){const b=json(path.join(this.dir(id),'imports',safe(d.importId),d.page+'.json'));if(d.design)b.design=clone(d.design);if(d.extraMotifs)b.resources.motifs.push(...clone(d.extraMotifs));for(const o of b.design.objects)if(o.type==='text'&&!b.resources.fonts[o.font]&&availableFonts()[o.font])b.resources.fonts[o.font]=availableFonts()[o.font];return b;}
 detail(id){const p=this.load(id);return {...p,designs:p.designs.map(d=>({...d,errors:this.diagnostics(p,d).map(x=>x.message),thumbnail:`/api/product-workbench/${id}/preview/${d.importId}/${d.page}`})),issues:this.issues(p)};}
 svg(id,designId,override=null,{paper=false}={}){const p=this.load(id),record=p.designs.find(d=>d.id===designId);if(!record)fail('Design fehlt.',404);const b=this.bundle(id,record),data=p.data;if(override)b.design=roundDesign(override);for(const o of b.design.objects)if(o.type==='text'&&availableFonts()[o.font])b.resources.fonts[o.font]=availableFonts()[o.font];validateDesignContent(b.design,{universal:true,extraFontIds:[...Object.keys(b.resources.fonts),...b.design.objects.map(o=>o.font).filter(Boolean)]});
   localFontIds({reviewOnly:true,profile:{binding:{kind:'local-review'},features:{orderEnabled:false}},localResources:b.resources});
   const proc=PROCESSING_PROFILES.find(x=>x.id===data.processing),color=paper?'#111111':proc.ink;
   const elements=b.design.objects.filter(o=>!o.uxHidden).map(o=>{const color=proc.method==='print'&&/^#[0-9a-f]{6}$/i.test(o.color||'')?o.color:paper?'#111111':proc.ink;let content='';if(o.type==='text')content=textPaths(o,b.resources.fonts);else if(o.type==='photoSlot')content=`<rect x="${-o.w/2}" y="${-o.h/2}" width="${o.w}" height="${o.h}" fill="none" stroke="${color}" stroke-width=".4" stroke-dasharray="2 1"/><text font-family="Arial" font-size="4" text-anchor="middle">Dein Foto</text>`;else if(o.type==='graphic'){const stroke=o.strokeWidth||.5,w=Math.max(0,o.w-stroke),h=Math.max(0,o.h-stroke),attrs=`fill="${o.filled?color:'none'}" stroke="${color}" stroke-width="${stroke}"`;content=o.shape==='line'?`<path d="M${-w/2} 0H${w/2}" ${attrs}/>`:o.shape==='ellipse'?`<ellipse rx="${w/2}" ry="${h/2}" ${attrs}/>`:`<rect x="${-w/2}" y="${-h/2}" width="${w}" height="${h}" ${attrs}/>`;}else if(o.type==='motif'){const m=b.resources.motifs.find(m=>m.key===o.motif);if(m)content=`<g transform="translate(${-o.w/2} ${-o.h/2}) scale(${o.w/m.bounds[2]} ${o.h/m.bounds[3]}) translate(${-m.bounds[0]} ${-m.bounds[1]})">${m.svgFragment}</g>`;}
   return `<g fill="${color}" color="${color}" transform="translate(${o.x} ${o.y}) rotate(${o.rotation})">${content}</g>`;}).join('');
   const surface=paper?'':this.library.surface(data.materialId),plate=data.shape==='ellipse'?`<ellipse cx="${data.width/2}" cy="${data.height/2}" rx="${data.width/2}" ry="${data.height/2}"`:`<rect width="${data.width}" height="${data.height}"`;
   return surfacePreview(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${data.width} ${data.height}"><defs></defs>${plate} fill="${paper?'white':MATERIAL_COLORS[proc.materialKind]||'#eee'}"/>${elements}</svg>`,surface,data);
 }
 issues(p){const a=[];if(p.data.basePrice===null)a.push('Grundpreis fehlt.');if(!p.data.description.trim())a.push('Artikelbeschreibung noch leer.');if(!VERSIONS.find(v=>v.id===p.data.configurator)?.available)a.push('Für die gewählte Konfiguratorversion fehlt der Importadapter. Variante M ist verfügbar.');if(!p.designs.some(d=>!d.deleted&&d.selected))a.push('Noch kein Design ausgewählt.');return a;}
 async locked(id,fn){if(this.pending.has(id))fail('Import läuft bereits. Bitte kurz warten.',409);const job=fn();this.pending.set(id,job);try{return await job;}finally{this.pending.delete(id);}}
 async upload(id,body){return this.locked(id,async()=>{
   let p=this.load(id);if(p.revision!==body.expectedRevision)fail('Produktstand geändert. Bitte neu laden.',409);
   const name=String(body.name||'');if(path.basename(name)!==name||!/^.{1,160}\.pdf$/i.test(name))fail('Bitte eine PDF-Datei wählen.');
   const bytes=Buffer.from(body.base64||'','base64');if(bytes.length<5||bytes.length>30*1024*1024||!bytes.subarray(0,1024).includes(Buffer.from('%PDF-')))fail('Ungültige PDF oder größer als 30 MB.');
   const workingMatch=p.designs.find(d=>this.workingPdfInfo(id,d.id)?.sha256===hash(bytes));if(workingMatch)return {duplicate:true,product:this.detail(id),message:'Diese Arbeits-PDF entspricht bereits der aktuellen Gestaltung.'};
   const fontDir=path.join(this.root,'fonts'),fontStamp=fs.existsSync(fontDir)?fs.readdirSync(fontDir).filter(n=>/\.(ttf|otf)$/i.test(n)).sort().map(n=>n+fs.statSync(path.join(fontDir,n)).mtimeMs).join('|'):'';
   const sha=hash(bytes),converterVersion=hash(Buffer.concat([fs.readFileSync(this.converter),Buffer.from(fontStamp)])),same=p.designs.filter(d=>d.sha256===sha);
   if(same.length&&same.every(d=>d.converterVersion===converterVersion)&&!same.some(d=>d.errors.length)&&!body.retry)return {duplicate:true,product:this.detail(id),message:'Bereits importiert. Entfernte Designs findest du unter „Entfernt“. '};
   const importId=randomUUID(),dir=path.join(this.dir(id),'imports',importId);fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,name);fs.writeFileSync(file,bytes,{flag:'wx'});
   let report;
   try{const result=await run(this.python,[this.converter,'--pdf',file,'--out',dir,'--fonts',path.join(this.root,'fonts'),'--width',String(p.data.width),'--height',String(p.data.height)],{timeout:180000,maxBuffer:4*1024*1024,windowsHide:true,env:{...process.env,...(this.pythonPath?{PYTHONPATH:this.pythonPath}:{})}});report=JSON.parse(result.stdout);}
   catch(e){atomic(path.join(dir,'error.json'),{source:name,sha256:sha,error:String(e.stderr||e.message).slice(-1500)});fail('PDF konnte nicht eingelesen werden. '+String(e.stderr||e.message).slice(-600));}
   p=this.load(id);if(p.revision!==body.expectedRevision)fail('Produkt wurde während des Imports geändert. Original erhalten; Upload nach Neuladen wiederholen.',409);
   for(const row of report.pages){const imported=json(path.join(dir,row.page+'.json'));if(imported.editablePdf){const ids=localFontIds({reviewOnly:true,profile:{binding:{kind:'local-review'},features:{orderEnabled:false}},localResources:imported.resources});validateDesignContent(imported.design,{universal:true,extraFontIds:ids});if(imported.design.id!==row.id)fail('Arbeits-PDF-Kennung stimmt nicht überein.');for(const o of imported.design.objects)if(o.type==='text')measureText(o,imported.resources.fonts);}const prior=p.designs.find(d=>d.id===row.id);const next={...row,source:name,sha256:sha,converterVersion,importId,selected:false,reviewed:false,deleted:false,importedAt:new Date().toISOString()};
     if(prior){if(prior.source!==name&&!imported.editablePdf)fail('Diese Designkennung gehört bereits zu einer anderen Datei. Bitte Dateinamen eindeutig vergeben.');next.previous={importId:prior.importId,page:prior.page,sha256:prior.sha256,design:prior.design||null};next.issues.unshift('Neue Fassung vorhanden. Vor Übernahme mit der bisherigen Fassung vergleichen.');p.designs[p.designs.indexOf(prior)]=next;}else p.designs.push(next);}
   if(p.designs.filter(d=>!d.deleted).length>60)fail('Höchstens 60 aktive Designs je Produkt. Vorher nicht benötigte Designs entfernen.');
   this.save(p,body.expectedRevision);return {duplicate:false,product:this.detail(id)};
 });}
 uploadFont(body){const name=String(body.name||'');if(path.basename(name)!==name||!/^.{1,120}\.(ttf|otf)$/i.test(name))fail('Bitte TTF oder OTF wählen.');const bytes=Buffer.from(body.base64||'','base64');if(bytes.length<100||bytes.length>15*1024*1024||!(bytes.subarray(0,4).equals(Buffer.from([0,1,0,0]))||bytes.subarray(0,4).toString()==='OTTO'))fail('Ungültige Schriftdatei.');const dir=path.join(this.root,'fonts');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,hash(bytes)+'-'+name),bytes);return {ok:true};}
 changeDesign(id,designId,b){const p=this.load(id),d=p.designs.find(d=>d.id===designId);if(!d)fail('Design fehlt.',404);
   if(b.action==='delete'){d.deleted=true;d.selected=false;d.reviewed=false;}
   else if(b.action==='restore'){d.deleted=false;d.reviewed=false;}
   else if(b.action==='select'){d.selected=!!b.selected;}
   else if(b.action==='review'){if(this.diagnostics(p,d).length)fail('Importfehler zuerst beheben.');d.reviewed=!!b.reviewed;d.selected=d.reviewed;}
   else if(b.action==='rollback'){if(!d.previous)fail('Keine vorherige Fassung.');const old=this.bundle(id,{...d,...d.previous});const prev=d.previous;d.previous={importId:d.importId,page:d.page,sha256:d.sha256,design:d.design||null};Object.assign(d,prev,{design:old.design,issues:old.issues,errors:old.errors,reviewed:false,selected:false});}
   else if(b.action==='edit'){
     const bundle=this.bundle(id,d),design=roundDesign(b.design);if(design.id!==d.id)fail('Designkennung darf nicht verändert werden.');
     if(design.objects.some(o=>o.uxUploadId))fail('Testfotos zuerst entfernen. Vorlagen speichern Fotofelder; Kundenfotos bleiben separat.');const fonts={...availableFonts(),...bundle.resources.fonts};validateDesignContent(design,{universal:true,extraFontIds:Object.keys(fonts)});
     for(const o of design.objects)if(o.type==='text')measureText(o,fonts);
     if(b.resolvedMotifs){localFontIds({reviewOnly:true,profile:{binding:{kind:'local-review'},features:{orderEnabled:false}},localResources:{scope:'local-review-only',fonts:{},motifs:b.resolvedMotifs}});d.extraMotifs=[...(d.extraMotifs||[]),...b.resolvedMotifs];}d.design=design;d.objects=design.objects.length;d.fonts=[...new Set(design.objects.filter(o=>o.type==='text').map(o=>o.font))];d.errors=this.diagnostics(p,d,design).map(x=>x.message);d.reviewed=false;d.selected=false;
   }else fail('Unbekannte Designaktion.');
   this.save(p,b.expectedRevision);return this.detail(id);
 }
 workingPdfInfo(id,designId){
   const p=this.load(id),record=p.designs.find(d=>d.id===designId);if(!record||record.deleted)return null;
   const file=path.join(this.dir(id),'aktuelle-designs',safe(designId)+'.pdf'),manifest=path.join(this.dir(id),'pdf-verlauf',safe(designId),'aktuell.json');
   if(!fs.existsSync(file)||!fs.existsSync(manifest))return null;const state=json(manifest);
   if(state.geometryHash!==hash(Buffer.from(JSON.stringify([p.data.width,p.data.height,p.data.processing]))))return null;
   if(state.designHash!==hash(Buffer.from(JSON.stringify(this.bundle(id,record).design))))return null;
   return {path:file,revision:state.revision,sha256:state.sha256};
 }
 async writeWorkingPdf(id,designId){
   const p=this.load(id),record=p.designs.find(d=>d.id===designId);if(!record)fail('Design fehlt.',404);
   const dir=path.join(this.dir(id),'aktuelle-designs'),target=path.join(dir,safe(designId)+'.pdf');fs.mkdirSync(dir,{recursive:true});
   if(record.deleted){for(const f of [target,path.join(this.dir(id),'pdf-verlauf',safe(designId),'aktuell.json')])if(fs.existsSync(f))fs.unlinkSync(f);return null;}
   const bundle=this.bundle(id,record);bundle.geometry={width:p.data.width,height:p.data.height};bundle.processing=p.data.processing;
   for(const o of bundle.design.objects){if(o.uxUploadId)fail('Testfotos zuerst entfernen. Die Arbeits-PDF speichert Fotofelder.');if(o.type==='text'){measureText(o,{...availableFonts(),...bundle.resources.fonts});}}
   const usedFonts=new Set(bundle.design.objects.filter(o=>o.type==='text').map(o=>o.font));bundle.resources.fonts=Object.fromEntries([...usedFonts].map(f=>[f,bundle.resources.fonts[f]||availableFonts()[f]]));
   localFontIds({reviewOnly:true,profile:{binding:{kind:'local-review'},features:{orderEnabled:false}},localResources:bundle.resources});
   const history=path.join(this.dir(id),'pdf-verlauf',safe(designId));fs.mkdirSync(history,{recursive:true});const base=path.join(history,String(p.revision)),source=base+'.json',pdf=base+'.pdf';atomic(source,bundle);
   await run(this.python,[path.join(HERE,'working-pdf.py'),'--bundle',source,'--out',pdf],{timeout:60000,maxBuffer:1024*1024,windowsHide:true,env:{...process.env,...(this.pythonPath?{PYTHONPATH:this.pythonPath}:{})}});
   if(this.load(id).revision!==p.revision)fail('Produkt während PDF-Erstellung geändert. Aktuelle PDF bitte erneut speichern.',409);
   const temp=target+'.tmp';fs.copyFileSync(pdf,temp);fs.renameSync(temp,target);
   atomic(path.join(history,'aktuell.json'),{geometryHash:hash(Buffer.from(JSON.stringify([p.data.width,p.data.height,p.data.processing]))),revision:p.revision,sha256:hash(fs.readFileSync(target)),designHash:hash(Buffer.from(JSON.stringify(this.bundle(id,record).design)))});
   return this.workingPdfInfo(id,designId);
 }
 async changeWithPdf(id,designId,body){return this.locked(id,async()=>{
   const safeBody={...body};delete safeBody.resolvedMotifs;
   if(body.action==='edit'){
    const p=this.load(id);if(p.revision!==body.expectedRevision)fail('Produktstand geändert.',409);const record=p.designs.find(d=>d.id===designId);if(!record)fail('Design fehlt.',404);
    const existing=this.bundle(id,record).resources.motifs,missing=[...new Set(body.design.objects.filter(o=>o.type==='motif'&&!existing.some(m=>m.key===o.motif)).map(o=>o.motif))];
    if(missing.length){
     const source=fs.readFileSync(path.join(ROOT,'references/aosu-upgrade-2026-09-21/verification/editor-source.html'),'utf8');
     const urls=JSON.parse(source.match(/<script[^>]*id="preview-urls"[^>]*>([\s\S]*?)<\/script>/)[1]);
     const catalog=JSON.parse(gunzipSync(Buffer.from(urls.parts.map(u=>fs.readFileSync(path.join(ROOT,'designs/aosu-labrador/runtime',u.split('/').pop()),'utf8')).join(''),'base64')));
     const items=missing.map(key=>{const m=catalog.find(m=>m.key===key);if(!m)fail('Motiv fehlt in der gespeicherten Bibliothek: '+key);return m;});
     const cache=path.join(this.dir(id),'motif-resources');fs.mkdirSync(cache,{recursive:true});const input=path.join(cache,randomUUID()+'.json'),output=input+'.paths.json';atomic(input,items);
     await run(this.python,[path.join(HERE,'native-motifs.py'),input,output],{timeout:30000,maxBuffer:1024*1024,windowsHide:true,env:{...process.env,...(this.pythonPath?{PYTHONPATH:this.pythonPath}:{})}});safeBody.resolvedMotifs=json(output);
    }
   }
   const result=this.changeDesign(id,designId,safeBody);
   if(['edit','rollback','restore','delete'].includes(body.action))try{await this.writeWorkingPdf(id,designId);}catch(e){console.error('Arbeits-PDF:',String(e.stderr||e.message).slice(-1500));result.workingPdfError='PDF-Erstellung fehlgeschlagen. Die Gestaltung ist gespeichert; bitte erneut speichern oder die Meldung prüfen lassen.';}
   return result;
 });}
 compile(id,{designId,active=false,strict=false,designOverride=null}={}){
   let p=this.load(id);if(active){if(!p.activeRevision)fail('Noch keine Fassung übernommen.');p=json(path.join(this.dir(id),'revisions',p.activeRevision+'.json'));}
   if(!VERSIONS.find(v=>v.id===p.data.configurator)?.available)fail('Diese Konfiguratorversion hat noch keinen PDF-Importadapter. Bitte Variante M wählen.');
   const records=p.designs.filter(d=>!d.deleted&&(designId?d.id===designId:d.selected));if(!records.length)fail('Bitte mindestens ein Design auswählen.');
   const job=json(path.join(HERE,'jobs/hunde-gedenktafeln.json')),profile=profileForProduct(job,job.products[0].productId,job.products[0].handle);
   const data=p.data,processing=PROCESSING_PROFILES.find(v=>v.id===data.processing);
   profile.id=p.id;profile.name=data.title;profile.revision=String(p.revision);profile.binding={kind:'local-review',productId:p.id};
   profile.geometry={width:data.width,height:data.height,shape:data.shape,cornerRadiusMm:0,safeMarginMm:0,holes:[]};
   const selectedMaterial=this.library.load().materials.find(m=>m.id===data.materialId),materialKind=selectedMaterial?.kind||processing.materialKind||'other';
   profile.material=active&&p.materialSnapshot?clone(p.materialSnapshot):{kind:materialKind,color:MATERIAL_COLORS[materialKind]||'#343b3d',thicknessMm:data.thickness};profile.processing={profileId:data.processing};
   profile.features={...profile.features,orderEnabled:false,productionConfirmed:false};profile.optionGroups=optionGroups(data);profile.designs=[];
   const resources={scope:'local-review-only',fonts:{},motifs:[]};
   for(const record of records){const edited=designOverride&&record.id===designId?roundDesign(designOverride):null;if(edited&&edited.id!==record.id)fail('Designkennung darf nicht verändert werden.');const problems=this.diagnostics(p,record,edited);if(problems.length)fail(record.id+': '+problems.map(x=>x.message).join(' '));if(strict&&!record.reviewed)fail(record.id+': Prüfung noch nicht bestätigt.');const bundle=this.bundle(id,record);if(edited){bundle.design=edited;for(const o of edited.objects)if(o.type==='text'&&availableFonts()[o.font])bundle.resources.fonts[o.font]=availableFonts()[o.font];}profile.designs.push(bundle.design);Object.assign(resources.fonts,bundle.resources.fonts);resources.motifs.push(...bundle.resources.motifs);}
   const config={profile,materialSurface:active?(p.materialSurfaceSnapshot||''):this.library.surfaceUrl(data.materialId),reviewOnly:true,basePriceCents:cents(data.basePrice,{optional:true}),extraMotifCents:data.basePrice===null?null:cents(data.extraMotifPrice),photo:{enabled:true,mode:'upload-only',includedCount:data.includedPhotos,extraPriceCents:cents(data.extraPhotoPrice)},localResources:resources,workbench:{productId:id,revision:p.revision}};
   return prepareConfig(config);
 }
 activate(id,b){const p=this.load(id);if(p.revision!==b.expectedRevision)fail('Stand geändert.',409);if(p.data.basePrice===null)fail('Grundpreis zuerst eintragen.');const config=this.compile(id,{strict:true});
   if(b.confirm!==true)fail('Übernahme bitte ausdrücklich bestätigen.');
   const issues=[];for(const d of config.profile.designs)for(const group of config.profile.optionGroups)for(const v of group.values)for(const o of d.objects){const issue=objectIssue(o,{...config.profile,geometry:{...config.profile.geometry,holes:v.holes}});if(issue)issues.push({design:d.id,option:v.label,element:o.id,message:issue});}
   p.materialSnapshot=clone(config.profile.material);p.materialSurfaceSnapshot=config.materialSurface;p.activeRevision=p.revision+1;p.lastCheck={issues,checkedAt:new Date().toISOString()};this.save(p,b.expectedRevision);return this.detail(id);
 }
 csv(id){const p=this.load(id);if(p.data.basePrice===null)fail('Grundpreis fehlt.');const config=this.compile(id,{strict:true});const d=p.data,quote=s=>'"'+String(s??'').replaceAll('"','""')+'"',handle=d.handle||'gravuru-'+id.toLowerCase();
   const rows=[['Handle','Title','Body (HTML)','Vendor','Type','Tags','Published','Option1 Name','Option1 Value','Variant SKU','Variant Price','Variant Grams','Variant Requires Shipping','Variant Taxable','Status','SEO Title','SEO Description','Image Alt Text']];
   config.profile.optionGroups[0].values.forEach((v,i)=>rows.push([handle,i?'':d.title,i?'':'<p>'+escapeXml(d.description||describe(d)).replaceAll('\n','<br>')+'</p>',i?'':'gravuru GmbH',i?'':'Personalisiertes Schild',i?'':d.tags,'FALSE','Befestigung',v.label,(d.sku||id)+'-'+v.id,((cents(d.basePrice)+v.priceCents)/100).toFixed(2),d.weight??'','TRUE','TRUE','draft',i?'':d.seoTitle,i?'':d.seoDescription,i?'':d.imageAlt]));
   return '\ufeff'+rows.map(r=>r.map(quote).join(',')).join('\r\n');
 }
 package(id){const p=this.load(id),config=this.compile(id,{strict:true});if(p.data.basePrice===null)fail('Grundpreis fehlt.');return {schema:'gravuru-product-package/v1',product:clone(p),config,shopify:{status:'DRAFT',handle:p.data.handle||'gravuru-'+id.toLowerCase(),title:p.data.title,description:p.data.description||describe(p.data),category:this.library.load().categories.find(c=>c.id===p.data.categoryId)||null,collectionIds:this.library.load().categories.filter(c=>c.id===p.data.categoryId&&c.collectionId).map(c=>c.collectionId)},images:p.designs.filter(d=>d.selected&&!d.deleted).map((d,i)=>({designId:d.id,filename:slug(p.data.imageName||p.data.keyword||p.data.title)+'-'+slug(d.id)+'.png',alt:p.data.imageAlt||p.data.title+' – '+d.id,sourceType:'original-pdf-preview',productionImage:false})),checks:{customerRuntime:false,checkout:false,production:false}};}
 async shopify(id,b){return this.locked(id,async()=>{const p=this.load(id);if(p.revision!==b.expectedRevision)fail('Produktstand geändert.',409);if(!b.confirm)fail('Übertragung bitte bestätigen.');const file=path.join(this.dir(id),'shopify-journal.json'),previous=fs.existsSync(file)?json(file):null;return transferDraft(this.package(id),{token:process.env.GRAVURU_SHOPIFY_ADMIN_TOKEN,previous,journal:record=>atomic(file,{...record,checkedAt:new Date().toISOString()})});});}
}

export async function workbenchRoute(workbench,req,res,url,{body,send}={}){
 const prefix='/api/product-workbench';if(!url.pathname.startsWith(prefix))return false;
 const parts=url.pathname.slice(prefix.length).split('/').filter(Boolean).map(decodeURIComponent),[id,action,arg,page]=parts;
 if(req.method==='GET'){
   if(!id){send({previewPath:workbench.previewPath,products:workbench.list(),defaults:defaultProduct(),versions:VERSIONS,fonts:Object.keys(availableFonts()),processing:PROCESSING_PROFILES.map(p=>({id:p.id,name:p.name})),shopifyConnected:!!process.env.GRAVURU_SHOPIFY_ADMIN_TOKEN});return true;}
   if(id==='library'){send(workbench.library.load());return true;}
   if(id==='catalog'){send(workbench.library.catalog());return true;}
   if(id==='assets'){const file=workbench.library.asset(action),bytes=fs.readFileSync(file);res.writeHead(200,{'Content-Type':file.endsWith('.jpg')?'image/jpeg':file.endsWith('.webp')?'image/webp':'image/png','Cache-Control':'private, max-age=3600','X-Content-Type-Options':'nosniff'}).end(bytes);return true;}
   if(id==='fonts'){send({ok:true});return true;}
   if(action==='preview'){safe(arg);if(!/^[1-9]\d?$/.test(page||''))fail('Seite fehlt.');const bytes=fs.readFileSync(path.join(workbench.dir(id),'imports',arg,page+'.png'));res.writeHead(200,{'Content-Type':'image/png','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(bytes);return true;}
   if(action==='design'){const p=workbench.load(id),d=p.designs.find(d=>d.id===arg);if(!d)fail('Design fehlt.',404);send({...workbench.bundle(id,d),workingPdf:workbench.workingPdfInfo(id,arg),problems:workbench.diagnostics(p,d)});return true;}
   if(action==='history'){const dir=path.join(workbench.dir(id),'revisions');send(fs.readdirSync(dir).filter(f=>/^\d+\.json$/.test(f)).sort((a,b)=>parseInt(b)-parseInt(a)).slice(0,30).map(f=>workbench.summary(json(path.join(dir,f)))));return true;}
   if(action==='image'){const p=workbench.load(id),d=p.designs.find(d=>d.id===arg);if(!d)fail('Design fehlt.',404);const filename=slug(p.data.imageName||p.data.keyword||p.data.title)+'-'+slug(d.id)+'.png';res.writeHead(200,{'Content-Type':'image/png','Content-Disposition':'attachment; filename="'+filename+'"','Cache-Control':'no-store'}).end(fs.readFileSync(path.join(workbench.dir(id),'imports',safe(d.importId),d.page+'.png')));return true;}
   if(action==='working-pdf'){const info=workbench.workingPdfInfo(id,arg);if(!info)fail('Noch keine aktuelle Arbeits-PDF. Korrekturen zuerst speichern.',404);res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="'+safe(arg)+'.pdf"','Cache-Control':'no-store'}).end(fs.readFileSync(info.path));return true;}
   if(action==='render'){const svg=workbench.svg(id,arg);res.writeHead(200,{'Content-Type':'image/svg+xml','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; img-src data:; style-src 'unsafe-inline'",'X-Content-Type-Options':'nosniff'});res.end(svg);return true;}
   if(action==='config'){send(workbench.compile(id,{designId:url.searchParams.get('design')||undefined,active:url.searchParams.get('active')==='1'}));return true;}
   if(action==='export.csv'){const csv=workbench.csv(id);res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="Shopify-'+id+'.csv"'});res.end(csv);return true;}
   if(action==='package.json'){const pack=workbench.package(id);res.writeHead(200,{'Content-Type':'application/json','Content-Disposition':'attachment; filename="Produktpaket-'+id+'.json"'});res.end(JSON.stringify(pack));return true;}
   if(!action){send(workbench.detail(id));return true;}
 }
 if(req.method==='POST'){
   const b=await body(req,45000000);
   if(!id)send(workbench.create(b.data));
   else if(id==='library'){if(action==='mountings'){validateProduct({...defaultProduct(),width:b.value.width||2000,height:b.value.height||2000,options:b.value.options});}send(workbench.library.save(action,b));}
   else if(id==='assets')send(workbench.library.uploadImage(b));
   else if(id==='catalog')send(workbench.library.editCatalog(b));
   else if(id==='fonts')send(workbench.uploadFont(b));
   else if(action==='archive')send(workbench.archive(id,b));
   else if(action==='check')send(workbench.check(id,arg,b));
   else if(action==='editor-config'){const p=workbench.load(id);if(p.revision!==b.expectedRevision)fail('Produktstand geändert. Korrekturen zuerst sichern.',409);send(workbench.compile(id,{designId:arg,designOverride:b.design}));}
   else if(action==='upload')send(await workbench.upload(id,b));
   else if(action==='design')send(await workbench.changeWithPdf(id,arg,b));
   else if(action==='activate')send(workbench.activate(id,b));
   else if(action==='shopify')send(await workbench.shopify(id,b));
   else if(action==='description'){const p=workbench.load(id);send({description:p.data.templateId?workbench.library.template(p.data.templateId,p.data):describe(p.data)});}
   else if(!action)send(workbench.update(id,b));
   else fail('Aktion nicht gefunden.',404);
   return true;
 }
 fail('Nicht verfügbar.',405);
}
