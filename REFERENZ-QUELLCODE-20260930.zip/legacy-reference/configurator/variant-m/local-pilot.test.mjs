import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {makeLocalPilot} from './local-pilot.mjs';
import {prepareConfig,quote,selectedProfile,saveDraft,readDraft} from './contract.mjs';
import {validateDesignContent} from '../../platform/sources/app/shared/models/design-content.mjs';
import {readJson,profileForProduct,REPO} from '../../automation/product-pipeline/lib/core.mjs';

const job=readJson(REPO+'/automation/product-pipeline/jobs/hunde-gedenktafeln.json');
const reference={profile:profileForProduct(job,job.products[0].productId,job.products[0].handle),basePriceCents:job.basePriceCents,extraMotifCents:job.extraMotifCents,photo:{enabled:true,mode:'upload-only'}};
const font={regular:{units:1000,glyphs:Object.fromEntries([...new Set('SnowLunaÄöß†2019 -.*')].map(c=>[c,{a:500,d:c===' '?'':'M0 0L400 0L200 700Z'}]))}};
const bundle=()=>({schema:'gravuru-local-pdf-pilot/v1',revision:'test-v1',source:{sha256:'a'.repeat(64)},geometry:{width:220,height:140},design:{id:'GT-S-22x14-D201',name:'D201',objects:[{id:'D201-name',type:'text',fieldKey:'name',text:'Snow',font:'Pilot Serif',size:10,bold:false,x:150,y:40,w:20,h:12,rotation:0},{id:'D201-photo',type:'photoSlot',fieldKey:'photo-01',photoShape:'rect',required:true,x:70,y:80,w:50,h:70,rotation:0}]},resources:{scope:'local-review-only',fonts:{'Pilot Serif':font},motifs:[]}});

test('local pilot preserves source and option identities, repositions holes by edge offset',()=>{
 const before=JSON.stringify(reference),cfg=prepareConfig(makeLocalPilot(bundle(),reference));
 assert.equal(JSON.stringify(reference),before);assert.equal(cfg.profile.geometry.width,220);assert.equal(cfg.profile.geometry.height,140);
 assert.deepEqual(selectedProfile(cfg,{mounting:'B02'}).geometry.holes,[{x:12,y:70,diameter:5},{x:208,y:70,diameter:5}]);
 assert.deepEqual(selectedProfile(cfg,{mounting:'B04'}).geometry.holes,[{x:12,y:12,diameter:5},{x:208,y:12,diameter:5},{x:208,y:128,diameter:5},{x:12,y:128,diameter:5}]);
 assert.deepEqual(cfg.profile.optionGroups[0].values.map(v=>[v.id,v.priceCents]),reference.profile.optionGroups[0].values.map(v=>[v.id,v.priceCents]));
 assert.ok(!JSON.stringify(cfg.profile.binding).includes('gid://shopify'));assert.equal(cfg.profile.features.orderEnabled,false);
});
test('unknown prices never become a zero-euro quotation',()=>{
 const cfg=prepareConfig(makeLocalPilot(bundle(),reference));assert.equal(cfg.basePriceCents,null);assert.equal(cfg.extraMotifCents,null);
 assert.throws(()=>quote(cfg,cfg.profile.designs[0].objects,'GT-S-22x14-D201'),/Preis noch offen/);
 assert.throws(()=>prepareConfig({...cfg,reviewOnly:false}),/lokalen Prüfprodukt/);
});
test('custom font is explicit and remains rejected by default production validator',()=>{
 const b=bundle();assert.throws(()=>validateDesignContent(b.design,{universal:true}),/Schriftart/);
 assert.doesNotThrow(()=>prepareConfig(makeLocalPilot(b,reference)));
 b.resources.fonts={};assert.throws(()=>makeLocalPilot(b,reference),/Schriftanzahl/);
});
test('active SVG or malformed font paths cannot enter pilot resources',()=>{
 const b=bundle();b.resources.motifs=[{key:'bad',bounds:[0,0,1,1],svgFragment:'<image href="https://example.org/private"/>'}];assert.throws(()=>makeLocalPilot(b,reference),/nicht erlaubte/);
 const c=bundle();c.resources.fonts=structuredClone(c.resources.fonts);c.resources.fonts['Pilot Serif'].regular.glyphs.S.d='<script/>';assert.throws(()=>makeLocalPilot(c,reference),/ungültige Pfade/);
});
test('custom-font text and photo references roundtrip without photo bytes',()=>{
 const cfg=prepareConfig(makeLocalPilot(bundle(),reference)),d=structuredClone(cfg.profile.designs[0]);d.objects[0].text='Luna';d.objects[1].uxUploadId='local-file';d.objects[1].uxUploadKind='photo';
 const draft=saveDraft(cfg,{designId:d.id,objects:d.objects},{},cfg.localResources.fonts,[]);
 const restored=readDraft(cfg,draft,cfg.localResources.fonts,[]);assert.equal(restored.design.objects[0].text,'Luna');assert.equal(restored.design.objects[1].uxUploadId,'local-file');assert.ok(!JSON.stringify(draft).includes('data:'));
});
test('actual external D201 package validates and accepts new German customer text',{skip:!process.env.D201_PILOT},()=>{
 const b=JSON.parse(fs.readFileSync(process.env.D201_PILOT,'utf8')),cfg=prepareConfig(makeLocalPilot(b,reference)),d=structuredClone(cfg.profile.designs[0]);
 assert.equal(d.objects.filter(o=>o.type==='photoSlot').length,1);assert.equal(d.objects.filter(o=>o.type==='text').length,3);assert.equal(d.objects.filter(o=>o.type==='motif').length,1);
 assert.equal((b.resources.motifs[0].svgFragment.match(/<path /g)||[]).length,1);assert.ok(b.resources.motifs[0].svgFragment.includes('fill-rule="evenodd"'));
 const t=d.objects.find(o=>o.fieldKey==='name');t.text='Luna';
 const draft=saveDraft(cfg,{designId:d.id,objects:d.objects},{mounting:'OHNE'},cfg.localResources.fonts,cfg.localResources.motifs);
 assert.equal(readDraft(cfg,draft,cfg.localResources.fonts,cfg.localResources.motifs).design.objects.find(o=>o.fieldKey==='name').text,'Luna');
 assert.throws(()=>saveDraft(cfg,{designId:d.id,objects:d.objects},{mounting:'B04'},cfg.localResources.fonts,cfg.localResources.motifs),/Bohrloch/);
});

