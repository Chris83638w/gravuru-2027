# Gedenktafeln – Übersicht der Bestandsdesigns

650 Designs, vorsortiert nach Zielgruppe und Unterkategorie. Unter jedem Bild: Schlüssel · Sicherheit der Zuordnung · Materialien. Korrekturen in [`GEDENKTAFELN-DESIGNS.xlsx`](GEDENKTAFELN-DESIGNS.xlsx).

Sprungmarken: [Menschen – Allgemein (333)](#menschen-allgemein) · [Menschen – Freund (2)](#menschen-freund) · [Menschen – Kind (12)](#menschen-kind) · [Menschen – Mama (15)](#menschen-mama) · [Menschen – Opa (1)](#menschen-opa) · [Menschen – Papa (1)](#menschen-papa) · [Menschen – Partner (6)](#menschen-partner) · [Sternenkinder – Sternenkind (22)](#sternenkinder-sternenkind) · [Tiere – Allgemein (202)](#tiere-allgemein) · [Tiere – Hund (39)](#tiere-hund) · [Tiere – Katze (11)](#tiere-katze) · [Tiere – Kleintier (3)](#tiere-kleintier) · [Tiere – Pferd (3)](#tiere-pferd)

## Menschen – Allgemein

333 Designs

![Menschen – Allgemein](_uebersicht/Menschen-Allgemein-1.png)

![Menschen – Allgemein](_uebersicht/Menschen-Allgemein-2.png)

![Menschen – Allgemein](_uebersicht/Menschen-Allgemein-3.png)

![Menschen – Allgemein](_uebersicht/Menschen-Allgemein-4.png)

![Menschen – Allgemein](_uebersicht/Menschen-Allgemein-5.png)

![Menschen – Allgemein](_uebersicht/Menschen-Allgemein-6.png)

## Menschen – Freund

2 Designs

![Menschen – Freund](_uebersicht/Menschen-Freund.png)

## Menschen – Kind

12 Designs

![Menschen – Kind](_uebersicht/Menschen-Kind.png)

## Menschen – Mama

15 Designs

![Menschen – Mama](_uebersicht/Menschen-Mama.png)

## Menschen – Opa

1 Designs

![Menschen – Opa](_uebersicht/Menschen-Opa.png)

## Menschen – Papa

1 Designs

![Menschen – Papa](_uebersicht/Menschen-Papa.png)

## Menschen – Partner

6 Designs

![Menschen – Partner](_uebersicht/Menschen-Partner.png)

## Sternenkinder – Sternenkind

22 Designs

![Sternenkinder – Sternenkind](_uebersicht/Sternenkinder-Sternenkind.png)

## Tiere – Allgemein

202 Designs

![Tiere – Allgemein](_uebersicht/Tiere-Allgemein-1.png)

![Tiere – Allgemein](_uebersicht/Tiere-Allgemein-2.png)

![Tiere – Allgemein](_uebersicht/Tiere-Allgemein-3.png)

![Tiere – Allgemein](_uebersicht/Tiere-Allgemein-4.png)

## Tiere – Hund

39 Designs

![Tiere – Hund](_uebersicht/Tiere-Hund.png)

## Tiere – Katze

11 Designs

![Tiere – Katze](_uebersicht/Tiere-Katze.png)

## Tiere – Kleintier

3 Designs

![Tiere – Kleintier](_uebersicht/Tiere-Kleintier.png)

## Tiere – Pferd

3 Designs

![Tiere – Pferd](_uebersicht/Tiere-Pferd.png)

