// Bridge for models with Shopify MCP but without a local Admin API token.
// Input snapshot comes exclusively from the read-only operations in lib/shopify.mjs.
import path from 'node:path';
import {REPO,readJson,writeJson,validateJob,profileForProduct,configurationFields,hash} from './lib/core.mjs';
import {plan,listingInput,OPS} from './lib/shopify.mjs';
const [jobFile,snapshotFile,outFile]=process.argv.slice(2);
const job=readJson(jobFile),snapshot=readJson(snapshotFile);
const report=validateJob(job);if(!report.ok)throw Error(report.errors.map(e=>e.message).join('\n'));
const api=async(op,variables)=>{
 if(op==='shop')return snapshot.context;
 if(op==='product'){const handle=variables.query.slice(7),p=snapshot.products.find(p=>p.handle===handle);return {products:{nodes:p?[p]:[],pageInfo:{hasNextPage:false}}};}
 if(op==='metaobject'){
   if(!Object.hasOwn(snapshot.profiles,variables.handle.handle))throw Error('Vorlagenabfrage fehlt: '+variables.handle.handle);
   return {metaobjectByHandle:snapshot.profiles[variables.handle.handle]};
 }
 if(op==='bindings'){
   if(!snapshot.bindingsComplete||!Array.isArray(snapshot.bindings))throw Error('Vollständige Profilzuordnungsliste fehlt. bindings mit Pagination einlesen.');
   return {metaobjects:{nodes:snapshot.bindings,pageInfo:{hasNextPage:false}}};
 }
 throw Error('Snapshot erlaubt ausschließlich Lesen.');
};
const prepared=await plan(job,api),actions=[];
for(const p of job.products){
 const live=snapshot.products.find(x=>x.handle===p.handle);
 if(!live){actions.push({key:p.key+':create',query:OPS.create,variables:{product:{...listingInput(p),status:'DRAFT'}},after:'Produkt erneut lesen, ID und SKU-Zuordnung vervollständigen, Plan neu erstellen.'});continue;}
 const base=live.variants.nodes[0];
 actions.push({key:p.key+':listing',query:OPS.update,variables:{product:{id:live.id,...listingInput(p),tags:[...new Set([...live.tags,...p.tags])]}},precondition:{productId:live.id,updatedAt:live.updatedAt}});
 actions.push({key:p.key+':price',query:OPS.variant,variables:{productId:live.id,variants:[{id:base.id,price:(job.basePriceCents/100).toFixed(2),taxable:true,inventoryItem:{sku:p.sku,measurement:{weight:{value:job.weightG,unit:'GRAMS'}}}}]}});
 const files=[];
 for(const image of p.images){
   const filename=path.basename(image.path).replace(/\.[^.]+$/,'');
   const matches=live.media.nodes.filter(m=>m.image?.url&&path.posix.basename(new URL(m.image.url).pathname).replace(/\.[^.]+$/,'')===filename);
   if(matches.length!==1||matches[0].status!=='READY')throw Error('Bildzuordnung für Connector ungeklärt: '+image.path+'. Mit stagedUploadsCreate übertragen, danach neu einlesen.');
   if(matches[0].alt!==image.alt)files.push({id:matches[0].id,alt:image.alt});
 }
 if(files.length)actions.push({key:p.key+':alt',query:OPS.alt,variables:{files}});
 const profile=profileForProduct(job,live.id,p.handle);
 actions.push({key:p.key+':workshop',query:OPS.profile,variables:{handle:{type:'gravuru_configurator',handle:profile.id},metaobject:{fields:configurationFields(profile,job.formCode)}},precondition:{profileUpdatedAt:prepared.items.find(x=>x.key===p.key).profileUpdatedAt}});
}
writeJson(outFile,{...prepared,sourceSnapshotSha256:hash(JSON.stringify(snapshot)),actions,after:'Produkt und Metaobjekt erneut abfragen. Listing, Collection, Preis, Gewicht, Alt-Texte und Konfiguration prüfen. Keine Runtime-Freigabe daraus ableiten.'});
console.log(`${actions.length} geprüfte Aktionen vorbereitet. Nichts übertragen.`);
