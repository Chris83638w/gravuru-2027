# Gravuru-Katalog

Erzeugt aus den Familien-Stammdaten (`familien/`). Nicht von Hand bearbeiten – Änderungen in den JSON-Dateien oder über die Stammdaten-Excel, dann `python scripts/build-katalog.py` (Repo gravuru-2027).

## Abgeglichener Werkstattstand

Produktlinie → Unterkategorie → Hauptprodukt → Ausführungen. Maßgeblich für die Werkstatt ist [struktur.json](struktur.json). Die nachfolgenden älteren Familien bleiben als eigene Quellen erhalten.

| Serie | Ausführungen | Formen / Größen | Designs |
| --- | --- | --- | --- |
| [Acryl-Türschilder · 3 mm](serien/acryl-tuerschilder-2027.json) | 798 | 79 | 40 |
| [Edelstahl · Türschilder und Familienschilder](serien/edelstahl-tuerschilder-2027.json) | 399 | 79 | 40 |

### Zugeordnete Hauptprodukte

| Linie | Produkt | Shopify-ID | Varianten | Stand |
| --- | --- | --- | --- | --- |
| gedenktafeln-22x14-tiere | [Gedenktafel Hund Naturschiefer mit Foto und Knochenherz 22×14 cm](https://admin.shopify.com/store/gravuru-design/products/16168645525884) | 16168645525884 | 9 | parallelbestand · DRAFT |
| gedenktafeln-22x14-tiere | [Gedenktafel Hund Naturschiefer mit Foto und Rosen 22×14 cm](https://admin.shopify.com/store/gravuru-design/products/16168659321212) | 16168659321212 | 9 | parallelbestand · DRAFT |
| gedenktafeln-22x14-tiere | [Gedenktafel Hund Naturschiefer mit Foto und Blüten 22×14 cm](https://admin.shopify.com/store/gravuru-design/products/16168667775356) | 16168667775356 | 9 | parallelbestand · DRAFT |
| gedenktafeln-22x14-tiere | [Gedenktafel Hund Naturschiefer mit Foto und Sternschnuppe 22×14 cm](https://admin.shopify.com/store/gravuru-design/products/16168669512060) | 16168669512060 | 9 | parallelbestand · DRAFT |
| gedenktafeln-22x14-tiere | [Gedenktafel Katze Naturschiefer mit Foto und Pfotenherz 22×14 cm](https://admin.shopify.com/store/gravuru-design/products/16168671183228) | 16168671183228 | 9 | parallelbestand · DRAFT |
| gedenktafeln-22x14-tiere | [Gedenktafel Katze Naturschiefer mit Foto und Blätterzweig 22×14 cm](https://admin.shopify.com/store/gravuru-design/products/16168672756092) | 16168672756092 | 9 | parallelbestand · DRAFT |
| gedenktafeln-22x14-tiere | [Hunde-Gedenktafel aus Schiefer mit Foto und Knochenherz – 22 × 14 cm](https://admin.shopify.com/store/gravuru-design/products/16168868348284) | 16168868348284 | 48 | hauptprodukt · DRAFT |
| gedenktafeln-22x14-tiere | [Gedenktafel für Hunde aus Schiefer mit Foto und Rosen – 22 × 14 cm](https://admin.shopify.com/store/gravuru-design/products/16168869429628) | 16168869429628 | 48 | hauptprodukt · DRAFT |
| gedenktafeln-22x14-tiere | [Hunde-Gedenktafel aus Schiefer mit Foto und Blüten – 22 × 14 cm](https://admin.shopify.com/store/gravuru-design/products/16168869659004) | 16168869659004 | 48 | hauptprodukt · DRAFT |
| gedenktafeln-22x14-tiere | [Gedenktafel für Hunde mit Foto und Sternschnuppe – Schiefer 22 × 14 cm](https://admin.shopify.com/store/gravuru-design/products/16168869724540) | 16168869724540 | 48 | hauptprodukt · DRAFT |
| gedenktafeln-22x14-tiere | [Hunde-Gedenktafel aus Schiefer mit Foto und Regenbogen – 22 × 14 cm](https://admin.shopify.com/store/gravuru-design/products/16168869888380) | 16168869888380 | 48 | archiviert · ARCHIVED |
| acryl-tuerschilder | [Acryl-Türschild selbst gestalten – Schwarz & Anthrazit](https://admin.shopify.com/store/gravuru-design/products/16175627665788) | 16175627665788 | 798 | hauptprodukt · DRAFT |

### Abgleich und offene Punkte

- **Acrylserie übernommen:** 798 Ausführungen, 79 Form-/Größenkombinationen, 40 Designs und 399 preisgleiche Farbpaare. Konturen und Produktkennungen erhalten.
- **Neue Edelstahlserie erfasst:** 399 lokale Ausführungen, 79 Form-/Größenkombinationen, 40 Designs. Ältere Familie und vorhandene Shopprodukte bleiben separat.
- **Vier Hunde-Hauptprodukte zugeordnet:** Je 48 Varianten, 16 Designs. Neue Hundefamilie enthält Ø4/Ø8-Bohrungen und 19 mm Randabstand; ältere Tierfamilie bleibt erhalten.
- **Sechs ältere Gedenktafel-Entwürfe:** Vier Hunde- und zwei Katzenprodukte mit je neun Varianten sind Parallelbestand. Keine automatische Übernahme oder Veröffentlichung.
- **Türklingeln zurückgestellt:** Historische Linie bleibt erhalten; Funkklingelschilder sind ausgeschlossen.
- **Kundenanbindung mit neuem Konfigurator:** Warenkorb, Bestell- und Fertigungszuordnung werden gesondert mit dem neuen Konfigurator angebunden.

Kundenanbindung und Veröffentlichung sind zurückgestellt. Geplante Anzahlen und Zuordnungen werden in der Mitarbeiter-Werkstatt gespeichert; sie erzeugen keine Shopify-Artikel.

## Produktlinien und Unterkategorien

Linie = was physisch verkauft wird (Familien); Unterkategorie = Thema/Zielgruppe innerhalb der Linie (Name im Shop „Linie – Unterkategorie“). Je Unterkategorie: Schrift-Set, Design-Themen und Motivkategorien aus [themen.json](themen.json), eigene Preise nur wo abweichend (`priceOverrides`). Status „Vorschlag“ = vom Nutzer noch zu bestätigen.

### Acrylglas Schilder mit Abstandshaltern (AA / AS / S/S)

Familien: [Acrylglas anthrazit 5 mm · Abstandshalter (AA)](#acryl-aa-abstandshalter), [Acrylglas schwarz 5 mm · Abstandshalter (AS)](#acryl-as-abstandshalter), [Acrylglas schwarz satiniert 3 mm + Rückplatte schwarz (S/S)](#acryl-ss-abstandshalter) · Stand: Familien da, Preise offen

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Hausnummern | `hausnummern` | `hausnummern` | Haus, Linien mit Verzierungen | wie Familie | offen |
| Namensschilder | `namensschilder` | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | wie Familie | offen |
| Familienschilder | `familienschilder` | `tuerschilder` | Figuren, Herzen, Haus, Bäume | wie Familie | offen |
| Firmen- und Praxisschilder | `firmenschilder` | `firmenschilder` | Berufe & Gewerbe, Hinweise - Piktogramme, Social Media | wie Familie | offen |
| Willkommensschilder | `willkommensschilder` | `tuerschilder` | Blumen, Schmetterlinge, Ornamente, Herzen | wie Familie | offen |
| Hundeschilder | `hundeschilder` | `hundeschilder` | Hunderassen, Hunde, Pfoten | wie Familie | offen |

### Acrylglas Türschilder 3 mm

Familien: Familie offen · Stand: 798 Werkstattausführungen; 79 Form-/Größenkombinationen; 40 Designs; beide Farben preisgleich; Kundenanbindung ausstehend

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Namensschilder | `namensschilder` | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | wie Familie | offen |
| Familienschilder | `familienschilder` | `tuerschilder` | Figuren, Herzen, Haus, Bäume | wie Familie | offen |
| Hundeschilder | `hundeschilder` | `hundeschilder` | Hunderassen, Hunde, Pfoten | wie Familie | offen |
| Hochzeitsschilder | `hochzeitsschilder` | `andenken` | Hochzeit, Herzen, Infinity, Schleifen | wie Familie | offen |
| Firmen- und Praxisschilder | `firmenschilder` | `firmenschilder` | Berufe & Gewerbe, Hinweise - Piktogramme, Social Media | wie Familie | offen |
| Hinweisschilder | `hinweisschilder` | `firmenschilder` | Hinweise - Piktogramme, Pfeile | wie Familie | offen |

### Alu-Dibond 30 × 20 (Druck)

Familien: Familie offen · Stand: Familie offen (3 mm, eckig, Ø 4, 2/4 Löcher oder Schrauben, selbstklebend glatt/rau, vollflächiger Druck)

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Gedenktafeln | `gedenktafeln` | `andenken` | Kreuze, Engel, Symbole Religion, Kerzen, Bäume, Vögel | wie Familie | offen |
| Hausnummern | `hausnummern` | `hausnummern` | Haus, Linien mit Verzierungen | wie Familie | offen |
| Hundeschilder | `hundeschilder` | `hundeschilder` | Hunderassen, Hunde, Pfoten | wie Familie | offen |
| Geschenkartikel | `geschenkartikel` | `geschenkartikel` | Geburtstag, Jubiläum, Muttertag, Vatertag, Weihnachten, Ostern | wie Familie | offen |
| Wanddeko | `wanddeko` | `geschenkartikel` | Ornamente, Sternzeichen, Urlaub, Musik, Sport | wie Familie | offen |

### Brettchen

Familien: Familie offen · Stand: Familie offen

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Namensschilder | `namensschilder` | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | wie Familie | offen |
| Familienschilder | `familienschilder` | `tuerschilder` | Figuren, Herzen, Haus, Bäume | wie Familie | offen |
| Hochzeitsschilder | `hochzeitsschilder` | `andenken` | Hochzeit, Herzen, Infinity, Schleifen | wie Familie | offen |
| Geschenkartikel | `geschenkartikel` | `geschenkartikel` | Geburtstag, Jubiläum, Muttertag, Vatertag, Weihnachten, Ostern | wie Familie | offen |

### Edelstahl Türschilder

Familien: [Edelstahl-Türschilder](#steel-door-signs) · Stand: Neue Serie: 399 lokale Werkstattausführungen, 79 Form-/Größenkombinationen, 40 Designs. Ältere 61-Größen-Familie unverändert als Bestand. Hauptprodukte je Unterkategorie (mainProducts) seit 22.10.2026, Muster Familienschilder 7x2.

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Namensschilder | `namensschilder` | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | wie Familie | offen |
| Familienschilder | `familienschilder` | `tuerschilder` | Figuren, Herzen, Haus, Bäume | wie Familie | offen |
| Hausnummern | `hausnummern` | `hausnummern` | Haus, Linien mit Verzierungen | wie Familie | offen |
| Hundeschilder | `hundeschilder` | `hundeschilder` | Hunderassen, Hunde, Pfoten | wie Familie | offen |
| Katzenschilder | `katzenschilder` | `hundeschilder` | Katzen, Pfoten | wie Familie | offen |
| Hochzeitsschilder | `hochzeitsschilder` | `andenken` | Hochzeit, Herzen, Infinity, Schleifen | wie Familie | offen |
| Firmen- und Praxisschilder | `firmenschilder` | `firmenschilder` | Berufe & Gewerbe, Hinweise - Piktogramme, Social Media | wie Familie | offen |
| Willkommensschilder | `willkommensschilder` | `tuerschilder` | Blumen, Schmetterlinge, Ornamente, Herzen | wie Familie | offen |
| Hinweisschilder | `hinweisschilder` | `firmenschilder` | Hinweise - Piktogramme, Pfeile | wie Familie | offen |
| Pferdeschilder | `pferdeschilder` | `pferdeschilder` | Pferde, Brandzeichen | wie Familie | offen |

| Hauptprodukt | Unterkategorie | Startdesign | Größen | Externe Kennungen | Status |
| --- | --- | --- | --- | --- | --- |
| Türschild Edelstahl 7 × 2 cm – Familienschild mit Zierlinien (`3100000`) | Familienschilder | `TRE-V2A-7x2-D5` | `GR-ES-RE-70X23P3-T15` | customizationId 3100000, sku TRE-V2A-7x2-D5, shopifyProductId 16077793821052 | Muster 7x2 – Startdesign D5 Familie Schneider (zwei Linien); CustomizationID aus FancyCustomizationIDs.csv (alter Fancy Product Designer, diente dem Taggen – Chris 22.10.2026), Titel von Claude nach Startdesign unterschieden; Shopify aktualisiert 22.10.2026 (bestehendes Produkt, SKU TRE-V2A-7x2-D5) |
| Türschild Edelstahl 7 × 2 cm – Namensschild mit Glocke (`3200000`) | Familienschilder | `TRE-V2A-7x2-D26` | `GR-ES-RE-70X23P3-T15` | customizationId 3200000, sku TRE-V2A-7x2-D26, shopifyProductId 16077793984892 | Muster 7x2 – Startdesign D26 Oliver Zimmermann (Glocke); CustomizationID aus FancyCustomizationIDs.csv (alter Fancy Product Designer, diente dem Taggen – Chris 22.10.2026), Titel von Claude nach Startdesign unterschieden; Shopify aktualisiert 22.10.2026 (bestehendes Produkt, SKU TRE-V2A-7x2-D26) |
| Türschild Edelstahl 7 × 2 cm – Familienschild mit Katze (`3300000`) | Familienschilder | `TRE-V2A-7x2-D35` | `GR-ES-RE-70X23P3-T15` | customizationId 3300000, sku TRE-V2A-7x2-D35, shopifyProductId 16077794148732 | Muster 7x2 – Startdesign D35 Familie Heinemann (Katze, Serifenschrift); CustomizationID aus FancyCustomizationIDs.csv (alter Fancy Product Designer, diente dem Taggen – Chris 22.10.2026), Titel von Claude nach Startdesign unterschieden; Shopify aktualisiert 22.10.2026 (bestehendes Produkt, SKU TRE-V2A-7x2-D35) |
| Türschild Edelstahl personalisiert – Hund 8×5 cm (`1600000`) | Familienschilder | `TRE-V2A-8x5-D30` | `GR-ES-RE-80X53P3-T15` | customizationId 1600000, sku TRE-V2A-8x5-D30, shopifyProductId 16078289076604 | Hauptdesign TRE-V2A-8x5-D30 (Bogen TRE-V2A-8x5, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D30); Titel aus Shopify (Produkt 16078289076604, ACTIVE, 1 Variante(n), 24.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert 5×2 cm (`2500000`) | Familienschilder | `TRE-V2A-5x2-D1` | `GR-ES-RE-50X20-T15` | customizationId 2500000, sku TRE-V2A-5x2-D1, shopifyProductId 16077792936316 | Hauptdesign TRE-V2A-5x2-D1 (Bogen TRE-V2A-5x2, Reihe edelstahl-gravur-50x20, Master TRE-V2A-5x2-D1); Titel aus Shopify (Produkt 16077792936316, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Brief 5×2 cm (`2600000`) | Familienschilder | `TRE-V2A-5x2-D27` | `GR-ES-RE-50X20-T15` | customizationId 2600000, sku TRE-V2A-5x2-D27, shopifyProductId 16077793132924 | Hauptdesign TRE-V2A-5x2-D27 (Bogen TRE-V2A-5x2, Reihe edelstahl-gravur-50x20, Master TRE-V2A-5x2-D27); Titel aus Shopify (Produkt 16077793132924, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Herz 5×2 cm (`2700000`) | Familienschilder | `TRE-V2A-5x2-D52` | `GR-ES-RE-50X20-T15` | customizationId 2700000, sku TRE-V2A-5x2-D52, shopifyProductId 16077793263996 | Hauptdesign TRE-V2A-5x2-D52 (Bogen TRE-V2A-5x2, Reihe edelstahl-gravur-50x20, Master TRE-V2A-5x2-D52); Titel aus Shopify (Produkt 16077793263996, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert 6×2 cm (`2800000`) | Familienschilder | `TRE-V2A-6x2-D3` | `GR-ES-RE-60X20-T15` | customizationId 2800000, sku TRE-V2A-6x2-D3, shopifyProductId 16077793329532 | Hauptdesign TRE-V2A-6x2-D3 (Bogen TRE-V2A-6x2, Reihe edelstahl-gravur-60x20, Master TRE-V2A-6x2-D3); Titel aus Shopify (Produkt 16077793329532, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Haus 6×2 cm (`2900000`) | Familienschilder | `TRE-V2A-6x2-D23` | `GR-ES-RE-60X20-T15` | customizationId 2900000, sku TRE-V2A-6x2-D23, shopifyProductId 16077793624444 | Hauptdesign TRE-V2A-6x2-D23 (Bogen TRE-V2A-6x2, Reihe edelstahl-gravur-60x20, Master TRE-V2A-6x2-D23); Titel aus Shopify (Produkt 16077793624444, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Vogel Silhouette 6×2 cm (`3000000`) | Familienschilder | `TRE-V2A-6x2-D42` | `GR-ES-RE-60X20-T15` | customizationId 3000000, sku TRE-V2A-6x2-D42, shopifyProductId 16077793755516 | Hauptdesign TRE-V2A-6x2-D42 (Bogen TRE-V2A-6x2, Reihe edelstahl-gravur-60x20, Master TRE-V2A-6x2-D42); Titel aus Shopify (Produkt 16077793755516, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert 8×2 cm (`3400000`) | Familienschilder | `TRE-V2A-8x2-D2` | `GR-ES-RE-80X20-T15` | customizationId 3400000, sku TRE-V2A-8x2-D2, shopifyProductId 16077794247036 | Hauptdesign TRE-V2A-8x2-D2 (Bogen TRE-V2A-8x2, Reihe edelstahl-gravur-80x20, Master TRE-V2A-8x2-D2); Titel aus Shopify (Produkt 16077794247036, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Dezentes Symbol 8×2 cm (`3500000`) | Familienschilder | `TRE-V2A-8x2-D30` | `GR-ES-RE-80X20-T15` | customizationId 3500000, sku TRE-V2A-8x2-D30, shopifyProductId 16077794312572 | Hauptdesign TRE-V2A-8x2-D30 (Bogen TRE-V2A-8x2, Reihe edelstahl-gravur-80x20, Master TRE-V2A-8x2-D30); Titel aus Shopify (Produkt 16077794312572, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Anker 8×2 cm (`3600000`) | Familienschilder | `TRE-V2A-8x2-D6` | `GR-ES-RE-80X20-T15` | customizationId 3600000, sku TRE-V2A-8x2-D6, shopifyProductId 16077794476412 | Hauptdesign TRE-V2A-8x2-D6 (Bogen TRE-V2A-8x2, Reihe edelstahl-gravur-80x20, Master TRE-V2A-8x2-D6); Titel aus Shopify (Produkt 16077794476412, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Pusteblume 8×5 cm (`3700000`) | Familienschilder | `TAE-V2A-8x5-D14` | `GR-ES-AB-80X53P3-T15` | customizationId 3700000, sku TAE-V2A-8x5-D14, shopifyProductId 16077794541948 | Hauptdesign TAE-V2A-8x5-D14 (Bogen TAE-V2A-8x5, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D14); Titel aus Shopify (Produkt 16077794541948, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen; Design prüfen: Beispieltext enthält eine Adresse (drittes Textfeld) (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Pfoten 8×5 cm (`3800000`) | Familienschilder | `TAE-V2A-8x5-D33` | `GR-ES-AB-80X53P3-T15` | customizationId 3800000, sku TAE-V2A-8x5-D33, shopifyProductId 16077794705788 | Hauptdesign TAE-V2A-8x5-D33 (Bogen TAE-V2A-8x5, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D33); Titel aus Shopify (Produkt 16077794705788, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Schnörkel mit Herz 9×6 cm (`3900000`) | Familienschilder | `TRE-V2A-8x5-D55` | `GR-ES-RE-90X60-T15` | customizationId 3900000, sku TRE-V2A-9x6-D55, shopifyProductId 16077794804092 | Hauptdesign TRE-V2A-9x6-D55 (Bogen TRE-V2A-9x6, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D55); Titel aus Shopify (Produkt 16077794804092, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Lebensbaum 9×6 cm (`4000000`) | Familienschilder | `TRE-V2A-8x5-D20` | `GR-ES-RE-90X60-T15` | customizationId 4000000, sku TRE-V2A-9x6-D20, shopifyProductId 16077798867324 | Hauptdesign TRE-V2A-9x6-D20 (Bogen TRE-V2A-9x6, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D20); Titel aus Shopify (Produkt 16077798867324, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Leuchtturm 12×8 cm (`4100000`) | Familienschilder | `TAE-V2A-8x5-D8` | `GR-ES-AB-120X80-T15` | customizationId 4100000, sku TAE-V2A-12x8-D8, shopifyProductId 16077798965628 | Hauptdesign TAE-V2A-12x8-D8 (Bogen TAE-V2A-12x8, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D8); Titel aus Shopify (Produkt 16077798965628, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen; Design prüfen: Beispieltext enthält eine Adresse (drittes Textfeld) (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Laubbaum 12×8 cm (`4200000`) | Familienschilder | `TAE-V2A-8x5-D10` | `GR-ES-AB-120X80-T15` | customizationId 4200000, sku TAE-V2A-12x8-D10, shopifyProductId 16077799063932 | Hauptdesign TAE-V2A-12x8-D10 (Bogen TAE-V2A-12x8, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D10); Titel aus Shopify (Produkt 16077799063932, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Pusteblume 15×10 cm (`4300000`) | Familienschilder | `TAE-V2A-8x5-D12` | `GR-ES-AB-150X100-T15` | customizationId 4300000, sku TAE-V2A-15x10-D12, shopifyProductId 16077799096700 | Hauptdesign TAE-V2A-15x10-D12 (Bogen TAE-V2A-15x10, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D12); Titel aus Shopify (Produkt 16077799096700, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Katze 15×10 cm (`4400000`) | Familienschilder | `TAE-V2A-8x5-D34` | `GR-ES-AB-150X100-T15` | customizationId 4400000, sku TAE-V2A-15x10-D34, shopifyProductId 16077799162236 | Hauptdesign TAE-V2A-15x10-D34 (Bogen TAE-V2A-15x10, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D34); Titel aus Shopify (Produkt 16077799162236, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, katzenschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Pfoten 18×12 cm (`4500000`) | Familienschilder | `TAE-V2A-8x5-D32` | `GR-ES-AB-180X120-T15` | customizationId 4500000, sku TAE-V2A-18x12-D32, shopifyProductId 16077799227772 | Hauptdesign TAE-V2A-18x12-D32 (Bogen TAE-V2A-18x12, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D32); Titel aus Shopify (Produkt 16077799227772, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Schlüssel 18×12 cm (`4600000`) | Familienschilder | `TAE-V2A-8x5-D62` | `GR-ES-AB-180X120-T15` | customizationId 4600000, sku TAE-V2A-18x12-D62, shopifyProductId 16077799326076 | Hauptdesign TAE-V2A-18x12-D62 (Bogen TAE-V2A-18x12, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D62); Titel aus Shopify (Produkt 16077799326076, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Herzen 30×20 cm (`4700000`) | Familienschilder | `TAE-V2A-8x5-D65` | `GR-ES-AB-300X200-T15` | customizationId 4700000, sku TAE-V2A-30x20-D65, shopifyProductId 16077799457148 | Hauptdesign TAE-V2A-30x20-D65 (Bogen TAE-V2A-30x20, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D65); Titel aus Shopify (Produkt 16077799457148, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Abger. Ecken V2A personalisiert – Haus mit Herz 30×20 cm (`4800000`) | Familienschilder | `TAE-V2A-8x5-D24` | `GR-ES-AB-300X200-T15` | customizationId 4800000, sku TAE-V2A-30x20-D24, shopifyProductId 16077799555452 | Hauptdesign TAE-V2A-30x20-D24 (Bogen TAE-V2A-30x20, Reihe edelstahl-gravur-ab-80x53, Master TAE-V2A-8x5-D24); Titel aus Shopify (Produkt 16077799555452, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert 9×6 cm (`4900000`) | Familienschilder | `TO-V2A-9x6-D1` | `GR-ES-OV-90X60-T15` | customizationId 4900000, sku TO-V2A-9x6-D1, shopifyProductId 16077799588220 | Hauptdesign TO-V2A-9x6-D1 (Bogen TO-V2A-9x6, Reihe edelstahl-gravur-oval-90x60, Master TO-V2A-9x6-D1); Titel aus Shopify (Produkt 16077799588220, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Haus mit Herz 9×6 cm (`5000000`) | Familienschilder | `TO-V2A-9x6-D24` | `GR-ES-OV-90X60-T15` | customizationId 5000000, sku TO-V2A-9x6-D24, shopifyProductId 16077799653756 | Hauptdesign TO-V2A-9x6-D24 (Bogen TO-V2A-9x6, Reihe edelstahl-gravur-oval-90x60, Master TO-V2A-9x6-D24); Titel aus Shopify (Produkt 16077799653756, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Segelboot 9×6 cm (`5100000`) | Familienschilder | `TO-V2A-9x6-D7` | `GR-ES-OV-90X60-T15` | customizationId 5100000, sku TO-V2A-9x6-D7, shopifyProductId 16077799686524 | Hauptdesign TO-V2A-9x6-D7 (Bogen TO-V2A-9x6, Reihe edelstahl-gravur-oval-90x60, Master TO-V2A-9x6-D7); Titel aus Shopify (Produkt 16077799686524, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Haus 21×14 cm (`5200000`) | Familienschilder | `TO-V2A-9x6-D25` | `GR-ES-OV-210X140-T15` | customizationId 5200000, sku TO-V2A-21x14-D25, shopifyProductId 16077799817596 | Hauptdesign TO-V2A-21x14-D25 (Bogen TO-V2A-21x14, Reihe edelstahl-gravur-oval-90x60, Master TO-V2A-9x6-D25); Titel aus Shopify (Produkt 16077799817596, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Pusteblume 21×14 cm (`5300000`) | Familienschilder | `TO-V2A-9x6-D13` | `GR-ES-OV-210X140-T15` | customizationId 5300000, sku TO-V2A-21x14-D13, shopifyProductId 16077799883132 | Hauptdesign TO-V2A-21x14-D13 (Bogen TO-V2A-21x14, Reihe edelstahl-gravur-oval-90x60, Master TO-V2A-9x6-D13); Titel aus Shopify (Produkt 16077799883132, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Herz 21×14 cm (`5400000`) | Familienschilder | `TO-V2A-9x6-D61` | `GR-ES-OV-210X140-T15` | customizationId 5400000, sku TO-V2A-21x14-D61, shopifyProductId 16077799981436 | Hauptdesign TO-V2A-21x14-D61 (Bogen TO-V2A-21x14, Reihe edelstahl-gravur-oval-90x60, Master TO-V2A-9x6-D61); Titel aus Shopify (Produkt 16077799981436, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Vögel 12×4 cm (`5500000`) | Familienschilder | `TO-V2A-12x4-D48` | `GR-ES-EL-120X40-T15` | customizationId 5500000, sku TO-V2A-12x4-D48, shopifyProductId 16077800112508 | Hauptdesign TO-V2A-12x4-D48 (Bogen TO-V2A-12x4, Reihe edelstahl-gravur-oval-120x40, Master TO-V2A-12x4-D48); Titel aus Shopify (Produkt 16077800112508, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Herzranke 12×4 cm (`5600000`) | Familienschilder | `TO-V2A-12x4-D58` | `GR-ES-EL-120X40-T15` | customizationId 5600000, sku TO-V2A-12x4-D58, shopifyProductId 16077800210812 | Hauptdesign TO-V2A-12x4-D58 (Bogen TO-V2A-12x4, Reihe edelstahl-gravur-oval-120x40, Master TO-V2A-12x4-D58); Titel aus Shopify (Produkt 16077800210812, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Herz 12×4 cm (`5700000`) | Familienschilder | `TO-V2A-12x4-D52` | `GR-ES-EL-120X40-T15` | customizationId 5700000, sku TO-V2A-12x4-D52, shopifyProductId 16077800243580 | Hauptdesign TO-V2A-12x4-D52 (Bogen TO-V2A-12x4, Reihe edelstahl-gravur-oval-120x40, Master TO-V2A-12x4-D52); Titel aus Shopify (Produkt 16077800243580, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Pusteblume 12×4 cm (`5800000`) | Familienschilder | `TO-V2A-12x4-D12` | `GR-ES-EL-120X40-T15` | customizationId 5800000, sku TO-V2A-12x4-D12, shopifyProductId 16077800407420 | Hauptdesign TO-V2A-12x4-D12 (Bogen TO-V2A-12x4, Reihe edelstahl-gravur-oval-120x40, Master TO-V2A-12x4-D12); Titel aus Shopify (Produkt 16077800407420, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Ornament 12×4 cm (`5900000`) | Familienschilder | `TO-V2A-12x4-D60` | `GR-ES-EL-120X40-T15` | customizationId 5900000, sku TO-V2A-12x4-D60, shopifyProductId 16077800440188 | Hauptdesign TO-V2A-12x4-D60 (Bogen TO-V2A-12x4, Reihe edelstahl-gravur-oval-120x40, Master TO-V2A-12x4-D60); Titel aus Shopify (Produkt 16077800440188, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Hund Silhouette 12×4 cm (`6000000`) | Familienschilder | `TO-V2A-12x4-D31` | `GR-ES-EL-120X40-T15` | customizationId 6000000, sku TO-V2A-12x4-D31, shopifyProductId 16077800472956 | Hauptdesign TO-V2A-12x4-D31 (Bogen TO-V2A-12x4, Reihe edelstahl-gravur-oval-120x40, Master TO-V2A-12x4-D31); Titel aus Shopify (Produkt 16077800472956, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Vogelpaar 15×8 cm (`6100000`) | Familienschilder | `TO-V2A-15x8-D47` | `GR-ES-OV-150X80-T15` | customizationId 6100000, sku TO-V2A-15x8-D47, shopifyProductId 16077800505724 | Hauptdesign TO-V2A-15x8-D47 (Bogen TO-V2A-15x8, Reihe edelstahl-gravur-oval-150x80, Master TO-V2A-15x8-D47); Titel aus Shopify (Produkt 16077800505724, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Rose 15×8 cm (`6200000`) | Familienschilder | `TO-V2A-15x8-D19` | `GR-ES-OV-150X80-T15` | customizationId 6200000, sku TO-V2A-15x8-D19, shopifyProductId 16077800604028 | Hauptdesign TO-V2A-15x8-D19 (Bogen TO-V2A-15x8, Reihe edelstahl-gravur-oval-150x80, Master TO-V2A-15x8-D19); Titel aus Shopify (Produkt 16077800604028, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Oval Edelstahl V2A personalisiert – Laubbaum 15×8 cm (`6300000`) | Familienschilder | `TO-V2A-15x8-D10` | `GR-ES-OV-150X80-T15` | customizationId 6300000, sku TO-V2A-15x8-D10, shopifyProductId 16077800702332 | Hauptdesign TO-V2A-15x8-D10 (Bogen TO-V2A-15x8, Reihe edelstahl-gravur-oval-150x80, Master TO-V2A-15x8-D10); Titel aus Shopify (Produkt 16077800702332, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert 8×8 cm (`7200000`) | Familienschilder | `TQ-V2A-8x8-D3` | `GR-ES-QU-80X80-T15` | customizationId 7200000, sku TQ-V2A-8x8-D3, shopifyProductId 16077801324924 | Hauptdesign TQ-V2A-8x8-D3 (Bogen TQ-V2A-8x8, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D3); Titel aus Shopify (Produkt 16077801324924, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert – Herz 8×8 cm (`7300000`) | Familienschilder | `TQ-V2A-8x8-D53` | `GR-ES-QU-80X80-T15` | customizationId 7300000, sku TQ-V2A-8x8-D53, shopifyProductId 16077801390460 | Hauptdesign TQ-V2A-8x8-D53 (Bogen TQ-V2A-8x8, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D53); Titel aus Shopify (Produkt 16077801390460, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert – Pfoten 8×8 cm (`7400000`) | Familienschilder | `TQ-V2A-8x8-D33` | `GR-ES-QU-80X80-T15` | customizationId 7400000, sku TQ-V2A-8x8-D33, shopifyProductId 16077801488764 | Hauptdesign TQ-V2A-8x8-D33 (Bogen TQ-V2A-8x8, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D33); Titel aus Shopify (Produkt 16077801488764, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert – Pusteblume 16×16 cm (`7500000`) | Familienschilder | `TQ-V2A-8x8-D12` | `GR-ES-QU-160X160-T15` | customizationId 7500000, sku TQ-V2A-16x16-D12, shopifyProductId 16077801718140 | Hauptdesign TQ-V2A-16x16-D12 (Bogen TQ-V2A-16x16, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D12); Titel aus Shopify (Produkt 16077801718140, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert – Anker 16×16 cm (`7600000`) | Familienschilder | `TQ-V2A-8x8-D6` | `GR-ES-QU-160X160-T15` | customizationId 7600000, sku TQ-V2A-16x16-D6, shopifyProductId 16077801587068 | Hauptdesign TQ-V2A-16x16-D6 (Bogen TQ-V2A-16x16, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D6); Titel aus Shopify (Produkt 16077801587068, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert – Hundefigur 16×16 cm (`7700000`) | Familienschilder | `TQ-V2A-8x8-D29` | `GR-ES-QU-160X160-T15` | customizationId 7700000, sku TQ-V2A-16x16-D29, shopifyProductId 16077801849212 | Hauptdesign TQ-V2A-16x16-D29 (Bogen TQ-V2A-16x16, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D29); Titel aus Shopify (Produkt 16077801849212, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert 9×6 cm (`7800000`) | Familienschilder | `TRE-V2A-8x5-D5` | `GR-ES-RE-90X60-T15` | customizationId 7800000, sku TRE-V2A-9x6-D5, shopifyProductId 16078289109372 | Hauptdesign TRE-V2A-9x6-D5 (Bogen TRE-V2A-9x6, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D5); Titel aus Shopify (Produkt 16078289109372, ACTIVE, 1 Variante(n), 24.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert – Laubbaum 20×20 cm (`7900000`) | Familienschilder | `TQ-V2A-8x8-D10` | `GR-ES-QU-200X200-T15` | customizationId 7900000, sku TQ-V2A-20x20-D10, shopifyProductId 16077801947516 | Hauptdesign TQ-V2A-20x20-D10 (Bogen TQ-V2A-20x20, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D10); Titel aus Shopify (Produkt 16077801947516, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert – Haus 20×20 cm (`8000000`) | Familienschilder | `TQ-V2A-8x8-D25` | `GR-ES-QU-200X200-T15` | customizationId 8000000, sku TQ-V2A-20x20-D25, shopifyProductId 16077802045820 | Hauptdesign TQ-V2A-20x20-D25 (Bogen TQ-V2A-20x20, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D25); Titel aus Shopify (Produkt 16077802045820, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Quadrat Edelstahl V2A personalisiert – Segelboot 20×20 cm (`8100000`) | Familienschilder | `TQ-V2A-8x8-D7` | `GR-ES-QU-200X200-T15` | customizationId 8100000, sku TQ-V2A-20x20-D7, shopifyProductId 16077802078588 | Hauptdesign TQ-V2A-20x20-D7 (Bogen TQ-V2A-20x20, Reihe edelstahl-gravur-80x80, Master TQ-V2A-8x8-D7); Titel aus Shopify (Produkt 16077802078588, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert 8×3,5 cm (`8200000`) | Familienschilder | `TRE-V2A-8x3,5-D4` | `GR-ES-RE-80X35-T15` | customizationId 8200000, sku TRE-V2A-8x3,5-D4, shopifyProductId 16077802111356 | Hauptdesign TRE-V2A-8x3,5-D4 (Bogen TRE-V2A-8x3,5, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D4); Titel aus Shopify (Produkt 16077802111356, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Katze 8×3,5 cm (`8300000`) | Familienschilder | `TRE-V2A-8x3,5-D35` | `GR-ES-RE-80X35-T15` | customizationId 8300000, sku TRE-V2A-8x3,5-D35, shopifyProductId 16077802176892 | Hauptdesign TRE-V2A-8x3,5-D35 (Bogen TRE-V2A-8x3,5, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D35); Titel aus Shopify (Produkt 16077802176892, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, katzenschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Schlüssel 8×3,5 cm (`8400000`) | Familienschilder | `TRE-V2A-8x3,5-D62` | `GR-ES-RE-80X35-T15` | customizationId 8400000, sku TRE-V2A-8x3,5-D62, shopifyProductId 16077802242428 | Hauptdesign TRE-V2A-8x3,5-D62 (Bogen TRE-V2A-8x3,5, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D62); Titel aus Shopify (Produkt 16077802242428, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert 12×5,25 cm (`8500000`) | Familienschilder | `TRE-V2A-8x3,5-D5` | `GR-ES-RE-120X52P5-T15` | customizationId 8500000, sku TRE-V2A-12x5,25-D5, shopifyProductId 16077802275196 | Hauptdesign TRE-V2A-12x5,25-D5 (Bogen TRE-V2A-12x5,25, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D5); Titel aus Shopify (Produkt 16077802275196, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Pusteblume 12×5,25 cm (`8600000`) | Familienschilder | `TRE-V2A-8x3,5-D18` | `GR-ES-RE-120X52P5-T15` | customizationId 8600000, sku TRE-V2A-12x5,25-D18, shopifyProductId 16077802439036 | Hauptdesign TRE-V2A-12x5,25-D18 (Bogen TRE-V2A-12x5,25, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D18); Titel aus Shopify (Produkt 16077802439036, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Fußball-Symbol 12×5,25 cm (`8700000`) | Familienschilder | `TRE-V2A-8x3,5-D28` | `GR-ES-RE-120X52P5-T15` | customizationId 8700000, sku TRE-V2A-12x5,25-D28, shopifyProductId 16077802504572 | Hauptdesign TRE-V2A-12x5,25-D28 (Bogen TRE-V2A-12x5,25, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D28); Titel aus Shopify (Produkt 16077802504572, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Sonne 16×7 cm (`8800000`) | Familienschilder | `TRE-V2A-8x3,5-D21` | `GR-ES-RE-160X70-T15` | customizationId 8800000, sku TRE-V2A-16x7-D21, shopifyProductId 16077802537340 | Hauptdesign TRE-V2A-16x7-D21 (Bogen TRE-V2A-16x7, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D21); Titel aus Shopify (Produkt 16077802537340, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Hundefigur 16×7 cm (`8900000`) | Familienschilder | `TRE-V2A-8x3,5-D29` | `GR-ES-RE-160X70-T15` | customizationId 8900000, sku TRE-V2A-16x7-D29, shopifyProductId 16077802602876 | Hauptdesign TRE-V2A-16x7-D29 (Bogen TRE-V2A-16x7, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D29); Titel aus Shopify (Produkt 16077802602876, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Wimpelkette 16×7 cm (`9000000`) | Familienschilder | `TRE-V2A-8x3,5-D63` | `GR-ES-RE-160X70-T15` | customizationId 9000000, sku TRE-V2A-16x7-D63, shopifyProductId 16077802668412 | Hauptdesign TRE-V2A-16x7-D63 (Bogen TRE-V2A-16x7, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D63); Titel aus Shopify (Produkt 16077802668412, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Pfeil 24×10,5 cm (`9100000`) | Familienschilder | `TRE-V2A-8x3,5-D71` | `GR-ES-RE-240X105-T15` | customizationId 9100000, sku TRE-V2A-24x10,5-D71, shopifyProductId 16077802701180 | Hauptdesign TRE-V2A-24x10,5-D71 (Bogen TRE-V2A-24x10,5, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D71); Titel aus Shopify (Produkt 16077802701180, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen; Themenvorschlag unsicher: hinweisschilder (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Hundefigur 24×10,5 cm (`9300000`) | Familienschilder | `TRE-V2A-8x3,5-D29` | `GR-ES-RE-240X105-T15` | customizationId 9300000, sku TRE-V2A-24x10,5-D29, shopifyProductId 16077803028860 | Hauptdesign TRE-V2A-24x10,5-D29 (Bogen TRE-V2A-24x10,5, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D29); Titel aus Shopify (Produkt 16077803028860, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert 9×3 cm (`9400000`) | Familienschilder | `TRE-V2A-9x3-D2` | `GR-ES-RE-90X30-T15` | customizationId 9400000, sku TRE-V2A-9x3-D2, shopifyProductId 16077803094396 | Hauptdesign TRE-V2A-9x3-D2 (Bogen TRE-V2A-9x3, Reihe edelstahl-gravur-90x30, Master TRE-V2A-9x3-D2); Titel aus Shopify (Produkt 16077803094396, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Pfoten 9×3 cm (`9500000`) | Familienschilder | `TRE-V2A-9x3-D33` | `GR-ES-RE-90X30-T15` | customizationId 9500000, sku TRE-V2A-9x3-D33, shopifyProductId 16077803291004 | Hauptdesign TRE-V2A-9x3-D33 (Bogen TRE-V2A-9x3, Reihe edelstahl-gravur-90x30, Master TRE-V2A-9x3-D33); Titel aus Shopify (Produkt 16077803291004, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Schlichtes Design ohne Motiv 9×3 cm (`9600000`) | Familienschilder | `TRE-V2A-9x3-D39` | `GR-ES-RE-90X30-T15` | customizationId 9600000, sku TRE-V2A-9x3-D39, shopifyProductId 16077803389308 | Hauptdesign TRE-V2A-9x3-D39 (Bogen TRE-V2A-9x3, Reihe edelstahl-gravur-90x30, Master TRE-V2A-9x3-D39); Titel aus Shopify (Produkt 16077803389308, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Eck-Ornamente 24×8 cm (`9700000`) | Familienschilder | `TRE-V2A-9x3-D64` | `GR-ES-RE-240X80-T15` | customizationId 9700000, sku TRE-V2A-24x8-D64, shopifyProductId 16077803651452 | Hauptdesign TRE-V2A-24x8-D64 (Bogen TRE-V2A-24x8, Reihe edelstahl-gravur-90x30, Master TRE-V2A-9x3-D64); Titel aus Shopify (Produkt 16077803651452, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Pfeil 24×8 cm (`9800000`) | Familienschilder | `TRE-V2A-9x3-D68` | `GR-ES-RE-240X80-T15` | customizationId 9800000, sku TRE-V2A-24x8-D68, shopifyProductId 16077803782524 | Hauptdesign TRE-V2A-24x8-D68 (Bogen TRE-V2A-24x8, Reihe edelstahl-gravur-90x30, Master TRE-V2A-9x3-D68); Titel aus Shopify (Produkt 16077803782524, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen; Themenvorschlag unsicher: hinweisschilder (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Vogel Silhouette 24×8 cm (`9900000`) | Familienschilder | `TRE-V2A-9x3-D40` | `GR-ES-RE-240X80-T15` | customizationId 9900000, sku TRE-V2A-24x8-D40, shopifyProductId 16077803880828 | Hauptdesign TRE-V2A-24x8-D40 (Bogen TRE-V2A-24x8, Reihe edelstahl-gravur-90x30, Master TRE-V2A-9x3-D40); Titel aus Shopify (Produkt 16077803880828, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert 8×5 cm (`10000000`) | Familienschilder | `TRE-V2A-8x5-D3` | `GR-ES-RE-80X53P3-T15` | customizationId 10000000, sku TRE-V2A-8x5-D3, shopifyProductId 16077803946364 | Hauptdesign TRE-V2A-8x5-D3 (Bogen TRE-V2A-8x5, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D3); Titel aus Shopify (Produkt 16077803946364, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Brief 8×5 cm (`10100000`) | Familienschilder | `TRE-V2A-8x5-D27` | `GR-ES-RE-80X53P3-T15` | customizationId 10100000, sku TRE-V2A-8x5-D27, shopifyProductId 16078289043836 | Hauptdesign TRE-V2A-8x5-D27 (Bogen TRE-V2A-8x5, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D27); Titel aus Shopify (Produkt 16078289043836, ACTIVE, 1 Variante(n), 24.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Pusteblume 9×6 cm (`10200000`) | Familienschilder | `TRE-V2A-8x5-D14` | `GR-ES-RE-90X60-T15` | customizationId 10200000, sku TRE-V2A-9x6-D14, shopifyProductId 16078289174908 | Hauptdesign TRE-V2A-9x6-D14 (Bogen TRE-V2A-9x6, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D14); Titel aus Shopify (Produkt 16078289174908, ACTIVE, 1 Variante(n), 24.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen; Design prüfen: Beispieltext enthält eine Adresse (drittes Textfeld) (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Eck-Ornamente 9×6 cm (`10300000`) | Familienschilder | `TRE-V2A-8x5-D64` | `GR-ES-RE-90X60-T15` | customizationId 10300000, sku TRE-V2A-9x6-D64, shopifyProductId 16078289273212 | Hauptdesign TRE-V2A-9x6-D64 (Bogen TRE-V2A-9x6, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D64); Titel aus Shopify (Produkt 16078289273212, ACTIVE, 1 Variante(n), 24.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Pusteblume 12×8 cm (`10400000`) | Familienschilder | `TRE-V2A-8x5-D12` | `GR-ES-RE-120X80-T15` | customizationId 10400000, sku TRE-V2A-12x8-D12, shopifyProductId 16078289404284 | Hauptdesign TRE-V2A-12x8-D12 (Bogen TRE-V2A-12x8, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D12); Titel aus Shopify (Produkt 16078289404284, ACTIVE, 1 Variante(n), 29.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Haus mit Herz 12×8 cm (`10500000`) | Familienschilder | `TRE-V2A-8x5-D24` | `GR-ES-RE-120X80-T15` | customizationId 10500000, sku TRE-V2A-12x8-D24, shopifyProductId 16078289600892 | Hauptdesign TRE-V2A-12x8-D24 (Bogen TRE-V2A-12x8, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D24); Titel aus Shopify (Produkt 16078289600892, ACTIVE, 1 Variante(n), 29.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Eulen Familie 12×8 cm (`10600000`) | Familienschilder | `TRE-V2A-8x5-D49` | `GR-ES-RE-120X80-T15` | customizationId 10600000, sku TRE-V2A-12x8-D49, shopifyProductId 16078289666428 | Hauptdesign TRE-V2A-12x8-D49 (Bogen TRE-V2A-12x8, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D49); Titel aus Shopify (Produkt 16078289666428, ACTIVE, 1 Variante(n), 29.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Herzen 15×10 cm (`10700000`) | Familienschilder | `TRE-V2A-8x5-D65` | `GR-ES-RE-150X100-T15` | customizationId 10700000, sku TRE-V2A-15x10-D65, shopifyProductId 16078289731964 | Hauptdesign TRE-V2A-15x10-D65 (Bogen TRE-V2A-15x10, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D65); Titel aus Shopify (Produkt 16078289731964, ACTIVE, 1 Variante(n), 29.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Katze 15×10 cm (`10800000`) | Familienschilder | `TRE-V2A-8x5-D34` | `GR-ES-RE-150X100-T15` | customizationId 10800000, sku TRE-V2A-15x10-D34, shopifyProductId 16078289764732 | Hauptdesign TRE-V2A-15x10-D34 (Bogen TRE-V2A-15x10, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D34); Titel aus Shopify (Produkt 16078289764732, ACTIVE, 1 Variante(n), 29.90 €); Themen laut Design: familienschilder, namensschilder, katzenschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Haus 15×10 cm (`10900000`) | Familienschilder | `TRE-V2A-8x5-D25` | `GR-ES-RE-150X100-T15` | customizationId 10900000, sku TRE-V2A-15x10-D25, shopifyProductId 16078289797500 | Hauptdesign TRE-V2A-15x10-D25 (Bogen TRE-V2A-15x10, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D25); Titel aus Shopify (Produkt 16078289797500, ACTIVE, 1 Variante(n), 29.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Leuchtturm 18×12 cm (`11000000`) | Familienschilder | `TRE-V2A-8x5-D8` | `GR-ES-RE-180X120-T15` | customizationId 11000000, sku TRE-V2A-18x12-D8, shopifyProductId 16078289863036 | Hauptdesign TRE-V2A-18x12-D8 (Bogen TRE-V2A-18x12, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D8); Titel aus Shopify (Produkt 16078289863036, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen; Design prüfen: Beispieltext enthält eine Adresse (drittes Textfeld) (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Blütenranke 18×12 cm (`11100000`) | Familienschilder | `TRE-V2A-8x5-D15` | `GR-ES-RE-180X120-T15` | customizationId 11100000, sku TRE-V2A-18x12-D15, shopifyProductId 16078289895804 | Hauptdesign TRE-V2A-18x12-D15 (Bogen TRE-V2A-18x12, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D15); Titel aus Shopify (Produkt 16078289895804, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Herzranke 18×12 cm (`11200000`) | Familienschilder | `TRE-V2A-8x5-D58` | `GR-ES-RE-180X120-T15` | customizationId 11200000, sku TRE-V2A-18x12-D58, shopifyProductId 16078289928572 | Hauptdesign TRE-V2A-18x12-D58 (Bogen TRE-V2A-18x12, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D58); Titel aus Shopify (Produkt 16078289928572, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Pusteblume 21×14 cm (`11300000`) | Familienschilder | `TRE-V2A-8x5-D11` | `GR-ES-RE-210X140-T15` | customizationId 11300000, sku TRE-V2A-21x14-D11, shopifyProductId 16078290059644 | Hauptdesign TRE-V2A-21x14-D11 (Bogen TRE-V2A-21x14, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D11); Titel aus Shopify (Produkt 16078290059644, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Kolibri 21×14 cm (`11400000`) | Familienschilder | `TRE-V2A-8x5-D41` | `GR-ES-RE-210X140-T15` | customizationId 11400000, sku TRE-V2A-21x14-D41, shopifyProductId 16078290092412 | Hauptdesign TRE-V2A-21x14-D41 (Bogen TRE-V2A-21x14, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D41); Titel aus Shopify (Produkt 16078290092412, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Ornament 21×14 cm (`11500000`) | Familienschilder | `TRE-V2A-8x5-D60` | `GR-ES-RE-210X140-T15` | customizationId 11500000, sku TRE-V2A-21x14-D60, shopifyProductId 16078290157948 | Hauptdesign TRE-V2A-21x14-D60 (Bogen TRE-V2A-21x14, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D60); Titel aus Shopify (Produkt 16078290157948, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Sonne 24×16 cm (`11600000`) | Familienschilder | `TRE-V2A-8x5-D21` | `GR-ES-RE-240X160-T15` | customizationId 11600000, sku TRE-V2A-24x16-D21, shopifyProductId 16078290223484 | Hauptdesign TRE-V2A-24x16-D21 (Bogen TRE-V2A-24x16, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D21); Titel aus Shopify (Produkt 16078290223484, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Strich Haus 24×16 cm (`11700000`) | Familienschilder | `TRE-V2A-8x5-D22` | `GR-ES-RE-240X160-T15` | customizationId 11700000, sku TRE-V2A-24x16-D22, shopifyProductId 16078290256252 | Hauptdesign TRE-V2A-24x16-D22 (Bogen TRE-V2A-24x16, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D22); Titel aus Shopify (Produkt 16078290256252, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Hund Silhouette 24×16 cm (`11800000`) | Familienschilder | `TRE-V2A-8x5-D31` | `GR-ES-RE-240X160-T15` | customizationId 11800000, sku TRE-V2A-24x16-D31, shopifyProductId 16078290289020 | Hauptdesign TRE-V2A-24x16-D31 (Bogen TRE-V2A-24x16, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D31); Titel aus Shopify (Produkt 16078290289020, ACTIVE, 1 Variante(n), 34.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert 30×20 cm (`11900000`) | Familienschilder | `TRE-V2A-8x5-D1` | `GR-ES-RE-300X200-T15` | customizationId 11900000, sku TRE-V2A-30x20-D1, shopifyProductId 16078290452860 | Hauptdesign TRE-V2A-30x20-D1 (Bogen TRE-V2A-30x20, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D1); Titel aus Shopify (Produkt 16078290452860, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Pfoten 30×20 cm (`12000000`) | Familienschilder | `TRE-V2A-8x5-D32` | `GR-ES-RE-300X200-T15` | customizationId 12000000, sku TRE-V2A-30x20-D32, shopifyProductId 16078290485628 | Hauptdesign TRE-V2A-30x20-D32 (Bogen TRE-V2A-30x20, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D32); Titel aus Shopify (Produkt 16078290485628, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Laubbaum 30×20 cm (`12100000`) | Familienschilder | `TRE-V2A-8x5-D10` | `GR-ES-RE-300X200-T15` | customizationId 12100000, sku TRE-V2A-30x20-D10, shopifyProductId 16078290518396 | Hauptdesign TRE-V2A-30x20-D10 (Bogen TRE-V2A-30x20, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D10); Titel aus Shopify (Produkt 16078290518396, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Anker 42×28 cm (`12200000`) | Familienschilder | `TRE-V2A-8x5-D6` | `GR-ES-RE-420X280-T15` | customizationId 12200000, sku TRE-V2A-42x28-D6, shopifyProductId 16078290616700 | Hauptdesign TRE-V2A-42x28-D6 (Bogen TRE-V2A-42x28, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D6); Titel aus Shopify (Produkt 16078290616700, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Pfeil 45×30 cm (`12300000`) | Familienschilder | `TRE-V2A-8x5-D69` | `GR-ES-RE-450X300-T15` | customizationId 12300000, sku TRE-V2A-45x30-D69, shopifyProductId 16078290649468 | Hauptdesign TRE-V2A-45x30-D69 (Bogen TRE-V2A-45x30, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D69); Titel aus Shopify (Produkt 16078290649468, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen; Themenvorschlag unsicher: hinweisschilder (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Lebensbaum 45×30 cm (`12400000`) | Familienschilder | `TRE-V2A-8x5-D20` | `GR-ES-RE-450X300-T15` | customizationId 12400000, sku TRE-V2A-45x30-D20, shopifyProductId 16078290682236 | Hauptdesign TRE-V2A-45x30-D20 (Bogen TRE-V2A-45x30, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D20); Titel aus Shopify (Produkt 16078290682236, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Pfoten 45×30 cm (`12500000`) | Familienschilder | `TRE-V2A-8x5-D33` | `GR-ES-RE-450X300-T15` | customizationId 12500000, sku TRE-V2A-45x30-D33, shopifyProductId 16078290747772 | Hauptdesign TRE-V2A-45x30-D33 (Bogen TRE-V2A-45x30, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D33); Titel aus Shopify (Produkt 16078290747772, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: familienschilder, namensschilder, hundeschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Herz-Punkte-Ornament 42×28 cm (`12600000`) | Familienschilder | `TRE-V2A-8x5-D57` | `GR-ES-RE-420X280-T15` | customizationId 12600000, sku TRE-V2A-42x28-D57, shopifyProductId 16078290813308 | Hauptdesign TRE-V2A-42x28-D57 (Bogen TRE-V2A-42x28, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D57); Titel aus Shopify (Produkt 16078290813308, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Retro I V2A personalisiert – Ranken-Ornament 9×6 cm (`6400000`) | Familienschilder | `TR1-V2A-9x6-D57` | `GR-ES-RT1-90X60-T15` | customizationId 6400000, sku TR1-V2A-9x6-D57, shopifyProductId 16077800800636 | Hauptdesign TR1-V2A-9x6-D57 (Bogen TR1-V2A-9x6, Reihe edelstahl-gravur-retro1-90x60, Master TR1-V2A-9x6-D57); Bisher offene Konturgröße anhand Zeichnung und Familie zugeordnet; Designübertragung und Konfiguratoranschluss offen (Paket B); Titel aus Shopify (Produkt 16077800800636, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Retro I V2A personalisiert – Blütenranke 9×6 cm (`6500000`) | Familienschilder | `TR1-V2A-9x6-D15` | `GR-ES-RT1-90X60-T15` | customizationId 6500000, sku TR1-V2A-9x6-D15, shopifyProductId 16077800833404 | Hauptdesign TR1-V2A-9x6-D15 (Bogen TR1-V2A-9x6, Reihe edelstahl-gravur-retro1-90x60, Master TR1-V2A-9x6-D15); Bisher offene Konturgröße anhand Zeichnung und Familie zugeordnet; Designübertragung und Konfiguratoranschluss offen (Paket B); Titel aus Shopify (Produkt 16077800833404, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Retro II Edelstahl V2A personalisiert – Rosen 9×6 cm (`6600000`) | Familienschilder | `TR2-V2A-9x6-D59` | `GR-ES-RT2-90X60-T15` | customizationId 6600000, sku TR2-V2A-9x6-D59, shopifyProductId 16077800898940 | Hauptdesign TR2-V2A-9x6-D59 (Bogen TR2-V2A-9x6, Reihe edelstahl-gravur-retro2-91x61, Master TR2-V2A-9x6-D59); Bisher offene Konturgröße anhand Zeichnung und Familie zugeordnet; Designübertragung und Konfiguratoranschluss offen (Paket B); Titel aus Shopify (Produkt 16077800898940, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Retro II Edelstahl V2A personalisiert – Anker 9×6 cm (`6700000`) | Familienschilder | `TR2-V2A-9x6-D6` | `GR-ES-RT2-90X60-T15` | customizationId 6700000, sku TR2-V2A-9x6-D6, shopifyProductId 16077800931708 | Hauptdesign TR2-V2A-9x6-D6 (Bogen TR2-V2A-9x6, Reihe edelstahl-gravur-retro2-91x61, Master TR2-V2A-9x6-D6); Bisher offene Konturgröße anhand Zeichnung und Familie zugeordnet; Designübertragung und Konfiguratoranschluss offen (Paket B); Titel aus Shopify (Produkt 16077800931708, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Retro II Edelstahl V2A personalisiert – Pusteblume 9×6 cm (`6800000`) | Familienschilder | `TR2-V2A-9x6-D12` | `GR-ES-RT2-90X60-T15` | customizationId 6800000, sku TR2-V2A-9x6-D12, shopifyProductId 16077801062780 | Hauptdesign TR2-V2A-9x6-D12 (Bogen TR2-V2A-9x6, Reihe edelstahl-gravur-retro2-91x61, Master TR2-V2A-9x6-D12); Bisher offene Konturgröße anhand Zeichnung und Familie zugeordnet; Designübertragung und Konfiguratoranschluss offen (Paket B); Titel aus Shopify (Produkt 16077801062780, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Retro II Edelstahl V2A personalisiert – Sonne 9×6 cm (`6900000`) | Familienschilder | `TR2-V2A-9x6-D21` | `GR-ES-RT2-90X60-T15` | customizationId 6900000, sku TR2-V2A-9x6-D21, shopifyProductId 16077801128316 | Hauptdesign TR2-V2A-9x6-D21 (Bogen TR2-V2A-9x6, Reihe edelstahl-gravur-retro2-91x61, Master TR2-V2A-9x6-D21); Bisher offene Konturgröße anhand Zeichnung und Familie zugeordnet; Designübertragung und Konfiguratoranschluss offen (Paket B); Titel aus Shopify (Produkt 16077801128316, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Retro II Edelstahl V2A personalisiert – Rose 12×8 cm (`7000000`) | Familienschilder | `TR2-V2A-9x6-D16` | `GR-ES-RT2-120X80-T15` | customizationId 7000000, sku TR2-V2A-12x8-D16, shopifyProductId 16077801193852 | Hauptdesign TR2-V2A-12x8-D16 (Bogen TR2-V2A-12x8, Reihe edelstahl-gravur-retro2-91x61, Master TR2-V2A-9x6-D16); Bisher offene Konturgröße anhand Zeichnung und Familie zugeordnet; Designübertragung und Konfiguratoranschluss offen (Paket B); Titel aus Shopify (Produkt 16077801193852, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder, willkommensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Retro II Edelstahl V2A personalisiert – Lilie 12×8 cm (`7100000`) | Familienschilder | `TR2-V2A-9x6-D54` | `GR-ES-RT2-120X80-T15` | customizationId 7100000, sku TR2-V2A-12x8-D54, shopifyProductId 16077801259388 | Hauptdesign TR2-V2A-12x8-D54 (Bogen TR2-V2A-12x8, Reihe edelstahl-gravur-retro2-91x61, Master TR2-V2A-9x6-D54); Bisher offene Konturgröße anhand Zeichnung und Familie zugeordnet; Designübertragung und Konfiguratoranschluss offen (Paket B); Titel aus Shopify (Produkt 16077801259388, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: familienschilder, namensschilder – Unterkategorie „familienschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl V2A personalisiert – Dreieck 24×10,5 cm (`9200000`) | Hinweisschilder | `TRE-V2A-8x3,5-D72` | `GR-ES-RE-240X105-T15` | customizationId 9200000, sku TRE-V2A-24x10,5-D72, shopifyProductId 16077802832252 | Hauptdesign TRE-V2A-24x10,5-D72 (Bogen TRE-V2A-24x10,5, Reihe edelstahl-gravur-80x35, Master TRE-V2A-8x3,5-D72); Titel aus Shopify (Produkt 16077802832252, ACTIVE, 1 Variante(n), 19.90 €); Themen laut Design: hinweisschilder, familienschilder – Unterkategorie „hinweisschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |
| Türschild Edelstahl personalisiert – Dreieck 42×28 cm (`12700000`) | Hinweisschilder | `TRE-V2A-8x5-D72` | `GR-ES-RE-420X280-T15` | customizationId 12700000, sku TRE-V2A-42x28-D72, shopifyProductId 16078290846076 | Hauptdesign TRE-V2A-42x28-D72 (Bogen TRE-V2A-42x28, Reihe edelstahl-gravur-80x53, Master TRE-V2A-8x5-D72); Titel aus Shopify (Produkt 16078290846076, ACTIVE, 1 Variante(n), 49.90 €); Themen laut Design: hinweisschilder, familienschilder – Unterkategorie „hinweisschilder“ gewählt, prüfen (eingetragen 23.10.2026, katalog-hauptprodukte.py) |

### Tier-Gedenktafeln Schiefer 22 × 14

Familien: [Gedenktafel 22 × 14 · Naturschiefer (helle Gravur)](#gedenktafel-22x14-schiefer-natur) · Stand: 4 aktuelle Hunde-Entwürfe mit je 48 Varianten; 6 ältere Parallelentwürfe getrennt gekennzeichnet

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Hunde-Gedenktafeln | `hundegedenktafeln` | `andenken` | Hunde, Pfoten, Regenbogen, Flügel | wie Familie | offen |
| Katzen-Gedenktafeln | `katzengedenktafeln` | `andenken` | Katzen, Pfoten, Regenbogen, Flügel | wie Familie | offen |

### Gedenktafeln 30 × 20

Familien: [Gedenktafel 30 × 20 · Edelstahl](#gedenktafel-30x20-edelstahl), [Gedenktafel 30 × 20 · Naturschiefer](#gedenktafel-30x20-schiefer-natur), [Gedenktafel 30 × 20 · Premium-Schiefer](#gedenktafel-30x20-schiefer-premium), [Gedenktafel 30 × 20 · Acrylglas schwarz](#gedenktafel-30x20-acryl-schwarz), [Gedenktafel 30 × 20 · Acrylglas anthrazit](#gedenktafel-30x20-acryl-anthrazit) · Stand: Schiefer natur vollständig, Rest offen

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Gedenktafeln | `gedenktafeln` | `andenken` | Kreuze, Engel, Symbole Religion, Kerzen, Bäume, Vögel | wie Familie | offen |
| Tiergedenktafeln | `tiergedenktafeln` | `andenken` | Hunde, Katzen, Pferde, Pfoten, Regenbogen, Flügel | wie Familie | offen |

### Lineale

Familien: Familie offen · Stand: Familie offen

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Namensschilder | `namensschilder` | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | wie Familie | offen |
| Geschenkartikel | `geschenkartikel` | `geschenkartikel` | Geburtstag, Jubiläum, Muttertag, Vatertag, Weihnachten, Ostern | wie Familie | offen |
| Firmen- und Praxisschilder | `firmenschilder` | `firmenschilder` | Berufe & Gewerbe, Hinweise - Piktogramme, Social Media | wie Familie | offen |

### Pferdeschilder (Boxen- und Stallschilder)

Familien: Familie offen · Stand: Familie offen

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Pferdeschilder | `pferdeschilder` | `pferdeschilder` | Pferde, Brandzeichen | wie Familie | offen |
| Hinweisschilder | `hinweisschilder` | `firmenschilder` | Hinweise - Piktogramme, Pfeile | wie Familie | offen |

### Schlüsselanhänger

Familien: Familie offen · Stand: Familie offen

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Namensschilder | `namensschilder` | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | wie Familie | offen |
| Hochzeitsschilder | `hochzeitsschilder` | `andenken` | Hochzeit, Herzen, Infinity, Schleifen | wie Familie | offen |
| Hundeschilder | `hundeschilder` | `hundeschilder` | Hunderassen, Hunde, Pfoten | wie Familie | offen |
| Firmen- und Praxisschilder | `firmenschilder` | `firmenschilder` | Berufe & Gewerbe, Hinweise - Piktogramme, Social Media | wie Familie | offen |
| Geschenkartikel | `geschenkartikel` | `geschenkartikel` | Geburtstag, Jubiläum, Muttertag, Vatertag, Weihnachten, Ostern | wie Familie | offen |

### Stifthalterdosen

Familien: Familie offen · Stand: Familie offen

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Namensschilder | `namensschilder` | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | wie Familie | offen |
| Geschenkartikel | `geschenkartikel` | `geschenkartikel` | Geburtstag, Jubiläum, Muttertag, Vatertag, Weihnachten, Ostern | wie Familie | offen |
| Firmen- und Praxisschilder | `firmenschilder` | `firmenschilder` | Berufe & Gewerbe, Hinweise - Piktogramme, Social Media | wie Familie | offen |

### Türklingeln (zurückgestellt)

Familien: Familie offen · Stand: Familie offen

| Unterkategorie | Thema | Schrift-Set | Motivkategorien | Preise | Status |
| --- | --- | --- | --- | --- | --- |
| Namensschilder | `namensschilder` | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | wie Familie | offen |
| Hausnummern | `hausnummern` | `hausnummern` | Haus, Linien mit Verzierungen | wie Familie | offen |
| Firmen- und Praxisschilder | `firmenschilder` | `firmenschilder` | Berufe & Gewerbe, Hinweise - Piktogramme, Social Media | wie Familie | offen |

## Familien auf einen Blick

| Material | Familie | Größen | Formen | Bohrbilder | Preise | Stand |
| --- | --- | --- | --- | --- | --- | --- |
| Acrylglas | [Acrylglas anthrazit 5 mm · Abstandshalter (AA)](#acryl-aa-abstandshalter) | 33 | Rechteck, Oval, Eingezogene Ecken, Abgerundete Ecken R5 | 4 | offen | 6 offen |
| Acrylglas | [Acrylglas schwarz 5 mm · Abstandshalter (AS)](#acryl-as-abstandshalter) | 33 | Rechteck, Oval, Eingezogene Ecken, Abgerundete Ecken R5 | 4 | offen | 6 offen |
| Acrylglas | [Acrylglas schwarz satiniert 3 mm + Rückplatte schwarz (S/S)](#acryl-ss-abstandshalter) | 33 | Rechteck, Oval, Eingezogene Ecken, Abgerundete Ecken R5 | 4 | offen | 6 offen |
| Acrylglas | [Gedenktafel 30 × 20 · Acrylglas anthrazit](#gedenktafel-30x20-acryl-anthrazit) | 1 | Rechteck | 0 | offen | 3 offen |
| Acrylglas | [Gedenktafel 30 × 20 · Acrylglas schwarz](#gedenktafel-30x20-acryl-schwarz) | 1 | Rechteck | 0 | offen | 3 offen |
| Edelstahl | [Gedenktafel 30 × 20 · Edelstahl](#gedenktafel-30x20-edelstahl) | 1 | Rechteck | 1 | hinterlegt | 3 offen |
| Edelstahl | [Edelstahl-Türschilder](#steel-door-signs) | 80 | Rechteck, Abgerundete Ecken R5, Quadrat, Oval, Ellipse, Rund, Retro 1 (eckig), Retro 2 (geschwungen) | 18 | hinterlegt | vollständig |
| Schiefer | [Hunde-Gedenktafel 22 × 14 · Naturschiefer](#gedenktafel-22x14-schiefer-hunde-2027) | 1 | Rechteck | 8 | hinterlegt | vollständig |
| Schiefer | [Gedenktafel 22 × 14 · Naturschiefer (helle Gravur)](#gedenktafel-22x14-schiefer-natur) | 1 | Rechteck | 8 | hinterlegt | vollständig |
| Schiefer | [Gedenktafel 30 × 20 · Naturschiefer](#gedenktafel-30x20-schiefer-natur) | 1 | Rechteck | 2 | hinterlegt | vollständig |
| Schiefer | [Gedenktafel 30 × 20 · Premium-Schiefer](#gedenktafel-30x20-schiefer-premium) | 1 | Rechteck | 0 | offen | 3 offen |

## Familien im Einzelnen

<a id="acryl-aa-abstandshalter"></a>
### Acrylglas anthrazit 5 mm · Abstandshalter (AA)

Stammdaten: [`familien/acryl/acryl-aa-abstandshalter.json`](familien/acryl/acryl-aa-abstandshalter.json) · Material Acrylglas anthrazit, 5 mm, Verfahren `acrylic-engraving`, Gravur von hinten.
**Offen:** Aufpreis „2 Abstandshalter“; Aufpreis „4 Abstandshalter“; Grundpreis: alle 33 Größen; Form „eingezogene Ecken“ ist im Konfigurator noch nicht angeschlossen (Schablone und Katalog zeigen sie schon)

![Acrylglas anthrazit 5 mm · Abstandshalter (AA)](kataloge/png/acryl-aa-abstandshalter.png)

Plattenkatalog: [kataloge/acryl-aa-abstandshalter.pdf](kataloge/acryl-aa-abstandshalter.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 3.43:1 | Rechteck | 24 × 7 cm (`AA-RE-240X70` · offen) |
| 3:1 | Rechteck | 21 × 7 cm (`AA-RE-210X70` · offen), 27 × 9 cm (`AA-RE-270X90` · offen), 36 × 12 cm (`AA-RE-360X120` · offen), 45 × 15 cm (`AA-RE-450X150` · offen) |
| 15:8 | Oval | 15 × 8 cm (`AA-OV-150X80` · offen), 22,5 × 12 cm (`AA-OV-225X120` · offen), 30 × 16 cm (`AA-OV-300X160` · offen) |
| 3:2 | Rechteck | 15 × 10 cm (`AA-RE-150X100` · offen), 18 × 12 cm (`AA-RE-180X120` · offen), 24 × 16 cm (`AA-RE-240X160` · offen), 30 × 20 cm (`AA-RE-300X200` · offen), 36 × 24 cm (`AA-RE-360X240` · offen), 42 × 28 cm (`AA-RE-420X280` · offen) |
| 3:2 | Oval | 15 × 10 cm (`AA-OV-150X100` · offen), 18 × 12 cm (`AA-OV-180X120` · offen), 21 × 14 cm (`AA-OV-210X140` · offen), 24 × 16 cm (`AA-OV-240X160` · offen), 30 × 20 cm (`AA-OV-300X200` · offen) |
| 3:2 | Abgerundete Ecken R5 | 15 × 10 cm (`AA-R5-150X100` · offen), 18 × 12 cm (`AA-R5-180X120` · offen), 24 × 16 cm (`AA-R5-240X160` · offen), 30 × 20 cm (`AA-R5-300X200` · offen), 36 × 24 cm (`AA-R5-360X240` · offen), 42 × 28 cm (`AA-R5-420X280` · offen) |
| 3:2 | Eingezogene Ecken | 18 × 12 cm R11.6 (`AA-EE-180X120` · offen), 21 × 14 cm R13.5 (`AA-EE-210X140` · offen), 24 × 16 cm R15.5 (`AA-EE-240X160` · offen), 30 × 20 cm R19.3 (`AA-EE-300X200` · offen) |
| 1:1 | Rechteck | 16 × 16 cm (`AA-RE-160X160` · offen), 20 × 20 cm (`AA-RE-200X200` · offen), 26 × 26 cm (`AA-RE-260X260` · offen), 30 × 30 cm (`AA-RE-300X300` · offen) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |
| 2 Abstandshalter (`AH02-E10-D8`) | seitlich mittig | 2 | 8 | 10.0 | standoffs | offen |
| 2 Abstandshalter (`AH02-E15-D8`) | seitlich mittig | 2 | 8 | 15.0 | standoffs | offen |
| 4 Abstandshalter (`AH04-E10-D8`) | in den Ecken | 4 | 8 | 10.0 | standoffs | offen |
| 4 Abstandshalter (`AH04-E15-D8`) | in den Ecken | 4 | 8 | 15.0 | standoffs | offen |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Antic Slab, Bellefair, Cinzel, Roboto Slab, Aldrich, Audiowide, Comfortaa, Lato, Michroma, Minimalist, Raleway, Rounded Elegance, Archivo Black, Ashley Marie, Bebas Neue, Bernardo Moda Contrast, Chewy, Days One, Dream Orphans, Righteous, Alex Brush, Allura, Ashley, Betsy Bailey, Dancing Script, Great Vibes, Italianno, Magnolia Script, Parisienne, Rochester, Satisfy, Sweetie, Tangerine, Cookie, Courgette, Homage, Kaushan Script, Pacifico, Soulmate, Standlist, Bad Script, Caveat, Daniel, Daniel Black, Desyrel, Fineliner Script, Gloria Hallelujah, Rock Salt, Zentenar Fraktur, Fjalla One, Cormorant Garamond, Playfair Display, Libre Baskerville, Lora, Oswald, Roboto Condensed, Montserrat, Josefin Sans, Amatic SC, Kalam, Patrick Hand, Lobster, Sacramento, Special Elite, Courier Prime, Cinzel Decorative, Poiret One, Rye, Alfa Slab One, Stardos Stencil, Fredoka, Baloo 2, Uncial Antiqua, MedievalSharp, Permanent Marker

Hinweis: Randabstand der Bohrlöcher je Platte wie in der Corel-Zeichnung: 10 mm bei kleinen, 15 mm bei größeren Platten, aus optischen Gründen und damit die Platten unter Spannung hängen und nicht durchhängen (Nutzer, 17.10.2026). Nicht vereinheitlichen. Preise und Aufpreise offen. Schutzzone 1 mm vorläufig; Kopfdurchmesser der Abstandshalter noch nicht bekannt.

<a id="acryl-as-abstandshalter"></a>
### Acrylglas schwarz 5 mm · Abstandshalter (AS)

Stammdaten: [`familien/acryl/acryl-as-abstandshalter.json`](familien/acryl/acryl-as-abstandshalter.json) · Material Acrylglas schwarz, 5 mm, Verfahren `acrylic-engraving`, Gravur von hinten.
**Offen:** Aufpreis „2 Abstandshalter“; Aufpreis „4 Abstandshalter“; Grundpreis: alle 33 Größen; Form „eingezogene Ecken“ ist im Konfigurator noch nicht angeschlossen (Schablone und Katalog zeigen sie schon)

![Acrylglas schwarz 5 mm · Abstandshalter (AS)](kataloge/png/acryl-as-abstandshalter.png)

Plattenkatalog: [kataloge/acryl-as-abstandshalter.pdf](kataloge/acryl-as-abstandshalter.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 3.43:1 | Rechteck | 24 × 7 cm (`AS-RE-240X70` · offen) |
| 3:1 | Rechteck | 21 × 7 cm (`AS-RE-210X70` · offen), 27 × 9 cm (`AS-RE-270X90` · offen), 36 × 12 cm (`AS-RE-360X120` · offen), 45 × 15 cm (`AS-RE-450X150` · offen) |
| 15:8 | Oval | 15 × 8 cm (`AS-OV-150X80` · offen), 22,5 × 12 cm (`AS-OV-225X120` · offen), 30 × 16 cm (`AS-OV-300X160` · offen) |
| 3:2 | Rechteck | 15 × 10 cm (`AS-RE-150X100` · offen), 18 × 12 cm (`AS-RE-180X120` · offen), 24 × 16 cm (`AS-RE-240X160` · offen), 30 × 20 cm (`AS-RE-300X200` · offen), 36 × 24 cm (`AS-RE-360X240` · offen), 42 × 28 cm (`AS-RE-420X280` · offen) |
| 3:2 | Oval | 15 × 10 cm (`AS-OV-150X100` · offen), 18 × 12 cm (`AS-OV-180X120` · offen), 21 × 14 cm (`AS-OV-210X140` · offen), 24 × 16 cm (`AS-OV-240X160` · offen), 30 × 20 cm (`AS-OV-300X200` · offen) |
| 3:2 | Abgerundete Ecken R5 | 15 × 10 cm (`AS-R5-150X100` · offen), 18 × 12 cm (`AS-R5-180X120` · offen), 24 × 16 cm (`AS-R5-240X160` · offen), 30 × 20 cm (`AS-R5-300X200` · offen), 36 × 24 cm (`AS-R5-360X240` · offen), 42 × 28 cm (`AS-R5-420X280` · offen) |
| 3:2 | Eingezogene Ecken | 18 × 12 cm R11.6 (`AS-EE-180X120` · offen), 21 × 14 cm R13.5 (`AS-EE-210X140` · offen), 24 × 16 cm R15.5 (`AS-EE-240X160` · offen), 30 × 20 cm R19.3 (`AS-EE-300X200` · offen) |
| 1:1 | Rechteck | 16 × 16 cm (`AS-RE-160X160` · offen), 20 × 20 cm (`AS-RE-200X200` · offen), 26 × 26 cm (`AS-RE-260X260` · offen), 30 × 30 cm (`AS-RE-300X300` · offen) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |
| 2 Abstandshalter (`AH02-E10-D8`) | seitlich mittig | 2 | 8 | 10.0 | standoffs | offen |
| 2 Abstandshalter (`AH02-E15-D8`) | seitlich mittig | 2 | 8 | 15.0 | standoffs | offen |
| 4 Abstandshalter (`AH04-E10-D8`) | in den Ecken | 4 | 8 | 10.0 | standoffs | offen |
| 4 Abstandshalter (`AH04-E15-D8`) | in den Ecken | 4 | 8 | 15.0 | standoffs | offen |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Antic Slab, Bellefair, Cinzel, Roboto Slab, Aldrich, Audiowide, Comfortaa, Lato, Michroma, Minimalist, Raleway, Rounded Elegance, Archivo Black, Ashley Marie, Bebas Neue, Bernardo Moda Contrast, Chewy, Days One, Dream Orphans, Righteous, Alex Brush, Allura, Ashley, Betsy Bailey, Dancing Script, Great Vibes, Italianno, Magnolia Script, Parisienne, Rochester, Satisfy, Sweetie, Tangerine, Cookie, Courgette, Homage, Kaushan Script, Pacifico, Soulmate, Standlist, Bad Script, Caveat, Daniel, Daniel Black, Desyrel, Fineliner Script, Gloria Hallelujah, Rock Salt, Zentenar Fraktur, Fjalla One, Cormorant Garamond, Playfair Display, Libre Baskerville, Lora, Oswald, Roboto Condensed, Montserrat, Josefin Sans, Amatic SC, Kalam, Patrick Hand, Lobster, Sacramento, Special Elite, Courier Prime, Cinzel Decorative, Poiret One, Rye, Alfa Slab One, Stardos Stencil, Fredoka, Baloo 2, Uncial Antiqua, MedievalSharp, Permanent Marker

Hinweis: Randabstand der Bohrlöcher je Platte wie in der Corel-Zeichnung: 10 mm bei kleinen, 15 mm bei größeren Platten, aus optischen Gründen und damit die Platten unter Spannung hängen und nicht durchhängen (Nutzer, 17.10.2026). Nicht vereinheitlichen. Preise und Aufpreise offen. Schutzzone 1 mm vorläufig; Kopfdurchmesser der Abstandshalter noch nicht bekannt.

<a id="acryl-ss-abstandshalter"></a>
### Acrylglas schwarz satiniert 3 mm + Rückplatte schwarz (S/S)

Stammdaten: [`familien/acryl/acryl-ss-abstandshalter.json`](familien/acryl/acryl-ss-abstandshalter.json) · Material Acrylglas satiniert, Front, 3 mm, Verfahren `acrylic-engraving`, Gravur von vorn · Rückplatte: Rückplatte Acrylglas schwarz 3 mm, rundum 10 mm.
**Offen:** Aufpreis „2 Abstandshalter“; Aufpreis „4 Abstandshalter“; Grundpreis: alle 33 Größen; Form „eingezogene Ecken“ ist im Konfigurator noch nicht angeschlossen (Schablone und Katalog zeigen sie schon)

![Acrylglas schwarz satiniert 3 mm + Rückplatte schwarz (S/S)](kataloge/png/acryl-ss-abstandshalter.png)

Plattenkatalog: [kataloge/acryl-ss-abstandshalter.pdf](kataloge/acryl-ss-abstandshalter.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 3.43:1 | Rechteck | 24 × 7 cm (`SS-RE-240X70` · offen) |
| 3:1 | Rechteck | 21 × 7 cm (`SS-RE-210X70` · offen), 27 × 9 cm (`SS-RE-270X90` · offen), 36 × 12 cm (`SS-RE-360X120` · offen), 45 × 15 cm (`SS-RE-450X150` · offen) |
| 15:8 | Oval | 15 × 8 cm (`SS-OV-150X80` · offen), 22,5 × 12 cm (`SS-OV-225X120` · offen), 30 × 16 cm (`SS-OV-300X160` · offen) |
| 3:2 | Rechteck | 15 × 10 cm (`SS-RE-150X100` · offen), 18 × 12 cm (`SS-RE-180X120` · offen), 24 × 16 cm (`SS-RE-240X160` · offen), 30 × 20 cm (`SS-RE-300X200` · offen), 36 × 24 cm (`SS-RE-360X240` · offen), 42 × 28 cm (`SS-RE-420X280` · offen) |
| 3:2 | Oval | 15 × 10 cm (`SS-OV-150X100` · offen), 18 × 12 cm (`SS-OV-180X120` · offen), 21 × 14 cm (`SS-OV-210X140` · offen), 24 × 16 cm (`SS-OV-240X160` · offen), 30 × 20 cm (`SS-OV-300X200` · offen) |
| 3:2 | Abgerundete Ecken R5 | 15 × 10 cm (`SS-R5-150X100` · offen), 18 × 12 cm (`SS-R5-180X120` · offen), 24 × 16 cm (`SS-R5-240X160` · offen), 30 × 20 cm (`SS-R5-300X200` · offen), 36 × 24 cm (`SS-R5-360X240` · offen), 42 × 28 cm (`SS-R5-420X280` · offen) |
| 3:2 | Eingezogene Ecken | 18 × 12 cm R11.6 (`SS-EE-180X120` · offen), 21 × 14 cm R13.5 (`SS-EE-210X140` · offen), 24 × 16 cm R15.5 (`SS-EE-240X160` · offen), 30 × 20 cm R19.3 (`SS-EE-300X200` · offen) |
| 1:1 | Rechteck | 16 × 16 cm (`SS-RE-160X160` · offen), 20 × 20 cm (`SS-RE-200X200` · offen), 26 × 26 cm (`SS-RE-260X260` · offen), 30 × 30 cm (`SS-RE-300X300` · offen) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |
| 2 Abstandshalter (`AH02-E10-D8`) | seitlich mittig | 2 | 8 | 10.0 | standoffs | offen |
| 2 Abstandshalter (`AH02-E15-D8`) | seitlich mittig | 2 | 8 | 15.0 | standoffs | offen |
| 4 Abstandshalter (`AH04-E10-D8`) | in den Ecken | 4 | 8 | 10.0 | standoffs | offen |
| 4 Abstandshalter (`AH04-E15-D8`) | in den Ecken | 4 | 8 | 15.0 | standoffs | offen |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Antic Slab, Bellefair, Cinzel, Roboto Slab, Aldrich, Audiowide, Comfortaa, Lato, Michroma, Minimalist, Raleway, Rounded Elegance, Archivo Black, Ashley Marie, Bebas Neue, Bernardo Moda Contrast, Chewy, Days One, Dream Orphans, Righteous, Alex Brush, Allura, Ashley, Betsy Bailey, Dancing Script, Great Vibes, Italianno, Magnolia Script, Parisienne, Rochester, Satisfy, Sweetie, Tangerine, Cookie, Courgette, Homage, Kaushan Script, Pacifico, Soulmate, Standlist, Bad Script, Caveat, Daniel, Daniel Black, Desyrel, Fineliner Script, Gloria Hallelujah, Rock Salt, Zentenar Fraktur, Fjalla One, Cormorant Garamond, Playfair Display, Libre Baskerville, Lora, Oswald, Roboto Condensed, Montserrat, Josefin Sans, Amatic SC, Kalam, Patrick Hand, Lobster, Sacramento, Special Elite, Courier Prime, Cinzel Decorative, Poiret One, Rye, Alfa Slab One, Stardos Stencil, Fredoka, Baloo 2, Uncial Antiqua, MedievalSharp, Permanent Marker

Hinweis: Randabstand der Bohrlöcher je Platte wie in der Corel-Zeichnung: 10 mm bei kleinen, 15 mm bei größeren Platten, aus optischen Gründen und damit die Platten unter Spannung hängen und nicht durchhängen (Nutzer, 17.10.2026). Nicht vereinheitlichen. Preise und Aufpreise offen. Schutzzone 1 mm vorläufig; Kopfdurchmesser der Abstandshalter noch nicht bekannt.

<a id="gedenktafel-30x20-acryl-anthrazit"></a>
### Gedenktafel 30 × 20 · Acrylglas anthrazit

Stammdaten: [`familien/acryl/gedenktafel-30x20-acryl-anthrazit.json`](familien/acryl/gedenktafel-30x20-acryl-anthrazit.json) · Material Acrylglas anthrazit, Stärke offen, Verfahren `acrylic-engraving`.
**Offen:** Materialstärke; Gestaltungsrand; Grundpreis: 30 × 20 cm

![Gedenktafel 30 × 20 · Acrylglas anthrazit](kataloge/png/gedenktafel-30x20-acryl-anthrazit.png)

Plattenkatalog: [kataloge/gedenktafel-30x20-acryl-anthrazit.pdf](kataloge/gedenktafel-30x20-acryl-anthrazit.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 3:2 | Rechteck | 30 × 20 cm (`GT-AA-RE-300X200` · offen) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Montserrat, Great Vibes, Cinzel, Cormorant Garamond, Allura, Lora, Parisienne, Josefin Sans, Dancing Script, Lora Italic, Caveat, Kalam, Oswald

Hinweis: Nur Größe 30 × 20 cm vom Nutzer genannt. Offen: Stärke (3 mm nur aus Bildname, nicht bestätigt), Ecken, Rand, Grundpreis, Bohrbilder mit Preisen. Produkterzeugung für Acryl-Gravurplatten noch nicht angeschlossen.

<a id="gedenktafel-30x20-acryl-schwarz"></a>
### Gedenktafel 30 × 20 · Acrylglas schwarz

Stammdaten: [`familien/acryl/gedenktafel-30x20-acryl-schwarz.json`](familien/acryl/gedenktafel-30x20-acryl-schwarz.json) · Material Acrylglas schwarz, Stärke offen, Verfahren `acrylic-engraving`.
**Offen:** Materialstärke; Gestaltungsrand; Grundpreis: 30 × 20 cm

![Gedenktafel 30 × 20 · Acrylglas schwarz](kataloge/png/gedenktafel-30x20-acryl-schwarz.png)

Plattenkatalog: [kataloge/gedenktafel-30x20-acryl-schwarz.pdf](kataloge/gedenktafel-30x20-acryl-schwarz.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 3:2 | Rechteck | 30 × 20 cm (`GT-AS-RE-300X200` · offen) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Montserrat, Great Vibes, Cinzel, Cormorant Garamond, Allura, Lora, Parisienne, Josefin Sans, Dancing Script, Lora Italic, Caveat, Kalam, Oswald

Hinweis: Nur Größe 30 × 20 cm vom Nutzer genannt. Offen: Stärke (3 mm nur aus Bildname, nicht bestätigt), Ecken, Rand, Grundpreis, Bohrbilder mit Preisen. Produkterzeugung für Acryl-Gravurplatten noch nicht angeschlossen.

<a id="gedenktafel-30x20-edelstahl"></a>
### Gedenktafel 30 × 20 · Edelstahl

Stammdaten: [`familien/edelstahl/gedenktafel-30x20-edelstahl.json`](familien/edelstahl/gedenktafel-30x20-edelstahl.json) · Material Edelstahl gebürstet, Stärke offen, Verfahren `steel-engraving`.
**Offen:** Materialstärke; Gestaltungsrand; Bohrbild „4 Bohrlöcher“: Durchmesser und Randabstand

![Gedenktafel 30 × 20 · Edelstahl](kataloge/png/gedenktafel-30x20-edelstahl.png)

Plattenkatalog: [kataloge/gedenktafel-30x20-edelstahl.pdf](kataloge/gedenktafel-30x20-edelstahl.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 3:2 | Rechteck | 30 × 20 cm (`GT-ES-RE-300X200` · 29,99 €) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |
| 4 Bohrlöcher (`B04-OFFEN`) | in den Ecken | 4 | offen | offen | – | 2,99 € |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Montserrat, Great Vibes, Cinzel, Cormorant Garamond, Allura, Lora, Parisienne, Josefin Sans, Dancing Script, Lora Italic, Caveat, Kalam, Oswald

Hinweis: Preise vom Nutzer (gravuru-shopify platform/sources/steel-builder/PREISE.md @ b564422): Platte 29,99 €, vier Bohrlöcher 2,99 €. Offen: Stärke, Gestaltungsrand, Bohrlochdurchmesser und Randabstand, Ecken (eckig angenommen). Motivaufpreis 1,00 € und Abstandshalter gehören nicht ins Familienmodell.

<a id="steel-door-signs"></a>
### Edelstahl-Türschilder

Stammdaten: [`familien/edelstahl/steel-door-signs.json`](familien/edelstahl/steel-door-signs.json) · Material Edelstahl gebürstet, 1.5 mm, Verfahren `steel-engraving`.
**Stammdaten vollständig.**

![Edelstahl-Türschilder](kataloge/png/steel-door-signs.png)

Plattenkatalog: [kataloge/steel-door-signs.pdf](kataloge/steel-door-signs.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 4:1 | Rechteck | 8 × 2 cm (`GR-ES-RE-80X20-T15` · 9,49 €) |
| 3:1 | Rechteck | 6 × 2 cm (`GR-ES-RE-60X20-T15` · 8,99 €), 7 × 2 cm (`GR-ES-RE-70X23P3-T15` · 8,99 €), 9 × 3 cm (`GR-ES-RE-90X30-T15` · 9,99 €), 12 × 4 cm (`GR-ES-RE-120X40-T15` · 13,99 €), 15 × 5 cm (`GR-ES-RE-150X50-T15` · 16,99 €), 18 × 6 cm (`GR-ES-RE-180X60-T15` · 22,99 €), 21 × 7 cm (`GR-ES-RE-210X70-T15` · 29,99 €), 24 × 8 cm (`GR-ES-RE-240X80-T15` · 32,99 €), 27 × 9 cm (`GR-ES-RE-270X90-T15` · 39,99 €) |
| 3:1 | Ellipse | 12 × 4 cm (`GR-ES-EL-120X40-T15` · 13,99 €), 15 × 5 cm (`GR-ES-EL-150X50-T15` · 16,99 €), 18 × 6 cm (`GR-ES-EL-180X60-T15` · 22,99 €), 21 × 7 cm (`GR-ES-EL-210X70-T15` · 29,99 €), 24 × 8 cm (`GR-ES-EL-240X80-T15` · 30,99 €), 27 × 9 cm (`GR-ES-EL-270X90-T15` · 36,99 €), 30 × 10 cm (`GR-ES-EL-300X100-T15` · 44,99 €) |
| 5:2 | Rechteck | 5 × 2 cm (`GR-ES-RE-50X20-T15` · 7,99 €) |
| 16:7 | Rechteck | 8 × 3,5 cm (`GR-ES-RE-80X35-T15` · 9,99 €), 12 × 5,25 cm (`GR-ES-RE-120X52P5-T15` · 17,99 €), 16 × 7 cm (`GR-ES-RE-160X70-T15` · 22,99 €), 24 × 10,5 cm (`GR-ES-RE-240X105-T15` · 37,99 €), 32 × 14 cm (`GR-ES-RE-320X140-T15` · 53,99 €), 40 × 17,5 cm (`GR-ES-RE-400X175-T15` · 87,99 €) |
| 15:8 | Oval | 15 × 8 cm (`GR-ES-OV-150X80-T15` · 21,99 €), 22,5 × 12 cm (`GR-ES-OV-225X120-T15` · 33,99 €), 30 × 16 cm (`GR-ES-OV-300X159P9-T15` · 59,99 €) |
| 1.50:1 | Rechteck | 8 × 5 cm (`GR-ES-RE-80X53P3-T15` · 13,99 €), 9 × 6 cm (`GR-ES-RE-90X60-T15` · 14,99 €), 12 × 8 cm (`GR-ES-RE-120X80-T15` · 19,99 €), 15 × 10 cm (`GR-ES-RE-150X100-T15` · 23,99 €), 18 × 12 cm (`GR-ES-RE-180X120-T15` · 29,99 €), 21 × 14 cm (`GR-ES-RE-210X140-T15` · 39,99 €), 24 × 16 cm (`GR-ES-RE-240X160-T15` · 49,99 €), 30 × 20 cm (`GR-ES-RE-300X200-T15` · 79,99 €), 42 × 28 cm (`GR-ES-RE-420X280-T15` · 109,99 €), 45 × 30 cm (`GR-ES-RE-450X300-T15` · 159,99 €) |
| 1.50:1 | Abgerundete Ecken R5 | 8 × 5 cm (`GR-ES-AB-80X53P3-T15` · 13,99 €), 9 × 6 cm (`GR-ES-AB-90X60-T15` · 14,99 €), 12 × 8 cm (`GR-ES-AB-120X80-T15` · 19,99 €), 15 × 10 cm (`GR-ES-AB-150X100-T15` · 23,99 €), 18 × 12 cm (`GR-ES-AB-180X120-T15` · 29,99 €), 21 × 14 cm (`GR-ES-AB-210X140-T15` · 39,99 €), 24 × 16 cm (`GR-ES-AB-240X160-T15` · 49,99 €), 30 × 20 cm (`GR-ES-AB-300X200-T15` · 79,99 €), 42 × 28 cm (`GR-ES-AB-420X280-T15` · 109,99 €), 45 × 30 cm (`GR-ES-AB-450X300-T15` · 159,99 €) |
| 3:2 | Oval | 9 × 6 cm (`GR-ES-OV-90X60-T15` · 14,99 €), 12 × 8 cm (`GR-ES-OV-120X80-T15` · 19,99 €), 15 × 10 cm (`GR-ES-OV-150X100-T15` · 23,99 €), 18 × 12 cm (`GR-ES-OV-180X120-T15` · 29,99 €), 21 × 14 cm (`GR-ES-OV-210X140-T15` · 39,99 €), 24 × 16 cm (`GR-ES-OV-240X160-T15` · 49,99 €), 30 × 20 cm (`GR-ES-OV-300X200-T15` · 79,99 €) |
| 3:2 | Retro 1 (eckig) | 9 × 6 cm (`GR-ES-RT1-90X60-T15` · 14,99 €), 12 × 8 cm (`GR-ES-RT1-120X80-T15` · 19,99 €), 15 × 10 cm (`GR-ES-RT1-150X100-T15` · 23,99 €), 18 × 12 cm (`GR-ES-RT1-180X120-T15` · 29,99 €), 21 × 14 cm (`GR-ES-RT1-210X140-T15` · 39,99 €), 24 × 16 cm (`GR-ES-RT1-240X160-T15` · 49,99 €), 30 × 20 cm (`GR-ES-RT1-300X200-T15` · 79,99 €) |
| 3:2 | Retro 2 (geschwungen) | 9 × 6 cm (`GR-ES-RT2-90X60-T15` · 14,99 €), 12 × 8 cm (`GR-ES-RT2-120X80-T15` · 19,99 €), 15 × 10 cm (`GR-ES-RT2-150X100-T15` · 23,99 €), 18 × 12 cm (`GR-ES-RT2-180X120-T15` · 29,99 €), 21 × 14 cm (`GR-ES-RT2-210X140-T15` · 39,99 €), 24 × 16 cm (`GR-ES-RT2-240X160-T15` · 49,99 €), 30 × 20 cm (`GR-ES-RT2-300X200-T15` · 79,99 €) |
| 1:1 | Rund | 6,5 × 6,5 cm (`GR-ES-R-65X65-T15` · 13,99 €), 8,5 × 8,5 cm (`GR-ES-R-85X85-T15` · 14,99 €), 12 × 12 cm (`GR-ES-R-120X120-T15` · 22,99 €), 16 × 16 cm (`GR-ES-R-160X160-T15` · 34,99 €), 20 × 20 cm (`GR-ES-R-200X200-T15` · 47,99 €) |
| 1:1 | Quadrat | 8 × 8 cm (`GR-ES-QU-80X80-T15` · 14,99 €), 10 × 10 cm (`GR-ES-QU-100X100-T15` · 19,99 €), 12 × 12 cm (`GR-ES-QU-120X120-T15` · 22,99 €), 16 × 16 cm (`GR-ES-QU-160X160-T15` · 34,99 €), 20 × 20 cm (`GR-ES-QU-200X200-T15` · 47,99 €), 26 × 26 cm (`GR-ES-QU-260X260-T15` · 79,99 €), 30 × 30 cm (`GR-ES-QU-300X300-T15` · 106,99 €) |

#### Konturformen aus der Zeichnung

Pfad und feste Lochmitten in mm aus der Familie; Bohrungen gelten für die gebohrten Befestigungen. Der Konfigurator verwendet diese Kontur mit Gestaltungsrand und Lochschutz.

| Größe | Kontur | Feste Lochmitten (x / y / Ø mm) |
| --- | --- | --- |
| GR-ES-RT1-90X60-T15 | ![9 × 6 cm](kataloge/konturen/GR-ES-RT1-90X60-T15.svg) | 6 / 30 / 4; 84 / 30 / 4 |
| GR-ES-RT1-120X80-T15 | ![12 × 8 cm](kataloge/konturen/GR-ES-RT1-120X80-T15.svg) | 6 / 40 / 4; 114 / 40 / 4 |
| GR-ES-RT1-150X100-T15 | ![15 × 10 cm](kataloge/konturen/GR-ES-RT1-150X100-T15.svg) | 6 / 50 / 4; 144 / 50 / 4 |
| GR-ES-RT1-180X120-T15 | ![18 × 12 cm](kataloge/konturen/GR-ES-RT1-180X120-T15.svg) | 8 / 60 / 4; 172 / 60 / 4 |
| GR-ES-RT1-210X140-T15 | ![21 × 14 cm](kataloge/konturen/GR-ES-RT1-210X140-T15.svg) | 8 / 70 / 4; 202 / 70 / 4 |
| GR-ES-RT1-240X160-T15 | ![24 × 16 cm](kataloge/konturen/GR-ES-RT1-240X160-T15.svg) | 8 / 80 / 4; 232 / 80 / 4 |
| GR-ES-RT1-300X200-T15 | ![30 × 20 cm](kataloge/konturen/GR-ES-RT1-300X200-T15.svg) | 8 / 100 / 4; 292 / 100 / 4 |
| GR-ES-RT2-90X60-T15 | ![9 × 6 cm](kataloge/konturen/GR-ES-RT2-90X60-T15.svg) | 7.995 / 30 / 4; 82.005 / 30 / 4 |
| GR-ES-RT2-120X80-T15 | ![12 × 8 cm](kataloge/konturen/GR-ES-RT2-120X80-T15.svg) | 10.66 / 40 / 4; 109.34 / 40 / 4 |
| GR-ES-RT2-150X100-T15 | ![15 × 10 cm](kataloge/konturen/GR-ES-RT2-150X100-T15.svg) | 13.325 / 50 / 4; 136.675 / 50 / 4 |
| GR-ES-RT2-180X120-T15 | ![18 × 12 cm](kataloge/konturen/GR-ES-RT2-180X120-T15.svg) | 15.99 / 60 / 4; 164.01 / 60 / 4 |
| GR-ES-RT2-210X140-T15 | ![21 × 14 cm](kataloge/konturen/GR-ES-RT2-210X140-T15.svg) | 18.655 / 70 / 4; 191.345 / 70 / 4 |
| GR-ES-RT2-240X160-T15 | ![24 × 16 cm](kataloge/konturen/GR-ES-RT2-240X160-T15.svg) | 21.32 / 80 / 4; 218.68 / 80 / 4 |
| GR-ES-RT2-300X200-T15 | ![30 × 20 cm](kataloge/konturen/GR-ES-RT2-300X200-T15.svg) | 26.65 / 100 / 4; 273.35 / 100 / 4 |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |
| Selbstklebend – glatte Flächen (`KGL`) | ohne Löcher | 0 | offen | offen | – | 2,99 € |
| Selbstklebend – raue Flächen (`KRA`) | ohne Löcher | 0 | offen | offen | – | 3,99 € |
| Mit 2 Bohrlöchern (`B02-E4-D4`) | seitlich mittig | 2 | 4 | 4 | – | 2,49 € |
| Mit 2 Schrauben (`B02S-E4-D4`) | seitlich mittig | 2 | 4 | 4 | screws | 2,69 € |
| Mit 2 Bohrlöchern (`B02-E6-D4`) | seitlich mittig | 2 | 4 | 6 | – | 2,49 € |
| Mit 2 Schrauben (`B02S-E6-D4`) | seitlich mittig | 2 | 4 | 6 | screws | 2,69 € |
| Mit 2 Bohrlöchern (`B02-E8-D4`) | seitlich mittig | 2 | 4 | 8 | – | 2,49 € |
| Mit 2 Schrauben (`B02S-E8-D4`) | seitlich mittig | 2 | 4 | 8 | screws | 2,69 € |
| Mit 4 Bohrlöchern (`B04-E8-D4`) | in den Ecken | 4 | 4 | 8 | – | 2,89 € |
| Mit 4 Schrauben (`B04S-E8-D4`) | in den Ecken | 4 | 4 | 8 | screws | 3,09 € |
| Mit 4 Bohrlöchern (`B04-E15-D4`) | in den Ecken | 4 | 4 | 15 | – | 2,89 € |
| Mit 4 Schrauben (`B04S-E15-D4`) | in den Ecken | 4 | 4 | 15 | screws | 3,09 € |
| Mit 4 Bohrlöchern (`B04-E10-D4`) | in den Ecken | 4 | 4 | 10 | – | 2,89 € |
| Mit 4 Schrauben (`B04S-E10-D4`) | in den Ecken | 4 | 4 | 10 | screws | 3,09 € |
| Mit 4 Bohrlöchern (`B04-E6-D4`) | in den Ecken | 4 | 4 | 6 | – | 2,89 € |
| Mit 4 Schrauben (`B04S-E6-D4`) | in den Ecken | 4 | 4 | 6 | screws | 3,09 € |
| Mit 2 Bohrlöchern (`B02-KONTUR`) | seitlich mittig | 2 | 4 | feste Lochmitten je Größe | – | 2,49 € |
| Mit 2 Schrauben (`B02S-KONTUR`) | seitlich mittig | 2 | 4 | feste Lochmitten je Größe | screws | 2,69 € |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Montserrat, Great Vibes, Cinzel, Cormorant Garamond, Allura, Lora, Parisienne, Josefin Sans, Dancing Script, Lora Italic, Caveat, Kalam, Oswald

Hinweis: Bohrbilder aus dem Altprojekt-Seed; Grundpreise mit Shopprodukt Variante C abgeglichen (0 Abweichungen). Nicht verfügbare Schriften weggelassen: keine · Serie 2027 (23.10.2026): Grundpreise aus der Excel von Chris (21.10.) übernommen, Rund (R) neu; Quelle zeichnungen/edelstahl-schilder-2027/geometrie.json (Excel-SHA 1c27161c5d77…, Zeichnung-SHA d5a021410ec2…); Retro 1/2 offen (Kontur im Schema v2 nicht abbildbar). Bericht familien/edelstahl/quellen/edelstahl-serie-2027-abgleich.md · Retro 1/2 als Kontur (23.10.2026): outlinePath und holesMm unverändert aus zeichnungen/edelstahl-schilder-2027/geometrie.json (Zeichnung-SHA d5a021410ec2…); 90×60 jeweils 1499 ct, übrige Retro-Preise offen. Befestigungsaufpreise aus bestehenden Familienregeln; Konfiguratoranschluss offen (Paket B). · 24.10.2026 (Chris): Retro I/II und Rund kosten je Größe dasselbe wie das normale Edelstahlschild gleicher Größe (Rechteck bzw. Quadrat); Rund 8,5 × 8,5 ohne gleiche Größe: 14,99 € wie 9 × 6 (Chris 24.10.2026).

<a id="gedenktafel-22x14-schiefer-hunde-2027"></a>
### Hunde-Gedenktafel 22 × 14 · Naturschiefer

Stammdaten: [`familien/schiefer/gedenktafel-22x14-schiefer-hunde-2027.json`](familien/schiefer/gedenktafel-22x14-schiefer-hunde-2027.json) · Material Naturschiefer, natürliche Bruchkante, helle Gravur, 5 mm, Verfahren `slate-engraving`.
**Stammdaten vollständig.**

![Hunde-Gedenktafel 22 × 14 · Naturschiefer](kataloge/png/gedenktafel-22x14-schiefer-hunde-2027.png)

Plattenkatalog: [kataloge/gedenktafel-22x14-schiefer-hunde-2027.pdf](kataloge/gedenktafel-22x14-schiefer-hunde-2027.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 11:7 | Rechteck | 22 × 14 cm (`GT-SN-RE-220X140` · 25,99 €) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |
| 2 Bohrlöcher ohne Schrauben (`B02-E12-D5`) | seitlich mittig | 2 | 4 | 19 | – | 3,09 € |
| 2 Bohrlöcher mit Schrauben (`B02S-E12-D5`) | seitlich mittig | 2 | 4 | 19 | screws | 3,39 € |
| 4 Bohrlöcher ohne Schrauben (`B04-E12-D5`) | in den Ecken | 4 | 4 | 19 | – | 3,99 € |
| 4 Bohrlöcher mit Schrauben (`B04S-E12-D5`) | in den Ecken | 4 | 4 | 19 | screws | 4,49 € |
| 2 Abstandshalter · Kopf Ø 12 mm · Bohrung Ø 8 mm (`AH02-E12-D5`) | seitlich mittig | 2 | 8 | 19 | standoffs | 5,99 € |
| Acrylständer klar (`ST-KLAR`) | ohne Löcher | 0 | offen | offen | – | 11,99 € |
| Acrylständer schwarz (`ST-SCHWARZ`) | ohne Löcher | 0 | offen | offen | – | 13,99 € |
| Silikon 40 ml zum Aufkleben (`SIL-40`) | ohne Löcher | 0 | offen | offen | – | 5,99 € |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Allura, Great Vibes, Tangerine, Cinzel, Bellefair, Libre Baskerville, Cormorant Garamond, Lato, Montserrat Light, Poppins ExtraLight, Arvo, Homage, Betsy Bailey, Ashley, Sweetie, Desyrel, Michroma

Hinweis: Bestätigte Hunde-Serie (Festlegungen.json, 21.10.2026): Normalbohrungen Ø4, Halterbohrungen Ø8, Lochmitte 19 mm vom Rand; Halterkopf Ø12. Bestehende Regelkennungen bleiben als Referenzen erhalten und sind keine Maßangabe. Abweichende ältere Tierfamilie bleibt unverändert. 48 Zubehörkombinationen sind im Serienplan dokumentiert; die einfache Familienauswahl ist kein vollständiger Kundenanschluss.

<a id="gedenktafel-22x14-schiefer-natur"></a>
### Gedenktafel 22 × 14 · Naturschiefer (helle Gravur)

Stammdaten: [`familien/schiefer/gedenktafel-22x14-schiefer-natur.json`](familien/schiefer/gedenktafel-22x14-schiefer-natur.json) · Material Naturschiefer, natürliche Bruchkante, helle Gravur, 5 mm, Verfahren `slate-engraving`.
**Stammdaten vollständig.**

![Gedenktafel 22 × 14 · Naturschiefer (helle Gravur)](kataloge/png/gedenktafel-22x14-schiefer-natur.png)

Plattenkatalog: [kataloge/gedenktafel-22x14-schiefer-natur.pdf](kataloge/gedenktafel-22x14-schiefer-natur.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 11:7 | Rechteck | 22 × 14 cm (`GT-SN-RE-220X140` · 25,99 €) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |
| 2 Bohrlöcher ohne Schrauben (`B02-E12-D5`) | seitlich mittig | 2 | 5 | 12 | – | 2,99 € |
| 2 Bohrlöcher mit Schrauben (`B02S-E12-D5`) | seitlich mittig | 2 | 5 | 12 | screws | 3,39 € |
| 4 Bohrlöcher ohne Schrauben (`B04-E12-D5`) | in den Ecken | 4 | 5 | 12 | – | 3,99 € |
| 4 Bohrlöcher mit Schrauben (`B04S-E12-D5`) | in den Ecken | 4 | 5 | 12 | screws | 4,49 € |
| 2 Abstandshalter Ø 8 mm Edelstahlknopf (`AH02-E12-D5`) | seitlich mittig | 2 | 5 | 12 | standoffs | 5,99 € |
| Acrylständer klar (`ST-KLAR`) | ohne Löcher | 0 | offen | offen | – | 11,99 € |
| Acrylständer schwarz (`ST-SCHWARZ`) | ohne Löcher | 0 | offen | offen | – | 13,99 € |
| Silikon 40 ml zum Aufkleben (`SIL-40`) | ohne Löcher | 0 | offen | offen | – | 5,99 € |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Allura, Great Vibes, Tangerine, Cinzel, Bellefair, Libre Baskerville, Cormorant Garamond, Lato, Montserrat Light, Poppins ExtraLight, Arvo, Homage, Betsy Bailey, Ashley, Sweetie, Desyrel, Michroma

Hinweis: Auftrag Chris 20.10.2026: Grundpreis 25,99 € inkl. 1. Foto · weiteres Foto 8,99 € · 2/4 Bohrlöcher mit Schrauben 3,39/4,49 € · 2/4 Bohrlöcher ohne Schrauben (Chris: „Bohrlöcher auch ohne Schrauben“) 2,99/3,99 € – Preis aus Familie 30 × 20 Naturschiefer übernommen, Chris 20.10.2026: „alles fertig machen“ · 2 Abstandshalter Ø 8 mm Edelstahlknopf 5,99 € · Acrylständer klar 11,99 € / schwarz 13,99 € · Silikon 40 ml 5,99 € · Staffel ab 2 St. −6 %, ab 3 St. −10 %. Von Chris bestätigt (20.10.2026): Stärke 5 mm, Gestaltungsrand 0 mm (die Corel-Vorlagen gestalten bis an den Plattenrand), Bohrbild Ø 5 mm / 12 mm, Abstandshalter-Maß 12 mm, Freistellen kostenlos. Keine Kombinationen (Ständer/Silikon ersetzen die Bohrung; bei Bedarf später eigene Optionsgruppe).

<a id="gedenktafel-30x20-schiefer-natur"></a>
### Gedenktafel 30 × 20 · Naturschiefer

Stammdaten: [`familien/schiefer/gedenktafel-30x20-schiefer-natur.json`](familien/schiefer/gedenktafel-30x20-schiefer-natur.json) · Material Naturschiefer, natürliche Bruchkante, 5 mm, Verfahren `slate-engraving`.
**Stammdaten vollständig.**

![Gedenktafel 30 × 20 · Naturschiefer](kataloge/png/gedenktafel-30x20-schiefer-natur.png)

Plattenkatalog: [kataloge/gedenktafel-30x20-schiefer-natur.pdf](kataloge/gedenktafel-30x20-schiefer-natur.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 3:2 | Rechteck | 30 × 20 cm (`GT-SN-RE-300X200` · 29,99 €) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |
| 2 Bohrlöcher Ø 5 mm (`B02-E12-D5`) | seitlich mittig | 2 | 5 | 12 | – | 2,99 € |
| 4 Bohrlöcher Ø 5 mm (`B04-E12-D5`) | in den Ecken | 4 | 5 | 12 | – | 3,99 € |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Montserrat, Great Vibes, Cinzel, Cormorant Garamond, Allura, Lora, Parisienne, Josefin Sans, Dancing Script, Lora Italic, Caveat, Kalam, Oswald

Hinweis: Übernommen aus app/configurator/variant-m/fixtures/native-profile.json („Hunde-Gedenktafel Schiefer 30 × 20 cm“): 5 mm, Rand 10 mm, Grundpreis 29,99 €, B02 Ø 5 mm/12 mm 2,99 €, B04 Ø 5 mm/12 mm 3,99 €. Werte bitte mit der Stammdaten-Excel bestätigen. Zubehör (Acrylständer, Silikon, Abstandshalter) noch nicht im Familienmodell.

<a id="gedenktafel-30x20-schiefer-premium"></a>
### Gedenktafel 30 × 20 · Premium-Schiefer

Stammdaten: [`familien/schiefer/gedenktafel-30x20-schiefer-premium.json`](familien/schiefer/gedenktafel-30x20-schiefer-premium.json) · Material Premium-Schiefer, Stärke offen, Verfahren `slate-engraving`.
**Offen:** Materialstärke; Gestaltungsrand; Grundpreis: 30 × 20 cm

![Gedenktafel 30 × 20 · Premium-Schiefer](kataloge/png/gedenktafel-30x20-schiefer-premium.png)

Plattenkatalog: [kataloge/gedenktafel-30x20-schiefer-premium.pdf](kataloge/gedenktafel-30x20-schiefer-premium.pdf)

| Formatreihe | Form | Größen (SKU-Schlüssel · Grundpreis) |
| --- | --- | --- |
| 3:2 | Rechteck | 30 × 20 cm (`GT-SP-RE-300X200` · offen) |

| Bohrbild | Lage | Löcher | Ø | Randabstand | Zubehör | Aufpreis |
| --- | --- | --- | --- | --- | --- | --- |

Optionen (Zubehör/Varianten): noch keine hinterlegt – Blatt „Optionen“ der Stammdaten-Excel.

Schriften: Montserrat, Great Vibes, Cinzel, Cormorant Garamond, Allura, Lora, Parisienne, Josefin Sans, Dancing Script, Lora Italic, Caveat, Kalam, Oswald

Hinweis: Nur Größe 30 × 20 cm vom Nutzer genannt. Offen: Stärke, Kante/Rand, Grundpreis, Bohrbilder mit Preisen.


Stammdaten-Excel (alle Familien): [kataloge/Stammdaten-Gravuru.xlsx](kataloge/Stammdaten-Gravuru.xlsx)
