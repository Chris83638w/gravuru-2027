# Separate Testbereitstellung

Stand: 25.09.2026. Öffentlich ohne Anmeldung erreichbar und im Browser geprüft.

- Quellbasis: `4f4abe35ba2e975cc5fb9b85a99027bbe1936445`.
- Aufgabenbranch: `feat/variante-m-profile-20260924`.
- Projekt: `gravuru-konfigurator-test`, bestehendes Netlify-Team `chrck82`.
- Site-ID: `9bf27be0-ba8c-4bf6-b833-c9fe743c38ff`.
- Adresse: https://gravuru-konfigurator-test.netlify.app/
- Deploy-ID: `6ab63538f8ea0e911bb60825`, Netlify meldet `ready`.
- Deploydetails: https://app.netlify.com/sites/9bf27be0-ba8c-4bf6-b833-c9fe743c38ff/deploys/6ab63538f8ea0e911bb60825

## Paket

`node configurator/variant-m/export-public.mjs` erzeugt einen neuen, eindeutigen
Ordner unter `.public-preview/` und daneben ein SHA-256-Manifest. Kein Löschen
älterer Ordner erforderlich. Nur diesen ausgegebenen Site-Ordner hochladen.

91 Dateien, 21.205.100 Bytes, 20 Browsermodule. Enthalten sind der bestehende
Editor, sechs Modelle, seine importierten Browsermodule, Stile und geprüften
Bild-/Motiv-/Schriftressourcen. Kein Repository, Server, Tests, Credentials oder
Kundenbilder. 104 Referenzressourcen vor Export geprüft. Alle 91 Exporthashes
und 38 eingebetteten Runtime-URL-Ziele geprüft. Syntax und Git-Diff-Prüfung bestanden.

Statische Netlify-Konfiguration: Publish-Verzeichnis `.`, keine Serverfunktionen.
`/api/guides` wird auf die bestehende statische Hilfe umgeschrieben. Modul-MIME,
lokale Content-Security-Policy und `noindex`/robots-Ausnahme für die Testseite.
Der Testhinweis steht auf der Startseite, nicht zusätzlich über dem Canvas.
Quellen: https://docs.netlify.com/manage/routing/headers/ und
https://docs.netlify.com/manage/routing/redirects/rewrites-proxies/.

Deployment über den verbundenen Netlify-MCP-Bereitstellungsweg; ausführendes
Paket `@netlify/mcp` 1.15.1. Temporäre Uploadberechtigung nicht speichern.
Keine Kontospeicherung, Bestellstrecke, Kundenfoto-Server oder externe KI verbunden.

## Öffentlicher Nachweis

Das neue Projekt war zunächst durch Netlify-Team-Login geschützt (HTTP 401).
Nach Ablehnung der Zugriffsänderung durch die automatische Freigabeprüfung hat
Christopher selbst „Make public“ ausgeführt und dies mit „hab ich“ bestätigt.
Keine Umgehung durch Codex; keine weitere Änderung der Zugriffsrechte erforderlich.

Danach anonym, ohne Cookies oder Authorization, frisch geprüft: `/`,
`/editor.html`, `/models.json` und `/api/guides` jeweils HTTP 200.
In einem neuen In-App-Browser-Tab ohne Netlify-Anmeldung geprüft:

- Startseite mit sechs Produkten/Profilen, Personalisieren öffnet den Editor.
- AOSU startet mit Optionen und ohne ausgewähltes Objekt.
- Zeile 2 auf „Testfamilie“ geändert, Vorschau sichtbar aktualisiert; Plus setzt
  die Schriftgröße auf 13 mm.
- Vorhandenes nicht privates AOSU-Testbild ausgewählt: Miniatur und Bild auf dem
  Schild sichtbar, Status „Bild übernommen“, Preis von 49,99 auf 59,98 EUR.
- Hilfe öffnet „Fotos & Logos“; mobile Ansicht 390 × 844 und Vollbild öffnen.
- Keine erfassten Browser-Konsolenfehler; nach Prüfung Testdaten durch Neuladen
  verworfen, temporäre Mobilgröße zurückgesetzt.

Grenzen: Funktionsstichprobe mit AOSU, kein vollständiger öffentlicher Test aller
Profile und kein physischer Smartphone-Nachweis. Netlify blendet ein eigenes
Badge unten rechts ein; dieses überlagert insbesondere mobil einen Teil der
ohnehin deaktivierten Warenkorbschaltfläche. Vor einer Verkaufsversion klären.
Dauerhaftes Speichern und Bestellungen bleiben unverbunden. Andere Projekte,
Shopify, Plesk und Main wurden durch Codex nicht geändert.

