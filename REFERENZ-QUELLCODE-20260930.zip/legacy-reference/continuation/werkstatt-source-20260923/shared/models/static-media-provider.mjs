import {createMediaClient} from './media-client.mjs';

const fields=['mediaId','revisionId','label','role','mimeType','byteLength','sha256','width','height','previewable'];
const roles=new Set(['thumbnail','amazon-overlay','product-preview']);
const roleFilters=new Set([...roles,'original-photo','photo-mask','mounting-diagram','original-vector','production-vector','font']);
const id=/^media-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const revision=/^revision-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const key=item=>item.mediaId+'/'+item.revisionId;
function validateCatalog(value){
 if(!value||value.schema!=='gravuru-static-media/v1'||!Array.isArray(value.items)||value.items.length>1000)throw Error('Veröffentlichter Medienkatalog ist ungültig.');
 const keys=new Set();
 return value.items.map(item=>{
  if(!item||Object.keys(item).some(k=>!fields.includes(k))||!id.test(item.mediaId)||!revision.test(item.revisionId)||typeof item.label!=='string'||!item.label.trim()||item.label.length>200||/[\x00-\x1f]/.test(item.label)||!roles.has(item.role)||item.mimeType!=='image/png'||item.previewable!==true||!Number.isSafeInteger(item.width)||item.width<1||!Number.isSafeInteger(item.height)||item.height<1||item.width*item.height>64000000||!Number.isSafeInteger(item.byteLength)||item.byteLength<1||item.byteLength>50*1024*1024||!/^[a-f0-9]{64}$/.test(item.sha256)||keys.has(key(item)))throw Error('Veröffentlichte Medienbeschreibung ist ungültig.');
  keys.add(key(item));return Object.fromEntries(fields.map(k=>[k,item[k]]));
 });
}
/** Static, public product images only. No token, server fixture, or eager image fetch. */
export function createStaticMediaProvider({base='./media',fetcher=fetch,createUrl,revokeUrl}={}){
 if(typeof base!=='string'||! /^(?:\.\/)?[a-zA-Z0-9_-]+(?:\/[a-zA-Z0-9_-]+)*$/.test(base))throw Error('Statische Medien benötigen einen relativen Pfad zur eigenen Anwendung.');
 const prefix=base.replace(/^\.\//,'');let catalogJob;
 async function hosted(filename,options){
  const target=prefix+'/'+filename,response=await fetcher(target,{...options,credentials:'same-origin',redirect:'error'});
  const baseURI=globalThis.document?.baseURI||globalThis.location?.href;
  if(response.redirected||response.url&&baseURI&&new URL(response.url).href!==new URL(target,baseURI).href)throw Error('Medien dürfen nicht auf eine andere Adresse weiterleiten.');
  return response;
 }
 async function catalog(options){
  if(!catalogJob)catalogJob=(async()=>{
   const response=await hosted('catalog.json',options);if(!response.ok)throw Error('Medienkatalog konnte nicht geladen werden.');
   const type=response.headers.get('content-type')?.split(';')[0];if(type!=='application/json')throw Error('Medienkatalog besitzt ein unerwartetes Format.');
   return validateCatalog(await response.json());
  })().catch(error=>{catalogJob=null;throw error;});
  return catalogJob;
 }
 const json=value=>new Response(JSON.stringify(value),{headers:{'content-type':'application/json'}});
 async function bridge(url,options){
  const request=new URL(url,'https://static.invalid');
  if(request.origin!=='https://static.invalid'||!request.pathname.startsWith('/static-media'))throw Error('Unzulässige Medienanfrage.');
  const items=await catalog(options),tail=request.pathname.slice('/static-media'.length);
  if(!tail){
   for(const k of request.searchParams.keys())if(!['search','role','kind','limit','offset'].includes(k))throw Error('Unbekannter Medienfilter.');
   const search=request.searchParams.get('search')||'',role=request.searchParams.get('role')||'',kind=request.searchParams.get('kind')||'all';
   const number=(name,fallback)=>{const raw=request.searchParams.get(name);if(raw!==null&&!/^\d+$/.test(raw))throw Error('Ungültige Medienseite.');return raw===null?fallback:Number(raw);};
   const limit=number('limit',24),offset=number('offset',0);
   if(search.length>200||/[\x00-\x1f]/.test(search)||role&&!roleFilters.has(role)||!['all','image','font','vector','document'].includes(kind)||limit<1||limit>100||offset>1000000)throw Error('Ungültiger Medienfilter.');
   const filtered=items.filter(item=>['all','image'].includes(kind)&&(!role||item.role===role)&&item.label.toLocaleLowerCase('de-DE').includes(search.trim().toLocaleLowerCase('de-DE')));
   return json({items:filtered.slice(offset,offset+limit),total:filtered.length,hasMore:offset+limit<filtered.length});
  }
  const content=tail.endsWith('/content'),ref=tail.slice(1,content?-'/content'.length:undefined),item=items.find(item=>key(item)===ref);
  if(!item)throw Error('Diese Medienrevision gehört nicht zum veröffentlichten Katalog.');
  return content?hosted(item.sha256+'.png',options):json(item);
 }
 return createMediaClient({base:'/static-media',fetcher:bridge,...(createUrl?{createUrl}:{}),...(revokeUrl?{revokeUrl}:{})});
}
