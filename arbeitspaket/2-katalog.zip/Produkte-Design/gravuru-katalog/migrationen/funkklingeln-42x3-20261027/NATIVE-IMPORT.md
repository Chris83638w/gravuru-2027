# Nativer Import

Dieses Datenpaket ist für `migrationen/funkklingeln-42x3-20261027/` im Katalog vorgesehen. Das eigene versionierte Schema beschreibt die überlagerten Funkklingelschilder; es behauptet keine Kompatibilität mit `family-v2`.

Der ausführbare Adapter gehört in das Code-Repository: `scripts/import-doorbell-catalog.mjs`. Er liest und prüft die Quellen, übernimmt Originaldekorationen durch den vorhandenen SVG-Assetimport und validiert alle 126 nativen Produkte. Standard ist ein Dryrun mit isolierter Assetablage. Der ausdrückliche Schreibmodus benötigt getrennte Datenbankpfade. Er aktiviert keine Produkte und ändert Shopify nicht; die spätere, revisionsgebundene Veröffentlichung bleibt Aufgabe des regulären Veröffentlichungswegs.

Die 30 ursprünglichen Schriften und 703 Motive werden über die bereits vorhandene Ressourcenbibliothek aufgelöst. `legacy-resources-index.json` enthält die SHA-256-Werte der 735 unveränderten Bibliotheksdateien inklusive beider Indizes. Die 176 weiteren Originaldateien bleiben unter `sources/` erhalten. `resource-provenance.json` dokumentiert vorhandene Katalog- und Archivnachweise, ohne neue Lizenzen zu behaupten. Für sechs Schriften fehlt in den untersuchten Nachweisen eine individuelle Zuordnung; auch für die Motive liegt dort keine vollständige individuelle Rechtematrix vor.

`device-index.json` bindet 42 Originalgerätebilder an `devices/<sha256>.webp`. Die Dateien sind bytegleich mit den ursprünglichen PDF-Extraktionen. Die native Vorschau nutzt dafür ausschließlich `/doorbell-assets/<sha256>.webp`; die Fertigungsdaten verwenden weiterhin die ursprünglichen Vektorausschnitte. Eine Bilddatei wird von den drei Hauptprodukteinstiegen desselben Modells gemeinsam verwendet.

Die Python-Dateien in diesem lokalen Stagingordner dokumentieren die einmalige Aufbereitung. Sie gehören nicht in das Katalog-Repository. Der produktive, reproduzierbare Importer und seine Tests gehören in das Code-Repository. `native-inputs/` sind ausdrücklich Adaptereingaben, keine freigegebenen Laufzeitkonfigurationen. Historische Freigabeflags in den Quellen gelten nicht als Abnahme für die neue Laufzeit.
