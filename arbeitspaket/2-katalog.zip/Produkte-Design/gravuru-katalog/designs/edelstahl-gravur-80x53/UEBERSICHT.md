# Rechteckig ab 8x5 – Lieferform 2 (edelstahl-gravur-80x53)

Quelle: Bögen TRE-V2A-8x5, TRE-V2A-9x6, TRE-V2A-12x8, TRE-V2A-15x10, TRE-V2A-18x12, TRE-V2A-21x14, TRE-V2A-24x16, TRE-V2A-30x20, TRE-V2A-42x28, TRE-V2A-45x30 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**73 Designs**, davon 2 mit Produktionsfassung, 7 mit Themenvorschlag (unsicher), 3 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TRE-V2A-8x5 | GR-ES-RE-80X53P3-T15 | 69 | 4 | 2 | 1 |
| TRE-V2A-9x6 | GR-ES-RE-90X60-T15 | 72 | 1 | 2 | 2 |
| TRE-V2A-12x8 | GR-ES-RE-120X80-T15 | 72 | 1 | 2 | 2 |
| TRE-V2A-15x10 | GR-ES-RE-150X100-T15 | 72 | 1 | 2 | 2 |
| TRE-V2A-18x12 | GR-ES-RE-180X120-T15 | 72 | 1 | 1 | 3 |
| TRE-V2A-21x14 | GR-ES-RE-210X140-T15 | 72 | 1 | 0 | 3 |
| TRE-V2A-24x16 | GR-ES-RE-240X160-T15 | 73 | 0 | 1 | 3 |
| TRE-V2A-30x20 | GR-ES-RE-300X200-T15 | 73 | 0 | 1 | 0 |
| TRE-V2A-42x28 | GR-ES-RE-420X280-T15 | 72 | 1 | 0 | 0 |
| TRE-V2A-45x30 | GR-ES-RE-450X300-T15 | 72 | 1 | 0 | 0 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TRE-V2A-8x5-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D2 | Zwei Zeilen, versetzt | D2 Niedermeier | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D3 | Zwei Zeilen mit Trennlinie | D3 Schäfer | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D6 | Familie mit Anker | D6 Erdmann | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D7 | Hier wohnt Familie mit Segelboot | D7 Fischer | familienschilder, namensschilder |  | 10 |  | Great Vibes, Montserrat Light |  |  |
| TRE-V2A-8x5-D8 | Zwei Vornamen und Nachname mit Leuchtturm und Adresse | D8 Meyer | familienschilder, namensschilder |  | 10 |  | Ashley, Cinzel, Raleway | ja | Beispieltext enthält eine Adresse (drittes Textfeld); „Heimathafen …“: Zeilenabstand 5.2 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Produktionsfassung: „Heimathafen …“: Zeilenabstand 5.2 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Produktionsfassung auch auf TRE-V2A-9x6, TRE-V2A-12x8, TRE-V2A-15x10, TRE-V2A-18x12, TRE-V2A-24x16 |
| TRE-V2A-8x5-D9 | Vor- und Nachname mit Leuchtturm | D9 Groner | familienschilder, namensschilder |  | 10 |  | Homage, Raleway |  |  |
| TRE-V2A-8x5-D10 | Zwei Vornamen und Nachname mit Laubbaum und Spruch | D10 Altmann | familienschilder, namensschilder |  | 10 |  | Comfortaa, Homage |  |  |
| TRE-V2A-8x5-D11 | Vor- und Nachname mit Pusteblume, Handschrift | D11 Bellini | familienschilder, namensschilder |  | 10 |  | Sweetie |  |  |
| TRE-V2A-8x5-D12 | Herzlich Willkommen bei Familie mit Pusteblume | D12 Bohlmann | familienschilder, namensschilder, willkommensschilder |  | 10 |  | Homage, Raleway |  |  |
| TRE-V2A-8x5-D13 | Familie mit Pusteblume, Serifenschrift | D13 Neumann | familienschilder, namensschilder |  | 10 |  | Cinzel, Homage |  |  |
| TRE-V2A-8x5-D14 | Familie mit Blumenwiese und Adresse | D14 Wagner | familienschilder, namensschilder |  | 10 |  | Ashley, Libre Baskerville |  | Beispieltext enthält eine Adresse (drittes Textfeld) |
| TRE-V2A-8x5-D15 | Herzlich Willkommen bei Familie mit Blumenwiese | D15 Familie Kuhlmann | familienschilder, namensschilder, willkommensschilder |  | 10 |  | Homage, Raleway | ja | Produktionsfassung auch auf TRE-V2A-9x6, TRE-V2A-12x8, TRE-V2A-15x10, TRE-V2A-30x20 |
| TRE-V2A-8x5-D16 | Willkommen bei Vor- und Nachname mit Rose | D16 Laura | familienschilder, namensschilder, willkommensschilder |  | 10 |  | Libre Baskerville |  |  |
| TRE-V2A-8x5-D17 | Hier wohnt Familie mit Blütenranke | D17 Schneider | familienschilder, namensschilder |  | 10 |  | Cinzel, Italianno |  |  |
| TRE-V2A-8x5-D18 | Zwei Namen mit Pusteblume | D18 Felix Becker | familienschilder, namensschilder |  | 10 |  | Allura |  |  |
| TRE-V2A-8x5-D19 | Herzlich Willkommen bei Vor- und Nachname mit Rose | D19 Ursel Mayer | familienschilder, namensschilder, willkommensschilder |  | 10 |  | Bellefair, Great Vibes |  |  |
| TRE-V2A-8x5-D20 | Familie mit Lebensbaum, Serifenschrift | D20 Familie | familienschilder, namensschilder |  | 10 |  | Libre Baskerville |  |  |
| TRE-V2A-8x5-D21 | Familie mit Sonne, Spruch und Vornamen | D21 Familie Lehmann | familienschilder, namensschilder |  | 10 |  | Comic Sans MS, Daniel |  | „Hier leben, …“: Zeilenabstand 7.0 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Schrift ohne Datei im Katalog: Comic Sans MS; Schrift ohne Datei im Katalog: Comic Sans MS |
| TRE-V2A-8x5-D22 | Familie mit Haus-Skizze und Spruch | D22 Schmittberger | familienschilder, namensschilder |  | 10 |  | Dancing Script, Libre Baskerville |  |  |
| TRE-V2A-8x5-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 10 |  | Rochester |  |  |
| TRE-V2A-8x5-D24 | Zuhause von Familie mit Haus und Herz | D24 Zuhause von | familienschilder, namensschilder |  | 10 |  | Homage, Raleway |  |  |
| TRE-V2A-8x5-D25 | Hier wohnt Familie mit Haus, Herz und Gründungsjahr | D25 Goldmann | familienschilder, namensschilder |  | 10 |  | Allura, Cinzel |  |  |
| TRE-V2A-8x5-D26 | Vor- und Nachname mit Glocke | D26 Zimmermann | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D27 | Zwei Vornamen und Nachname mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D28 | Vor- und Nachname mit Fußball | D28 Schulze | familienschilder, namensschilder |  | 10 |  | Michroma |  |  |
| TRE-V2A-8x5-D29 | Familie mit Hundewelpe und Hundename, Serifenschrift | D29 Trautmann | familienschilder, namensschilder, hundeschilder |  | 10 |  | Libre Baskerville |  |  |
| TRE-V2A-8x5-D30 | Familie mit Hundekopf und Hundename | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 10 |  | Raleway |  |  |
| TRE-V2A-8x5-D31 | Zuhause von Familie mit Hund-Silhouette | D31 Familie Fischer | familienschilder, namensschilder, hundeschilder |  | 10 |  | Ashley, Cinzel |  |  |
| TRE-V2A-8x5-D32 | Familie mit Pfote und Hundename, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 10 |  | Homage, Michroma |  |  |
| TRE-V2A-8x5-D33 | Familie mit Pfoten und Hundename | D33 mit Lucky | familienschilder, namensschilder, hundeschilder |  | 10 |  | Raleway, Sweetie |  |  |
| TRE-V2A-8x5-D34 | Willkommen bei Familie mit Katze und Katzenname | D34 Albrecht | familienschilder, namensschilder, katzenschilder, willkommensschilder |  | 10 |  | Ashley, Libre Baskerville |  |  |
| TRE-V2A-8x5-D35 | Hier leben – zwei Vornamen und Nachname mit Katze und Katzenname | D35 mit Oskar | familienschilder, namensschilder, katzenschilder |  | 10 |  | Michroma, Sweetie |  |  |
| TRE-V2A-8x5-D36 | Schnörkel-Ornament (ohne Text) | D36 | familienschilder | namensschilder | 2 | GR-ES-RE-80X53P3-T15, GR-ES-RE-90X60-T15, GR-ES-RE-120X80-T15, GR-ES-RE-150X100-T15, GR-ES-RE-180X120-T15, GR-ES-RE-210X140-T15, GR-ES-RE-420X280-T15, GR-ES-RE-450X300-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TRE-V2A-8x5-D37 | Vor- und Nachname mit Unendlichkeitszeichen | D37 Hannah | familienschilder, namensschilder |  | 10 |  | Great Vibes |  |  |
| TRE-V2A-8x5-D38 | Zwei Namen mit Herzen, Schreibschrift | D38 Olivia Sander | familienschilder, namensschilder | hochzeitsschilder | 10 |  | Italianno |  |  |
| TRE-V2A-8x5-D39 | Herzlich Willkommen bei Familie mit Schnörkel-Herz | D39 Herzlich Willkommen | familienschilder, namensschilder, willkommensschilder |  | 10 |  | Great Vibes |  |  |
| TRE-V2A-8x5-D40 | Willkommen bei Vor- und Nachname mit Eule | D40 Willkommen | familienschilder, namensschilder, willkommensschilder |  | 10 |  | Dancing Script |  |  |
| TRE-V2A-8x5-D41 | Familie mit Kolibri | D41 Vogel | familienschilder, namensschilder |  | 10 |  | Ashley, Raleway |  |  |
| TRE-V2A-8x5-D42 | Vor- und Nachname mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 10 |  | Homage, Montserrat Light |  |  |
| TRE-V2A-8x5-D43 | Familie mit Taubenpaar, Serifenschrift | D43 Familie Krone | familienschilder, namensschilder |  | 10 |  | Libre Baskerville |  |  |
| TRE-V2A-8x5-D44 | Zwei Vornamen und Nachname mit Vogelpaar im Herz | D44 Ruprecht | familienschilder, namensschilder | hochzeitsschilder | 10 |  | Allura, Raleway |  |  |
| TRE-V2A-8x5-D45 | Hier wohnt Vor- und Nachname mit Vogel | D45 König | familienschilder, namensschilder |  | 10 |  | Cinzel, Rochester |  |  |
| TRE-V2A-8x5-D46 | Familie mit Vogelpaar auf Zweig | D46 Vogel | familienschilder, namensschilder |  | 10 |  | Ashley, Raleway |  |  |
| TRE-V2A-8x5-D47 | Herzlich Willkommen bei Vor- und Nachname mit Vogel auf Zweig | D47 Carla | familienschilder, namensschilder, willkommensschilder |  | 10 |  | Sweetie |  |  |
| TRE-V2A-8x5-D48 | Familie mit Schmetterlingen | D48 Schumacher | familienschilder, namensschilder |  | 10 |  | Allura, Raleway |  |  |
| TRE-V2A-8x5-D49 | Familie mit Eulenfamilie, Schreibschrift | D49 Familie | familienschilder, namensschilder |  | 9 | GR-ES-RE-80X53P3-T15 | Magnolia Script |  |  |
| TRE-V2A-8x5-D50 | Zwei Vornamen und Nachname mit Eulenfamilie | D50 Maier | familienschilder, namensschilder |  | 9 | GR-ES-RE-80X53P3-T15 | Ashley, Cinzel |  | motiv-1 um -4.4/0.0 mm nach innen (stand über die Kante) |
| TRE-V2A-8x5-D51 | Willkommen bei Familie mit Eulenfamilie | D51 Lichter | familienschilder, namensschilder, willkommensschilder |  | 9 | GR-ES-RE-80X53P3-T15 | Allura, Cinzel |  | motiv-1 um -4.4/0.0 mm nach innen (stand über die Kante) |
| TRE-V2A-8x5-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 10 |  | Ashley |  |  |
| TRE-V2A-8x5-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 10 |  | Ashley, Montserrat Light |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x5-D54 | Familie mit Lilie, Serifenschrift | D54 Kampmann | familienschilder, namensschilder |  | 10 |  | Libre Baskerville |  |  |
| TRE-V2A-8x5-D55 | Hier wohnt Familie mit Schnörkel und Herz | D55 Hier wohnt | familienschilder, namensschilder |  | 10 |  | Allura, Montserrat Light |  |  |
| TRE-V2A-8x5-D56 | Familie mit Schnörkel-Ornament | D56 Lachtermann | familienschilder, namensschilder |  | 10 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TRE-V2A-8x5-D57 | Familie mit Herz-Ranken-Ornament | D57 Pielstädt | familienschilder, namensschilder |  | 10 |  | Cinzel, Italianno |  |  |
| TRE-V2A-8x5-D58 | Familie mit Herzranke und Spruch | D58 Feldkamp | familienschilder, namensschilder |  | 10 |  | Comfortaa, Italianno |  |  |
| TRE-V2A-8x5-D59 | Familie mit Rosen-Ornament, Serifenschrift | D59 Landhagen | familienschilder, namensschilder |  | 10 |  | Libre Baskerville |  |  |
| TRE-V2A-8x5-D60 | Familie mit Ornament und Spruch | D60 Willkommen bei uns | familienschilder, namensschilder, willkommensschilder |  | 10 |  | Allura, Cinzel |  |  |
| TRE-V2A-8x5-D61 | Zwei Vornamen und Nachname mit Zweigen und Herz | D61 Kampmann | familienschilder, namensschilder |  | 10 |  | Montserrat Light, Sweetie |  |  |
| TRE-V2A-8x5-D62 | Familie mit Schlüssel und Linie | D62 Schielmann | familienschilder, namensschilder |  | 10 |  | Fineliner Script, Raleway |  | Schrift ohne Datei im Katalog: Fineliner Script |
| TRE-V2A-8x5-D63 | Familie mit Wimpelkette, Serifenschrift | D63 Poller | familienschilder, namensschilder |  | 10 |  | Libre Baskerville |  |  |
| TRE-V2A-8x5-D64 | Familie mit Eck-Ornamenten, Serifenschrift | D64 Schötter | familienschilder, namensschilder |  | 10 |  | Cinzel |  |  |
| TRE-V2A-8x5-D65 | Hier wohnt Familie mit Vornamen und Herzen | D65 Familie Wegner | familienschilder, namensschilder |  | 10 |  | Homage, Raleway |  |  |
| TRE-V2A-8x5-D66 | Mr. & Mrs. mit Herzen und Nachname | D66 Westermann | familienschilder, namensschilder, hochzeitsschilder |  | 10 |  | Raleway |  |  |
| TRE-V2A-8x5-D67 | Initialen mit Ringen und Nachname | D67 Trautmann | familienschilder, namensschilder, hochzeitsschilder |  | 10 |  | Antic Slab, Great Vibes |  |  |
| TRE-V2A-8x5-D68 | Familie mit Pfeil nach links | D68 Familie | familienschilder, namensschilder | hinweisschilder | 10 |  | Michroma |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x5-D69 | Familie mit Pfeil nach rechts, Serifenschrift | D69 Maier | familienschilder, namensschilder | hinweisschilder | 10 |  | Libre Baskerville |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x5-D70 | Zwei Vornamen und Nachname mit Pfeil nach oben | D70 Mükmann | familienschilder, namensschilder | hinweisschilder | 10 |  | Cinzel, Italianno |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x5-D71 | Familie mit Pfeil nach unten | D71 Kleester | familienschilder, namensschilder | hinweisschilder | 10 |  | Comfortaa |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-8x5-D72 | Achtung Videoüberwachung mit Familie | D72 Familie Hübner | hinweisschilder, familienschilder |  | 10 |  | Cinzel, Lato |  |  |
| TRE-V2A-8x5-D73 | Kein Eingang mit STOP | D73 Kein | hinweisschilder |  | 10 |  | Lato, Libre Baskerville |  |  |

## Abweichende Doppel (prüfen)

| Bogen | Doppel | von | grün |
| --- | --- | --- | --- |
| TRE-V2A-8x5 | TRE-V2A-8x5-D14-DOPPELT2 | TRE-V2A-8x5-D14 | ja |
| TRE-V2A-9x6 | TRE-V2A-9x6-D14-DOPPELT2 | TRE-V2A-9x6-D14 | ja |
| TRE-V2A-9x6 | TRE-V2A-9x6-D18-DOPPELT2 | TRE-V2A-9x6-D18 | ja |
| TRE-V2A-12x8 | TRE-V2A-12x8-D18-DOPPELT2 | TRE-V2A-12x8-D18 | ja |
| TRE-V2A-12x8 | TRE-V2A-12x8-D14-DOPPELT2 | TRE-V2A-12x8-D14 | ja |
| TRE-V2A-15x10 | TRE-V2A-15x10-D18-DOPPELT2 | TRE-V2A-15x10-D18 | ja |
| TRE-V2A-15x10 | TRE-V2A-15x10-D14-DOPPELT2 | TRE-V2A-15x10-D14 | ja |
| TRE-V2A-18x12 | TRE-V2A-18x12-D18-DOPPELT2 | TRE-V2A-18x12-D18 | ja |
| TRE-V2A-18x12 | TRE-V2A-18x12-D15-DOPPELT2 | TRE-V2A-18x12-D15 | ja |
| TRE-V2A-18x12 | TRE-V2A-18x12-D14-DOPPELT2 | TRE-V2A-18x12-D14 | ja |
| TRE-V2A-21x14 | TRE-V2A-21x14-D18-DOPPELT2 | TRE-V2A-21x14-D18 | ja |
| TRE-V2A-21x14 | TRE-V2A-21x14-D15-DOPPELT2 | TRE-V2A-21x14-D15 | ja |
| TRE-V2A-21x14 | TRE-V2A-21x14-D11-DOPPELT2 | TRE-V2A-21x14-D11 | ja |
| TRE-V2A-24x16 | TRE-V2A-24x16-D18-DOPPELT2 | TRE-V2A-24x16-D18 | ja |
| TRE-V2A-24x16 | TRE-V2A-24x16-D15-DOPPELT2 | TRE-V2A-24x16-D15 | ja |
| TRE-V2A-24x16 | TRE-V2A-24x16-D11-DOPPELT2 | TRE-V2A-24x16-D11 | ja |

## Schriften ohne Datei im Katalog

- Comic Sans MS: 1 Designs (TRE-V2A-8x5-D21)
- Fineliner Script: 2 Designs (TRE-V2A-8x5-D56, TRE-V2A-8x5-D62)
