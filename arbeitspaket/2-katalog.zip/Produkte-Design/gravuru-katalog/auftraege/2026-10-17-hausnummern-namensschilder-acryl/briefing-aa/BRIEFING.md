# Acrylglas anthrazit 5 mm · Abstandshalter (AA) – Briefing für die Designerstellung

Familienrevision katalog. Automatisch aus der Werkstatt erzeugt; nicht von Hand ändern, sondern in der Werkstatt pflegen und neu herunterladen.

## Was gestaltet wird

Nur das **Design**: Texte, Motive, Foto. Form, Größe, Material, Bohrlöcher, Befestigung und Preise legt die Werkstatt fest.

- Material: Acrylglas anthrazit, 5 mm, Verfahren Gravur. Gravur erscheint hell (weiß) auf dem farbigen Acrylglas; Weiß bleibt ungraviert. Gestaltet wird immer schwarz auf weiß; die Werkstatt stellt die Gravur je Material dar. Keine Graustufenflächen in Motiven.
- Randabstand der Gestaltung: 0 mm. Gravur von der Rückseite (die Werkstatt spiegelt für die Fertigung; gestaltet wird seitenrichtig). Schutzzone um Bohrlöcher: 1 mm um den Lochrand.
- **Texte** nicht in die Schutzzonen legen (sonst sieht der Kunde einen Hinweis). **Motive dürfen über Bohrlöcher** gehen.
- Zugelassene Schriften (exakt diese Namen verwenden): siehe `schriften.txt`.

## Lieferformat je Design

Ordner `<design-id>/` mit `design.svg` in Endmaß (width/height in mm, viewBox 0 0 Breite Höhe, Maße exakt wie die Schablone der Zielgröße). Oberste Ebenen als `<g id="…">`:

| Ebene | Inhalt |
| --- | --- |
| `text-<name>` | genau ein `<text>` mit `text-anchor="middle"`, Schrift aus schriften.txt – wird bearbeitbares Kundenfeld |
| `motiv-<n>` | Vektormotiv, schwarz auf transparent |
| `deko-<n>` | feste Dekoration |
| `foto-<name>` | genau ein Bild mit Rechteck-, Kreis- oder Bogenmaske (nur bei Fotoprodukten) |

Texte als echten Text, nicht in Pfade umwandeln. Kein Text in Deko oder Motiv. Keine Transformationen, Skripte oder externen Links. Optional `original.png` als Vergleichsbild.

## Formen und Größen

| SKU | Form | Größe | Grundpreis | Befestigung | Schablone |
| --- | --- | --- | ---: | --- | --- |
| AA-RE-150X100 | Rechteck | 15 × 10 cm (150 × 100 mm) | offen | 2 Abstandshalter · 10 mm Randabstand; 4 Abstandshalter · 10 mm Randabstand | schablonen/AA-RE-150X100.svg |
| AA-RE-180X120 | Rechteck | 18 × 12 cm (180 × 120 mm) | offen | 2 Abstandshalter · 10 mm Randabstand; 4 Abstandshalter · 10 mm Randabstand | schablonen/AA-RE-180X120.svg |
| AA-RE-240X160 | Rechteck | 24 × 16 cm (240 × 160 mm) | offen | 2 Abstandshalter · 15 mm Randabstand; 4 Abstandshalter · 15 mm Randabstand | schablonen/AA-RE-240X160.svg |
| AA-RE-300X200 | Rechteck | 30 × 20 cm (300 × 200 mm) | offen | 2 Abstandshalter · 15 mm Randabstand; 4 Abstandshalter · 15 mm Randabstand | schablonen/AA-RE-300X200.svg |
| AA-RE-360X240 | Rechteck | 36 × 24 cm (360 × 240 mm) | offen | 2 Abstandshalter · 15 mm Randabstand; 4 Abstandshalter · 15 mm Randabstand | schablonen/AA-RE-360X240.svg |
| AA-RE-420X280 | Rechteck | 42 × 28 cm (420 × 280 mm) | offen | 2 Abstandshalter · 15 mm Randabstand; 4 Abstandshalter · 15 mm Randabstand | schablonen/AA-RE-420X280.svg |
| AA-OV-150X80 | Oval | 15 × 8 cm (150 × 80 mm) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-OV-150X80.svg |
| AA-OV-225X120 | Oval | 22,5 × 12 cm (225 × 120 mm) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-OV-225X120.svg |
| AA-OV-300X160 | Oval | 30 × 16 cm (300 × 160 mm) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-OV-300X160.svg |
| AA-OV-150X100 | Oval | 15 × 10 cm (150 × 100 mm) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-OV-150X100.svg |
| AA-OV-180X120 | Oval | 18 × 12 cm (180 × 120 mm) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-OV-180X120.svg |
| AA-OV-210X140 | Oval | 21 × 14 cm (210 × 140 mm) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-OV-210X140.svg |
| AA-OV-240X160 | Oval | 24 × 16 cm (240 × 160 mm) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-OV-240X160.svg |
| AA-OV-300X200 | Oval | 30 × 20 cm (300 × 200 mm) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-OV-300X200.svg |
| AA-RE-210X70 | Rechteck | 21 × 7 cm (210 × 70 mm) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-RE-210X70.svg |
| AA-RE-240X70 | Rechteck | 24 × 7 cm (240 × 70 mm) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-RE-240X70.svg |
| AA-RE-270X90 | Rechteck | 27 × 9 cm (270 × 90 mm) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-RE-270X90.svg |
| AA-RE-360X120 | Rechteck | 36 × 12 cm (360 × 120 mm) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-RE-360X120.svg |
| AA-RE-450X150 | Rechteck | 45 × 15 cm (450 × 150 mm) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-RE-450X150.svg |
| AA-RE-160X160 | Rechteck | 16 × 16 cm (160 × 160 mm) | offen | 2 Abstandshalter · 10 mm Randabstand; 4 Abstandshalter · 10 mm Randabstand | schablonen/AA-RE-160X160.svg |
| AA-RE-200X200 | Rechteck | 20 × 20 cm (200 × 200 mm) | offen | 2 Abstandshalter · 10 mm Randabstand; 4 Abstandshalter · 10 mm Randabstand | schablonen/AA-RE-200X200.svg |
| AA-RE-260X260 | Rechteck | 26 × 26 cm (260 × 260 mm) | offen | 2 Abstandshalter · 15 mm Randabstand; 4 Abstandshalter · 15 mm Randabstand | schablonen/AA-RE-260X260.svg |
| AA-RE-300X300 | Rechteck | 30 × 30 cm (300 × 300 mm) | offen | 2 Abstandshalter · 15 mm Randabstand; 4 Abstandshalter · 15 mm Randabstand | schablonen/AA-RE-300X300.svg |
| AA-EE-180X120 | Eingezogene Ecken | 18 × 12 cm (180 × 120 mm, eingezogene Ecken R11.6) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-EE-180X120.svg |
| AA-EE-210X140 | Eingezogene Ecken | 21 × 14 cm (210 × 140 mm, eingezogene Ecken R13.5) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-EE-210X140.svg |
| AA-EE-240X160 | Eingezogene Ecken | 24 × 16 cm (240 × 160 mm, eingezogene Ecken R15.5) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-EE-240X160.svg |
| AA-EE-300X200 | Eingezogene Ecken | 30 × 20 cm (300 × 200 mm, eingezogene Ecken R19.3) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-EE-300X200.svg |
| AA-R5-150X100 | Abgerundete Ecken R5 | 15 × 10 cm (150 × 100 mm, Ecken R5) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-R5-150X100.svg |
| AA-R5-180X120 | Abgerundete Ecken R5 | 18 × 12 cm (180 × 120 mm, Ecken R5) | offen | 2 Abstandshalter · 10 mm Randabstand | schablonen/AA-R5-180X120.svg |
| AA-R5-240X160 | Abgerundete Ecken R5 | 24 × 16 cm (240 × 160 mm, Ecken R5) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-R5-240X160.svg |
| AA-R5-300X200 | Abgerundete Ecken R5 | 30 × 20 cm (300 × 200 mm, Ecken R5) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-R5-300X200.svg |
| AA-R5-360X240 | Abgerundete Ecken R5 | 36 × 24 cm (360 × 240 mm, Ecken R5) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-R5-360X240.svg |
| AA-R5-420X280 | Abgerundete Ecken R5 | 42 × 28 cm (420 × 280 mm, Ecken R5) | offen | 2 Abstandshalter · 15 mm Randabstand | schablonen/AA-R5-420X280.svg |

## Noch offen in den Stammdaten

- Aufpreis „2 Abstandshalter“
- Aufpreis „2 Abstandshalter“
- Aufpreis „4 Abstandshalter“
- Aufpreis „4 Abstandshalter“
- Grundpreis: 15 × 10 cm, 18 × 12 cm, 24 × 16 cm, 30 × 20 cm, 36 × 24 cm, 42 × 28 cm, 15 × 8 cm, 22,5 × 12 cm, 30 × 16 cm, 15 × 10 cm, 18 × 12 cm, 21 × 14 cm, 24 × 16 cm, 30 × 20 cm, 21 × 7 cm, 24 × 7 cm, 27 × 9 cm, 36 × 12 cm, 45 × 15 cm, 16 × 16 cm, 20 × 20 cm, 26 × 26 cm, 30 × 30 cm, 18 × 12 cm, 21 × 14 cm, 24 × 16 cm, 30 × 20 cm, 15 × 10 cm, 18 × 12 cm, 24 × 16 cm, 30 × 20 cm, 36 × 24 cm, 42 × 28 cm
- Form „eingezogene Ecken“ ist im Konfigurator noch nicht angeschlossen (Schablone und Katalog zeigen sie schon)

## Stil und Hinweise

Namens- und Hausnummernschilder. Gravur von hinten, erscheint hell auf Anthrazit. Texte groß und ruhig; Abstandshalter in den Ecken oder seitlich freihalten.
