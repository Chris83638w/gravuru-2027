import test from 'node:test';
import assert from 'node:assert/strict';
import {ACRYLIC_BASES,acrylicSelection,containAcrylicObject,makeAcrylicConfig} from './acrylic-product.mjs';
test('both sizes and all independent base/wall combinations use confirmed prices',()=>{
  for(const size of ['small','large'])for(const base of ACRYLIC_BASES)for(const wall of ['none','wall']){
    const result=acrylicSelection({size,base:base.id,wall});
    assert.equal(result.totalCents,(size==='small'?1499:1999)+base.priceCents+(size==='large'&&base.id!=='none'?100:0)+(wall==='wall'?599:0));
  }
  assert.throws(()=>acrylicSelection({base:'unknown'}));
});
test('design remains above maximum insertion and clearance, including rotated customer elements',()=>{
  for(const rotation of [0,30,90,135]){
    const o=containAcrylicObject({type:'text',x:170,y:210,w:80,h:12,size:8,rotation});
    const a=rotation*Math.PI/180,h=Math.abs(o.w*Math.sin(a))+Math.abs(o.h*Math.cos(a));
    assert(o.y+h/2<=190.00001);
  }
  const config=makeAcrylicConfig({profile:{}},{fonts:[],motifs:[]},'test');
  for(const o of config.profile.designs[0].objects)assert(o.y+o.h/2<=190, o.id);
});
