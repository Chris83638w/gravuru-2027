require('./ops/plesk/app.cjs');
