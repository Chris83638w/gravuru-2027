﻿<#
Gravuru – „Light-Kopien“ der Corel-Bögen anlegen (nur lesen vom Server).

Für jede *.cdr in einem [CDR]-Ordner unter V:\Produkte wird nach C:\katalog-quelle\... eine Kopie geschrieben,
in der content\data\Bitmaps.dat durch Nullen gleicher Länge ersetzt ist (Texte, Schriften, Pfade, Platten bleiben
vollständig; Musterfotos/Texturen entfallen). Gelesen werden dabei nur die kleinen Teile der Datei – das geht über
das Netzlaufwerk schnell. Zusätzlich aus jedem Konfigurator-Paket <SKU>.zip nur product.json und *_front.jpg.

Ausgeschlossen: Türklingel, Grabstecker, Archiv-/Backup-Ordner, Sicherungskopie_von_*.cdr, Thumbs.db.
Am Ende: C:\katalog-quelle\_dateiliste.csv (Quelle, Ziel, Größe, Bitmaps-Größe, Dauer).

Aufruf (PowerShell, nicht als Admin nötig):
    powershell -ExecutionPolicy Bypass -File make-light-copies.ps1
    powershell -ExecutionPolicy Bypass -File make-light-copies.ps1 -Linien "Türschilder","Hausnummern"   # nur diese Linien
    powershell -ExecutionPolicy Bypass -File make-light-copies.ps1 -OhneZips                              # nur Corel-Bögen
#>
param(
    [string]$Quelle = "V:\Produkte",
    [string]$Ziel = "C:\katalog-quelle",
    [string[]]$Linien = @(),
    [switch]$OhneZips,
    [switch]$OhneCdr,
    [string]$CdrListe = "",   # Textdatei mit [CDR]-Ordnern relativ zu -Quelle (spart die Suche über den ganzen Baum)
    [string]$SkuListe = ""    # Textdatei mit SKU-Ordnern relativ zu -Quelle
)
if (-not $CdrListe -and (Test-Path (Join-Path $PSScriptRoot 'cdr-ordner.txt'))) { $CdrListe = Join-Path $PSScriptRoot 'cdr-ordner.txt' }
if (-not $SkuListe -and (Test-Path (Join-Path $PSScriptRoot 'sku-ordner.txt'))) { $SkuListe = Join-Path $PSScriptRoot 'sku-ordner.txt' }
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$ausschluss = @('Türklingel', 'Tuerklingel', 'Grabstecker')
$log = New-Object System.Collections.Generic.List[string]
$log.Add('Art;Quelle;Ziel;Bytes;BitmapsBytes;Sekunden;Status')
New-Item -ItemType Directory -Force -Path $Ziel | Out-Null

function Ist-Ausgeschlossen($pfad) {
    $rel = $pfad.Substring($Quelle.Length).TrimStart('\')
    $linie = $rel.Split('\')[0]
    if ($ausschluss -contains $linie) { return $true }
    if ($Linien.Count -gt 0 -and -not ($Linien -contains $linie)) { return $true }
    if ($rel -match '\\(\[?Archiv\]?|Backup|Sicherung[^\\]*)(\\|$)') { return $true }
    return $false
}

# .NET (ZipFile) findet gemappte Netzlaufwerke nicht immer („Der Netzwerkpfad wurde nicht gefunden“) – dann den UNC-Pfad des Laufwerks verwenden
$script:NetRoot = $null
try {
    $drv = Get-PSDrive -Name $Quelle.Substring(0, 1) -ErrorAction Stop
    if ($drv.DisplayRoot) { $script:NetRoot = $drv.DisplayRoot.TrimEnd('\') }
} catch { }
function Net-Pfad($p) {
    if ($script:NetRoot -and $p.Length -ge 2 -and $p.Substring(1, 1) -eq ':') { return $script:NetRoot + $p.Substring(2) }
    return $p
}
function Zip-Oeffnen($p) {
    try { return [System.IO.Compression.ZipFile]::OpenRead($p) }
    catch {
        $u = Net-Pfad $p
        if ($u -ne $p) { return [System.IO.Compression.ZipFile]::OpenRead($u) }
        # letzter Versuch: Datei über den PowerShell-Provider in den lokalen Temp-Ordner kopieren und dort öffnen (langsamer, aber robust)
        $tmp = Join-Path $env:TEMP ('light-' + [IO.Path]::GetFileName($p))
        Copy-Item -LiteralPath $p -Destination $tmp -Force
        $script:TempKopie = $tmp
        return [System.IO.Compression.ZipFile]::OpenRead($tmp)
    }
}
$script:TempKopie = $null
function Temp-Aufraeumen() {
    if ($script:TempKopie -and (Test-Path -LiteralPath $script:TempKopie)) { Remove-Item -LiteralPath $script:TempKopie -Force -ErrorAction SilentlyContinue }
    $script:TempKopie = $null
}

function Light-Kopie($src, $dst) {
    $t0 = Get-Date
    New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
    if (Test-Path -LiteralPath $dst) { Remove-Item -LiteralPath $dst -Force }
    $zin = Zip-Oeffnen $src
    try {
        $zout = [System.IO.Compression.ZipFile]::Open($dst, [System.IO.Compression.ZipArchiveMode]::Create)
        try {
            $bmBytes = 0
            # mimetype zuerst und unkomprimiert (wie Corel es schreibt)
            $mt = $zin.GetEntry('mimetype')
            if ($mt) {
                $e = $zout.CreateEntry('mimetype', [System.IO.Compression.CompressionLevel]::NoCompression)
                $si = $mt.Open(); $so = $e.Open(); $si.CopyTo($so); $so.Dispose(); $si.Dispose()
            }
            foreach ($entry in $zin.Entries) {
                if ($entry.FullName -eq 'mimetype') { continue }
                if ($entry.FullName.EndsWith('/')) { continue }
                if ($entry.FullName -like '*Bitmaps.dat') {
                    $bmBytes += $entry.Length
                    $e = $zout.CreateEntry($entry.FullName, [System.IO.Compression.CompressionLevel]::Fastest)
                    $so = $e.Open()
                    $buf = New-Object byte[] (1MB); $rest = [long]$entry.Length
                    while ($rest -gt 0) { $n = [int][Math]::Min($buf.Length, $rest); $so.Write($buf, 0, $n); $rest -= $n }
                    $so.Dispose()
                } else {
                    $e = $zout.CreateEntry($entry.FullName, [System.IO.Compression.CompressionLevel]::Optimal)
                    $si = $entry.Open(); $so = $e.Open(); $si.CopyTo($so); $so.Dispose(); $si.Dispose()
                }
            }
        } finally { $zout.Dispose() }
    } finally { $zin.Dispose(); Temp-Aufraeumen }
    $dt = [int]((Get-Date) - $t0).TotalSeconds
    return @($bmBytes, $dt)
}

function Zip-Auszug($src, $dstDir) {
    # nur product.json und *_front.jpg aus dem Konfigurator-Paket
    $t0 = Get-Date; $n = 0
    $zin = Zip-Oeffnen $src
    try {
        foreach ($entry in $zin.Entries) {
            $name = $entry.Name
            if ($name -eq 'product.json' -or $name -like '*_front.jpg' -or $name -like 'Hauptform*.svg') {
                New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path $dstDir $name), $true); $n++
            }
        }
    } finally { $zin.Dispose(); Temp-Aufraeumen }
    return @($n, [int]((Get-Date) - $t0).TotalSeconds)
}

$gesamt0 = Get-Date
Write-Host ("PowerShell {0}, .NET {1}" -f $PSVersionTable.PSVersion, [System.Environment]::Version)
if ($script:NetRoot) { Write-Host ("Netzlaufwerk {0} = {1}" -f $Quelle.Substring(0, 2), $script:NetRoot) }
try { [void][System.IO.Compression.ZipFile] } catch { Write-Host "Diese PowerShell kann keine ZIP-Dateien lesen (System.IO.Compression fehlt). Bitte 'Windows PowerShell' (Version 5) oder 'pwsh' (PowerShell 7) verwenden." -ForegroundColor Red; exit 1 }
if (-not $OhneCdr) {
    if ($CdrListe) {
        Write-Host "Lese Corel-Boegen aus den [CDR]-Ordnern der Liste $CdrListe ..."
        $ordner = Get-Content $CdrListe | Where-Object { $_.Trim() -ne '' } | ForEach-Object { Join-Path $Quelle $_.Trim() }
        $cdrs = @(); $k = 0
        foreach ($o in $ordner) {
            $k++; if ($k % 100 -eq 0) { Write-Host ("  {0}/{1} Ordner gelesen" -f $k, $ordner.Count) }
            if (-not (Test-Path -LiteralPath $o)) { continue }
            $cdrs += Get-ChildItem -LiteralPath $o -Filter *.cdr -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer -and $_.Name -notlike 'Sicherungskopie_von_*' -and -not (Ist-Ausgeschlossen $_.DirectoryName) }
        }
    } else {
        Write-Host "Suche Corel-Boegen unter $Quelle ..."
        $cdrs = Get-ChildItem -Path $Quelle -Recurse -Filter *.cdr -ErrorAction SilentlyContinue |
            Where-Object { -not $_.PSIsContainer -and $_.DirectoryName -like '*[[]CDR[]]*' -and $_.Name -notlike 'Sicherungskopie_von_*' -and -not (Ist-Ausgeschlossen $_.DirectoryName) }
    }
    Write-Host ("{0} Boegen" -f $cdrs.Count)
    $i = 0
    foreach ($f in $cdrs) {
        $i++
        $rel = $f.FullName.Substring($Quelle.Length).TrimStart('\')
        $dst = Join-Path $Ziel $rel
        if ((Test-Path -LiteralPath $dst) -and (Get-Item -LiteralPath $dst).Length -gt 0 -and (Get-Item -LiteralPath $dst).LastWriteTime -ge $f.LastWriteTime) { $log.Add("cdr;$($f.FullName);$dst;$($f.Length);;0;vorhanden"); continue }
        try {
            $r = Light-Kopie $f.FullName $dst
            $log.Add("cdr;$($f.FullName);$dst;$($f.Length);$($r[0]);$($r[1]);ok")
            Write-Host ("[{0}/{1}] {2}  ({3} MB, Bitmaps {4} MB, {5} s)" -f $i, $cdrs.Count, $rel, [int]($f.Length / 1MB), [int]($r[0] / 1MB), $r[1])
        } catch {
            $log.Add("cdr;$($f.FullName);$dst;$($f.Length);;0;FEHLER $($_.Exception.Message -replace ';',',')")
            Write-Host ("[{0}/{1}] FEHLER {2}: {3}" -f $i, $cdrs.Count, $rel, $_.Exception.Message) -ForegroundColor Red
        }
        if ($i % 25 -eq 0) { $log | Set-Content -Path (Join-Path $Ziel '_dateiliste.csv') -Encoding UTF8 }
    }
}
if (-not $OhneZips) {
    if ($SkuListe) {
        Write-Host "Lese Konfigurator-Pakete aus den SKU-Ordnern der Liste $SkuListe ..."
        $zips = @(); $k = 0
        foreach ($rel in (Get-Content $SkuListe | Where-Object { $_.Trim() -ne '' })) {
            $k++; if ($k % 2000 -eq 0) { Write-Host ("  {0} SKU-Ordner geprueft" -f $k) }
            $rel = $rel.Trim(); $name = Split-Path $rel -Leaf; $zp = Join-Path (Join-Path $Quelle $rel) ($name + '.zip')
            if (Test-Path -LiteralPath $zp) { $zips += Get-Item -LiteralPath $zp }
        }
    } else {
        Write-Host "Suche Konfigurator-Pakete ..."
        $zips = Get-ChildItem -Path $Quelle -Recurse -Filter *.zip -ErrorAction SilentlyContinue |
            Where-Object { -not $_.PSIsContainer -and $_.BaseName -match '^[A-Z]{2,8}[A-Z0-9]*-[A-Z0-9]+-[\d.,]+x[\d.,]+-D\d+$' -and $_.Directory.Name -eq $_.BaseName -and -not (Ist-Ausgeschlossen $_.DirectoryName) }
    }
    Write-Host ("{0} Pakete" -f $zips.Count)
    $i = 0
    foreach ($f in $zips) {
        $i++
        $rel = $f.DirectoryName.Substring($Quelle.Length).TrimStart('\')
        $dstDir = Join-Path $Ziel $rel
        if (Test-Path -LiteralPath (Join-Path $dstDir 'product.json')) { continue }
        try {
            $r = Zip-Auszug $f.FullName $dstDir
            $log.Add("zip;$($f.FullName);$dstDir;$($f.Length);;$($r[1]);ok $($r[0]) Dateien")
        } catch {
            $log.Add("zip;$($f.FullName);$dstDir;$($f.Length);;0;FEHLER $($_.Exception.Message -replace ';',',')")
        }
        if ($i % 200 -eq 0) { Write-Host ("[{0}/{1}] Pakete" -f $i, $zips.Count); $log | Set-Content -Path (Join-Path $Ziel '_dateiliste.csv') -Encoding UTF8 }
    }
}
$log | Set-Content -Path (Join-Path $Ziel '_dateiliste.csv') -Encoding UTF8
Write-Host ("Fertig in {0} Minuten. Liste: {1}" -f [int]((Get-Date) - $gesamt0).TotalMinutes, (Join-Path $Ziel '_dateiliste.csv'))
