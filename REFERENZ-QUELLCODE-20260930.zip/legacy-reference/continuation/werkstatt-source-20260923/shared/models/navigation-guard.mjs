import {useEffect} from 'preact/hooks';
export function useNavigationGuard(dirty,onDirtyChange){useEffect(()=>{onDirtyChange?.(Boolean(dirty));const warn=e=>{if(dirty){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',warn);return()=>{window.removeEventListener('beforeunload',warn);onDirtyChange?.(false);};},[dirty,onDirtyChange]);}
