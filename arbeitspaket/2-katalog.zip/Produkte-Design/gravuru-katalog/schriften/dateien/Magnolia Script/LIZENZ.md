# Magnolia Script

Lizenz laut Nutzerliste (Schriftarten-Uebersicht-Lizenz, 30.09.2026): Jovanny Lemonad – OFL (Version prüfen).
Datei übernommen am 17.10.2026 aus dem Schriftenordner des Nutzers (`_fpd_pr_fonts`, Fancy-Product-Designer-Bestand der WooCommerce-Seite), Originalname `Magnolia Script.ttf`.
Lizenztext nicht beigelegt – bei Bedarf vom Anbieter nachreichen.
