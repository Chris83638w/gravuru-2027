# Lizenzen der vorgeschlagenen Motive

- **Phosphor Icons** – MIT-Lizenz (freie kommerzielle Nutzung, Lizenztext muss in der Software/Dokumentation mitgeführt werden): https://github.com/phosphor-icons/core/blob/main/LICENSE
- **game-icons.net** – CC BY 3.0 (freie kommerzielle Nutzung, **Namensnennung des Autors** erforderlich, z. B. auf einer Lizenzseite im Shop: „Icons von Lorc, Delapouite u. a. – game-icons.net, CC BY 3.0“): https://creativecommons.org/licenses/by/3.0/

| Motiv | Datei | Quelle | Autor | Lizenz |
| --- | --- | --- | --- | --- |
| Sanduhr | trauersymbole/sanduhr.svg | Phosphor Icons (phosphor-icons/core): hourglass | Phosphor Icons | MIT |
| Sanduhr 2 | trauersymbole/sanduhr-2.svg | game-icons.net: lorc/hourglass | lorc | CC BY 3.0 |
| Kerze mit Flamme | trauersymbole/kerze-mit-flamme.svg | game-icons.net: lorc/candle-light | lorc | CC BY 3.0 |
| Kerzenflamme | trauersymbole/kerzenflamme.svg | game-icons.net: lorc/candle-flame | lorc | CC BY 3.0 |
| Drei Kerzen | trauersymbole/drei-kerzen.svg | game-icons.net: delapouite/candles | delapouite | CC BY 3.0 |
| Laterne | trauersymbole/laterne.svg | game-icons.net: lorc/lantern | lorc | CC BY 3.0 |
| Alte Laterne | trauersymbole/alte-laterne.svg | game-icons.net: delapouite/old-lantern | delapouite | CC BY 3.0 |
| Gebetskette | trauersymbole/gebetskette.svg | game-icons.net: delapouite/prayer-beads | delapouite | CC BY 3.0 |
| Betende Figur | trauersymbole/betende-figur.svg | game-icons.net: lorc/prayer | lorc | CC BY 3.0 |
| Betende Hände | trauersymbole/betende-hande.svg | Phosphor Icons (phosphor-icons/core): hands-praying | Phosphor Icons | MIT |
| Kirche | trauersymbole/kirche.svg | Phosphor Icons (phosphor-icons/core): church | Phosphor Icons | MIT |
| Dorfkirche | trauersymbole/dorfkirche.svg | game-icons.net: delapouite/church | delapouite | CC BY 3.0 |
| Himmelstor | trauersymbole/himmelstor.svg | game-icons.net: delapouite/heaven-gate | delapouite | CC BY 3.0 |
| Treppe | trauersymbole/treppe.svg | game-icons.net: delapouite/stairs | delapouite | CC BY 3.0 |
| Sonne am Horizont | trauersymbole/sonne-am-horizont.svg | Phosphor Icons (phosphor-icons/core): sun-horizon | Phosphor Icons | MIT |
| Friedenstaube | trauersymbole/friedenstaube.svg | game-icons.net: delapouite/peace-dove | delapouite | CC BY 3.0 |
| Taube fliegend | trauersymbole/taube-fliegend.svg | game-icons.net: lorc/dove | lorc | CC BY 3.0 |
| Schwan | trauersymbole/schwan.svg | game-icons.net: lorc/swan | lorc | CC BY 3.0 |
| Fußabdruck | trauersymbole/fuabdruck.svg | game-icons.net: lorc/footprint | lorc | CC BY 3.0 |
| Herz mit Flügeln | trauersymbole/herz-mit-flugeln.svg | game-icons.net: delapouite/heart-wings | delapouite | CC BY 3.0 |
| Engelsflügel | trauersymbole/engelsflugel.svg | game-icons.net: lorc/angel-wings | lorc | CC BY 3.0 |
| Grabblumen | trauersymbole/grabblumen.svg | game-icons.net: delapouite/grave-flowers | delapouite | CC BY 3.0 |
| Trauerweide | trauersymbole/trauerweide.svg | game-icons.net: caro-asercion/willow-tree | caro-asercion | CC BY 3.0 |
| Eiche | trauersymbole/eiche.svg | game-icons.net: lorc/oak | lorc | CC BY 3.0 |
| Eichenblatt | trauersymbole/eichenblatt.svg | game-icons.net: delapouite/oak-leaf | delapouite | CC BY 3.0 |
| Birken | trauersymbole/birken.svg | game-icons.net: caro-asercion/birch-trees | caro-asercion | CC BY 3.0 |
| Berge | trauersymbole/berge.svg | Phosphor Icons (phosphor-icons/core): mountains | Phosphor Icons | MIT |
| Bergkette | trauersymbole/bergkette.svg | game-icons.net: lorc/mountains | lorc | CC BY 3.0 |
| Schaukelstuhl | trauersymbole/schaukelstuhl.svg | game-icons.net: delapouite/rocking-chair | delapouite | CC BY 3.0 |
| Hand mit Herz | trauersymbole/hand-mit-herz.svg | Phosphor Icons (phosphor-icons/core): hand-heart | Phosphor Icons | MIT |
| Händedruck | trauersymbole/handedruck.svg | Phosphor Icons (phosphor-icons/core): handshake | Phosphor Icons | MIT |
| Mond mit Sternen | trauersymbole/mond-mit-sternen.svg | Phosphor Icons (phosphor-icons/core): moon-stars | Phosphor Icons | MIT |
| Regenbogen mit Wolke | trauersymbole/regenbogen-mit-wolke.svg | Phosphor Icons (phosphor-icons/core): rainbow-cloud | Phosphor Icons | MIT |
| Sonnenblume | blumen-neu/sonnenblume.svg | game-icons.net: delapouite/sunflower | delapouite | CC BY 3.0 |
| Mohnblume | blumen-neu/mohnblume.svg | game-icons.net: quoting/poppy | quoting | CC BY 3.0 |
| Gänseblümchen | blumen-neu/ganseblumchen.svg | game-icons.net: lorc/daisy | lorc | CC BY 3.0 |
| Tulpe | blumen-neu/tulpe.svg | Phosphor Icons (phosphor-icons/core): flower-tulip | Phosphor Icons | MIT |
| Blüte | blumen-neu/blute.svg | Phosphor Icons (phosphor-icons/core): flower | Phosphor Icons | MIT |
| Lotus | blumen-neu/lotus.svg | Phosphor Icons (phosphor-icons/core): flower-lotus | Phosphor Icons | MIT |
| Pusteblume | blumen-neu/pusteblume.svg | game-icons.net: delapouite/dandelion-flower | delapouite | CC BY 3.0 |
| Rose | blumen-neu/rose.svg | game-icons.net: lorc/rose | lorc | CC BY 3.0 |
| Kleeblatt | blumen-neu/kleeblatt.svg | game-icons.net: lorc/clover | lorc | CC BY 3.0 |
| Lilie heraldisch | blumen-neu/lilie-heraldisch.svg | game-icons.net: lorc/trefoil-lily | lorc | CC BY 3.0 |
| Blatt | blumen-neu/blatt.svg | Phosphor Icons (phosphor-icons/core): leaf | Phosphor Icons | MIT |
| Pflanze | blumen-neu/pflanze.svg | Phosphor Icons (phosphor-icons/core): plant | Phosphor Icons | MIT |
| Kirschen | blumen-neu/kirschen.svg | Phosphor Icons (phosphor-icons/core): cherries | Phosphor Icons | MIT |
| Baum | blumen-neu/baum.svg | Phosphor Icons (phosphor-icons/core): tree | Phosphor Icons | MIT |
| Tanne | blumen-neu/tanne.svg | Phosphor Icons (phosphor-icons/core): tree-evergreen | Phosphor Icons | MIT |
| Angelrute | hobbys/angelrute.svg | game-icons.net: delapouite/fishing-pole | delapouite | CC BY 3.0 |
| Angler | hobbys/angler.svg | game-icons.net: delapouite/fishing | delapouite | CC BY 3.0 |
| Fisch | hobbys/fisch.svg | Phosphor Icons (phosphor-icons/core): fish | Phosphor Icons | MIT |
| Fisch schlicht | hobbys/fisch-schlicht.svg | Phosphor Icons (phosphor-icons/core): fish-simple | Phosphor Icons | MIT |
| Gitarre | hobbys/gitarre.svg | game-icons.net: lorc/guitar | lorc | CC BY 3.0 |
| Gitarre 2 | hobbys/gitarre-2.svg | Phosphor Icons (phosphor-icons/core): guitar | Phosphor Icons | MIT |
| Akkordeon | hobbys/akkordeon.svg | game-icons.net: caro-asercion/accordion | caro-asercion | CC BY 3.0 |
| Trompete | hobbys/trompete.svg | game-icons.net: delapouite/trumpet | delapouite | CC BY 3.0 |
| Saxophon | hobbys/saxophon.svg | game-icons.net: delapouite/saxophone | delapouite | CC BY 3.0 |
| Klaviertasten | hobbys/klaviertasten.svg | Phosphor Icons (phosphor-icons/core): piano-keys | Phosphor Icons | MIT |
| Noten | hobbys/noten.svg | Phosphor Icons (phosphor-icons/core): music-notes | Phosphor Icons | MIT |
| Wanderer | hobbys/wanderer.svg | game-icons.net: delapouite/hiking | delapouite | CC BY 3.0 |
| Zelt | hobbys/zelt.svg | Phosphor Icons (phosphor-icons/core): tent | Phosphor Icons | MIT |
| Lagerfeuer | hobbys/lagerfeuer.svg | Phosphor Icons (phosphor-icons/core): campfire | Phosphor Icons | MIT |
| Spielkarte Pik-Ass | hobbys/spielkarte-pik-ass.svg | game-icons.net: aussiesim/card-ace-spades | aussiesim | CC BY 3.0 |
| Bierkrug | hobbys/bierkrug.svg | game-icons.net: lorc/beer-stein | lorc | CC BY 3.0 |
| Bierkrug 2 | hobbys/bierkrug-2.svg | Phosphor Icons (phosphor-icons/core): beer-stein | Phosphor Icons | MIT |
| Weinglas | hobbys/weinglas.svg | Phosphor Icons (phosphor-icons/core): wine | Phosphor Icons | MIT |
| Tabakspfeife | hobbys/tabakspfeife.svg | game-icons.net: delapouite/smoking-pipe | delapouite | CC BY 3.0 |
| Gießkanne | hobbys/giekanne.svg | game-icons.net: delapouite/watering-can | delapouite | CC BY 3.0 |
| Schubkarre | hobbys/schubkarre.svg | game-icons.net: delapouite/wheelbarrow | delapouite | CC BY 3.0 |
| Schaufel | hobbys/schaufel.svg | Phosphor Icons (phosphor-icons/core): shovel | Phosphor Icons | MIT |
| Schach Springer | hobbys/schach-springer.svg | game-icons.net: skoll/chess-knight | skoll | CC BY 3.0 |
| Golf | hobbys/golf.svg | Phosphor Icons (phosphor-icons/core): golf | Phosphor Icons | MIT |
| Golf-Tee | hobbys/golf-tee.svg | game-icons.net: delapouite/golf-tee | delapouite | CC BY 3.0 |
| Tennisschläger | hobbys/tennisschlager.svg | game-icons.net: delapouite/tennis-racket | delapouite | CC BY 3.0 |
| Fußball | hobbys/fuball.svg | Phosphor Icons (phosphor-icons/core): soccer-ball | Phosphor Icons | MIT |
| Pokal | hobbys/pokal.svg | Phosphor Icons (phosphor-icons/core): trophy | Phosphor Icons | MIT |
| Fernglas | hobbys/fernglas.svg | Phosphor Icons (phosphor-icons/core): binoculars | Phosphor Icons | MIT |
| Kamera | hobbys/kamera.svg | Phosphor Icons (phosphor-icons/core): camera | Phosphor Icons | MIT |
| Aufgeschlagenes Buch | hobbys/aufgeschlagenes-buch.svg | Phosphor Icons (phosphor-icons/core): book-open | Phosphor Icons | MIT |
| Jagdhorn | hobbys/jagdhorn.svg | game-icons.net: lorc/hunting-horn | lorc | CC BY 3.0 |
| Hirsch | hobbys/hirsch.svg | game-icons.net: caro-asercion/deer | caro-asercion | CC BY 3.0 |
| Hirschkopf | hobbys/hirschkopf.svg | game-icons.net: caro-asercion/deer-head | caro-asercion | CC BY 3.0 |
| Wildschwein | hobbys/wildschwein.svg | game-icons.net: caro-asercion/boar | caro-asercion | CC BY 3.0 |
| Kegel | hobbys/kegel.svg | game-icons.net: delapouite/bowling-pin | delapouite | CC BY 3.0 |
| Fahrrad | hobbys/fahrrad.svg | Phosphor Icons (phosphor-icons/core): bicycle | Phosphor Icons | MIT |
| Windmühle | hobbys/windmuhle.svg | game-icons.net: delapouite/windmill | delapouite | CC BY 3.0 |
| Motorrad | fahrzeuge/motorrad.svg | Phosphor Icons (phosphor-icons/core): motorcycle | Phosphor Icons | MIT |
| Traktor | fahrzeuge/traktor.svg | game-icons.net: delapouite/farm-tractor | delapouite | CC BY 3.0 |
| Traktor 2 | fahrzeuge/traktor-2.svg | Phosphor Icons (phosphor-icons/core): tractor | Phosphor Icons | MIT |
| Dampflok | fahrzeuge/dampflok.svg | game-icons.net: delapouite/steam-locomotive | delapouite | CC BY 3.0 |
| Zug | fahrzeuge/zug.svg | Phosphor Icons (phosphor-icons/core): train | Phosphor Icons | MIT |
| LKW | fahrzeuge/lkw.svg | game-icons.net: delapouite/truck | delapouite | CC BY 3.0 |
| LKW 2 | fahrzeuge/lkw-2.svg | Phosphor Icons (phosphor-icons/core): truck | Phosphor Icons | MIT |
| Auto | fahrzeuge/auto.svg | Phosphor Icons (phosphor-icons/core): car-profile | Phosphor Icons | MIT |
| Segelboot | fahrzeuge/segelboot.svg | game-icons.net: delapouite/sailboat | delapouite | CC BY 3.0 |
| Segelboot 2 | fahrzeuge/segelboot-2.svg | Phosphor Icons (phosphor-icons/core): sailboat | Phosphor Icons | MIT |
| Fischerboot | fahrzeuge/fischerboot.svg | game-icons.net: delapouite/fishing-boat | delapouite | CC BY 3.0 |
| Flugzeug | fahrzeuge/flugzeug.svg | Phosphor Icons (phosphor-icons/core): airplane | Phosphor Icons | MIT |
| Feuerwehrauto | fahrzeuge/feuerwehrauto.svg | Phosphor Icons (phosphor-icons/core): fire-truck | Phosphor Icons | MIT |
| Roller | fahrzeuge/roller.svg | game-icons.net: delapouite/scooter | delapouite | CC BY 3.0 |
| Kaninchen | kleintiere-und-hoftiere/kaninchen.svg | game-icons.net: delapouite/rabbit | delapouite | CC BY 3.0 |
| Kaninchen 2 | kleintiere-und-hoftiere/kaninchen-2.svg | Phosphor Icons (phosphor-icons/core): rabbit | Phosphor Icons | MIT |
| Kaninchenkopf | kleintiere-und-hoftiere/kaninchenkopf.svg | game-icons.net: delapouite/rabbit-head | delapouite | CC BY 3.0 |
| Igel | kleintiere-und-hoftiere/igel.svg | game-icons.net: caro-asercion/hedgehog | caro-asercion | CC BY 3.0 |
| Schildkröte | kleintiere-und-hoftiere/schildkrote.svg | game-icons.net: lorc/turtle | lorc | CC BY 3.0 |
| Meeresschildkröte | kleintiere-und-hoftiere/meeresschildkrote.svg | game-icons.net: delapouite/sea-turtle | delapouite | CC BY 3.0 |
| Papageienkopf | kleintiere-und-hoftiere/papageienkopf.svg | game-icons.net: lorc/parrot-head | lorc | CC BY 3.0 |
| Maus | kleintiere-und-hoftiere/maus.svg | game-icons.net: lorc/mouse | lorc | CC BY 3.0 |
| Maus sitzend | kleintiere-und-hoftiere/maus-sitzend.svg | game-icons.net: lorc/seated-mouse | lorc | CC BY 3.0 |
| Schaf | kleintiere-und-hoftiere/schaf.svg | game-icons.net: delapouite/sheep | delapouite | CC BY 3.0 |
| Ziege | kleintiere-und-hoftiere/ziege.svg | game-icons.net: skoll/goat | skoll | CC BY 3.0 |
| Kuh | kleintiere-und-hoftiere/kuh.svg | game-icons.net: delapouite/cow | delapouite | CC BY 3.0 |
| Kuh 2 | kleintiere-und-hoftiere/kuh-2.svg | Phosphor Icons (phosphor-icons/core): cow | Phosphor Icons | MIT |
| Esel | kleintiere-und-hoftiere/esel.svg | game-icons.net: skoll/donkey | skoll | CC BY 3.0 |
| Huhn | kleintiere-und-hoftiere/huhn.svg | game-icons.net: delapouite/chicken | delapouite | CC BY 3.0 |
| Vogelkäfig | kleintiere-und-hoftiere/vogelkafig.svg | game-icons.net: delapouite/bird-cage | delapouite | CC BY 3.0 |
| Vogelhaus | kleintiere-und-hoftiere/vogelhaus.svg | game-icons.net: delapouite/bird-house | delapouite | CC BY 3.0 |
| Vogel | kleintiere-und-hoftiere/vogel.svg | Phosphor Icons (phosphor-icons/core): bird | Phosphor Icons | MIT |
| Kolibri | kleintiere-und-hoftiere/kolibri.svg | game-icons.net: delapouite/hummingbird | delapouite | CC BY 3.0 |
| Biene | kleintiere-und-hoftiere/biene.svg | game-icons.net: lorc/bee | lorc | CC BY 3.0 |
| Schmetterling | kleintiere-und-hoftiere/schmetterling.svg | Phosphor Icons (phosphor-icons/core): butterfly | Phosphor Icons | MIT |
| Futternapf | hunde-und-katzen-neu/futternapf.svg | game-icons.net: delapouite/dog-bowl | delapouite | CC BY 3.0 |
| Hund sitzend | hunde-und-katzen-neu/hund-sitzend.svg | game-icons.net: delapouite/sitting-dog | delapouite | CC BY 3.0 |
| Hund springend | hunde-und-katzen-neu/hund-springend.svg | game-icons.net: delapouite/jumping-dog | delapouite | CC BY 3.0 |
| Hund schnüffelnd | hunde-und-katzen-neu/hund-schnuffelnd.svg | game-icons.net: delapouite/sniffing-dog | delapouite | CC BY 3.0 |
| Hund | hunde-und-katzen-neu/hund.svg | Phosphor Icons (phosphor-icons/core): dog | Phosphor Icons | MIT |
| Katze | hunde-und-katzen-neu/katze.svg | Phosphor Icons (phosphor-icons/core): cat | Phosphor Icons | MIT |
| Katze 2 | hunde-und-katzen-neu/katze-2.svg | game-icons.net: lorc/cat | lorc | CC BY 3.0 |
| Knochen | hunde-und-katzen-neu/knochen.svg | Phosphor Icons (phosphor-icons/core): bone | Phosphor Icons | MIT |
| Pfotenabdruck | hunde-und-katzen-neu/pfotenabdruck.svg | game-icons.net: lorc/paw-print | lorc | CC BY 3.0 |
| Pfotenherz | hunde-und-katzen-neu/pfotenherz.svg | game-icons.net: lorc/paw-heart | lorc | CC BY 3.0 |
| Pferdekopf | pferde-neu/pferdekopf.svg | game-icons.net: delapouite/horse-head | delapouite | CC BY 3.0 |
| Pferdekopf 2 | pferde-neu/pferdekopf-2.svg | game-icons.net: lorc/horse-head | lorc | CC BY 3.0 |
| Pferd | pferde-neu/pferd.svg | Phosphor Icons (phosphor-icons/core): horse | Phosphor Icons | MIT |
| Hufeisen | pferde-neu/hufeisen.svg | game-icons.net: delapouite/horseshoe | delapouite | CC BY 3.0 |
| Storch | sternenkinder/storch.svg | game-icons.net: delapouite/stork-delivery | delapouite | CC BY 3.0 |
| Baby | sternenkinder/baby.svg | Phosphor Icons (phosphor-icons/core): baby | Phosphor Icons | MIT |
| Kinderwagen | sternenkinder/kinderwagen.svg | Phosphor Icons (phosphor-icons/core): baby-carriage | Phosphor Icons | MIT |
| Papierwindrad | sternenkinder/papierwindrad.svg | game-icons.net: delapouite/paper-windmill | delapouite | CC BY 3.0 |
| Wolke | sternenkinder/wolke.svg | Phosphor Icons (phosphor-icons/core): cloud | Phosphor Icons | MIT |
| Mond | sternenkinder/mond.svg | Phosphor Icons (phosphor-icons/core): moon | Phosphor Icons | MIT |
| Stern | sternenkinder/stern.svg | Phosphor Icons (phosphor-icons/core): star | Phosphor Icons | MIT |
| Vierstern | sternenkinder/vierstern.svg | Phosphor Icons (phosphor-icons/core): star-four | Phosphor Icons | MIT |
| Feder | sternenkinder/feder.svg | Phosphor Icons (phosphor-icons/core): feather | Phosphor Icons | MIT |
