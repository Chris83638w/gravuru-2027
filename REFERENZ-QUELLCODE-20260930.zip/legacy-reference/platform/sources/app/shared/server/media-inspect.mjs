import {inflateSync,brotliDecompressSync} from 'node:zlib';

const MAX=64*1024*1024;
const fail=message=>{throw Error('Ungültige Mediendatei: '+message);};
const need=(test,message)=>{if(!test)fail(message);};
function range(b,offset,length){need(Number.isSafeInteger(offset)&&Number.isSafeInteger(length)&&offset>=0&&length>=0&&offset+length<=b.length,'Dateibereich ist abgeschnitten.');}
function dimensions(w,h){need(Number.isInteger(w)&&Number.isInteger(h)&&w>0&&h>0&&w<=32768&&h<=32768&&w*h<=64000000,'Bildmaße sind ungültig oder zu groß.');return {widthPx:w,heightPx:h};}
const crcTable=Array.from({length:256},(_,n)=>{for(let j=0;j<8;j++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
export function pngCrc(bytes){let c=0xffffffff;for(const n of bytes)c=crcTable[(c^n)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
function png(b){
 need(b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])),'PNG-Signatur fehlt.');
 let p=8,header,ended=false,idatStarted=false,idatEnded=false,palette=false;const data=[];
 while(p<b.length){range(b,p,12);const n=b.readUInt32BE(p);range(b,p+8,n+4);const type=b.toString('ascii',p+4,p+8),v=b.subarray(p+8,p+8+n);
  need(/^[A-Za-z]{4}$/.test(type),'PNG-Chunkname ungültig.');need(pngCrc(b.subarray(p+4,p+8+n))===b.readUInt32BE(p+8+n),'PNG-Prüfsumme stimmt nicht.');
  if(!header)need(type==='IHDR','PNG muss mit IHDR beginnen.');
  if(type==='IHDR'){need(!header&&n===13,'PNG-IHDR ungültig.');const w=v.readUInt32BE(0),h=v.readUInt32BE(4);dimensions(w,h);const depth=v[8],color=v[9];need(({0:[1,2,4,8,16],2:[8,16],3:[1,2,4,8],4:[8,16],6:[8,16]})[color]?.includes(depth),'PNG-Farbtiefe ungültig.');need(v[10]===0&&v[11]===0&&v[12]<=1,'PNG-Verfahren unbekannt.');header={w,h,depth,color,interlace:v[12]};}
  else if(type==='PLTE'){need(!palette&&!idatStarted&&n>=3&&n<=768&&n%3===0,'PNG-Palette ungültig.');palette=true;}
  else if(type==='IDAT'){need(!idatEnded,'PNG-IDAT muss zusammenhängend sein.');idatStarted=true;data.push(v);}
  else if(type==='IEND'){need(n===0&&idatStarted,'PNG-Ende oder Bilddaten fehlen.');ended=true;p+=12;break;}
  else{if(idatStarted)idatEnded=true;need(type[0]===type[0].toLowerCase(),'Unbekannter kritischer PNG-Chunk.');need(!['acTL','fcTL','fdAT'].includes(type),'Animierte PNG-Dateien werden noch nicht unterstützt.');}
  p+=n+12;
 }
 need(ended&&p===b.length,'PNG-Dateiende ungültig.');need(header.color!==3||palette,'PNG-Palette fehlt.');
 const channels=({0:1,2:3,3:1,4:2,6:4})[header.color],passes=header.interlace?[[0,0,8,8],[4,0,8,8],[0,4,4,8],[2,0,4,4],[0,2,2,4],[1,0,2,2],[0,1,1,2]]:[[0,0,1,1]];
 const rows=[];let expected=0;for(const[x,y,dx,dy]of passes){const w=Math.max(0,Math.ceil((header.w-x)/dx)),h=Math.max(0,Math.ceil((header.h-y)/dy));if(!w||!h)continue;const stride=Math.ceil(w*channels*header.depth/8);expected+=(stride+1)*h;rows.push({stride,h});}
 need(expected<=MAX,'Entpacktes PNG überschreitet 64 MB.');const decoded=inflateSync(Buffer.concat(data),{maxOutputLength:expected+1});need(decoded.length===expected,'PNG-Bilddatenlänge stimmt nicht.');let cursor=0;for(const{stride,h}of rows)for(let row=0;row<h;row++){need(decoded[cursor]<=4,'PNG-Zeilenfilter ungültig.');cursor+=stride+1;}
 return {...dimensions(header.w,header.h),validation:'png-crc-and-scanlines',bitDepth:header.depth,colorType:header.color,interlaced:Boolean(header.interlace)};
}
function jpeg(b){
 need(b.length>=4&&b[0]===255&&b[1]===216,'JPEG-Signatur fehlt.');let p=2,meta,scan=false,ended=false;
 while(p<b.length){need(b[p++]===255,'JPEG-Marker erwartet.');while(b[p]===255)p++;range(b,p,1);const marker=b[p++];
  if(marker===217){ended=true;break;}need(![0,216].includes(marker),'JPEG-Marker ungültig.');if(marker===1||(marker>=208&&marker<=215))continue;
  range(b,p,2);const size=b.readUInt16BE(p);need(size>=2,'JPEG-Segmentlänge ungültig.');range(b,p,size);
  if([192,193,194].includes(marker)){need(!meta&&size>=8,'JPEG-Bildkopf ungültig.');const components=b[p+7];need(size===8+components*3&&components>0&&components<=4,'JPEG-Komponenten ungültig.');meta=dimensions(b.readUInt16BE(p+5),b.readUInt16BE(p+3));}
  if(marker===218){need(meta&&size>=6,'JPEG-Bildkopf fehlt.');scan=true;p+=size;while(p<b.length){if(b[p]!==255){p++;continue;}range(b,p,2);if(b[p+1]===0||(b[p+1]>=208&&b[p+1]<=215)){p+=2;continue;}break;}continue;}p+=size;
 }
 need(ended&&scan&&meta&&p===b.length,'JPEG ist abgeschnitten oder enthält unerwartete Restdaten.');return {...meta,validation:'jpeg-marker-structure'};
}
function webp(b){
 need(b.length>=20&&b.toString('ascii',0,4)==='RIFF'&&b.toString('ascii',8,12)==='WEBP'&&b.readUInt32LE(4)+8===b.length,'WebP-RIFF-Länge ungültig.');let p=12,canvas,frame,count=0;
 while(p<b.length){range(b,p,8);const t=b.toString('ascii',p,p+4),n=b.readUInt32LE(p+4);range(b,p+8,n+(n%2));const v=b.subarray(p+8,p+8+n);
  if(t==='VP8X'){need(!canvas&&n===10,'WebP-VP8X ungültig.');need(!(v[0]&2),'Animiertes WebP wird noch nicht unterstützt.');canvas=dimensions(v.readUIntLE(4,3)+1,v.readUIntLE(7,3)+1);}
  if(t==='VP8 '){need(n>=10&&v[0]%2===0&&v.subarray(3,6).equals(Buffer.from([157,1,42])),'WebP-VP8-Bildkopf ungültig.');frame=dimensions(v.readUInt16LE(6)&16383,v.readUInt16LE(8)&16383);count++;}
  if(t==='VP8L'){need(n>=5&&v[0]===47,'WebP-VP8L-Bildkopf ungültig.');const bits=v.readUInt32LE(1);need((bits>>>29)===0,'WebP-VP8L-Version unbekannt.');frame=dimensions((bits&16383)+1,((bits>>>14)&16383)+1);count++;}
  need(!['ANIM','ANMF'].includes(t),'Animiertes WebP wird noch nicht unterstützt.');p+=8+n+(n%2);
 }
 need(count===1&&frame,'WebP-Bilddaten fehlen oder sind mehrdeutig.');if(canvas)need(canvas.widthPx===frame.widthPx&&canvas.heightPx===frame.heightPx,'WebP-Maße widersprechen sich.');return {...frame,validation:'webp-riff-and-frame-structure'};
}
function font(b,mime){
 const sig=b.toString('ascii',0,4);let count;
 if(mime==='font/woff'){
  range(b,0,44);need(sig==='wOFF'&&b.readUInt32BE(8)===b.length,'WOFF-Kopf ungültig.');count=b.readUInt16BE(12);need(count>0&&count<=4096&&b.readUInt16BE(14)===0,'WOFF-Tabellenzahl ungültig.');range(b,44,count*20);
  const intervals=[];let decodedTotal=0;for(let i=0;i<count;i++){const p=44+i*20,offset=b.readUInt32BE(p+4),compressed=b.readUInt32BE(p+8),original=b.readUInt32BE(p+12);need(offset>=44+count*20&&offset%4===0&&compressed>0&&compressed<=original&&original<=MAX,'WOFF-Tabelle ungültig.');decodedTotal+=original;need(decodedTotal<=MAX,'WOFF-Ausgabe überschreitet 64 MB.');range(b,offset,compressed);intervals.push([offset,offset+compressed]);if(compressed<original)need(inflateSync(b.subarray(offset,offset+compressed),{maxOutputLength:original+1}).length===original,'WOFF-Entpacklänge falsch.');}intervals.sort((a,c)=>a[0]-c[0]);for(let i=1;i<intervals.length;i++)need(intervals[i][0]>=intervals[i-1][1],'WOFF-Tabellen überlappen.');
  for(const[o,l]of[[24,28],[36,40]])if(b.readUInt32BE(o))range(b,b.readUInt32BE(o),b.readUInt32BE(l));
 }else if(mime==='font/woff2'){
  range(b,0,48);need(sig==='wOF2'&&b.readUInt32BE(8)===b.length,'WOFF2-Kopf ungültig.');count=b.readUInt16BE(12);need(count>0&&count<=4096&&b.readUInt16BE(14)===0,'WOFF2-Tabellenzahl ungültig.');let p=48,expected=0;
  const uint=()=>{let value=0;for(let i=0;i<5;i++){range(b,p,1);const byte=b[p++];need(!(i===0&&byte===128)&&value<=0x1ffffff,'WOFF2-Base128 ungültig.');value=value*128+(byte&127);if(!(byte&128))return value;}fail('WOFF2-Base128 zu lang.');};
  for(let i=0;i<count;i++){range(b,p,1);const flag=b[p++],tag=flag&63,version=flag>>>6;let explicit='';if(tag===63){range(b,p,4);explicit=b.toString('ascii',p,p+4);p+=4;}const original=uint();need(original<=MAX,'WOFF2-Tabelle zu groß.');const glyf=tag===10||explicit==='glyf',loca=tag===11||explicit==='loca',transformed=(glyf||loca)?version!==3:version!==0;let length=original;if(transformed){need((glyf||loca)?version===0:(tag===3||explicit==='hmtx')&&version===1,'Unbekannte WOFF2-Transformation.');length=uint();if(loca)need(length===0,'WOFF2-loca ungültig.');}expected+=length;}
  need(expected>0&&expected<=MAX,'WOFF2-Ausgabegröße ungültig.');const compressed=b.readUInt32BE(20);range(b,p,compressed);need(brotliDecompressSync(b.subarray(p,p+compressed),{maxOutputLength:expected+1}).length===expected,'WOFF2-Entpacklänge falsch.');for(const[o,l]of[[28,32],[40,44]])if(b.readUInt32BE(o))range(b,b.readUInt32BE(o),b.readUInt32BE(l));
 }else{
  range(b,0,12);need(mime==='font/ttf'?b.readUInt32BE(0)===0x00010000:sig==='OTTO','SFNT-Signatur stimmt nicht.');count=b.readUInt16BE(4);need(count>0&&count<=4096,'SFNT-Tabellenzahl ungültig.');range(b,12,count*16);const tags=new Set();for(let i=0;i<count;i++){const p=12+i*16,tag=b.toString('ascii',p,p+4),offset=b.readUInt32BE(p+8),length=b.readUInt32BE(p+12);need(!tags.has(tag),'Doppelte SFNT-Tabelle.');tags.add(tag);need(offset>=12+count*16&&offset%4===0,'SFNT-Tabellenoffset ungültig.');range(b,offset,length);}
 }
 return {fontFormat:mime.slice(5),tableCount:count,validation:'font-container-structure'};
}
function svg(b){
 const s=new TextDecoder('utf-8',{fatal:true}).decode(b);need(!/<!DOCTYPE|<!ENTITY|\b(?:href|src)\s*=|\bon[a-z]+\s*=|url\s*\(|@import|javascript:/i.test(s),'SVG enthält aktive oder externe Inhalte.');
 const clean=s.replace(/^\s*<\?xml\s[^?]*\?>/,'').replace(/<!--[\s\S]*?-->/g,'');need(!/<!|<\?/.test(clean),'SVG-Sonderkonstruktion nicht unterstützt.');
 const tags=new Set(['svg','g','path','rect','circle','ellipse','line','polyline','polygon','defs','clipPath','mask','linearGradient','radialGradient','stop','title','desc','text','tspan']);const stack=[];let cursor=0,root=false,metadata;
 need(!/&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)/.test(clean),'SVG-Entität ungültig.');
 for(const match of clean.matchAll(/<[^>]*>/g)){const gap=clean.slice(cursor,match.index);need(!/[<>]/.test(gap)&&(stack.length||!gap.trim()),'SVG-Textstruktur ungültig.');const token=match[0],m=token.match(/^<(\/?)([A-Za-z][\w:-]*)([\s\S]*?)(\/?)>$/);need(m&&tags.has(m[2]),'SVG-Element nicht unterstützt.');const[,closing,name,attributes,self]=m;need(!(closing&&self),'SVG-Endtag ungültig.');
  if(closing){need(!attributes.trim()&&stack.pop()===name,'SVG-Elemente nicht korrekt geschlossen.');}
  else{need(root?stack.length>0:name==='svg','SVG braucht genau ein Wurzelelement.');const attrs={};let last=0;for(const a of attributes.matchAll(/\s+([A-Za-z_][\w:.-]*)\s*=\s*(["'])([^<>]*?)\2/g)){need(!attributes.slice(last,a.index).trim()&&!Object.hasOwn(attrs,a[1]),'SVG-Attribute ungültig.');attrs[a[1]]=a[3];last=a.index+a[0].length;}need(!attributes.slice(last).trim(),'SVG-Attributsyntax ungültig.');if(!root){root=true;need(attrs.viewBox,'SVG benötigt eine explizite viewBox.');const box=attrs.viewBox.trim().split(/[\s,]+/).map(Number);need(box.length===4&&box.every(Number.isFinite)&&box[2]>0&&box[3]>0,'SVG-viewBox ungültig.');metadata={viewBox:box,validation:'passive-svg-subset'};}if(!self)stack.push(name);}
  cursor=match.index+token.length;
 }
 need(root&&!stack.length&&!clean.slice(cursor).trim(),'SVG ist abgeschnitten.');return metadata;
}
export function inspectMedia(bytes,mimeType){
 need(bytes instanceof Uint8Array&&bytes.length>0&&bytes.length<=50*1024*1024,'Dateigröße ungültig.');const b=Buffer.from(bytes);let metadata;
 try{if(mimeType==='image/png')metadata=png(b);else if(mimeType==='image/jpeg')metadata=jpeg(b);else if(mimeType==='image/webp')metadata=webp(b);else if(mimeType==='image/svg+xml')metadata=svg(b);else if(['font/ttf','font/otf','font/woff','font/woff2'].includes(mimeType))metadata=font(b,mimeType);else if(mimeType==='application/pdf'){need(/^%PDF-[12]\.\d/.test(b.toString('ascii',0,8))&&/%%EOF\s*$/.test(b.subarray(-1024).toString('ascii'))&&/\bstartxref\s+\d+\s+%%EOF\s*$/.test(b.subarray(-1024).toString('ascii')),'PDF-Kopf oder Dateiende ungültig.');metadata={validation:'pdf-envelope-only'};}else fail('Dateityp wird nicht unterstützt.');}catch(e){if(e.message.startsWith('Ungültige Mediendatei:'))throw e;fail('Struktur oder komprimierte Daten sind fehlerhaft ('+e.message+').');}
 return {bytes:b,metadata};
}
