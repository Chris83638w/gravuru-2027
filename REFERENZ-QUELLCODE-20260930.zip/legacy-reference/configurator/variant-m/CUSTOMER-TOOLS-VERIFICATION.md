# Bedienung und ignorierbare Hinweise – 27.09.2026

## Auftrag und Grundlage
Nutzerauftrag in der bestehenden Werkstattaufgabe: Änderungen zunächst getrennt vorbereiten, nichts überschreiben/veröffentlichen; zuletzt „Man sollte die Warnung auch ignorieren können. Dann leg mal los“.
Gelesene GitHub-Basis: `feat/variante-m-profile-20260924`, `23c8115eb626e98c8a06651e6119ecf10b8c2d36`.
Aufgabenbranch: `task/konfigurator-bedienung-20260927`. Verantwortlich: Codex, bestehende Werkstattaufgabe.
Aktuelle Regeln, zentrale Übergabe, START_HERE, AI-INSTRUCTIONS, STATUS und M-Anleitung gelesen. Lokaler Aufgabenordner hatte keinen Git-Arbeitsbaum. Git-HTTPS-Klon scheiterte am lokalen Git-Helfer; gezielte Quellen wurden über den authentifizierten GitHub-Connector geladen. Keine bestehende Arbeitskopie zurückgesetzt. Remote-Aufgabenbranch enthält durch seine Eltern die vollständige Basis, nicht nur ein Patchpaket.

## Änderungen
- Weißer Vorschauhintergrund, modernere Reiter/Uploadfläche/Dialoge, auswärts gerichtete Eckpfeile, roter Löschknopf mit weißem Icon.
- Klick auf freie Vorschaufläche hebt Auswahl auf. Dialoge schließen nach einem vollständigen Klick außerhalb ihres Rahmens. Keine Schließung durch Ziehen aus einem Dialog heraus.
- Alter erklärender Link „Text mittig ausrichten“ entfernt. Mehrfachauswahl mit Checkboxen und Klick auf Texte; gemeinsame horizontale Zentrierung erhält Höhen/Abstände. Nach freiem Ziehen nahe der Mitte: ausdrücklicher Zentriervorschlag.
- Schriftübernahme fragt nach weiteren Zieltexten. Gesperrte, ausgeblendete und technisch feste Texte werden nicht angeboten. Rückgängig bleibt verfügbar.
- Kategorieänderung leert Suchfeld/Filter. Lokale begriffsbasierte Suche mit Synonymgruppen, Umlautnormalisierung und Rangfolge; exakte Treffer zuerst. Keine Embedding- oder externe KI-Suche, keine laufenden API-Kosten. Wortschatz ist begrenzt und erweiterbar.
- Konturprüfung verwendet die vorhandenen `inkMask`-/`collisions`-Funktionen. Im aktuellen M-Aufbau wird deren ältere Warnoberfläche nicht verlässlich initialisiert; deshalb separate Terminierung und Darstellung, gleiche Konturprüfung. Helle Vektorgravuren werden ausschließlich in der Prüfmaske dunkel behandelt. Originale/Farben bleiben erhalten. Mehrfachtexte/Prüfmarkierungen sind reine Oberfläche, keine Fertigungselemente.
- Konkrete Namen betroffener Elemente, gemeinsame Markierung, Ignorieren und Wiederanzeigen. Ignorierung ist sitzungsbezogen und gilt nur für denselben Konfliktzustand; keine Fertigungsfreigabe.
- Dekorative Texte/Motive nahe einer Bohrung lösen in der Kundenentwurfsprüfung keine pauschale mechanische Fehlermeldung mehr aus. Kontur-/Geometrieprüfung bleibt. Die zentrale native Fertigungsvalidierung wurde nicht geändert.
- Mechanische Hinweise nutzen ausschließlich das vorhandene `layered-doorbell`-Profil: aktive sichtbare Schrauben, modellgebundene Acrylfläche, Loch-/Schraubenkopfmaße und fehlende vollständige Durchgangsbohrung. Einzelplatten/Klebebefestigung erhalten diese Warnung nicht. Keine erfundenen Maße oder Änderungen an technischen Produktprofilen.

## Tatsächlich geprüft
- 58 automatische Tests erfolgreich: contract, ux, image-processing, usability, customer-tools und pipeline. Zwei zunächst fehlgeschlagene Pipelinefälle waren fehlende lokale Originalmedien; nach Abruf der unveränderten Medien alle erfolgreich. Keine Tests mit privaten Kundenbeständen.
- Build und lokaler öffentlicher Export erfolgreich; 104 Originalressourcen gegen bestehendes Inventar geprüft. Export enthält neue CSS/Module; 97 Dateien. Nur lokal erzeugt, nicht veröffentlicht.
- Syntaxprüfung neuer Bedienung und angepasster Interaktionen erfolgreich.
- Browser: AOSU/Labrador, Mehrfachauswahl Familie/Müller und Zentrieren; Wechsel Michroma → Montserrat mit Auswahl der weiteren Texte und Übernahme; Suche „maritim“ liefert Anker, danach Kategorie Hunde leert Suchfeld und zeigt Hunde; Klick neben das Schild entfernt Auswahlgriffe.
- Browser: zwei identische helle Texte an x=80/y=70 erzeugen Überlagerung mit konkreten Namen; Markieren, Ignorieren und Wiederanzeigen funktionieren.
- Visuell: 390×844 und 1280×900. Weißer Hintergrund, auswärts gerichtete Pfeile, roter Löschknopf mit weißem Mülleimer, moderner Uploadbereich geprüft.
- Mechanische Konflikte einschließlich Schrauben/Kleben, vollständige Bohrung und Einzelplatte automatisch geprüft. Keine physische Montageprüfung. Der vorhandene AOSU-Katalog enthält keinen absichtlich ungültigen Rahmen; kein Originalprofil für einen Browsertest verändert.

## Start und Grenzen
Aus frischer vollständiger Arbeitskopie dieses Branches: Node 24, `node configurator/variant-m/server.mjs --port=8963`; dann `http://127.0.0.1:8963/`. Keine Datenbank oder Anmeldung für die sechs vorhandenen Prüfmodelle nötig. Ältere README enthält den umfassenderen Aufbau.
Die aktuelle lokale Arbeitskopie ist ein gezielter Quellenabruf, kein vollständiger Git-Clone; für andere Rechner den Aufgabenbranch vollständig klonen.
Noch nicht geprüft: physisches Smartphone, echte Upload-Dateiauswahl in dieser neuen Browserrunde, echtes Ziehen zur Zentriernachfrage und Dialog-Backdrop-Klick mit Koordinaten. Bestehende Uploadverarbeitung bleibt unverändert, automatische Verarbeitungstests bestanden. Browserprüfung ersetzte keinen Maschinen-/Bestelltest.
Mehrplattenmodelle ohne vorhandenen `layered-doorbell`-Montagevertrag benötigen erst eine belegte Geometrieanbindung. Allgemeine Aussagen über alle Werkstattmodelle wären falsch.
Warenkorb/Bestellung weiterhin nicht angeschlossen. Ignorierte Hinweise sind keine serverseitig gespeicherte Bestellfreigabe. Kein Main-Merge, keine Änderung der öffentlichen Netlify-Seite, Shopify oder Plesk.
Nächster Schritt: Nutzer prüft die separate Vorschau; danach gezielte Korrekturen und separat abgestimmte Veröffentlichung/Zusammenführung.
