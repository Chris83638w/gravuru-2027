# Kordelschilder – Steckbrief aus der Server-Inventur (17.10.2026)

Serverordner `V:\Produkte\Kordelschilder`: 7965 Ordner, Verfahren Gravur 5643 / UV 2315 Ordner, 4596 Fancy-Exportordner. Materialien laut Ordnernamen: Schiefer, Acryl, Holz. Formen: Rechteckig, Quadratisch, Abgerundete Ecken, Herz, Oval, Rund, Figuren (Schiefer), Schneeflocke. SKU-Präfixe: KSRE, KSREUV, KS, KSFI, TSKUV, KSQ, KSAEUV, KSRUUV, TSKUV2, KSOUV. Markierungen: [Archiv] 1, Alt 1.

Dazu gehören fachlich auch die **„Vorsicht Hund“-Kordelschilder** unter `Hinweisschilder\Gravur\Vorsicht Hund\Schiefer Kordel` bzw. `_Feste Designs\Kordel Schiefer` (3 Designordner, 45 Designs) – Vorschlag: Unterkategorie *Hundeschilder* der Linie Kordelschilder.

## Größen laut Register (Bestand.xlsm)

| Verfahren | Form | Material | Größen (° = im alten Konfigurator nicht fertig) |
| --- | --- | --- | --- |
| Gravur | Figuren | – | 20x10, 20x15, 20x20, 30x20 |
| Gravur | Herz | Schiefer | 15.2x15.2, 22.5x26.7 |
| Gravur | Quadratisch | Acryl | 20x20 |
| Gravur | Quadratisch | Schiefer | 20x20 |
| Gravur | Rechteckig | Acryl | 15x9, 20x10°, 20x15, 20x25, 30x20 |
| Gravur | Rechteckig | Schiefer | 15x9, 20x10°, 20x15, 20x25, 30x20 |
| UV | Abgerundete Ecken | – | 20x10, 20x15, 20x15 Tier 2 |
| UV | Herz | Acryl | 20x16 |
| UV | Herz | Holz | 25x20 |
| UV | Oval | Holz | 16x12 |
| UV | Rechteckig | Acryl | 12x8, 18x12, 20x10, 20x15, 20x15 Tier, 21x10, 24x16°, 30x20° |
| UV | Rechteckig | Holz | 15x20, 19x10, 20x15, 20x15 - Herbst°, 24x15, 30x18, 30x20 |
| UV | Rund | – | 16x16, 20x20° |

## Formatreihen (alle Größen aus Register und Ordnerbaum, Seitenverhältnis ±1 %)

| Verhältnis | Größen | Hinweis |
| --- | --- | --- |
| 3.33:1 | 20x6 | Einzelgröße |
| 2.10:1 | 21x10 | Einzelgröße |
| 2.00:1 | 20x10 | Einzelgröße |
| 1.90:1 | 19x10 | Einzelgröße |
| 1.67:1 | 30x18, 15x9 | Reihe (skalierbar) |
| 1.60:1 | 24x15 | Einzelgröße |
| 1.57:1 | 22x14 | Einzelgröße |
| 1.50:1 | 30x20, 12x8, 18x12, 24x16 | Reihe (skalierbar) |
| 1.33:1 | 16x12, 20x15 | Reihe (skalierbar) |
| 1.25:1 | 25x20, 20x16 | Reihe (skalierbar) |
| 1.00:1 | 15.2x15.2, 16x16, 20x20 | Reihe (skalierbar) |
| 0.84:1 | 22.5x26.7 | Einzelgröße |
| 0.80:1 | 20x25 | Einzelgröße |
| 0.75:1 | 15x20 | Einzelgröße |

**Befund:** 22 Größen in 14 Formatklassen – fast jede Größe ein eigenes Verhältnis. Das ist der Grund, warum Designs bisher je Größe neu angelegt wurden (1380 Designs in 51 Ordnern, bei den Schiefer-/Acryl-Rechtecken 42–52 je Größe, also im Kern dieselben ~50 Designs fünfmal). Eine Bereinigung auf wenige Reihen (z. B. 3:2 · 2:1 · 4:3 · 1:1 · Hochformat 4:5) würde die Designpflege auf ein Fünftel senken – Entscheidung des Nutzers.

## Designordner ([CDR]) – zu extrahieren

| SKU | Größe | Designs mit Text | Ordner |
| --- | --- | --- | --- |
| HSH-S-20x15 |  | 7 | `Hinweisschilder\Gravur\Vorsicht Hund\Schiefer Kordel\[CDR]` |
| HSHF-S-20x15 | 20x15 | 19 | `Hinweisschilder\Gravur\Vorsicht Hund\_Feste Designs\Kordel Schiefer\20x15\[CDR]` |
| HSHF-S-22x14 | 22x14 | 19 | `Hinweisschilder\Gravur\Vorsicht Hund\_Feste Designs\Kordel Schiefer\22x14\[CDR]` |
| KSFI-S-20x10 | 20x10 | 23 | `Kordelschilder\Gravur\Figuren\20x10\[CDR]` |
| KSFI-S-20x15 | 20x15 | 23 | `Kordelschilder\Gravur\Figuren\20x15\[CDR]` |
| KSFI-S-20x20 | 20x20 | 23 | `Kordelschilder\Gravur\Figuren\20x20\[CDR]` |
| KSFI-S-22x14 | 22x14 | 23 | `Kordelschilder\Gravur\Figuren\22x14\[CDR]` |
| KSFI-S-30x20 | 30x20 | 23 | `Kordelschilder\Gravur\Figuren\30x20\[CDR]` |
| KSQ-A-20x20 | 20x20 | 42 | `Kordelschilder\Gravur\Quadratisch\Acryl\20x20\[CDR]` |
| KSQ-S-20x20 | 20x20 | 51 | `Kordelschilder\Gravur\Quadratisch\Schiefer\20x20\[CDR]` |
| KSRE-A-15x9 | 15x9 | 42 | `Kordelschilder\Gravur\Rechteckig\Acryl\15x9\[CDR]` |
| KSRE-A-20x10 | 20x10 | 43 | `Kordelschilder\Gravur\Rechteckig\Acryl\20x10\[CDR]` |
| KSRE-A-20x15 | 20x15 | 42 | `Kordelschilder\Gravur\Rechteckig\Acryl\20x15\[CDR]` |
| KSRE-A-20x25 | 20x25 | 42 | `Kordelschilder\Gravur\Rechteckig\Acryl\20x25\[CDR]` |
| KSRE-A-30x20 | 30x20 | 42 | `Kordelschilder\Gravur\Rechteckig\Acryl\30x20\[CDR]` |
| KSRE-S-15x9 | 15x9 | 42 | `Kordelschilder\Gravur\Rechteckig\Schiefer\15x9\[CDR]` |
| KSRE-S-20x10 | 20x10 | 52 | `Kordelschilder\Gravur\Rechteckig\Schiefer\20x10\[CDR]` |
| KSRE-S-20x15 | 20x15 | 51 | `Kordelschilder\Gravur\Rechteckig\Schiefer\20x15\[CDR]` |
| KSRE-S-20x25 | 20x25 | 51 | `Kordelschilder\Gravur\Rechteckig\Schiefer\20x25\[CDR]` |
| KSRE-S-30x20 | 30x20 | 51 | `Kordelschilder\Gravur\Rechteckig\Schiefer\30x20\[CDR]` |
| KS-S-20x10 | 20x10 | 37 | `Kordelschilder\Gravur\Schiefer\20x10\[CDR]` |
| KS-S-20x15 | 20x15 | 37 | `Kordelschilder\Gravur\Schiefer\20x15\[CDR]` |
| KS-S-20x20 | 20x20 | 37 | `Kordelschilder\Gravur\Schiefer\20x20\[CDR]` |
| KS-S-20x25 | 20x25 | 37 | `Kordelschilder\Gravur\Schiefer\20x25\[CDR]` |
| KS-S-22x14 | 22x14 | 37 | `Kordelschilder\Gravur\Schiefer\22x14\[CDR]` |
| KS-S-30x20 | 30x20 | 37 | `Kordelschilder\Gravur\Schiefer\30x20\[CDR]` |
| KSH-S-22,5x26,7 | 22,5x26,7 | 37 | `Kordelschilder\Gravur\Schiefer\Herz - 22,5x26,7\[CDR]` |
| KSSF-A-15x17 |  | 4 | `Kordelschilder\Gravur\Schneeflocke\Acryl\[CDR]` |
| KSAEUV-A-20x10 | 20x10 | 31 | `Kordelschilder\UV\Abgerundete Ecken\20x10\[CDR]` |
| TSKUV3-A-20x15 | 20x15 | 6 | `Kordelschilder\UV\Abgerundete Ecken\20x15 Tier 2\[CDR]` |
| KSAEUV-A-20x15 | 20x15 | 21 | `Kordelschilder\UV\Abgerundete Ecken\20x15\[CDR]` |
| KSHUV-A-20x16 | 20x16 | 10 | `Kordelschilder\UV\Herz\Acryl\20x16\[CDR]` |
| KSH-H-25x20 | 25x20 | 2 | `Kordelschilder\UV\Herz\Holz\25x20\[CDR]` |
| KSOUV-H-16x12 | 16x12 | 10 | `Kordelschilder\UV\Oval\Holz\16x12\[CDR]` |
| TSKUV-A-12x8 | 12x8 | 3 | `Kordelschilder\UV\Rechteckig\Acryl\12x8\[CDR]` |
| TSKUV-A-18x12 | 18x12 | 33 | `Kordelschilder\UV\Rechteckig\Acryl\18x12\[CDR]` |
| KSREUV-A-20x10 | 20x10 | 31 | `Kordelschilder\UV\Rechteckig\Acryl\20x10\[CDR]` |
| TSKUV-A-20x15 | 20x15 | 4 | `Kordelschilder\UV\Rechteckig\Acryl\20x15 Tier\[CDR]` |
| KSREUV-A-20x15 | 20x15 | 16 | `Kordelschilder\UV\Rechteckig\Acryl\20x15\[CDR]` |
| TSKUV2-A-21x10 | 21x10 | 10 | `Kordelschilder\UV\Rechteckig\Acryl\21x10\[CDR]` |
| TSKUV-A-24x16 | 24x16 | 33 | `Kordelschilder\UV\Rechteckig\Acryl\24x16\[CDR]` |
| TSKUV-A-30x20 | 30x20 | 33 | `Kordelschilder\UV\Rechteckig\Acryl\30x20\[CDR]` |
| KSREUV-H-15x20 | 15x20 | 39 | `Kordelschilder\UV\Rechteckig\Holz\15x20\[CDR]` |
| KSREUV-H-19x10 | 19x10 | 4 | `Kordelschilder\UV\Rechteckig\Holz\19x10\[CDR]` |
| KSREHUV-H-20x15 | 20x15 | 6 | `Kordelschilder\UV\Rechteckig\Holz\20x15 - Herbst\[CDR]` |
| KSREUV-H-20x15 | 20x15 | 89 | `Kordelschilder\UV\Rechteckig\Holz\20x15\[CDR]` |
| KSREUV-H-24x15 | 24x15 | 2 | `Kordelschilder\UV\Rechteckig\Holz\24x15\[CDR]` |
| KSREUV-H-30x18 | 30x18 | 2 | `Kordelschilder\UV\Rechteckig\Holz\30x18\[CDR]` |
| KSREUV-H-30x20 | 30x20 | 5 | `Kordelschilder\UV\Rechteckig\Holz\30x20\[CDR]` |
| KSRUUV-H-16x16 | 16x16 | 5 | `Kordelschilder\UV\Rund\16x16\[CDR]` |
| KSRUUV-H-20x20 | 20x20 | 11 | `Kordelschilder\UV\Rund\20x20\[CDR]` |

Summe: 51 Ordner, 1380 Designs mit Text. Dateiinhalt der Ordner noch nicht gelesen (Serververbindung am 17.10. abends nicht mehr erreichbar).

## Unterkategorien (Vorschlag)

Schiefer-Kordelschilder (Gravur) · Acryl-Kordelschilder (Gravur/UV) · Holz-Kordelschilder (UV) sind **Materialvarianten derselben Linie**, keine Unterkategorien. Unterkategorien nach Thema: Willkommensschilder, Familienschilder, Hundeschilder („Vorsicht Hund“), Geschenkartikel (Herbst, Figuren, Herz, Schneeflocke), Hinweisschilder.
