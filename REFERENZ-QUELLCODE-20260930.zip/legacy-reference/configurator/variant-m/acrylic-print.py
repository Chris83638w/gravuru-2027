"""Vector artwork + original-resolution images; CMYK and named Roland separations.

No output ICC is asserted: DeviceCMYK values must be approved with the actual RIP
material profile. This renderer is deliberately limited to sanitized editor SVG.
"""
import base64
import io
import json
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
ET.register_namespace('', 'http://www.w3.org/2000/svg')

deps = os.environ.get('GRAVURU_PYTHON_DEPS')
if deps:
    sys.path.insert(0, deps)
from PIL import Image
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF
from reportlab.pdfgen import canvas
from reportlab.lib.colors import CMYKColorSep
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader, PdfWriter, Transformation
from pypdf.generic import (ArrayObject, DictionaryObject, NameObject, NumberObject,
                          FloatObject, DecodedStreamObject, ContentStream, BooleanObject)

MM = 72 / 25.4

class PrintRenderer(renderPDF._PDFRenderer):
    def drawImage(self, image):
        # Named XObjects preserve alpha and allow both CMYK and white separation
        # conversion. The default inline-image renderer bypasses those steps.
        if image.path:
            self._canvas.drawImage(ImageReader(image.path), image.x, image.y,
                                   image.width, image.height, mask='auto')

def drawing_pdf(drawing):
    output = io.BytesIO()
    target = canvas.Canvas(output, pagesize=(drawing.width, drawing.height), pageCompression=1)
    PrintRenderer().draw(renderPDF.renderScaledDrawing(drawing), target, 0, 0)
    target.showPage(); target.save()
    return output.getvalue()

def nums(values):
    return ArrayObject([FloatObject(v) for v in values])

def separation(name, alternate):
    fn = DictionaryObject({NameObject('/FunctionType'): NumberObject(2),
        NameObject('/Domain'): nums([0, 1]), NameObject('/C0'): nums([0, 0, 0, 0]),
        NameObject('/C1'): nums(alternate), NameObject('/N'): NumberObject(1)})
    return ArrayObject([NameObject('/Separation'), NameObject('/'+name), NameObject('/DeviceCMYK'), fn])

def sanitized_svg(value):
    if not isinstance(value, str) or len(value) > 44_000_000:
        raise ValueError('Ungültige oder zu große Gestaltung.')
    if '<!DOCTYPE' in value.upper() or '<!ENTITY' in value.upper():
        raise ValueError('Dokumentdefinitionen sind nicht erlaubt.')
    root = ET.fromstring(value)
    allowed = {'svg','g','defs','clipPath','path','rect','circle','ellipse','polygon','polyline','line','image','title','desc'}
    for node in root.iter():
        tag = node.tag.split('}')[-1]
        if tag not in allowed:
            raise ValueError('Nicht unterstütztes Druckelement: '+tag)
        for key, content in list(node.attrib.items()):
            attr = key.split('}')[-1]
            if attr == 'style':
                if content.strip() in ('cursor:move','cursor: move','cursor:default','cursor: default'):
                    node.attrib.pop(key);continue
                raise ValueError('Nicht unterstützte Druckdarstellung: style')
            if attr.startswith('on') or attr == 'filter':
                raise ValueError('Nicht unterstützte Druckdarstellung: '+attr)
            if 'url(' in content and not content.startswith('url(#'):
                raise ValueError('Externe Referenzen sind nicht erlaubt.')
            if attr == 'href':
                if tag != 'image' or not content.startswith(('data:image/png;base64,','data:image/jpeg;base64,','data:image/webp;base64,')):
                    raise ValueError('Druckbilder müssen eingebettet sein.')
                image = Image.open(io.BytesIO(base64.b64decode(content.split(',',1)[1],validate=True)))
                if image.width * image.height > 40_000_000:
                    raise ValueError('Bild überschreitet 40 Megapixel.')
                # SVG preserveAspectRatio="slice" is not implemented by svglib.
                # Encode the exact cover placement, preserving every source pixel.
                x,y,w,h = [float(node.get(k,'0')) for k in ('x','y','width','height')]
                if w <= 0 or h <= 0:
                    raise ValueError('Ungültiger Fotobereich.')
                scale = max(w/image.width,h/image.height)
                iw,ih = image.width*scale,image.height*scale
                for k,v in {'x':x+(w-iw)/2,'y':y+(h-ih)/2,'width':iw,'height':ih}.items():
                    node.set(k,str(v))
                node.set('preserveAspectRatio','none')
    root.set('width','150mm');root.set('height','200mm');root.set('viewBox','0 0 150 200')
    return ET.tostring(root)

def cmyk(rgb):
    r,g,b = [min(1,max(0,float(v))) for v in rgb]
    k=1-max(r,g,b)
    return [0,0,0,1] if k>=1 else [(1-r-k)/(1-k),(1-g-k)/(1-k),(1-b-k)/(1-k),k]

def transform_content(stream, pdf, white):
    content=ContentStream(stream,pdf)
    ops=[]
    for args,op in content.operations:
        if op in (b'rg',b'RG',b'g',b'G',b'k',b'K'):
            stroke=op in (b'RG',b'G',b'K')
            if white:
                ops += [([NameObject('/AcrylicWhite')],b'CS' if stroke else b'cs'),([NumberObject(1)],b'SCN' if stroke else b'scn')]
            else:
                vals = cmyk(args if len(args)==3 else [args[0]]*3) if len(args)!=4 else args
                ops.append((list(nums(vals)),b'K' if stroke else b'k'))
        else:
            ops.append((args,op))
    content.operations=ops
    return content

def transform_resources(resources,pdf,white,seen):
    spaces=resources.setdefault(NameObject('/ColorSpace'),DictionaryObject())
    spaces[NameObject('/AcrylicWhite')]=separation('RDG_WHITE',[0,0,0,0])
    for ref in resources.get('/XObject',{}).values():
        obj=ref.get_object()
        if id(obj) in seen: continue
        seen.add(id(obj))
        if obj.get('/Subtype')=='/Form':
            transform_resources(obj['/Resources'],pdf,white,seen)
            data=transform_content(obj,pdf,white).get_data()
            obj.pop('/Filter',None);obj.pop('/DecodeParms',None);obj.set_data(data)
        elif obj.get('/Subtype')=='/Image':
            width,height=int(obj['/Width']),int(obj['/Height'])
            if white:
                raw=b'\xff'*(width*height)
                colorspace=separation('RDG_WHITE',[0,0,0,0])
            else:
                mode={'/DeviceRGB':'RGB','/DeviceGray':'L','/DeviceCMYK':'CMYK'}.get(str(obj.get('/ColorSpace')))
                if not mode or int(obj.get('/BitsPerComponent',8))!=8:
                    raise ValueError('Nicht unterstützter Bildfarbraum.')
                image=Image.frombytes(mode,(width,height),obj.get_data())
                raw=image.convert('CMYK').tobytes();colorspace=NameObject('/DeviceCMYK')
            # Replace compressed encoding without resampling or JPEG recompression.
            import zlib
            obj._data=zlib.compress(raw)
            obj[NameObject('/Filter')]=NameObject('/FlateDecode')
            obj[NameObject('/ColorSpace')]=colorspace
            obj[NameObject('/BitsPerComponent')]=NumberObject(8)
            obj.pop('/DecodeParms',None);obj.pop('/Decode',None)
            # Existing SMask is retained unchanged: clear pixels receive no white.

def converted_page(raw,white):
    reader=PdfReader(io.BytesIO(raw));page=reader.pages[0]
    transform_resources(page['/Resources'],reader,white,set())
    page[NameObject('/Contents')]=transform_content(page.get_contents(),reader,white)
    return reader,page

def export_pdf(payload):
    if payload.get('schema')!='gravuru-acrylic-print/v1':
        raise ValueError('Unbekanntes Druckformat.')
    size=payload.get('options',{}).get('size','small')
    if size not in ('small','large'): raise ValueError('Ungültige Plattengröße.')
    width,height=(150,200) if size=='small' else (200,266.7)
    drawing=svg2rlg(io.BytesIO(sanitized_svg(payload.get('svg'))))
    if drawing is None: raise ValueError('Gestaltung konnte nicht gelesen werden.')
    raw=drawing_pdf(drawing)
    white_reader,white=converted_page(raw,True)
    color_reader,color=converted_page(raw,False)
    writer=PdfWriter();page=writer.add_blank_page(width*MM,height*MM)
    overprint=DictionaryObject({NameObject('/Type'):NameObject('/ExtGState'),
       NameObject('/OP'):BooleanObject(True),NameObject('/op'):BooleanObject(True),NameObject('/OPM'):NumberObject(1)})
    for layer in (white,color):
        layer['/Resources'].setdefault(NameObject('/ExtGState'),DictionaryObject())[NameObject('/AcrylicOverprint')]=overprint
        stream=DecodedStreamObject();stream.set_data(b'q /AcrylicOverprint gs\n'+layer.get_contents().get_data()+b'\nQ')
        layer[NameObject('/Contents')]=stream
        page.merge_transformed_page(layer,Transformation((-width/150,0,0,height/200,width*MM,0)))
    outline=io.BytesIO();c=canvas.Canvas(outline,pagesize=(width*MM,height*MM),pageCompression=1)
    c.setStrokeColor(CMYKColorSep(0,1,0,0,spotName='CutContour',density=1));c.setLineWidth(.1*MM)
    c.setStrokeOverprint(True)
    c.roundRect(0,0,width*MM,height*MM,2*MM,stroke=1,fill=0);c.showPage();c.save()
    page.merge_page(PdfReader(io.BytesIO(outline.getvalue())).pages[0])
    writer.add_metadata({'/Title':'Acrylglas – Rückseitendruck – CMYK / RDG_WHITE / CutContour',
       '/Subject':f'{width} x {height} mm; mirrored once; white under nontransparent artwork; DeviceCMYK, no approved ICC',
       '/Producer':'Gravuru acrylic vector export v1'})
    output=io.BytesIO();writer.write(output);return output.getvalue()

if __name__=='__main__':
    try:
        result=export_pdf(json.load(sys.stdin));sys.stdout.buffer.write(result)
    except Exception as error:
        print(str(error),file=sys.stderr);sys.exit(1)
