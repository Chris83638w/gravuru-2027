# Schriften

Schriften sind Stammdaten der Werkstatt (Schriftbibliothek: TTF/OTF, fester Schnitt, ≤ 8 MB, 1–10 000 Zeichen). Je Familie steht in `fonts` die Freigabeliste; sie landet im Familien-Briefing und ist die Vorgabe für ChatGPT. Skripte prüfen Schriftnamen gegen diese Liste und **ersetzen nie**. Im Design bleibt Text Text; die Fertigungsausgabe bei der Bestellung wandelt ihn mit den Schriftkonturen in Pfade.

## Ersatzschriften für entfernte Schriften (Entscheidung 20.10.2026)

Gilt beim Umrechnen von Bestandsdesigns in die Werkstatt; maschinenlesbar in `schriften.json` → `replacements`. Ersetzt wird nur hier Entschiedenes, alles andere bleibt als „Schrift fehlt“ markiert.

| Entfernt | Ersatz | Anmerkung |
| --- | --- | --- |
| Arial | Lato | neutral, gut lesbar |
| Times New Roman | Libre Baskerville | nächste freie Antiqua; Cinzel verworfen (nur Versalien) |
| Champagne & Limousines | Montserrat Light | statische Instanz wght 300 aus google/fonts (seit 20.10.2026 im Repo) |
| Comic Sans MS | Comic Neue | OFL, aus google/fonts (Chris 23.10.2026) |
| Minimalist (vorläufig Montserrat Light) | – | Datei seit 23.10.2026 im Repo, Ersatz zurückgenommen (katalog-schrift-wechsel.py) |

Ohne Ersatz, Designs ausgeblendet (Chris 23.10.2026): ParmaPetit, Welcome. Noch offen: Helvetica, Georgia, Verdana, Copperplate Gothic, Constantine, Amalfi Coast, AnotherBirdhouse, kindergarten, Melon hunter, Stones.

## Freigegebene Schriften (84)

Grundlage: Nutzer-Liste vom 30.09.2026 (49, [PDF](Schriftarten-Uebersicht-Lizenz_20260930.pdf)), Fjalla One (17.10.2026), 25 freie Ergänzungen für bisher fehlende Richtungen (Vorschlag Claude, vom Nutzer freigegeben 17.10.2026) und 8 für die Schiefer-Gedenktafel 22 × 14 (20.10.2026: Poppins ExtraLight, Montserrat Light, Arvo – OFL; Stylish, Baby Boho Script, Caviar Dreams, Hello Georgia, Sunflower – Dateien von Chris aus „Lizenzfrei & Creative Fabrica“, Lizenzbeleg je Schrift noch ablegen). Maschinenlesbar: [schriften.json](schriften.json). Google-Fonts-Dateien stammen aus dem offiziellen Repo google/fonts (`scripts/fetch-google-fonts.py`, Commit in schriften.json); variable Schriften liegen als statische Instanz Regular (wght 400) vor, weil die Werkstatt keine variablen Schriften verarbeitet. **Entfernt** (keine oder unklare Lizenz): Amalfi Coast, AnotherBirdhouse, kindergarten, Champagne & Limousines, Melon hunter, Stones, Arial, Helvetica, Times New Roman, Georgia, Verdana, Comic Sans MS.

| Kategorie | Schrift | Lizenz | Datei im Repo | im Konfigurator (Plattform) |
| --- | --- | --- | --- | --- |
| Klassische Serifenschriften | Antic Slab | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Klassische Serifenschriften | Bellefair | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Klassische Serifenschriften | Cinzel | Google Fonts – SIL Open Font License | ja | ja |
| Klassische Serifenschriften | Roboto Slab | Google Fonts – Apache License 2.0 | ja | nein (Import nötig) |
| Serifenlose Schriften | Aldrich | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Serifenlose Schriften | Audiowide | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Serifenlose Schriften | Comfortaa | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Serifenlose Schriften | Lato | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Serifenlose Schriften | Michroma | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Serifenlose Schriften | Minimalist | Creative Fabrica – gewerbliche Lizenz (Abo) | ja (23.10.2026, Versalschrift ohne ß – Ausnahme Chris) | nein (Import nötig) |
| Serifenlose Schriften | Raleway | Google Fonts – SIL Open Font License | ja | ja |
| Serifenlose Schriften | Rounded Elegance | Genumano – 100 % frei | ja | nein (Import nötig) |
| Serifenlose Schriften | Fjalla One | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Display- und Plakatschriften (fett/markant) | Archivo Black | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Display- und Plakatschriften (fett/markant) | Ashley Marie | Creative Fabrica – Versal-Schnitt aus dem Trio Ashley Marie, Lizenzschlüssel yk5s-…-xr75 | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Display- und Plakatschriften (fett/markant) | Bebas Neue | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Display- und Plakatschriften (fett/markant) | Bernardo Moda Contrast | Peter Wiegel – 100 % frei | ja | nein (Import nötig) |
| Display- und Plakatschriften (fett/markant) | Chewy | Google Fonts – Apache License 2.0 | ja | nein (Import nötig) |
| Display- und Plakatschriften (fett/markant) | Days One | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Display- und Plakatschriften (fett/markant) | Dream Orphans | Typodermic – CC0 | ja | nein (Import nötig) |
| Display- und Plakatschriften (fett/markant) | Righteous | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Alex Brush | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Allura | Google Fonts – SIL Open Font License | ja | ja |
| Elegante Schreibschriften (kalligrafisch) | Ashley | Creative Fabrica – Skript-Schnitt aus dem Trio Ashley Marie, Lizenzschlüssel yk5s-…-xr75 | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Betsy Bailey | Creative Fabrica – Lizenzschlüssel t6qL-…- gzrf (Download bestätigt) | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Dancing Script | Google Fonts – SIL Open Font License | ja | ja |
| Elegante Schreibschriften (kalligrafisch) | Great Vibes | Google Fonts – SIL Open Font License | ja | ja |
| Elegante Schreibschriften (kalligrafisch) | Italianno | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Magnolia Script | Jovanny Lemonad – OFL (Version prüfen) | ja | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Parisienne | Google Fonts – SIL Open Font License | ja | ja |
| Elegante Schreibschriften (kalligrafisch) | Rochester | Google Fonts – Apache License 2.0 | ja | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Satisfy | Google Fonts – Apache License 2.0 | ja | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Sweetie | Creative Fabrica – Lizenzschlüssel zAGs-…- X854 (Download bestätigt) | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Elegante Schreibschriften (kalligrafisch) | Tangerine | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Signatur- und Pinselschriften | Cookie | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Signatur- und Pinselschriften | Courgette | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Signatur- und Pinselschriften | Homage | Creative Fabrica – gewerbliche Lizenz (Abo) | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Signatur- und Pinselschriften | Kaushan Script | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Signatur- und Pinselschriften | Pacifico | Google Fonts – SIL Open Font License | ja | ja |
| Signatur- und Pinselschriften | Soulmate | Creative Fabrica – Lizenzschlüssel mU1v-…- ppOu (Download bestätigt) | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Signatur- und Pinselschriften | Standlist | Creative Fabrica – Lizenzschlüssel STBy-…- QXJr (Download bestätigt) | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Handschriften (locker/persönlich) | Bad Script | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Handschriften (locker/persönlich) | Caveat | Google Fonts – SIL Open Font License | ja | ja |
| Handschriften (locker/persönlich) | Daniel | Daniel Midgley – frei, auch kommerziell | ja | nein (Import nötig) |
| Handschriften (locker/persönlich) | Daniel Black | Daniel Midgley – frei, auch kommerziell | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Handschriften (locker/persönlich) | Desyrel | Apostrophic Labs – 100 % frei | **fehlt – Nutzer liefert** | nein (Import nötig) |
| Handschriften (locker/persönlich) | Fineliner Script | DrawPerfect – 100 % frei | ja (23.10.2026) | nein (Import nötig) |
| Handschriften (locker/persönlich) | Gloria Hallelujah | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Handschriften (locker/persönlich) | Rock Salt | Google Fonts – Apache License 2.0 | ja | nein (Import nötig) |
| Fraktur / Gebrochene Schrift | Zentenar Fraktur | Peter Wiegel – 100 % frei | ja | nein (Import nötig) |
| Klassische Antiqua | Cormorant Garamond | Google Fonts – SIL Open Font License | ja | ja |
| Klassische Antiqua | Playfair Display | Google Fonts – SIL Open Font License | ja | ja |
| Klassische Antiqua | Libre Baskerville | Google Fonts – SIL Open Font License | ja | ja |
| Klassische Antiqua | Lora | Google Fonts – SIL Open Font License | ja | ja |
| Schmale, kräftige Grotesk | Oswald | Google Fonts – SIL Open Font License | ja | ja |
| Schmale, kräftige Grotesk | Roboto Condensed | Google Fonts – SIL Open Font License | ja | ja |
| Geometrische Sans | Montserrat | Google Fonts – SIL Open Font License | ja | ja |
| Geometrische Sans | Josefin Sans | Google Fonts – SIL Open Font License | ja | ja |
| Marker-/Chalk-Handschrift | Amatic SC | Google Fonts – SIL Open Font License | ja | ja |
| Marker-/Chalk-Handschrift | Kalam | Google Fonts – SIL Open Font License | ja | ja |
| Marker-/Chalk-Handschrift | Patrick Hand | Google Fonts – SIL Open Font License | ja | ja |
| Retro-Script | Lobster | Google Fonts – SIL Open Font License | ja | ja |
| Retro-Script | Sacramento | Google Fonts – SIL Open Font License | ja | ja |
| Schreibmaschine / Monospace | Special Elite | Google Fonts – Apache License 2.0 | ja | nein (Import nötig) |
| Schreibmaschine / Monospace | Courier Prime | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Art déco / Versalien | Cinzel Decorative | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Art déco / Versalien | Poiret One | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Western / Rustikal | Rye | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Western / Rustikal | Alfa Slab One | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Schablone (Stencil) | Stardos Stencil | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Kinder / verspielt | Fredoka | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Kinder / verspielt | Baloo 2 | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Keltisch / Mittelalter | Uncial Antiqua | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Keltisch / Mittelalter | MedievalSharp | Google Fonts – SIL Open Font License | ja | nein (Import nötig) |
| Dicke Brush-Hand | Permanent Marker | Google Fonts – Apache License 2.0 | ja | nein (Import nötig) |

Stand: 64 von 75 Schriftdateien im Repo (`schriften/dateien/<Schrift>/`, je Regular-Schnitt plus Lizenztext).

## Schrift-Sets je Produktlinie (Kundenauswahl)

Die Freigabeliste ist das Reservoir; der Kunde sieht je Linie nur ein Set von 12–15 Schriften. Vorschlag Claude 17.10.2026, zur Freigabe durch den Nutzer; Quelle `sets.json`. **Ändern:** am einfachsten in [sets.xlsx](sets.xlsx) (Matrix Schrift × Set, „x“ ankreuzen oder löschen) – Datei an Claude geben oder hier committen, dann wird sie mit `build-font-sets.py --import-xlsx` zurückgespielt und Musterblätter und JSON sind neu; alternativ `sets.json` direkt auf GitHub bearbeiten. Später bekommt die Werkstatt dafür eine Maske (Auftrag #5). Musterblätter in `_muster/` (Text „Familie Niemann 32“, echte Dateien). Schriften mit feinen Haarlinien sind markiert und nicht in den Sets für kleine Formate. **Michroma und Lato sind in jedem Set enthalten** (Nutzer, 17.10.2026).

| Set | Linie | Schriften | Muster |
| --- | --- | --- | --- |
| `hausnummern` | Hausnummern – kräftig, auf Entfernung lesbar; Scripts nur für den Namensteil | Michroma, Lato, Fjalla One, Oswald, Bebas Neue, Montserrat, Roboto Slab, Cinzel, Archivo Black, Days One, Comfortaa, Rounded Elegance, Minimalist, Great Vibes, Allura | [hausnummern.png](_muster/hausnummern.png) |
| `tuerschilder` | Türschilder / Namensschilder – Familie, Praxis, Büro – ruhig und gut lesbar, dazu elegante Scripts | Michroma, Lato, Montserrat, Raleway, Josefin Sans, Comfortaa, Rounded Elegance, Cinzel, Cormorant Garamond, Playfair Display, Lora, Great Vibes, Allura, Alex Brush, Dancing Script, Homage | [tuerschilder.png](_muster/tuerschilder.png) |
| `andenken` | Andenken / Gedenken – würdevoll: klassische Antiqua und feine Schreibschriften | Michroma, Lato, Cormorant Garamond, Playfair Display, Libre Baskerville, Lora, Cinzel, Bellefair, Antic Slab, Bernardo Moda Contrast, Great Vibes, Italianno, Parisienne, Alex Brush, Magnolia Script, Josefin Sans | [andenken.png](_muster/andenken.png) |
| `schluesselanhaenger` | Schlüsselanhänger – kleine Formate: kräftige Strichstärken, keine Haarlinien | Michroma, Lato, Montserrat, Oswald, Bebas Neue, Fredoka, Baloo 2, Chewy, Righteous, Permanent Marker, Pacifico, Lobster, Kaushan Script, Amatic SC, Caveat | [schluesselanhaenger.png](_muster/schluesselanhaenger.png) |
| `geschenkartikel` | Geschenkartikel – Brettchen, Stifthalter, Lineale – verspielt und persönlich | Michroma, Lato, Pacifico, Lobster, Kaushan Script, Satisfy, Courgette, Cookie, Dancing Script, Sacramento, Amatic SC, Caveat, Patrick Hand, Daniel, Desyrel, Fredoka, Montserrat | [geschenkartikel.png](_muster/geschenkartikel.png) |
| `pferdeschilder` | Pferdeschilder / Stall / Hof – rustikal, western, keltisch, Fraktur | Michroma, Lato, Rye, Alfa Slab One, Special Elite, Uncial Antiqua, MedievalSharp, Zentenar Fraktur, Cinzel, Roboto Slab, Oswald, Bebas Neue, Great Vibes, Alex Brush, Kaushan Script, Permanent Marker | [pferdeschilder.png](_muster/pferdeschilder.png) |
| `hundeschilder` | Hundeschilder – freundlich und robust; Scripts mit Fleisch | Michroma, Lato, Fredoka, Baloo 2, Chewy, Permanent Marker, Pacifico, Lobster, Amatic SC, Caveat, Kalam, Montserrat, Oswald, Bebas Neue, Great Vibes, Rye | [hundeschilder.png](_muster/hundeschilder.png) |
| `firmenschilder` | Firmenschilder – sachlich, technisch bis klassisch; keine Schreibschriften | Michroma, Lato, Montserrat, Raleway, Roboto Condensed, Josefin Sans, Audiowide, Aldrich, Cinzel, Libre Baskerville, Playfair Display, Courier Prime | [firmenschilder.png](_muster/firmenschilder.png) |
| alle | – | alle 75 | [alle.png](_muster/alle.png) |

## Vom Nutzer zu liefern (keine Google Fonts, Dateien liegen nur bei ihm)

| Schrift | Lizenz laut Nutzer-Liste |
| --- | --- |
| Minimalist | Creative Fabrica – gewerbliche Lizenz (Abo) |
| Ashley Marie | Creative Fabrica – Versal-Schnitt aus dem Trio Ashley Marie, Lizenzschlüssel yk5s-…-xr75 |
| Ashley | Creative Fabrica – Skript-Schnitt aus dem Trio Ashley Marie, Lizenzschlüssel yk5s-…-xr75 |
| Betsy Bailey | Creative Fabrica – Lizenzschlüssel t6qL-…- gzrf (Download bestätigt) |
| Sweetie | Creative Fabrica – Lizenzschlüssel zAGs-…- X854 (Download bestätigt) |
| Homage | Creative Fabrica – gewerbliche Lizenz (Abo) |
| Soulmate | Creative Fabrica – Lizenzschlüssel mU1v-…- ppOu (Download bestätigt) |
| Standlist | Creative Fabrica – Lizenzschlüssel STBy-…- QXJr (Download bestätigt) |
| Daniel Black | Daniel Midgley – frei, auch kommerziell |
| Desyrel | Apostrophic Labs – 100 % frei |
| Fineliner Script | DrawPerfect – 100 % frei |
| Daniel (Regular) und Daniel Black | Daniel Midgley – frei, auch kommerziell (nur der Bold-Schnitt liegt vor) |

TTF oder OTF, je Schnitt eine Datei (Regular, Bold … getrennt), keine variablen Schriften, bis 8 MB. Als ZIP im Chat oder aus dem Schriftenordner des Rechners (C:\Windows\Fonts bzw. %LOCALAPPDATA%\Microsoft\Windows\Fonts). Creative-Fabrica-Lizenzschlüssel bleiben beim Nutzer, hier nur der Vermerk.

## Aus dem Testlauf Beispiele.pdf (17.10.2026)
Verwendet: Michroma, Cinzel, Alex Brush, Great Vibes, Rounded Elegance, Homage, Allura, Minimalist, Ashley, Fjalla One (alle freigegeben) und **Champagne & Limousines** (entfernt – in 5 von 19 Designs, muss ersetzt werden).
