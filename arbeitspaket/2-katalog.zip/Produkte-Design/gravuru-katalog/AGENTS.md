# Arbeitsregeln für Agenten (Claude, ChatGPT, Kollegen-Accounts)

Dieses Repo ist der **Gravuru-Katalog**: die einzige Quelle für Materialien, Rohling-Familien, Zeichnungen, Designs, Schriften und Produktlinien. Lies zuerst [STAND.md](STAND.md) (Projektstand, Regeln, offene Entscheidungen), dann [README.md](README.md) (Logik in fünf Ebenen) und [KATALOG.md](KATALOG.md) (erzeugte Übersicht).

## Was gilt
1. **Quelle ist JSON** (`familien/**/*.json`, Schema `gravuru-product-family/v2`). `KATALOG.md`, `kataloge/` (PDF, PNG, Excel) sind **erzeugt** – nie von Hand ändern, sondern nach jeder Änderung neu bauen: `python scripts/build-katalog.py --katalog <dieses Repo>` im Repo `gravuru-2027`.
2. **Nichts erfinden.** Preise, Stärken, Randabstände, Schriften, Lizenzen: unbekannt bleibt `null`/„offen“. Die Zeichnung (`zeichnungen/`) ist das Maß; ihre Werte werden nicht „vereinheitlicht“.
3. **Familie bleibt gültig:** Prüfen mit `node --input-type=module -e "import {validateFamily,familyGaps} from './app/workshop/product-families.mjs' …"` aus `gravuru-2027` (macht `build-katalog.py` automatisch). Ungültige Familien nicht committen.
4. **Motive:** Die allgemeine Bibliothek ist `motive/` (721, Index `motive/motive.json`); Erweiterung nur auf ausdrückliche Anweisung des Nutzers, als Vektor mit Herkunft. **Eigene Motive aus gelieferten Designs bleiben beim Design** (`deko-`/`motiv-`-Ebenen im Design-Ordner) und werden **nie** in `motive/` übernommen; von KIs neu gezeichnete Motive kommen zusätzlich nach `motive-eigene/` (nicht im Kundenkonfi). **Designs** nur nach Lieferform 2 (`designs/README.md`): Text bleibt Text, Motive einfarbig, Master je Formatreihe, `themes` in design.json (ein Design kann mehreren Unterkategorien gehören). Bestandsdesigns in alten Größen: Formatreihe zuordnen oder als „alte Größe“ kennzeichnen – nie alte Größen stillschweigend in Familien aufnehmen. Keine Schriftteilmengen aus PDFs, keine Schriftdateien ohne Lizenznachweis.
5. **Kennungen sind stabil** (Familien-ID, SKU-Schlüssel, Design-ID). Umbenennen nur mit Verweisprüfung.
6. **Jede Änderung ein Commit** mit Grund; Branch `main` ist der gültige Stand. Live-Systeme (Shopify, Amazon) werden aus dem Katalog **exportiert**, nie hier hineinkopiert, und nichts wird ohne Freigabe des Nutzers hochgeladen.
7. Skripte liegen im Code-Repo `gravuru-2027` (`scripts/`), nicht hier. Hier liegen Daten und erzeugte Ansichten.

## Design-Master (Chris, 29.10.2026)
**Für jedes Design und jeden Design-Auftrag gilt [designs/DESIGN-MASTER.md](designs/DESIGN-MASTER.md):** Vorlage 1:1 oder als starke Referenz, 1–3 Schriften aus allen 84 und variieren, Motiv nie verlieren oder verzerren (Text weicht), nicht automatisch mittig, je Serie 2–3 ganz neue Designs (neue Motive nach `motive-eigene/`, nicht im Kundenkonfi), Kontaktbogen 1:1 aus dem Konfi. Jeder neue Auftrag verweist darauf.

## Offene Aufträge
- [gravuru-2027 #4](https://github.com/Chris83638w/gravuru-2027/issues/4) Designstrecke: Umrechnungslauf je Formatreihe, Schriften
- [gravuru-2027 #5](https://github.com/Chris83638w/gravuru-2027/issues/5) Katalog-Basis: Linien, Materialdatenbank, Werkstatt liest aus diesem Repo
