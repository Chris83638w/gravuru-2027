# Oval ab 9x6 – Lieferform 2 (edelstahl-gravur-oval-90x60)

Quelle: Bögen TO-V2A-9x6, TO-V2A-21x14 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**73 Designs**, davon 2 mit Produktionsfassung, 20 mit Themenvorschlag (unsicher), 15 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TO-V2A-9x6 | GR-ES-OV-90X60-T15 | 58 | 15 | 2 | 0 |
| TO-V2A-21x14 | GR-ES-OV-210X140-T15 | 73 | 0 | 0 | 0 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TO-V2A-9x6-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-9x6-D2 | Zwei Zeilen, versetzt | D2 Niedermann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-9x6-D3 | Zwei Zeilen mit Trennlinie | D3 Schäfer | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-9x6-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-9x6-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-9x6-D6 | Familie mit Anker | D6 Erdmann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-9x6-D7 | Hier wohnt Familie mit Segelboot | D7 Fischer | familienschilder, namensschilder |  | 2 |  | Great Vibes, Montserrat Light |  |  |
| TO-V2A-9x6-D8 | Zwei Vornamen und Nachname mit Leuchtturm | D8 Meyer | familienschilder, namensschilder |  | 2 |  | Ashley, Cinzel | ja | „Heimathafen …“: Zeilenabstand 5.5 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Produktionsfassung: „Heimathafen …“: Zeilenabstand 5.5 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original) |
| TO-V2A-9x6-D9 | Leuchtturm (ohne Text) | D9 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D10 | Zwei Vornamen und Nachname mit Laubbaum | D10 Altmann | familienschilder, namensschilder |  | 2 |  | Comfortaa |  |  |
| TO-V2A-9x6-D11 | Pusteblume (ohne Text) | D11 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D12 | Herzlich Willkommen bei Familie mit Pusteblume | D12 Bohlmann | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Homage, Raleway |  |  |
| TO-V2A-9x6-D13 | Familie mit Pusteblume, Serifenschrift | D13 Neumann | familienschilder, namensschilder |  | 2 |  | Cinzel, Homage |  |  |
| TO-V2A-9x6-D14 | Blumenwiese mit Pusteblume (ohne Text) | D14 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D15 | Blumenwiese (ohne Text) | D15 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D16 | Rose (ohne Text) | D16 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D17 | Vor- und Nachname mit Blüten, Handschrift | D17 Julia | familienschilder, namensschilder |  | 2 |  | Bad Script | ja |  |
| TO-V2A-9x6-D18 | Familie mit Pusteblume, Antiqua | D18 Erdmann | familienschilder, namensschilder |  | 2 |  | Great Vibes, Libre Baskerville |  |  |
| TO-V2A-9x6-D19 | Zwei Vornamen und Nachname mit Rose | D19 Tauschner | familienschilder, namensschilder |  | 2 |  | Rochester |  |  |
| TO-V2A-9x6-D20 | Vor- und Nachname mit Lebensbaum, Serifenschrift | D20 Josef | familienschilder, namensschilder |  | 2 |  | Cinzel |  | „Josef…“: Zeilenabstand 11.4 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original) |
| TO-V2A-9x6-D21 | Zwei Vornamen und Nachname mit Sonne, Handschrift | D21 Wirtmann | familienschilder, namensschilder |  | 2 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TO-V2A-9x6-D22 | Familie mit Haus-Skizze, Serifenschrift | D22 Schmittberger | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TO-V2A-9x6-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 2 |  | Rochester |  |  |
| TO-V2A-9x6-D24 | Zuhause von Familie mit Haus und Herz | D24 Zuhause von | familienschilder, namensschilder |  | 2 |  | Homage, Raleway |  |  |
| TO-V2A-9x6-D25 | Hier wohnt Familie mit Haus und Herz | D25 Goldmann | familienschilder, namensschilder |  | 2 |  | Allura, Cinzel |  |  |
| TO-V2A-9x6-D26 | Vor- und Nachname mit Glocke | D26 Zimmermann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-9x6-D27 | Zwei Vornamen und Nachname mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-9x6-D28 | Fußball (ohne Text) | D28 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D29 | Herzlich Willkommen bei Familie mit Hundewelpe und Hundename | D29 Familie | familienschilder, namensschilder, hundeschilder, willkommensschilder |  | 2 |  | Ashley, Raleway |  |  |
| TO-V2A-9x6-D30 | Familie mit Hundekopf und Hundename | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 2 |  | Raleway |  |  |
| TO-V2A-9x6-D31 | Zuhause von Familie mit Hund-Silhouette | D31 Familie Fischer | familienschilder, namensschilder, hundeschilder |  | 2 |  | Ashley, Cinzel |  |  |
| TO-V2A-9x6-D32 | Familie mit Pfote und Hundename, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 2 |  | Homage, Michroma |  |  |
| TO-V2A-9x6-D33 | Familie mit Pfoten und Hundename | D33 mit Lucky | familienschilder, namensschilder, hundeschilder |  | 2 |  | Cinzel, Sweetie |  |  |
| TO-V2A-9x6-D34 | Willkommen bei Familie mit Katze und Katzenname | D34 Willkommen bei | familienschilder, namensschilder, katzenschilder, willkommensschilder |  | 2 |  | Allura, Libre Baskerville |  |  |
| TO-V2A-9x6-D35 | Hier leben – zwei Vornamen und Nachname mit Katze und Katzenname | D35 mit Oskar | familienschilder, namensschilder, katzenschilder |  | 2 |  | Michroma, Sweetie |  |  |
| TO-V2A-9x6-D36 | Schnörkel-Ornament (ohne Text) | D36 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D37 | Zwei Vornamen und Nachname mit Unendlichkeitszeichen | D37 Wortmann | familienschilder, namensschilder |  | 2 |  | Cinzel, Homage |  |  |
| TO-V2A-9x6-D38 | Familie mit Herzen | D38 Hottung | familienschilder, namensschilder | hochzeitsschilder | 2 |  | Allura, ParmaPetit |  | Schrift ohne Datei im Katalog: ParmaPetit |
| TO-V2A-9x6-D39 | Schnörkel mit Herz (ohne Text) | D39 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D40 | Eule auf Zweig (ohne Text) | D40 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D41 | Familie mit Kolibri | D41 Vogel | familienschilder, namensschilder |  | 2 |  | Ashley, Raleway |  |  |
| TO-V2A-9x6-D42 | Vor- und Nachname mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 2 |  | Homage, Montserrat Light |  |  |
| TO-V2A-9x6-D43 | Familie mit Taubenpaar, Serifenschrift | D43 Familie | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TO-V2A-9x6-D44 | Zwei Vornamen und Nachname mit Vogelpaar im Herz | D44 Ruprecht | familienschilder, namensschilder | hochzeitsschilder | 2 |  | Allura, Raleway |  |  |
| TO-V2A-9x6-D45 | Hier wohnt Vor- und Nachname mit Vogel | D45 König | familienschilder, namensschilder |  | 2 |  | Cinzel, Rochester |  |  |
| TO-V2A-9x6-D46 | Familie mit Vogelpaar auf Zweig | D46 Vogel | familienschilder, namensschilder |  | 2 |  | Ashley, Raleway |  |  |
| TO-V2A-9x6-D47 | Herzlich Willkommen bei Vor- und Nachname mit Vogel auf Zweig | D47 Carla Sonneburg | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Sweetie |  |  |
| TO-V2A-9x6-D48 | Familie mit Schmetterlingen | D48 Schumacher | familienschilder, namensschilder |  | 2 |  | Allura, Raleway |  |  |
| TO-V2A-9x6-D49 | Zwei Eulen auf Zweig (ohne Text) | D49 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D50 | Drei Eulen auf Zweig (ohne Text) | D50 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D51 | Vier Eulen auf Zweig (ohne Text) | D51 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 2 |  | Ashley |  |  |
| TO-V2A-9x6-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 2 |  | Ashley, Montserrat Light |  |  |
| TO-V2A-9x6-D54 | Familie mit Lilie, Serifenschrift | D54 Kampmann | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TO-V2A-9x6-D55 | Hier wohnt Familie mit Schnörkel und Herz | D55 Hier wohnt | familienschilder, namensschilder |  | 2 |  | Allura, Montserrat Light |  |  |
| TO-V2A-9x6-D56 | Familie mit Schnörkel-Ornament | D56 Familie | familienschilder, namensschilder |  | 2 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TO-V2A-9x6-D57 | Familie mit Herz-Ranken-Ornament | D57 Pielstädt | familienschilder, namensschilder |  | 2 |  | Cinzel, Italianno |  |  |
| TO-V2A-9x6-D58 | Familie mit Herzranke und Spruch | D58 Feldkamp | familienschilder, namensschilder |  | 2 |  | Comfortaa, Italianno |  |  |
| TO-V2A-9x6-D59 | Zwei Vornamen und Nachname mit Rosen-Ornament | D59 Langhagen | familienschilder, namensschilder |  | 2 |  | Italianno |  |  |
| TO-V2A-9x6-D60 | Familie mit Ornament und Spruch | D60 Willkommen bei uns | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Allura, Cinzel |  |  |
| TO-V2A-9x6-D61 | Zwei Vornamen und Nachname mit Zweigen und Herz | D61 Kampmann | familienschilder, namensschilder |  | 2 |  | Montserrat Light, Sweetie |  |  |
| TO-V2A-9x6-D62 | Familie mit Schlüssel und Linie | D62 Schielmann | familienschilder, namensschilder |  | 2 |  | Fineliner Script, Raleway |  | Schrift ohne Datei im Katalog: Fineliner Script |
| TO-V2A-9x6-D63 | Wimpelkette (ohne Text) | D63 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D64 | Eck-Ornamente (ohne Text) | D64 | familienschilder | namensschilder | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D65 | Hier wohnt Familie mit Vornamen und Herzen | D65 Familie Wegner | familienschilder, namensschilder |  | 2 |  | Homage, Raleway |  |  |
| TO-V2A-9x6-D66 | Mr. & Mrs. mit Herzen und Nachname | D66 Westermann | familienschilder, namensschilder, hochzeitsschilder |  | 2 |  | Raleway |  |  |
| TO-V2A-9x6-D67 | Initialen mit Ringen und Nachname | D67 Trautmann | familienschilder, namensschilder, hochzeitsschilder |  | 2 |  | Antic Slab, Great Vibes |  |  |
| TO-V2A-9x6-D68 | Familie mit Pfeil nach links | D68 Familie Reimer | familienschilder, namensschilder | hinweisschilder | 2 |  | Michroma |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TO-V2A-9x6-D69 | Familie mit Pfeil nach rechts, Serifenschrift | D69 Maier | familienschilder, namensschilder | hinweisschilder | 2 |  | Libre Baskerville |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TO-V2A-9x6-D70 | Zwei Vornamen und Nachname mit Pfeil nach oben | D70 Mükmann | familienschilder, namensschilder | hinweisschilder | 2 |  | Cinzel, Italianno |  |  |
| TO-V2A-9x6-D71 | Familie mit Pfeil nach unten | D71 Kleester | familienschilder, namensschilder | hinweisschilder | 2 |  | Comfortaa |  |  |
| TO-V2A-9x6-D72 | Videoüberwachung-Symbol (ohne Text) | D72 | hinweisschilder |  | 1 | GR-ES-OV-90X60-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TO-V2A-9x6-D73 | Kein Eingang mit STOP | D73 Kein | hinweisschilder |  | 2 |  | Lato, Libre Baskerville |  |  |

## Schriften ohne Datei im Katalog

- Fineliner Script: 3 Designs (TO-V2A-9x6-D21, TO-V2A-9x6-D56, TO-V2A-9x6-D62)
- ParmaPetit: 1 Designs (TO-V2A-9x6-D38)
