# Auftrag an ChatGPT · Neue Gedenktafel-Designs für unterbesetzte Zielgruppen

Du gestaltest Designs für unsere Gedenktafeln (Schiefer, Granit, Marmor, Acrylglas, Edelstahl – graviert oder UV-bedruckt). Der Bestand hat 653 Designs, aber fast alle sind „allgemein“ oder für Hunde. Für Oma, Opa, Papa, Eltern, Geschwister, Partner, Freund, Katzen, Pferde, Kleintiere und Sternenkinder fehlen eigene Designs. Form, Größe, Material und Preise sind festgelegt – du gestaltest nur Text, Motiv und (wo vorgesehen) die Fotofläche.

## Was mitgeliefert ist
- `zielgruppen.csv` – Zielgruppe, Unterkategorie, Anzahl im Bestand, **gewünschte Anzahl neuer Designs** und die gestalterische Richtung je Gruppe (insgesamt 104 Designs).
- `schablonen/*.svg` – die Platten in Endmaß (mm). Pflicht ist `GT-RE-300X200` (30 × 20 cm, Querformat); die anderen Formen sind Zusatzmaster (siehe unten). Blau gestrichelt = empfohlener Gestaltungsrand 10 mm: **Texte innerhalb**, Motive dürfen bis 3 mm an den Rand.
- `schriften.txt` – die einzigen zugelassenen Schriften, Namen exakt so verwenden (Namenszeilen gern Schreibschrift, Daten und Sprüche gut lesbar).
- `stilreferenz/*.png` – Übersichtsbögen unseres Bestands (Aufteilung, Tonalität, typische Motivgröße). **Nicht kopieren** – neue Entwürfe, die in dieselbe Reihe passen.
- `sprueche-bestand.md` – alle Sprüche, die wir schon verwenden. **Nicht wiederverwenden**, sondern neue, eigene Texte formulieren.
- Motive: (a) die allgemeine Bibliothek `motive/` im Katalog-Repo (721 Vektoren in 47 Kategorien, Übersicht `motive/INDEX.md`: Engel, Flügel, Herzen, Kreuze, Bäume, Blumen, Federn, Infinity, Hunde, Katzen, Pferde, Brandzeichen, Vögel …) – unverändert einsetzen, Dateiname nennen; (b) eigene, neu gezeichnete Vektormotive – sie **gehören zum Design** (`deko-<name>`) und kommen nicht in die Bibliothek. Keine Rasterbilder, keine Graustufen, keine Verläufe.

## Was du lieferst
Je Design **ein Master im Format 30 × 20 cm** (`GT-RE-300X200.svg`); daraus rechnen wir 20 × 15, 40 × 30 und die anderen 3:2-Größen automatisch. Zusätzlich, wenn das Motiv es trägt:

| Zusatzmaster | Schablone | wofür |
| --- | --- | --- |
| Hochformat 20 × 30 | `GT-RE-200X300.svg` | Menschen (Premium Schiefer) |
| Herz 24 × 22,5 | `GT-HZ-240X225.svg` | Menschen, Tiere – mindestens ein Drittel der Designs je Gruppe |
| Herz liegend 19 × 14,4 | `GT-HZ-190X144.svg` | kleine Herzen (Marmor, Schiefer) |
| Stern 20 × 19 | `GT-ST-200X190.svg` | Sternenkinder, Kinder |
| Knochen 23 × 10,5 | `GT-KN-230X105.svg` | nur Hunde |
| Rund Ø 25,3 | `GT-RD-253X253.svg` | Acrylglas rund, optional |

Jedes Design gibt es in **zwei Varianten**: „mit Foto“ (Fotofläche als Oval, Rechteck mit runden Ecken, Kreis oder Herz, 70–110 mm breit auf dem 30 × 20-Master) und „ohne Foto“ (die Fläche entfällt, der Rest rückt zusammen). Wenn eine Variante nicht sinnvoll ist, nur eine liefern und das in `designs.csv` vermerken.

## Inhalt und Tonalität
- **Textfelder je Design:** `text-name` (Vorname Nachname bzw. Tiername), `text-daten` (`* 12.03.1948   † 05.08.2024`; bei Tieren meist nur Jahre `2009 – 2023`; bei Sternenkindern oft ein Datum), `text-spruch` (2–5 Zeilen) und optional `text-zusatz` („Unsere liebe Oma“, „In liebevoller Erinnerung“, „Für immer in unseren Herzen“). Keine leeren Textobjekte.
- Platzhalter: erfundene Namen, je Design andere; Daten plausibel zur Gruppe (Oma/Opa 75–95 Jahre, Kind 3–17, Sternenkind unter 1 Jahr, Tiere 2–18 Jahre).
- **Sprüche müssen rechtefrei sein:** eigene kurze Texte oder gemeinfreie Zitate (Autor vor 1955 gestorben, Quelle in `designs.csv` nennen). Keine Liedzeilen, keine Gedichte lebender oder kürzlich verstorbener Autoren, keine Bibelzitate aus modernen Übersetzungen (Luther 1912 ist frei).
- Tonalität: ruhig, würdevoll, wenige Elemente; ein Motiv je Design, Schriftmischung höchstens zwei Schriften. Bei Tieren liebevoll, nicht kitschig; bei Sternenkindern sehr behutsam.
- Gestaltet wird **schwarz auf weiß**: Schwarz = graviert/gedruckt, Weiß = Platte. Die Werkstatt stellt daraus Gravur (hell auf dunkel) oder UV-Druck (weiß oder farbig) dar. Keine Graustufen, keine Verläufe, keine Konturen unter 0,3 mm.

## Lieferform
Ordner `<design-id>/` mit `design.svg` in Endmaß (`width="300mm" height="200mm" viewBox="0 0 300 200"`), oberste Ebenen als `<g id="…">`:

| Ebene | Inhalt |
| --- | --- |
| `text-name`, `text-daten`, `text-spruch`, `text-zusatz` | genau ein `<text>` je Ebene (mehrzeilig über `<tspan>`), `text-anchor` start/middle/end, Schrift aus `schriften.txt` – wird bearbeitbares Kundenfeld |
| `motiv-<n>` | Motiv aus der Bibliothek, schwarz auf transparent, Dateiname als `data-quelle="motive/<Kategorie>/<Datei>.svg"` |
| `deko-<name>` | eigenes Vektormotiv des Designs |
| `foto-1` | genau eine Form (Pfad) als Fotofläche, hellgrau gefüllt (`#dddddd`) – nur in der Variante „mit Foto“ |

**Text bleibt Text** – nichts in Kurven/Pfade umwandeln. Keine Transformationen, Skripte, externen Links oder eingebetteten Bilder. Dazu `design.json`:

```json
{ "id": "gt-oma-03", "themes": ["Menschen/Oma"], "photo": true, "masters": ["GT-RE-300X200", "GT-HZ-240X225"],
  "texts": { "text-name": "Hildegard Brandt", "text-daten": "* 03.04.1939   † 21.11.2024", "text-spruch": "…", "text-zusatz": "Unsere liebe Oma" },
  "motifs": ["motive/Blumen/Rose 2.svg"], "spruchQuelle": "eigener Text" }
```

Benennung: `gt-<gruppe>-<nn>` (Gruppen: oma, opa, papa, mama, eltern, partner, geschwister, freund, kind, katze, pferd, kleintier, hund, sternenkind), Fotovariante mit Suffix `-f`, ohne Foto `-o`. Zusammenfassung als `designs.csv` (Kennung; Zielgruppe; Unterkategorie; weitere Themen; Master; Foto; Motivquelle; Spruchquelle).

Alternativ als **Bogen** wie unsere Corel-Bögen: eine PDF-Seite je Master, je Design eine Platte im echten Maß, Gestaltung schwarz, darunter außerhalb der Platte die Kennung – wir zerlegen den Bogen automatisch.

## Abnahme
Wir prüfen automatisch: Text als Text, nur zugelassene Schriften, Lage im Gestaltungsrand, Kontur je Zielform, Lesbarkeit der Daten (Mindestgröße 9 pt auf 30 × 20), Rechtefreiheit der Sprüche (Quelle). Was nicht passt, kommt mit Begründung zurück. Freigegebene Designs werden in den Katalog unter `designs/bestand/gedenktafeln/<Zielgruppe>/<Unterkategorie>/` übernommen und auf alle Größen der Reihe übertragen.
