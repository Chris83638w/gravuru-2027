# 8x2 – Lieferform 2 (edelstahl-gravur-80x20)

Quelle: Bögen TRE-V2A-8x2 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**17 Designs**, davon 3 mit Produktionsfassung, 0 mit Themenvorschlag (unsicher), 0 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TRE-V2A-8x2 | GR-ES-RE-80X20-T15 | 17 | 56 | 3 | 0 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TRE-V2A-8x2-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TRE-V2A-8x2-D2 | Zwei Zeilen, versetzt | D2 Niedermeier | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TRE-V2A-8x2-D3 | Zwei Zeilen mit Trennlinie | D3 Schäfer | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TRE-V2A-8x2-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TRE-V2A-8x2-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TRE-V2A-8x2-D6 | Familie mit Anker | D6 Erdmann | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TRE-V2A-8x2-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 1 |  | Rochester | ja |  |
| TRE-V2A-8x2-D26 | Vor- und Nachname mit Glocke | D26 Zimmermann | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TRE-V2A-8x2-D27 | Name mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TRE-V2A-8x2-D30 | Familie mit Hund | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 1 |  | Raleway |  |  |
| TRE-V2A-8x2-D32 | Familie mit Pfote, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 1 |  | Homage, Michroma | ja |  |
| TRE-V2A-8x2-D35 | Familie mit Katze, Serifenschrift | D35 Familie | familienschilder, namensschilder, katzenschilder |  | 1 |  | Libre Baskerville |  |  |
| TRE-V2A-8x2-D37 | Zwei Namen mit Unendlichkeitszeichen | D37 Hannah | familienschilder, namensschilder |  | 1 |  | Great Vibes |  |  |
| TRE-V2A-8x2-D42 | Name mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 1 |  | Allura |  |  |
| TRE-V2A-8x2-D45 | Vor- und Nachname mit Vogel | D45 Stefan König | familienschilder, namensschilder |  | 1 |  | Rochester | ja |  |
| TRE-V2A-8x2-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 1 |  | Ashley |  |  |
| TRE-V2A-8x2-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 1 |  | Ashley, Montserrat Light |  |  |
