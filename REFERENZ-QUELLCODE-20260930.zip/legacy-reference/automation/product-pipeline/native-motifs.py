"""Flatten trusted bundled M-library SVGs into the existing passive path format."""
import json,sys
from pathlib import Path
from xml.etree import ElementTree as ET
from fontTools.svgLib.path import SVGPath,parse_path
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen

result=[]
for item in json.loads(Path(sys.argv[1]).read_text(encoding='utf-8')):
    svg=ET.fromstring(item['svgFragment']);x,y,w,h=map(float,svg.attrib['viewBox'].split());scale=min(100/w,100/h)
    matrix=(scale,0,0,scale,(100-w*scale)/2-x*scale,(100-h*scale)/2-y*scale)
    fragments=[];bounds=BoundsPen(None)
    for element in svg:
        if element.tag.split('}')[-1] not in ('path','polygon'):raise ValueError('Nicht unterstützte Bibliothekskontur')
        pen=SVGPathPen(None);SVGPath.fromstring(ET.tostring(element)).draw(TransformPen(pen,matrix));d=pen.getCommands()
        parse_path(d,bounds);rule=element.get('fill-rule',svg.get('fill-rule','nonzero'))
        if rule not in ('evenodd','nonzero'):raise ValueError('Ungültige Füllregel')
        fragments.append('<path d="'+d+'" fill="currentColor" fill-rule="'+rule+'"/>')
    bx,by,ex,ey=bounds.bounds
    result.append({'key':item['key'],'name':item['name'],'category':item.get('category',''),'bounds':[bx,by,ex-bx,ey-by],'svgFragment':''.join(fragments)})
Path(sys.argv[2]).write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
