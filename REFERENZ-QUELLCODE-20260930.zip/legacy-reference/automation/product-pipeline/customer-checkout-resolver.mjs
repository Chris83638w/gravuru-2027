// Resolves customer intent against a server-owned, pinned universal product.
// The legacy AOSU adapter is deliberately not inferred from a local demo profile.
import {prepareConfig,saveDraft,selectedProfile,quote} from '../../configurator/variant-m/contract.mjs';
import {uploadQuote} from '../../configurator/variant-m/ux-model.mjs';
const fail=message=>{throw Object.assign(Error(message),{status:400});};
export function createUniversalResolver({loadPublished,fonts,motifs}){
 if(typeof loadPublished!=='function'||!fonts||!Array.isArray(motifs))throw Error('Veröffentlichte Profile und Bibliotheken erforderlich.');
 return async function resolve(draft,quantity){
  if(draft?.schema!=='gravuru-customer-design/v2'||typeof draft.profileId!=='string'||draft.profileId.length>120||!Number.isInteger(quantity)||quantity<1||quantity>99)fail('Ungültige Gestaltung.');
  const source=await loadPublished(draft.profileId,draft.profileRevision);
  if(!source?.config||source.config.demo||source.config.reviewOnly||source.config.workbench?.embedded)fail('Prüfvorlagen sind nicht bestellbar.');
  const config=prepareConfig(source.config),p=config.profile;
  if(draft.profileId!==p.id||draft.profileRevision!==p.revision||draft.productId!==p.binding.productId)fail('Produkt oder Vorlagenstand hat sich geändert.');
  if(draft.state?.width!==undefined&&draft.state.width!==p.geometry.width||draft.state?.height!==undefined&&draft.state.height!==p.geometry.height)fail('Die Produktmaße sind modellgebunden.');
  const saved=saveDraft(config,draft.state,draft.state.mOptions||{},fonts,motifs);
  const price=quote(config,saved.design.objects,saved.design.id,saved.options,quantity),uploads=uploadQuote(saved.design.objects,quantity,false,config.photo.includedCount!==undefined?config.photo:undefined);
  const bindings=source.bindings;
  if(!bindings?.base||bindings.base.unitCents!==config.basePriceCents)fail('Verbindliche Shopify-Grundpreisbindung fehlt.');
  const picks=[{...bindings.base,quantity}];
  for(const group of p.optionGroups||[]){const option=group.values.find(v=>v.id===saved.options[group.id]),binding=bindings.options?.[group.id]?.[option.id];
   if(option.priceCents>0){if(binding?.unitCents!==option.priceCents)fail('Optionspreis ist nicht mit Shopify verbunden.');picks.push({...binding,quantity});}
  }
  if(price.additionalMotifs){if(bindings.motif?.unitCents!==config.extraMotifCents)fail('Motivpreis ist nicht mit Shopify verbunden.');picks.push({...bindings.motif,quantity:quantity*price.additionalMotifs});}
  if(uploads.unitCents){const unit=config.photo.extraPriceCents??999;if(!unit||bindings.photo?.unitCents!==unit)fail('Fotopreis ist nicht mit Shopify verbunden.');picks.push({...bindings.photo,quantity:quantity*uploads.unitCents/unit});}
  const aggregated=new Map();for(const pick of picks){const old=aggregated.get(pick.variantId);if(old){if(old.unitCents!==pick.unitCents)fail('Widersprüchliche Shopify-Preisbindung.');old.quantity+=pick.quantity;}else aggregated.set(pick.variantId,{variantId:pick.variantId,unitCents:pick.unitCents,quantity:pick.quantity});}
  const selected=selectedProfile(config,saved.options);
  return {release:source.release,lines:[...aggregated.values()],totalCents:price.totalCents+uploads.totalCents,
   snapshot:{profileId:p.id,profileRevision:p.revision,productId:p.binding.productId,geometry:selected.geometry,material:selected.material,processing:selected.processing,design:saved.design,options:saved.options,quantity}};
 };
}
