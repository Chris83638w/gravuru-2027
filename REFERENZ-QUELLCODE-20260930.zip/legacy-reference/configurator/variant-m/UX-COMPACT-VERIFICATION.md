# Variante M: kompakte Bedienung nach Screenshotkorrektur

Stand: 25.09.2026. Basis: `b07d668a11380aee0f4e91b732a6892a4f2de994`.
Aufgabenbranch: `feat/variante-m-profile-20260924`.
Dieser Nachweis aktualisiert die betreffenden Layoutaussagen in
`UX-REFINEMENT-VERIFICATION.md`; dessen fachliche Grenzen bleiben bestehen.

## Umsetzung

- Desktop wieder zweispaltig: Vorschau links, Bedienung rechts.
- Mobil kompakter Kopf; beim frischen Start kein Element ausgewählt. Vorschau,
  Reiter und die drei Textfelder sind bei 390 x 844 CSS-Pixeln gemeinsam sichtbar.
- Große zusätzliche Objektwerkzeugleiste entfernt. Hilfslinien unten links im
  Canvas, Modellname klein unten rechts; Reiter unmittelbar danach.
- Auswahlgriffe optisch 18 x 18 Pixel mit zusätzlicher unsichtbarer Trefferfläche.
  Verschieben, proportional skalieren und drehen funktionieren auf normaler und
  großer Vorschau. Freie Canvasflächen erlauben weiterhin vertikales Scrollen.
- „Schrift ändern“ und Schriftname in einem Button. Millimetereinheit separat,
  Größe über Minus/Plus oder Zahleneingabe, keine nativen Zahlenspinner.
  Sichtbare Texteinstellungen erhalten einen grünen Rahmen.
- Produktvollbild mit kleinem „Zurück“, ohne überlagerte Titelzeile.
- Motivkategorien linksbündig. Weiter/Fertig in der klebenden Reiterleiste;
  beim Scrollen bleibt darüber die aufrufbare Produktminiatur sichtbar.
- Fotoverwaltung zeigt das tatsächlich ausgewählte Bild als Miniatur. Entfernen
  ist rot, „Übernehmen“ steht oben im Bildeditor. Dateien werden sofort angezeigt;
  Bildbearbeitung bleibt optional und lokal.
- Wiederholte Entwurfs-/Sitzungshinweise aus der sichtbaren Oberfläche entfernt.
  Der Warenkorbbutton ist kräftig grün, bleibt aber technisch deaktiviert.
- Beide Maßlinien behalten Endstriche und getrennte Maßtexte. Hintergrund und
  Pseudoelemente der Maßbeschriftungen sind transparent; Edelstahlrahmen unverändert.

## Ausgeführte Prüfung

- Node-Syntaxprüfung der drei geänderten JavaScript-Module.
- Bestehende 45 Vertrags-, UX-, Bildverarbeitungs- und Produktpipeline-Tests.
- Build einschließlich unverändertem Prüfsummenvergleich aller 104 Ressourcen.
- Browser bei 1280 x 960 und 390 x 844 CSS-Pixeln: frischer Start, keine Auswahl,
  zwei Desktopspalten, unmittelbare mobile Reiter, Texteinstellungen und Schriftwahl.
- Tatsächliche Zeigerbewegungen im normalen mobilen Canvas: Text verschoben,
  durch Eckgriff von 12 auf etwa 20,7 mm skaliert und mit Drehgriff gedreht.
  Plusbutton zusätzlich von 12 auf 12,5 mm geprüft.
- Lokale Dateiauswahl eines vorhandenen öffentlichen AOSU-Produktbilds: Bild in
  Vorschau und geladene Miniatur (601 Pixel Originalbreite), sichtbarer Aufpreis,
  Bildeditor und Übernehmen. Keine Kundenbilder und keine externe Übertragung.
- Kategorien linksbündig; Miniatur bei Scrollen oben 62 Pixel hoch und Reiter
  unmittelbar darunter. Sichtprüfung des kleinen Vollbild-Zurück-Buttons.
- Beide Maßbereiche per Browserstilprüfung ohne weißen Hintergrund, Schatten
  oder Hintergrund-Pseudoelement. Keine Browser-Konsolenfehler beobachtet.

Keine Prüfung auf einem physischen Smartphone. Keine Shopify-, Konto-, Checkout-
oder Fertigungsprüfung. Tests bestätigen keine Qualität automatischer Freistellung.

## Freistellung und weiterhin offene Anschlüsse

Die vorhandene lokale Flächenentfernung bleibt unverändert und ist keine hochwertige
KI-Freistellung. Als möglicher Anbieter wurde Photoroom geprüft: Basic Background
Removal laut Anbieter 0,02 USD pro Bild (Abruf 25.09.2026).
Quelle: https://www.photoroom.com/api/pricing
Die Eignung für feines Hundefell muss mit freigegebenen Bildern verglichen werden.
Kein Konto angelegt, keine API verbunden, keine Kosten ausgelöst und keine Bilder
dorthin übertragen.

Dauerhaftes Speichern im Kundenkonto, geschützte Uploadablage, serverseitige Preise,
abrechenbare Shopify-Aufpreise, Kaufbindung/PNG-Download und persönliche KI-Hilfe
sind weiterhin offen. Entfernte Statushinweise sind keine Backend-Fertigstellung.
Die Nachfrage beim tatsächlichen Kontospeichern bleibt wahrheitsgemäß.
Profil-IDs, Preise, Originalreferenzen und historische Quellen unverändert.

