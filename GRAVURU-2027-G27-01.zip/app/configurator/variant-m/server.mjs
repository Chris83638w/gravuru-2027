import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {build,HERE,ROOT,OUTPUT} from './build.mjs';

const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.gz':'application/gzip'};
const csp="default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data: blob:; font-src 'self' data:; frame-src 'self'; object-src 'none'; frame-ancestors 'self'";

// Local, read-only customer preview. There are deliberately no admin, checkout,
// production or filesystem-write routes in this foundation server.
export function createPreviewServer({outputDirectory=OUTPUT}={}) {
  const server=http.createServer((req,res)=>{
    const fail=status=>res.writeHead(status,{'Cache-Control':'no-store'}).end();
    try {
      const port=server.address()?.port;
      if(![`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host))return fail(403);
      const origin='http://'+req.headers.host;
      if((req.headers.origin&&req.headers.origin!==origin)||req.headers['sec-fetch-site']==='cross-site')return fail(403);
      if(!['GET','HEAD'].includes(req.method))return fail(405);
      const pathname=decodeURIComponent(new URL(req.url,origin).pathname);
      if(pathname.includes('\\')||pathname.includes('\0')||pathname.split('/').some(p=>p==='..'||p.startsWith('.')))return fail(404);
      let base,relative;
      const fixed={
        '/':[HERE,'index.html'],
        '/models.json':[outputDirectory,'models.json'],
        '/editor.html':[outputDirectory,'editor.html'],
        '/assistant.js':[outputDirectory,'assistant.js'],
        '/api/guides':[outputDirectory,'guides.json']
      };
      if(fixed[pathname])[base,relative]=fixed[pathname];
      else if(/^\/acrylic-assets\/[a-z0-9-]+\.png$/.test(pathname)){
        base=path.join(ROOT,'designs/acrylic-unser-anfang');relative=pathname.split('/').pop();
      } else {
        const mounts=[['/_runtime/',path.join(ROOT,'designs/aosu-labrador/runtime')],['/platform/sources/app/shared/',path.join(ROOT,'platform/sources/app/shared')],['/configurator/variant-m/',HERE]];
        const mount=mounts.find(([prefix])=>pathname.startsWith(prefix));
        if(!mount)return fail(404);
        base=mount[1];relative=pathname.slice(mount[0].length);
        if(!relative||(!pathname.startsWith('/_runtime/')&&!/\.(mjs|js|css)$/.test(relative)))return fail(404);
      }
      const realBase=fs.realpathSync(base),file=fs.realpathSync(path.resolve(base,relative));
      const within=path.relative(realBase,file);
      if(within.startsWith('..')||path.isAbsolute(within)||!fs.statSync(file).isFile())return fail(404);
      const bytes=fs.readFileSync(file);
      res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Content-Length':bytes.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':csp});
      res.end(req.method==='HEAD'?undefined:bytes);
    } catch {if(!res.headersSent)fail(404);else res.end();}
  });
  return server;
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const port=Number(process.argv.find(v=>v.startsWith('--port='))?.split('=')[1]||8961);
  if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Ungültiger Port.');
  const result=build();
  createPreviewServer().listen(port,'127.0.0.1',()=>console.log(JSON.stringify({project:'Gravuru 2027',...result,url:`http://127.0.0.1:${port}/?model=acryl`,scope:'local-preview'})));
}
