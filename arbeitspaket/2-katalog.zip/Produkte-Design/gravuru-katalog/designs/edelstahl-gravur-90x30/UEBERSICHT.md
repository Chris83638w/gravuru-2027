# Rechteckig ab 9x3 – Lieferform 2 (edelstahl-gravur-90x30)

Quelle: Bögen TRE-V2A-9x3, TRE-V2A-24x8 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**61 Designs**, davon 3 mit Produktionsfassung, 6 mit Themenvorschlag (unsicher), 0 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TRE-V2A-9x3 | GR-ES-RE-90X30-T15 | 61 | 12 | 3 | 0 |
| TRE-V2A-24x8 | GR-ES-RE-240X80-T15 | 61 | 12 | 0 | 0 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TRE-V2A-9x3-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D2 | Zwei Zeilen, versetzt | D2 Niedermeier | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D3 | Zwei Zeilen mit Trennlinie | D3 Schäfer | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D6 | Familie mit Anker | D6 Erdmann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D7 | Familie mit Segelboot | D7 Fischer | familienschilder, namensschilder |  | 2 |  | Great Vibes |  | motiv-1 um 0.0/-0.7 mm nach innen (stand über die Kante) |
| TRE-V2A-9x3-D8 | Zwei Vornamen und Nachname mit Leuchtturm | D8 Meyer | familienschilder, namensschilder |  | 2 |  | Ashley | ja |  |
| TRE-V2A-9x3-D9 | Vor- und Nachname mit Leuchtturm | D9 Charlotte Groner | familienschilder, namensschilder |  | 2 |  | Homage, Raleway |  |  |
| TRE-V2A-9x3-D10 | Zwei Vornamen und Nachname mit Laubbaum | D10 Altmann | familienschilder, namensschilder |  | 2 |  | Comfortaa | ja |  |
| TRE-V2A-9x3-D16 | Vor- und Nachname mit Rose, Serifenschrift | D16 Laura | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TRE-V2A-9x3-D17 | Familie mit Blütenranke | D17 Schneider | familienschilder, namensschilder |  | 2 |  | Italianno | ja | Text „Schneider“ um 0.0/-0.6 mm nach innen (Textkasten stand über); Produktionsfassung: Text „Schneider“ um 0.0/-0.6 mm nach innen (Textkasten stand über) |
| TRE-V2A-9x3-D18 | Zwei Namen mit Pusteblume | D18 Felix Becker | familienschilder, namensschilder |  | 2 |  | Allura |  |  |
| TRE-V2A-9x3-D19 | Herzlich Willkommen bei Vor- und Nachname mit Rose | D19 Ursel Mayer | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Bellefair, Great Vibes |  |  |
| TRE-V2A-9x3-D21 | Familie mit Sonne und Spruch | D21 Familie Lehmann | familienschilder, namensschilder |  | 2 |  | Comic Sans MS, Daniel |  | Schrift ohne Datei im Katalog: Comic Sans MS |
| TRE-V2A-9x3-D22 | Familie mit Haus-Skizze, Serifenschrift | D22 Schmittberger | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TRE-V2A-9x3-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 2 |  | Rochester |  |  |
| TRE-V2A-9x3-D24 | Familie mit Haus und Herz | D24 Familie Hellwig | familienschilder, namensschilder |  | 2 |  | Homage |  |  |
| TRE-V2A-9x3-D25 | Hier wohnt Familie mit Haus und Herz | D25 Goldmann | familienschilder, namensschilder |  | 2 |  | Allura, Cinzel |  |  |
| TRE-V2A-9x3-D26 | Vor- und Nachname mit Glocke | D26 Zimmermann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D27 | Zwei Vornamen und Nachname mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D28 | Vor- und Nachname mit Fußball | D28 Schulze | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TRE-V2A-9x3-D29 | Familie mit Hundewelpe und Hundename | D29 Familie Kuhlmann | familienschilder, namensschilder, hundeschilder |  | 2 |  | Ashley, Raleway |  |  |
| TRE-V2A-9x3-D30 | Familie mit Hundekopf und Hundename | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 2 |  | Raleway |  |  |
| TRE-V2A-9x3-D31 | Zuhause von Familie mit Hund-Silhouette | D31 Familie Fischer | familienschilder, namensschilder, hundeschilder |  | 2 |  | Ashley, Cinzel |  |  |
| TRE-V2A-9x3-D32 | Familie mit Pfote und Hundename, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 2 |  | Homage, Michroma |  |  |
| TRE-V2A-9x3-D33 | Familie mit Pfoten und Hundename | D33 Familie Wegner | familienschilder, namensschilder, hundeschilder |  | 2 |  | Raleway, Sweetie |  |  |
| TRE-V2A-9x3-D34 | Willkommen bei Familie mit Katze und Katzenname | D34 Willkommen bei | familienschilder, namensschilder, katzenschilder, willkommensschilder |  | 2 |  | Allura, Libre Baskerville |  |  |
| TRE-V2A-9x3-D35 | Zwei Vornamen und Nachname mit Katze und Katzenname | D35 mit Oskar | familienschilder, namensschilder, katzenschilder |  | 2 |  | Michroma, Sweetie |  |  |
| TRE-V2A-9x3-D37 | Vor- und Nachname mit Unendlichkeitszeichen | D37 Hannah | familienschilder, namensschilder |  | 2 |  | Great Vibes |  |  |
| TRE-V2A-9x3-D38 | Zwei Namen mit Herzen, Schreibschrift | D38 Olivia Sander | familienschilder, namensschilder | hochzeitsschilder | 2 |  | Italianno |  |  |
| TRE-V2A-9x3-D39 | Herzlich Willkommen bei Familie mit Schnörkel-Herz | D39 Familie Wolf | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Great Vibes |  |  |
| TRE-V2A-9x3-D40 | Willkommen bei Vor- und Nachname mit Eule | D40 Dominik Schröder | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Dancing Script |  |  |
| TRE-V2A-9x3-D41 | Familie mit Kolibri | D41 Vogel | familienschilder, namensschilder |  | 2 |  | Ashley, Raleway |  |  |
| TRE-V2A-9x3-D42 | Vor- und Nachname mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 2 |  | Allura, Montserrat Light |  |  |
| TRE-V2A-9x3-D43 | Familie mit Taubenpaar, Serifenschrift | D43 Familie Krone | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TRE-V2A-9x3-D44 | Zwei Vornamen und Nachname mit Vogelpaar im Herz | D44 Ruprecht | familienschilder, namensschilder | hochzeitsschilder | 2 |  | Allura, Raleway |  |  |
| TRE-V2A-9x3-D45 | Hier wohnt Vor- und Nachname mit Vogel | D45 Stefan König | familienschilder, namensschilder |  | 2 |  | Cinzel, Rochester |  |  |
| TRE-V2A-9x3-D46 | Familie mit Vogelpaar auf Zweig | D46 Vogel | familienschilder, namensschilder |  | 2 |  | Ashley, Raleway |  |  |
| TRE-V2A-9x3-D48 | Familie mit Schmetterlingen | D48 Schumacher | familienschilder, namensschilder |  | 2 |  | Allura, Raleway |  |  |
| TRE-V2A-9x3-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 2 |  | Ashley |  |  |
| TRE-V2A-9x3-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 2 |  | Ashley, Montserrat Light |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-9x3-D54 | Familie mit Lilie, Serifenschrift | D54 Kampmann | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TRE-V2A-9x3-D55 | Hier wohnt Familie mit Schnörkel und Herz | D55 Hier wohnt | familienschilder, namensschilder |  | 2 |  | Allura, Montserrat Light |  |  |
| TRE-V2A-9x3-D56 | Familie mit Schnörkel-Ornament | D56 Familie | familienschilder, namensschilder |  | 2 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TRE-V2A-9x3-D57 | Familie mit Herz-Ranken-Ornament | D57 Pielstädt | familienschilder, namensschilder |  | 2 |  | Cinzel, Italianno |  | Text „Pielstädt“ um 0.0/-4.0 mm nach innen (Textkasten stand über) |
| TRE-V2A-9x3-D58 | Familie mit Herzranke | D58 Feldkamp | familienschilder, namensschilder |  | 2 |  | Comfortaa |  |  |
| TRE-V2A-9x3-D59 | Zwei Vornamen und Nachname mit Rosen-Ornament | D59 Eva & Norbert Langhagen | familienschilder, namensschilder |  | 2 |  | Italianno |  |  |
| TRE-V2A-9x3-D60 | Familie mit Ornament | D60 Familie Hampel | familienschilder, namensschilder |  | 2 |  | Cinzel |  |  |
| TRE-V2A-9x3-D62 | Familie mit Schlüssel und Linie | D62 Familie Schielmann | familienschilder, namensschilder |  | 2 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script |
| TRE-V2A-9x3-D63 | Familie mit Wimpelkette, Serifenschrift | D63 Familie Poller | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TRE-V2A-9x3-D64 | Familie mit Eck-Ornamenten, Serifenschrift | D64 Schötter | familienschilder, namensschilder |  | 2 |  | Cinzel |  |  |
| TRE-V2A-9x3-D65 | Drei Vornamen mit Herzen | D65 Familie Wegner | familienschilder, namensschilder |  | 2 |  | Homage, Raleway |  |  |
| TRE-V2A-9x3-D66 | Mr. & Mrs. mit Herzen und Nachname | D66 Westermann | familienschilder, namensschilder, hochzeitsschilder |  | 2 |  | Raleway |  |  |
| TRE-V2A-9x3-D67 | Initialen mit Ringen und Nachname | D67 Trautmann | familienschilder, namensschilder, hochzeitsschilder |  | 2 |  | Antic Slab, Great Vibes |  |  |
| TRE-V2A-9x3-D68 | Familie mit Pfeil nach links | D68 Familie Reimer | familienschilder, namensschilder | hinweisschilder | 2 |  | Michroma |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-9x3-D69 | Familie mit Pfeil nach rechts, Serifenschrift | D69 Maier | familienschilder, namensschilder | hinweisschilder | 2 |  | Libre Baskerville |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TRE-V2A-9x3-D70 | Zwei Vornamen und Nachname mit Pfeil nach oben | D70 Mükmann | familienschilder, namensschilder | hinweisschilder | 2 |  | Cinzel, Italianno |  | Text „Mükmann“ um 0.0/-0.4 mm nach innen (Textkasten stand über) |
| TRE-V2A-9x3-D71 | Familie mit Pfeil nach unten | D71 Kleester | familienschilder, namensschilder | hinweisschilder | 2 |  | Comfortaa |  |  |
| TRE-V2A-9x3-D72 | Achtung Videoüberwachung mit Familie | D72 Familie | hinweisschilder, familienschilder |  | 2 |  | Antic Slab, Cinzel |  |  |
| TRE-V2A-9x3-D73 | Kein Eingang mit STOP | D73 Kein | hinweisschilder |  | 2 |  | Lato, Libre Baskerville |  |  |

## Schriften ohne Datei im Katalog

- Comic Sans MS: 1 Designs (TRE-V2A-9x3-D21)
- Fineliner Script: 2 Designs (TRE-V2A-9x3-D56, TRE-V2A-9x3-D62)
