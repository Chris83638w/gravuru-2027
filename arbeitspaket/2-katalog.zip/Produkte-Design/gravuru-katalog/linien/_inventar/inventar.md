# Inventur Produktordner (Server)

Quelle: `\\bi-srv01-fs01\Neue-Struktur\Produkte\` – Ordnerliste mit 306805 Ordnern, 57 Produktordner. Nur gelesen; Dateien noch nicht geöffnet. Ausgeschlossen: funkklingel.

| Produkt | Ordner | Verfahren | Größen | davon mit Archiv-Anteil | SKU-Präfixe | Materialien (Ordnernamen) |
| --- | --- | --- | --- | --- | --- | --- |
| Türschilder | 59607 | Gravur 55440, UV 4152 | 52 | 0 | TRE, TQ, TREUV, TR2, TAE, TR1 | Edelstahl, Acryl, Kunststoff, Schiefer, Holz, Acryl+Edelstahl |
| Gedenktafeln | 47462 | Gravur 40294, UV 7138 | 36 | 0 | GT, GTUV, GTHUV, TEMP, GTRUV | Acryl, Acryl + Edelstahl, Schiefer, Premium Schiefer, Granit, Edelstahl |
| Hinweisschilder | 38118 | Gravur 38093 | 24 | 2 | HSH, HP, HSHF, HSW, KSRE | Edelstahl, Kunststoff, Acryl, Schiefer Kordel, Kordel Schiefer, Konfi Kunststoff |
| Namenschilder | 20453 | Gravur 18150, UV 2301 | 61 | 0 | NSREUV, NSR, NSRSG, NSRKG, NSO, NSAESG | Acryl+Edelstahl, Acryl, Acryl auf Edelstahl, Holz, Edelstahl, Schiefer |
| Wandbilder | 19353 | – | 19 | 0 | WBT, WBM, WBC, WBP, WBSZ, WBSC | Acryl, Holz, Alu-Dibond, _Produktbilder mit Nussholz Fuß, _Produktbilder mit Buchenholz Fuß, _Produktbilder mit Holz Fuß dunkel |
| Grabstecker | 18499 | Gravur 15649, UV 2773 | 46 | 0 | GSTH, GSTH4, GSTKR, GSTE, GSTH3, GSTH2 | Edelstahl, Acryl, Edelstahl anders |
| Standbilder | 15840 | Gravur 10242, UV 5384 | 34 | 0 | SH, SHG, SHS, SHUV, SF, STLESC | Acryl, Holz, Acryl ohne Foto, Holz1, Holz Instagram, Songcover Holz |
| Schlüsselanhänger | 15367 | Gravur 9621, UV 5399 | 15 | 0 | SAH, SARE, SA2, SAP, SANFC, SAO | Holz, Acryl, Leder, Lederband, Edelstahl, Acryl Klar |
| Türklingel | 12203 | Gravur 10340, UV 1855 | 26 | 0 | DTK, DTKU, DTKO, UV | Edelstahl, Schiefer, Acryl, Acryl + Edelstahl, mit Edelstahl, ohne Edelstahl |
| Hausnummern | 10411 | Gravur 8969, UV 1439 | 48 | 0 | HN, HNRUV, HNRSG, HNRA, HNRO, HNRHUV | Acryl, Schiefer, Acryl + Edelstahl, Edelstahl + Acryl, Holz Ausschnitt, Holz V2A |
| Kordelschilder | 7965 | Gravur 5643, UV 2315 | 20 | 0 | KSRE, KSREUV, KS, KSFI, TSKUV, KSQ | Schiefer, Acryl, Holz, [108000000 - Kordelschild Gravur Schiefer Figuren 20x10], [108100000 - Kordelschild Gravur Schiefer Figuren 20x10], [108200000 - Kordelschild Gravur Schiefer Figuren 20x15] |
| Gedenkstandbilder | 7421 | Gravur 5679, UV 1741 | 21 | 3 | GDSH, NEU, GDSHG, GDSF, GDSHS, GDSHUV | Acryl, Holz, Gedenkstätte hell mit Kerze Stein und Rosen, weißer Tisch rosa Blumen Infinity Foto UV Holz |
| Firmenschilder | 6122 | Gravur 5799, UV 321 | 19 | 0 | FS, ALT | Acryl, Acryl+Edelstahl, Edelstahl, Schiefer, [102300000 - Firmenschild Gravur Acryl 18x12], [102400000 - Firmenschild Gravur Acryl 20x15] |
| Autoanhänger | 4104 | Gravur 3115, UV 987 | 0 | 0 | – | Acryl, Holz, Acryl Klar Satiniert, Leder, Kreuz_Leder, Blume_Holz |
| Anhänger | 2984 | – | 5 | 0 | OA, SASK | Holz, Acryl, Acryl satiniert, Acryl klar, 11_Druck - Acryl Schleife, 12_Druck - Holz rund |
| Kreuze | 2877 | Gravur 2045, UV 811 | 13 | 1 | KZ, KZUV, KZTUV | Schiefer, Acryl, Holz |
| Hochzeitsschilder | 1457 | Gravur 1449 | 8 | 0 | HZSO, HZSR2, HZS, HZSR1, HZSH | Kunststoff, Acryl, Edelstahl, Edelstahl anders |
| Boxenschilder | 1433 | Gravur 696, UV 722 | 10 | 0 | BSUV, BS, BSS | Acryl, Aludibond, Schiefer, Edelstahl, Acryl+Edelstahl, Holz |
| Türkränze | 1130 | – | 0 | 0 | – | TKAH-H-24x24-D1_Buchenholz, TKAH-H-24x24-D1_Holz_UV_Holzmuster_Dunkel_Braun, TKAH-H-24x24-D1_Holz_UV_Holzmuster_Grau_Grundplatte, TKAH-H-24x24-D1_Holz_UV_Holzmuster_Hell_Braun, TKAH-H-24x24-D1_Holz_UV_Holzmuster_Weiss, TKAH-H-24x24F-D1_Buchenholz |
| Kalender | 984 | UV 979 | 4 | 0 | KSUV, KUV1 | – |
| Tierschilder | 915 | Gravur 63, UV 850 | 13 | 0 | TSUV | Aludibond, Holz, Schiefer, [135400000 - Tierschuld UV Acryl 10x15], [135300000 - Tierschild UV Acryl 10x6,5 oval], [135500000 - Tierschild UV Acryl 12x8] |
| Brotdosen-Set | 891 | Gravur 890 | 0 | 0 | – | – |
| Geldgeschenk | 866 | Gravur 135, UV 730 | 9 | 0 | WBGG, GGAUV, HZS, WBCAH | Acryl, Holz, Schiefer, mit Buchenholz Fuß Foto ohne Geld, Acrylfuß mit Geldherzen, Acrylfuß mit Geldröllchen |
| Tierzubehör | 838 | – | 11 | 0 | HMRG, HMKG, HMRK, HMH, HMKK, HMKM | Holz, Leder, Edelstahl, Alu |
| Frühstücksbrettchen | 804 | Gravur 438, UV 361 | 2 | 0 | FB, FBUV | Holz |
| Monogramme | 755 | – | 2 | 0 | MG, MG2, MG3 | Gravuru Monogramm Edelstahl Test Produktbilder, [107600000 - Monogramm Edelstahl Herz], [107700000 - Monogramm Schiefer 1], [107800000 - Monogramm Schiefer 2], [107900000 - Monogramm Schiefer 3] |
| Nachtlichter | 650 | Gravur 360, UV 287 | 0 | 0 | – | – |
| Radiergummi | 592 | UV 591 | 2 | 0 | RG | – |
| Lineal | 588 | Gravur 108, UV 472 | 0 | 0 | – | – |
| Hunde-Ecke | 568 | – | 2 | 0 | HEUV | Falsch (aus Holz) |
| Blumenstecker | 541 | – | 10 | 0 | BSTR, BSTE, BSTP, BSTI, BSTB1, BSTB2 | Edelstahl |
| Flachmann | 499 | – | 3 | 0 | FM | – |
| Lesehilfe | 463 | Gravur 69, UV 392 | 3 | 0 | LHUV, LH | – |
| Lesezeichen | 399 | UV 398 | 2 | 0 | LZ | Acryl, Holz |
| Puzzle | 342 | – | 1 | 1 | – | Holz, Acryl weiß |
| Erinnerungskiste | 315 | UV 313 | 1 | 0 | EKK, EKTIG, EKEP, EKF, EKH, EKNG | – |
| Messlatten | 247 | – | 3 | 0 | MLUV, MLFUV | – |
| Spardose | 243 | Gravur 62, UV 180 | 0 | 0 | – | – |
| Cake Topper | 233 | Gravur 125, UV 106 | 4 | 0 | CTUV, CT | Acryl, Holz |
| Stiftehalter | 228 | Gravur 25, UV 202 | 1 | 0 | STHUV | – |
| Stundenpläne | 198 | – | 1 | 0 | SP | Acryl |
| Schiefer mit Foto | 191 | UV 190 | 3 | 0 | SFUV | – |
| Adventskalender | 154 | – | 5 | 0 | AKUV, AK | Holz |
| Briefkasten | 154 | Gravur 152 | 5 | 0 | BK | Acryl, Edelstahl |
| Buchhalter | 154 | – | 0 | 0 | – | – |
| Postkarte | 143 | Gravur 141 | 1 | 0 | PK | – |
| Bilderrahmen | 135 | – | 0 | 0 | – | – |
| Gedenktafeln Sternenkinder | 113 | – | 4 | 0 | GTSK | – |
| Untersetzer | 103 | – | 1 | 0 | USRUV, USPUV | – |
| Staffelei | 79 | UV 78 | 0 | 0 | – | Schiefer |
| Blumenkübel | 72 | Gravur 30, UV 41 | 1 | 0 | BKUV, BK | – |
| Belohnungstafel | 71 | – | 1 | 0 | BT | Acryl |
| Namensausschnitt | 71 | – | 0 | 0 | – | – |
| Grillzange | 52 | – | 1 | 0 | GZ | Holz |
| Schreibübung | 39 | – | 0 | 0 | – | [Produktbilder]mit einem Holzblock-Ständer aus Buche |
| Bierhammer | 38 | – | 0 | 0 | – | – |
| Buffetplatte | 9 | – | 5 | 0 | – | Schiefer |

## Größen je Produkt

### Türschilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 5x2 | 712 | Gravur / Acryl | TRE-A-5x2, TRE-A-5x2-D1, TRE-A-5x2-D10 |  |
| 6x2 | 707 | Gravur / Acryl | TRE-A-6x2, TRE-A-6x2-D1, TRE-A-6x2-D10 |  |
| 6x4 | 1146 | Gravur / Kunststoff | TRE-A-6x4, TRE-A-6x4-D1, TRE-A-6x4-D10 |  |
| 7x2 | 1061 | Gravur / Holz | TRE-A-7x2, TRE-A-7x2-D1, TRE-A-7x2-D10 |  |
| 8x2 | 703 | Gravur / Acryl | TRE-A-8x2, TRE-A-8x2-D1, TRE-A-8x2-D10 |  |
| 8x3.5 | 2198 | Gravur / Kunststoff | TRE-A-8x3,5, TRE-A-8x3,5-D1, TRE-A-8x3,5-D10 |  |
| 8x5 | 1764 | Gravur / Kunststoff | TAE-V2A-8x5, TAE-V2A-8x5-D1, TAE-V2A-8x5-D10 |  |
| 8x8 | 1100 | Gravur / Acryl | TQ-A-8x8, TQ-A-8x8-D1, TQ-A-8x8-D10 |  |
| 9x3 | 140 | Gravur / Edelstahl / __NEU / Rechteckig ab 9x3 | TRE-V2A-9x3, TRE-V2A-9x3-D1, TRE-V2A-9x3-D10 |  |
| 9x6 | 3340 | Gravur / Kunststoff | TR1-A-9x6, TR1-A-9x6-D1, TR1-A-9x6-D10 |  |
| 10x3.5 | 805 | Gravur / Edelstahl | TRE-A-10x3,5, TRE-A-10x3,5-D1, TRE-A-10x3,5-D10 |  |
| 10x5 | 18 | UV / Rechteckig / Holz | TRE-H-10x5, TRE-H-10x5-D1 |  |
| 10x10 | 1577 | Gravur / Acryl | TQ-A-10x10, TQ-A-10x10-D1, TQ-A-10x10-D10 |  |
| 12x4 | 695 | Gravur / Edelstahl | TO-KS-12x4, TO-KS-12x4-D1, TO-KS-12x4-D10 |  |
| 12x5.25 | 133 | Gravur / Edelstahl / __NEU / Rechteckig ab 8x3,5 | TRE-V2A-12x5,25, TRE-V2A-12x5,25-D1, TRE-V2A-12x5,25-D10 |  |
| 12x5.5 | 740 | Gravur / Acryl | TRE-A-12x5,5, TRE-A-12x5,5-D1, TRE-A-12x5,5-D10 |  |
| 12x8 | 2684 | Gravur / Kunststoff | TAE-V2A-12x8, TAE-V2A-12x8-D1, TAE-V2A-12x8-D10 |  |
| 12x12 | 829 | Gravur / Acryl | TQ-A-12x12, TQ-A-12x12-D1, TQ-A-12x12-D10 |  |
| 13x13 | 318 | Gravur / Schiefer | TRE-S-13x13, TRE-S-13x13-D1, TRE-S-13x13-D10 |  |
| 14x3 | 423 | Gravur / Edelstahl | TRE-A-14x3, TRE-A-14x3-D1, TRE-A-14x3-D10 |  |
| 15x8 | 137 | Gravur / Kunststoff / __NEU / Oval ab 15x8 | TO-KS-15x8, TO-KS-15x8-D1, TO-KS-15x8-D10 |  |
| 15x10 | 2400 | Gravur / Kunststoff | TAE-V2A-15x10, TAE-V2A-15x10-D1, TAE-V2A-15x10-D10 |  |
| 16x7 | 160 | Gravur / Edelstahl / __NEU / Rechteckig ab 8x3,5 | TRE-V2A-16x7, TRE-V2A-16x7-D1, TRE-V2A-16x7-D10 |  |
| 16x16 | 952 | Gravur / Acryl | TQ-A-16x16, TQ-A-16x16-D1, TQ-A-16x16-D10 |  |
| 18x12 | 1259 | Gravur / Acryl | TAE-V2A-18x12, TAE-V2A-18x12-D1, TAE-V2A-18x12-D10 |  |
| 20x10 | 294 | Gravur / Schiefer | TRE-S-20x10, TRE-S-20x10-D1, TRE-S-20x10-D10 |  |
| 20x15 | 293 | Gravur / Schiefer | TRE-S-20x15, TRE-S-20x15-D1, TRE-S-20x15-D10 |  |
| 20x16 | 739 | Gravur / Acryl | TRE-A-20x16, TRE-A-20x16-D1, TRE-A-20x16-D10 |  |
| 20x20 | 471 | Gravur / Schiefer | TQ-S-20x20, TQ-S-20x20-D1, TQ-S-20x20-D10 |  |
| 21x10 | 793 | Gravur / Acryl | TRE-A-21x10, TRE-A-21x10-D1, TRE-A-21x10-D10 |  |
| 21x14 | 1315 | Gravur / Kunststoff | TRE-A-21x14, TRE-A-21x14-D1, TRE-A-21x14-D10 |  |
| 22x14 | 124 | Gravur / Schiefer | TRE-S-22x14, TRE-S-22x14-D1, TRE-S-22x14-D10 |  |
| 22.5x15 | 316 | Gravur / Edelstahl | TRE-V2A-22,5x15, TRE-V2A-22,5x15-D1, TRE-V2A-22,5x15-D10 |  |
| 23x10 | 52 | UV / _Neue Sortierung / Acryl | TREUV-A-23x10, TREUV-A-23x10-D1, TREUV-A-23x10-D2 |  |
| 23x12 | 740 | Gravur / Acryl | TRE-A-23x12, TRE-A-23x12-D1, TRE-A-23x12-D10 |  |
| 24x8 | 137 | Gravur / Edelstahl / __NEU / Rechteckig ab 9x3 | TRE-V2A-24x8, TRE-V2A-24x8-D1, TRE-V2A-24x8-D10 |  |
| 24x10.5 | 159 | Gravur / Edelstahl / __NEU / Rechteckig ab 8x3,5 | TRE-V2A-24x10,5, TRE-V2A-24x10,5-D1, TRE-V2A-24x10,5-D10 |  |
| 24x16 | 368 | UV / _Neue Sortierung / Acryl | TRE-V2A-24x16, TRE-V2A-24x16-D1, TRE-V2A-24x16-D10 |  |
| 25x10 | 293 | Gravur / Schiefer | TRE-S-25x10, TRE-S-25x10-D1, TRE-S-25x10-D10 |  |
| 25x15 | 1076 | Gravur / Acryl | TRE-A-25x15, TRE-A-25x15-D1, TRE-A-25x15-D10 |  |
| 25x20 | 15 | UV / _Neue Sortierung / Acryl | TREUV-A-25x20-D1, TREUV-A-25x20-D2, TREUV-A-25x20-D3 |  |
| 25x25 | 318 | Gravur / Schiefer | TQ-S-25x25, TQ-S-25x25-D1, TQ-S-25x25-D10 |  |
| 28x18 | 405 | Gravur / Acryl | TRE-A-28x18, TRE-A-28x18-D1, TRE-A-28x18-D10 |  |
| 30x11 | 294 | Gravur / Schiefer | TRE-S-30x11, TRE-S-30x11-D1, TRE-S-30x11-D10 |  |
| 30x20 | 2045 | Gravur / Kunststoff | TAE-V2A-30x20, TAE-V2A-30x20-D1, TAE-V2A-30x20-D10 |  |
| 32x22 | 316 | Gravur / Edelstahl | TRE-V2A-32x22, TRE-V2A-32x22-D1, TRE-V2A-32x22-D10 |  |
| 38x13 | 8 | Gravur / Schiefer |  |  |
| 40x20 | 635 | Gravur / Edelstahl | TRE-S-40x20, TRE-S-40x20-D1, TRE-S-40x20-D10 |  |
| 40x30 | 1018 | Gravur / Acryl | TRE-A-40x30, TRE-A-40x30-D1, TRE-A-40x30-D10 |  |
| 42x28 | 157 | Gravur / Edelstahl / __NEU / Rechteckig ab 8x5 | TRE-V2A-42x28, TRE-V2A-42x28-D1, TRE-V2A-42x28-D10 |  |
| 45x30 | 157 | Gravur / Edelstahl / __NEU / Rechteckig ab 8x5 | TRE-V2A-45x30, TRE-V2A-45x30-D1, TRE-V2A-45x30-D10 |  |
| 60x30 | 293 | Gravur / Schiefer | TRE-S-60x30, TRE-S-60x30-D1, TRE-S-60x30-D10 |  |

### Gedenktafeln
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 10x10 | 151 | Gravur / Schiefer / Herz | GT-S-10x10, GT-S-10x10-D1, GT-S-10x10-D10 |  |
| 10x11 | 167 | UV / Marmor | GTUV-M-10x11, GTUV-M-10x11-D1, GTUV-M-10x11-D10 |  |
| 12x10.5 | 63 | Gravur / Edelstahl | GT-V2A-12x10.5, GT-V2A-12x10.5-D0, GT-V2A-12x10.5-D1 |  |
| 13x9.5 | 168 | UV / Marmor / Herz liegend | GTUV-M-13x9.5, GTUV-M-13x9.5-D1, GTUV-M-13x9.5-D10 |  |
| 14x22 | 300 | Gravur / Schiefer | GT-S-14x22-D100, GT-S-14x22-D11, GT-S-14x22-D12 |  |
| 18x12 | 1376 | Gravur / Acryl + Edelstahl | GT-AV2A-18x12, GT-AV2A-18x12-D1, GT-AV2A-18x12-D10 |  |
| 18x13 | 311 | UV / Marmor / Herz liegend | GT-S-18x13, GT-S-18x13-D1, GT-S-18x13-D10 |  |
| 18x18 | 167 | UV / Marmor | GTUV-M-18x18, GTUV-M-18x18-D1, GTUV-M-18x18-D10 |  |
| 20x10 | 369 | Gravur / Acryl | GT-A-20x10, GT-A-20x10-D0, GT-A-20x10-D1 |  |
| 20x15 | 4372 | Gravur / Acryl | GT-A-20x15, GT-A-20x15-D0, GT-A-20x15-D1 |  |
| 20x16 | 1264 | Gravur / Acryl + Edelstahl | GT-AV2A-20x16, GT-AV2A-20x16-D1, GT-AV2A-20x16-D10 |  |
| 20x19.5 | 99 | UV / Schiefer / Stern | GTUV-S-20x19.5, GTUV-S-20x19.5-D1, GTUV-S-20x19.5-D10 |  |
| 20x20 | 2465 | Gravur / Acryl | GT-A-20x20, GT-A-20x20-D0, GT-A-20x20-D1 |  |
| 20x30 | 2994 | Gravur / Acryl | GT-A-20x30, GT-A-20x30-D0, GT-A-20x30-D1 |  |
| 21x10 | 65 | Gravur / Edelstahl | GT-V2A-21x10, GT-V2A-21x10-D0, GT-V2A-21x10-D1 |  |
| 21x14 | 1120 | Gravur / Acryl + Edelstahl | GT-AV2A-21x14, GT-AV2A-21x14-D1, GT-AV2A-21x14-D10 |  |
| 22x14 | 361 | Gravur / Schiefer | GT-S-22x14, GT-S-22x14-D1, GT-S-22x14-D10 |  |
| 22x22 | 1510 | Gravur / Acryl + Edelstahl | GT-AV2A-22x22, GT-AV2A-22x22-D1, GT-AV2A-22x22-D10 |  |
| 24x19 | 87 | Gravur / Schiefer / Herz | GT-S-24x19, GT-S-24x19-D1, GT-S-24x19-D10 |  |
| 25x10 | 547 | Gravur / Schiefer | GT-S-25x10, GT-S-25x10-D0, GT-S-25x10-D1 |  |
| 25x25 | 191 | Gravur / Schiefer / Herz | GT-S-25x25, GT-S-25x25-D1, GT-S-25x25-D10 |  |
| 26x19 | 138 | Gravur / Schiefer / Herz | GT-S-26x19, GT-S-26x19-D1, GT-S-26x19-D10 |  |
| 26x26 | 1096 | Gravur / Acryl | GT-A-26x26, GT-A-26x26-D0, GT-A-26x26-D1 |  |
| 28x28 | 1 | UV / Schiefer / Rund |  |  |
| 29x28 | 171 | UV / Marmor | GTUV-M-29x28, GTUV-M-29x28-D1, GTUV-M-29x28-D10 |  |
| 30x11 | 185 | Gravur / Schiefer | GT-S-30x11, GT-S-30x11-D100, GT-S-30x11-D250 |  |
| 30x20 | 8682 | Gravur / Acryl | GT-A-30x20, GT-A-30x20-D0, GT-A-30x20-D1 |  |
| 30x30 | 1181 | Gravur / Acryl | GT-A-30x30, GT-A-30x30-D0, GT-A-30x30-D1 |  |
| 30x60 | 1869 | Gravur / Acryl | GT-A-30x60, GT-A-30x60-D0, GT-A-30x60-D1 |  |
| 35x35 | 1 | UV / Schiefer / Rund |  |  |
| 38x13 | 5 | Gravur / Schiefer |  |  |
| 40x20 | 2235 | Gravur / Acryl | GT-A-40x20, GT-A-40x20-D0, GT-A-40x20-D1 |  |
| 40x30 | 6486 | Gravur / Acryl | GT-A-40x30, GT-A-40x30-D0, GT-A-40x30-D1 |  |
| 40x40 | 1169 | Gravur / Acryl | GT-A-40x40, GT-A-40x40-D1, GT-A-40x40-D10 |  |
| 42x28 | 1108 | Gravur / Acryl + Edelstahl | GT-AV2A-42x28, GT-AV2A-42x28-D1, GT-AV2A-42x28-D10 |  |
| 60x30 | 3371 | Gravur / Acryl | GT-A-60x30, GT-A-60x30-D0, GT-A-60x30-D1 |  |

### Hinweisschilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 5x2 | 107 | Gravur / Werbung / Edelstahl | HSW-V2A-5x2, HSW-V2A-5x2-D0, HSW-V2A-5x2-D1 |  |
| 6x2 | 476 | Gravur / Werbung / Kunststoff | HSW-A-6x2, HSW-A-6x2-D0, HSW-A-6x2-D1 |  |
| 6.5x6.5 | 284 | Gravur / Piktogramme / Rund / Acryl | HP-A-6.5x6.5, HP-A-6.5x6.5-D1, HP-A-6.5x6.5-D10 |  |
| 7x2 | 481 | Gravur / Werbung / Kunststoff | HSW-A-7x2, HSW-A-7x2-D0, HSW-A-7x2-D1 |  |
| 8x3.5 | 476 | Gravur / Werbung / Kunststoff | HSW-A-8x3.5, HSW-A-8x3.5-D0, HSW-A-8x3.5-D1 |  |
| 9x9 | 1077 | Gravur / Piktogramme / Rund / Kunststoff | HP-KS-9x9, HP-KS-9x9-D1, HP-KS-9x9-D10 |  |
| 10x6.5 | 43 | Gravur / Vorsicht Hund / Acryl / Personalisiert | HSH-A-10x6.5-oval-D1, HSH-A-10x6.5-oval-D2, HSH-A-10x6.5-oval-D3 |  |
| 10x10 | 95 | Gravur / Vorsicht Hund / Edelstahl / Personalisiert | HSH-A-10x10-D1, HSH-A-10x10-D2, HSH-A-10x10-D3 |  |
| 12x4 | 6920 | Gravur / Vorsicht Hund / [Archiv] / Rechteckig / Kunststoff | HP-A-12x4, HP-A-12x4-D0, HP-A-12x4-D1 |  |
| 12x8 | 7391 | Gravur / Vorsicht Hund / [Archiv] / Rechteckig / Kunststoff | HP-A-12x8, HP-A-12x8-D0, HP-A-12x8-D1 |  |
| 12x12 | 10 | Gravur / Vorsicht Hund / Kunststoff / Personalisiert / Schwarze Gravur | HSH-KS-12x12-D1 |  |
| 15x8 | 7699 | Gravur / Vorsicht Hund / [Archiv] / Oval / Kunststoff | HP-A-15x8, HP-A-15x8-D0, HP-A-15x8-D1 |  |
| 15x10 | 1476 | Gravur / Vorsicht Hund / [Archiv] / Rechteckig / Edelstahl / NEU | HSH-KS-15x10-D1, HSH-V2A-15x10, HSH-V2A-15x10-D1 |  |
| 16x16 | 10 | Gravur / Vorsicht Hund / Kunststoff / Personalisiert / Schwarze Gravur | HSH-KS-16x16-D1 |  |
| 18x12 | 1598 | Gravur / Vorsicht Hund / [Archiv] / Rechteckig / Edelstahl / NEU | HSH-KS-18x12-D1, HSH-V2A-18x12, HSH-V2A-18x12-D1 |  |
| 20x15 | 294 | Gravur / Vorsicht Hund / [Archiv] / Rechteckig / Schiefer Kordel | HSH-S-20x15, HSH-S-20x15-D1, HSH-S-20x15-D10 |  |
| 20x16 | 25 | Gravur / Vorsicht Hund / _NEU / Edelstahl | HSH-KS-20x16-D1, HSH-V2A-20x16, HSH-V2A-20x16-D1 |  |
| 20x20 | 10 | Gravur / Vorsicht Hund / Kunststoff / Personalisiert / Schwarze Gravur | HSH-KS-20x20-D1 |  |
| 21x10 | 10 | Gravur / Vorsicht Hund / Kunststoff / Personalisiert / Schwarze Gravur | HSH-KS-21x10-D1 |  |
| 21x12 | 5654 | Gravur / Vorsicht Hund / [Archiv] / Oval / Kunststoff | HP-A-21x12, HP-A-21x12-D0, HP-A-21x12-D1 |  |
| 21x14 | 1571 | Gravur / Vorsicht Hund / [Archiv] / Rechteckig / Edelstahl / NEU | HSH-V2A-21x14, HSH-V2A-21x14-D1, HSH-V2A-21x14-D10 | ja |
| 22x14 | 43 | Gravur / Vorsicht Hund / _Feste Designs / Kordel Schiefer | HSH-S-22x14, HSH-S-22x14-D1, HSH-S-22x14-D2 |  |
| 22x22 | 10 | Gravur / Vorsicht Hund / Kunststoff / Personalisiert / Schwarze Gravur | HSH-KS-22x22-D1 |  |
| 30x20 | 1578 | Gravur / Vorsicht Hund / [Archiv] / Rechteckig / Edelstahl / NEU | HSH-KS-30x20-D1, HSH-V2A-30x20, HSH-V2A-30x20-D1 | ja |

### Namenschilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 15x10 | 236 | UV / Rechteckig / Acryl | NSREUV-A-15x10, NSREUV-A-15x10-D1, NSREUV-A-15x10-D10 |  |
| 15x20 | 221 | UV / Rechteckig / Holz | NSREUV-H-15x20, NSREUV-H-15x20-D1, NSREUV-H-15x20-D10 |  |
| 15x30 | 627 | Gravur / Bogen / Acryl | NSB-A-15x30, NSB-A-15x30-D1, NSB-A-15x30-D10 |  |
| 16x5 | 57 | UV / Rechteckig / Acryl+Edelstahl | NSREUV-AV2A-16x5, NSREUV-AV2A-16x5-D1, NSREUV-AV2A-16x5-D2 |  |
| 16x12 | 67 | UV / Oval / Holz | NSOUV-H-16x12, NSOUV-H-16x12-D1, NSOUV-H-16x12-D10 |  |
| 16x16 | 97 | UV / Quadratisch / Acryl | NSQUV-A-16x16, NSQUV-A-16x16-D1, NSQUV-A-16x16-D2 |  |
| 16x20 | 140 | UV / Rechteckig / Acryl | NSREUV-A-16x20, NSREUV-A-16x20-D1, NSREUV-A-16x20-D10 |  |
| 18x18 | 61 | Gravur / Quadratisch / Schwarz satiniert | NSQSG-18x18, NSQSG-18x18-D1, NSQSG-18x18-D10 |  |
| 18x22 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-18x22, NSRSG-A-18x22-D1, NSRSG-A-18x22-D10 |  |
| 19x10 | 32 | UV / Rechteckig / Holz | NSREUV-H-19x10, NSREUV-H-19x10-D1, NSREUV-H-19x10-D2 |  |
| 20x11 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-20x11, NSRSG-A-20x11-D1, NSRSG-A-20x11-D10 |  |
| 20x14 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-20x14, NSRSG-A-20x14-D1, NSRSG-A-20x14-D10 |  |
| 20x15 | 496 | UV / Rechteckig / Holz | NSREUV-H-20x15, NSREUV-H-20x15-D1, NSREUV-H-20x15-D10 |  |
| 20x16 | 78 | UV / Rechteckig / Acryl | NSREUV-A-20x16, NSREUV-A-20x16-D1, NSREUV-A-20x16-D10 |  |
| 20x20 | 358 | Gravur / Quadratisch / Acryl | NSQ-A-20x20, NSQ-A-20x20-D1, NSQ-A-20x20-D10 |  |
| 20x25 | 358 | Gravur / Rechteckig / Acryl | NSR-A-20x25, NSR-A-20x25-D1, NSR-A-20x25-D10 |  |
| 21x10 | 405 | Gravur / Rechteckig / Acryl | NSR-A-21x10, NSR-A-21x10-D1, NSR-A-21x10-D10 |  |
| 21x14 | 44 | UV / Rechteckig / Acryl | NSREUV-A-21x14, NSREUV-A-21x14-D1, NSREUV-A-21x14-D2 |  |
| 22x14 | 18 | UV / _NEUE SORTIERUNG / Schiefer | NS-S-22x14, NS-S-22x14-D1, NS-S-22x14-D2 |  |
| 22x18 | 358 | Gravur / Oval / Acryl | NSO-A-22x18, NSO-A-22x18-D1, NSO-A-22x18-D10 |  |
| 22x22 | 154 | Gravur / Quadratisch / Schwarz satiniert | NSQSG-A-22x22, NSQSG-A-22x22-D1, NSQSG-A-22x22-D10 |  |
| 22x27 | 153 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-22x27, NSRSG-A-22x27-D1, NSRSG-A-22x27-D10 |  |
| 23x12 | 751 | UV / Rechteckig / Acryl | NSO-A-23x12, NSO-A-23x12-D1, NSO-A-23x12-D10 |  |
| 24x13 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-24x13, NSRSG-A-24x13-D1, NSRSG-A-24x13-D10 |  |
| 24x15 | 388 | Gravur / Abgerundete Ecken / Acryl | NSAE-A-24x15, NSAE-A-24x15-D1, NSAE-A-24x15-D10 |  |
| 24x16 | 358 | Gravur / Rechteckig / Acryl | NSR-A-24x16, NSR-A-24x16-D1, NSR-A-24x16-D10 |  |
| 24x20 | 153 | Gravur / Oval / Schwarz satiniert | NSOSG-A-24x20, NSOSG-A-24x20-D1, NSOSG-A-24x20-D10 |  |
| 25x14 | 153 | Gravur / Oval / Schwarz satiniert | NSOSG-A-25x14, NSOSG-A-25x14-D1, NSOSG-A-25x14-D10 |  |
| 25x20 | 380 | Gravur / Rechteckig / Acryl | NSHUV-H-25x20, NSHUV-H-25x20-D1, NSHUV-H-25x20-D2 |  |
| 26x13 | 358 | Gravur / Rechteckig / Acryl | NSR-A-26x13, NSR-A-26x13-D1, NSR-A-26x13-D10 |  |
| 26x17 | 155 | Gravur / Abgerundete Ecken / Schwarz satiniert | NSAESG-A-26x17, NSAESG-A-26x17-D1, NSAESG-A-26x17-D10 |  |
| 26x18 | 151 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-26x18, NSRSG-A-26x18-D1, NSRSG-A-26x18-D10 |  |
| 26x32 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-26x32, NSRSG-A-26x32-D1, NSRSG-A-26x32-D10 |  |
| 27x18 | 33 | UV / Rechteckig / Acryl | NSREUV-A-27x18, NSREUV-A-27x18-D1, NSREUV-A-27x18-D2 |  |
| 27x22 | 510 | Gravur / Oval / Acryl | NSO-A-27x22, NSO-A-27x22-D1, NSO-A-27x22-D10 |  |
| 28x6 | 35 | Gravur / Rechteckig / Acryl | NSR-A-28x6, NSR-A-28x6-D1, NSR-A-28x6-D10 |  |
| 28x15 | 153 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-28x15, NSRSG-A-28x15-D1, NSRSG-A-28x15-D10 |  |
| 28x28 | 61 | Gravur / Quadratisch / Schwarz satiniert | NSQSG-28x28, NSQSG-28x28-D1, NSQSG-28x28-D10 |  |
| 29x15 | 84 | UV / Rechteckig / Acryl | NSREUV-A-29x15, NSREUV-A-29x15-D1, NSREUV-A-29x15-D10 |  |
| 30x8 | 657 | Gravur / Rechteckig / Acryl | NSAESG-A-30x8, NSAESG-A-30x8-D1, NSAESG-A-30x8-D10 |  |
| 30x16 | 358 | Gravur / Rechteckig / Acryl | NSR-A-30x16, NSR-A-30x16-D1, NSR-A-30x16-D10 |  |
| 30x18 | 22 | UV / Rechteckig / Holz | NSREUV-H-30x18, NSREUV-H-30x18-D1, NSREUV-H-30x18-D2 |  |
| 30x20 | 171 | UV / Rechteckig / Acryl+Edelstahl | NS-S-30x20, NS-S-30x20-D1, NS-S-30x20-D2 |  |
| 32x17 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-32x17, NSRSG-A-32x17-D1, NSRSG-A-32x17-D10 |  |
| 32x22 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-32x22, NSRSG-A-32x22-D1, NSRSG-A-32x22-D10 |  |
| 34x22 | 63 | Gravur / Abgerundete Ecken / Schwarz satiniert | NSAESG-A-34x22, NSAESG-A-34x22-D1, NSAESG-A-34x22-D10 |  |
| 34x42 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-34x42, NSRSG-A-34x42-D1, NSRSG-A-34x42-D10 |  |
| 38x10 | 868 | Gravur / Abgerundete Ecken / Acryl | NSAE-A-38x10, NSAE-A-38x10-D1, NSAE-A-38x10-D10 |  |
| 38x38 | 61 | Gravur / Quadratisch / Schwarz satiniert | NSQSG-38x38, NSQSG-38x38-D1, NSQSG-38x38-D10 |  |
| 40x10 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-40x10, NSRSG-A-40x10-D1, NSRSG-A-40x10-D10 |  |
| 40x33 | 61 | Gravur / Oval / Schwarz satiniert | NSOSG-40x33, NSOSG-40x33-D1, NSOSG-40x33-D10 |  |
| 42x23 | 61 | Gravur / Oval / Schwarz satiniert | NSO-A-42x23, NSO-A-42x23-D1, NSO-A-42x23-D10 |  |
| 42x27 | 61 | Gravur / Abgerundete Ecken / Schwarz satiniert | NSAESG-A-42x27, NSAESG-A-42x27-D1, NSAESG-A-42x27-D10 |  |
| 42x52 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-42x52, NSRSG-A-42x52-D1, NSRSG-A-42x52-D10 |  |
| 44x22 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-44x22, NSRSG-A-44x22-D1, NSRSG-A-44x22-D10 |  |
| 44x30 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-44x30, NSRSG-A-44x30-D1, NSRSG-A-44x30-D10 |  |
| 50x12 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-50x12, NSRSG-A-50x12-D1, NSRSG-A-50x12-D10 |  |
| 50x32 | 61 | Gravur / Abgerundete Ecken / Schwarz satiniert | NSAESG-A-50x23, NSAESG-A-50x23-D1, NSAESG-A-50x23-D10 |  |
| 50x62 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-50x62, NSRSG-A-50x62-D1, NSRSG-A-50x62-D10 |  |
| 58x14 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-58x14, NSRSG-A-58x14-D1, NSRSG-A-58x14-D10 |  |
| 72x17 | 58 | Gravur / Rechteckig / Schwarz satiniert | NSRSG-A-72x17, NSRSG-A-72x17-D1, NSRSG-A-72x17-D10 |  |

### Wandbilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 1x1 | 40 | Kinder / Acryl |  |  |
| 12x16 | 57 | Fut Card | WBFC-A-12x16, WBFC-A-12x16-D1, WBFC-A-12x16-D2 |  |
| 15x20 | 3178 | Definition | WB-A-15x20-D1, WB-A-15x20-D2, WB-A-15x20-D3 |  |
| 20x15 | 1106 | Lehrer | WB-A-20x15-D1, WB-A-20x15-D2, WBL-A-20x15 |  |
| 20x20 | 77 | Personalisiert / Leinwand | WBP-LW-20x20, WBP-LW-20x20-D0, WBP-LW-20x20-D1 |  |
| 20x30 | 5300 | Definition | WB-A-20x30-D1, WB-A-20x30-D2, WBA-A-20x30 |  |
| 24x30 | 807 | Personalisiert / Leinwand | WBC-LW-24x30-D0, WBC-LW-24x30-D1, WBC-LW-24x30-D10 |  |
| 25x25 | 40 | Personalisiert / Leinwand | WBP-LW-25x25, WBP-LW-25x25-D0, WBP-LW-25x25-D1 |  |
| 29x29 | 92 | Personalisiert / Leinwand | WBP-LW-29x29, WBP-LW-29x29-D0, WBP-LW-29x29-D1 |  |
| 30x20 | 1628 | Typo / Alu-Dibond | WB-A-30x20-D1, WB-A-30x20-D2, WBC-A-30x20 |  |
| 30x24 | 59 | Personalisiert / Leinwand | WBP-LW-30x24, WBP-LW-30x24-D0, WBP-LW-30x24-D1 |  |
| 30x40 | 710 | Fingerabdruck / Leinwand | WBC-LW-30x40-D0, WBC-LW-30x40-D1, WBC-LW-30x40-D10 |  |
| 40x30 | 1043 | Typo / Acryl | WBC-A-40x30, WBC-A-40x30-D0, WBC-A-40x30-D1 |  |
| 40x60 | 2171 | Song Cover / Acryl | WBA-A-40x60-D0, WBA-A-40x60-D1, WBA-A-40x60-D2 |  |
| 50x30 | 824 | Typo / Acryl | WBC-A-50x30, WBC-A-50x30-D0, WBC-A-50x30-D1 |  |
| 60x40 | 408 | Hochzeit / Aludibond | WBC-A-60x40, WBC-A-60x40-D0, WBH-A-60x40 |  |
| 60x80 | 198 | Typo / Leinwand | WBCA-LW-60x80, WBCA-LW-60x80-D1, WBCA-LW-60x80-D2 |  |
| 80x60 | 208 | Typo / Leinwand | WBH-LW-80x60, WBH-LW-80x60-D1, WBH-LW-80x60-D10 |  |
| 90x60 | 85 | Weltkarte / Holz | WBWK-A-90x60, WBWK-A-90x60-D0, WBWK-A-90x60-D1 |  |

### Grabstecker
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 11x27 | 226 | Gravur / Edelstahl / Katze 2 - raus / Edelstahl | GSTKA2-V2A-11x27, GSTKA2-V2A-11x27-D0, GSTKA2-V2A-11x27-D1 |  |
| 11x37.5 | 311 | Gravur / Edelstahl / Engel / Edelstahl | GSTE-V2A-11x37.5, GSTE-V2A-11x37.5-D1, GSTE-V2A-11x37.5-D10 |  |
| 12x35.5 | 153 | Gravur / Edelstahl / Pfote / Edelstahl | GSTPF-V2A-12x35.5, GSTPF-V2A-12x35.5-D1, GSTPF-V2A-12x35.5-D10 |  |
| 12x40 | 61 | Gravur / Edelstahl / Hände / Edelstahl | GSTBE-V2A-12x40, GSTBE-V2A-12x40-D1, GSTBE-V2A-12x40-D2 |  |
| 13x38 | 90 | Gravur / Edelstahl / Katze 2 / Edelstahl | GSTKA-V2A-13x38, GSTKA-V2A-13x38-D1, GSTKA-V2A-13x38-D2 |  |
| 13x46 | 299 | Gravur / Edelstahl / Kreuz / Edelstahl | GSTKR-V2A-13x46, GSTKR-V2A-13x46-D1, GSTKR-V2A-13x46-D10 |  |
| 14x29 | 124 | Gravur / Edelstahl / Kreuz 2 / Edelstahl | GSTKR2-V2A-14x29, GSTKR2-V2A-14x29-D1, GSTKR2-V2A-14x29-D10 |  |
| 14x37 | 202 | Gravur / Edelstahl / Stern / Edelstahl | GSTST-V2A-14x37, GSTST-V2A-14x37-D1, GSTST-V2A-14x37-D10 |  |
| 14x38.5 | 139 | Gravur / Edelstahl / Katze / Edelstahl | GSTKA3-V2A-14x38.5, GSTKA3-V2A-14x38.5-D1, GSTKA3-V2A-14x38.5-D2 |  |
| 14x41.5 | 170 | Gravur / Edelstahl / Engel 2 / Edelstahl | GSTE2-V2A-14x41.5, GSTE2-V2A-14x41.5-D1, GSTE2-V2A-14x41.5-D10 |  |
| 15x36 | 564 | Gravur / Edelstahl / Herz-Rahmen / Edelstahl | GSTH2-V2A-15x36, GSTH2-V2A-15x36-D1, GSTH2-V2A-15x36-D10 |  |
| 15x38 | 305 | Gravur / Edelstahl / Flügel / Edelstahl | GSTFL-V2A-15x38, GSTFL-V2A-15x38-D1, GSTFL-V2A-15x38-D10 |  |
| 15x46 | 276 | Gravur / Edelstahl / Kreuz / Edelstahl | GSTKR-V2A-15x46, GSTKR-V2A-15x46-D1, GSTKR-V2A-15x46-D10 |  |
| 16x36.5 | 275 | Gravur / Edelstahl / Herz liegend / Edelstahl | GSTH5-V2A-16x36.5, GSTH5-V2A-16x36.5-D1, GSTH5-V2A-16x36.5-D10 |  |
| 16x37.5 | 846 | Gravur / Edelstahl / Engel / Edelstahl | GSTE-V2A-16x37.5, GSTE-V2A-16x37.5-D1, GSTE-V2A-16x37.5-D10 |  |
| 16x38 | 807 | Gravur / Edelstahl / Herz / Edelstahl | GSTH-V2A-16x38, GSTH-V2A-16x38-D1, GSTH-V2A-16x38-D10 |  |
| 16x39 | 100 | Gravur / Edelstahl / Hund 2 / Edelstahl | GSTHU2-V2A-16x39, GSTHU2-V2A-16x39-D1, GSTHU2-V2A-16x39-D2 |  |
| 16x39.5 | 90 | Gravur / Edelstahl / Hund 3 - raus / Edelstahl | GSTHU3-V2A-16x39.5, GSTHU3-V2A-16x39.5-D1, GSTHU3-V2A-16x39.5-D2 |  |
| 16x40 | 331 | Gravur / Edelstahl / Hände / Edelstahl | GSTBE-V2A-16x40, GSTBE-V2A-16x40-D1, GSTBE-V2A-16x40-D2 |  |
| 17x33 | 315 | Gravur / Edelstahl / Wolke / Edelstahl | GSTW-V2A-17x33, GSTW-V2A-17x33-D1, GSTW-V2A-17x33-D10 |  |
| 17x35.5 | 324 | Gravur / Edelstahl / Pfote / Edelstahl | GSTPF-V2A-17x35.5, GSTPF-V2A-17x35.5-D1, GSTPF-V2A-17x35.5-D10 |  |
| 17x36 | 560 | Gravur / Edelstahl / Herz-Rahmen / Edelstahl | GSTH2-V2A-17x36, GSTH2-V2A-17x36-D1, GSTH2-V2A-17x36-D10 |  |
| 17x38 | 433 | Gravur / Edelstahl / Herz / Edelstahl | GSTH-V2A-17x38, GSTH-V2A-17x38-D1, GSTH-V2A-17x38-D10 |  |
| 17x38.5 | 432 | Gravur / Edelstahl / Katze / Edelstahl | GSTHU-V2A-17x38.5, GSTHU-V2A-17x38.5-D1, GSTHU-V2A-17x38.5-D2 |  |
| 18x37 | 557 | Gravur / Edelstahl / Stern / Edelstahl | GSTST-V2A-18x37, GSTST-V2A-18x37-D1, GSTST-V2A-18x37-D10 |  |
| 18x41.5 | 462 | Gravur / Edelstahl / Engel 2 / Edelstahl | GSTE2-V2A-18x41.5, GSTE2-V2A-18x41.5-D1, GSTE2-V2A-18x41.5-D10 |  |
| 18x46 | 650 | Gravur / Edelstahl / Kreuz / Edelstahl | GSTKR-V2A-18x46, GSTKR-V2A-18x46-D1, GSTKR-V2A-18x46-D10 |  |
| 19x38.5 | 344 | Gravur / Edelstahl / Kreuz 2 / Edelstahl | GSTKR2-V2A-19x38.5, GSTKR2-V2A-19x38.5-D1, GSTKR2-V2A-19x38.5-D10 |  |
| 19x40 | 542 | Gravur / Edelstahl / Rund / Edelstahl | GSTR-V2A-19x40, GSTR-V2A-19x40-D1, GSTR-V2A-19x40-D10 |  |
| 19.5x38 | 337 | Gravur / Edelstahl / Herz mit Pfote / Edelstahl | GSTHPF-V2A-19.5x38, GSTHPF-V2A-19.5x38-D1, GSTHPF-V2A-19.5x38-D10 |  |
| 20x36 | 1611 | Gravur / Edelstahl / Herz-Doppelrahmen / Edelstahl | GSTH2-V2A-20x36, GSTH2-V2A-20x36-D1, GSTH2-V2A-20x36-D10 |  |
| 20x38 | 990 | Gravur / Edelstahl / Herz / Edelstahl | GSTH-V2A-20x38, GSTH-V2A-20x38-D1, GSTH-V2A-20x38-D10 |  |
| 20x39.5 | 238 | Gravur / Edelstahl / Hund 3 - raus / Edelstahl | GSTHU3-V2A-20x39.5, GSTHU3-V2A-20x39.5-D1, GSTHU3-V2A-20x39.5-D2 |  |
| 21x23 | 35 | Gravur / Edelstahl / Infinity Herzen / Edelstahl / [Feste Designs] | GSTINFH-V2A-21x23F, GSTINFH-V2A-21x23F-D0, GSTINFH-V2A-21x23F-D1 |  |
| 21x36.5 | 617 | Gravur / Edelstahl / Herz liegend / Edelstahl | GSTH5-V2A-21x36.5, GSTH5-V2A-21x36.5-D1, GSTH5-V2A-21x36.5-D10 |  |
| 21x38.5 | 311 | Gravur / Edelstahl / Hund / Edelstahl | GSTHU-V2A-21x38.5, GSTHU-V2A-21x38.5-D1, GSTHU-V2A-21x38.5-D2 |  |
| 21x39 | 266 | Gravur / Edelstahl / Hund 2 / Edelstahl | GSTHU2-V2A-21x39, GSTHU2-V2A-21x39-D1, GSTHU2-V2A-21x39-D2 |  |
| 22x33 | 361 | Gravur / Edelstahl / Wolke / Edelstahl / [Feste Designs] | GSTW-V2A-22x33, GSTW-V2A-22x33-D1, GSTW-V2A-22x33-D10 |  |
| 22x36.5 | 206 | Gravur / Edelstahl / Stern 2 / Edelstahl | GSTKO-V2A-22x36.5, GSTKO-V2A-22x36.5-D1, GSTKO-V2A-22x36.5-D10 |  |
| 22x39.5 | 140 | Gravur / Edelstahl / Engel 3 / Edelstahl | GSTE3-V2A-22x39.5, GSTE3-V2A-22x39.5-D1, GSTE3-V2A-22x39.5-D10 |  |
| 23x36 | 182 | Gravur / Edelstahl / Infinity Herzen / Edelstahl | GSTIHUV-V2A-23x36, GSTIHUV-V2A-23x36-D1, GSTIHUV-V2A-23x36-D2 |  |
| 23x38 | 625 | Gravur / Edelstahl / Flügel / Edelstahl | GSTFL-V2A-23x38, GSTFL-V2A-23x38-D1, GSTFL-V2A-23x38-D10 |  |
| 25x35 | 93 | Gravur / Edelstahl / Herz mit Pfote 2 / Edelstahl | GSTHPF2-V2A-25x35, GSTHPF2-V2A-25x35-D1, GSTHPF2-V2A-25x35-D2 |  |
| 29x36.5 | 463 | Gravur / Edelstahl / Stern 2 / Edelstahl | GSTKO-V2A-29x36.5, GSTKO-V2A-29x36.5-D1, GSTKO-V2A-29x36.5-D10 |  |
| 29x39.5 | 378 | Gravur / Edelstahl / Engel 3 / Edelstahl | GSTE3-V2A-29x39.5, GSTE3-V2A-29x39.5-D1, GSTE3-V2A-29x39.5-D10 |  |
| 30x36 | 177 | Gravur / Edelstahl / Infinity Herzen / Edelstahl | GSTIHUV-V2A-30x36, GSTIHUV-V2A-30x36 Kopie, GSTIHUV-V2A-30x36-D1 |  |

### Standbilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 8x9 | 86 | Gravur / Standfiguren / Acryl | SF-A-8x9, SF-A-8x9-D1, SF-A-8x9-D2 |  |
| 10x15 | 15 | UV / Standbogen / Acryl | SBOUV-A-10x15-D1, SBOUV-A-10x15-D2 |  |
| 10x16 | 493 | UV / Standbogen / Acryl | SBO-A-10x16, SBO-A-10x16-D1, SBO-A-10x16-D10 |  |
| 12x13.5 | 81 | Gravur / Standfiguren / Acryl | SF-A-12x13.5, SF-A-12x13.5-D1, SF-A-12x13.5-D2 |  |
| 14x14 | 1318 | Gravur / Standherzen / Acryl | SH-A-14x14, SH-A-14x14-D1, SH-A-14x14-D10 |  |
| 14x28.5 | 1832 | Gravur / Standherzen - Gebogen / Acryl | SHG-A-14x28,5, SHG-A-14x28,5-D1, SHG-A-14x28,5-D10 |  |
| 14.5x21.8 | 37 | UV / LED Hochkant | STLHKUV-A-14.5x21.8, STLHKUV-A-14.5x21.8-D1, STLHKUV-A-14.5x21.8-D2 |  |
| 15x15 | 52 | UV / Tierliebe | SBTLUV-A-15x15, SBTLUV-A-15x15-D1, SBTLUV-A-15x15-D2 |  |
| 15x20 | 316 | UV / Songcover / Acryl | STLEHK-A-15x20, STLEHK-A-15x20-D1, STLEHK-A-15x20-D2 |  |
| 15x21.5 | 97 | UV / Songcover / Acryl | STLESC-A-15x21,5, STLESC-A-15x21,5-D1, STLESC-A-15x21,5-D10 |  |
| 16x16 | 50 | UV / Kreis / Acryl | SBRUV-A-16x16, SBRUV-A-16x16-D1, SBRUV-A-16x16-D10 |  |
| 16x18 | 42 | Gravur / Standfiguren / Acryl | SF-A-16x18, SF-A-16x18-D1, SF-A-16x18-D2 |  |
| 18x13 | 1521 | Gravur / Standherzen / Acryl | SH-A-18x13, SH-A-18x13-D1, SH-A-18x13-D10 |  |
| 18x18 | 1063 | Gravur / Standherzen / Acryl | SH-A-18x18, SH-A-18x18-D1, SH-A-18x18-D10 |  |
| 18x28 | 1087 | Gravur / Standherzen - Spitz / Acryl | SHS-A-18x28, SHS-A-18x28-D1, SHS-A-18x28-D10 |  |
| 18x28.5 | 1543 | Gravur / Standherzen - Gebogen / Acryl / [Archiv] | SHG-A-18x28,5, SHG-A-18x28,5-D1, SHG-A-18x28,5-D10 |  |
| 18.5x19 | 62 | Gravur / Standfiguren / Acryl | SF-A-18.5x19, SF-A-18.5x19-D1, SF-A-18.5x19-D2 |  |
| 18.5x20.5 | 97 | Gravur / Standfiguren / Acryl | SF-A-18.5x20.5, SF-A-18.5x20.5-D1, SF-A-18.5x20.5-D2 |  |
| 20x8.5 | 223 | Gravur / Infinity Herzen / Acryl | INF-A-20x8.5, INF-A-20x8.5-D1, INF-A-20x8.5-D2 |  |
| 20x15 | 119 | UV / Fuß / Acryl | SBFUV-A-20x15, SBFUV-A-20x15-D1, SBFUV-A-20x15-D2 |  |
| 20x15.5 | 51 | Gravur / Standfiguren / Acryl | SF-A-20x15.5, SF-A-20x15.5-D1, SF-A-20x15.5-D2 |  |
| 20x16.5 | 28 | UV / Netflix | STLNETUV-20x15-D1, STLNETUV-20x15-D10, STLNETUV-20x15-D2 |  |
| 20x30 | 5 | UV / Netflix |  |  |
| 20.5x17 | 62 | Gravur / Standfiguren / Acryl | SF-A-20.5x17, SF-A-20.5x17-D1, SF-A-20.5x17-D2 |  |
| 21x8.5 | 2 | Gravur / Infinity Love / Acryl |  |  |
| 21x17.5 | 108 | Gravur / Raute | SF-A-21x17.5, SF-A-21x17.5-D1, SF-A-21x17.5-D2 |  |
| 22x13.5 | 62 | Gravur / Standfiguren / Acryl | SF-A-22x13.5, SF-A-22x13.5-D1, SF-A-22x13.5-D2 |  |
| 25x25 | 173 | UV / Kreis / Acryl | SBRUV-A-25x25, SBRUV-A-25x25-D1, SBRUV-A-25x25-D10 |  |
| 26x19 | 1396 | Gravur / Standherzen / Acryl | SH-A-26x19, SH-A-26x19-D1, SH-A-26x19-D10 |  |
| 28x12 | 30 | UV / Fotoständer | STFSUV-AH-28x12, STFSUV-AH-28x12-D1, STFSUV-AH-28x12-D2 |  |
| 28x16 | 61 | UV / Fotoständer | STFSUV-AH-28x16, STFSUV-AH-28x16-D1, STFSUV-AH-28x16-D10 |  |
| 30x12.5 | 176 | UV / Infinity / Holz | INF-A-30x12.5, INF-A-30x12.5-D1, INF-A-30x12.5-D2 |  |
| 30x13 | 76 | UV / Infinity Herzen / Acryl | INFHUV-A-30x13, INFHUV-A-30x13-D1, INFHUV-A-30x13-D2 |  |
| 40x60 | 5 | UV / Netflix |  |  |

### Schlüsselanhänger
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 3.5x5 | 1311 | Gravur / Rechteckig / Holz | SA2DT-A-3,5x5, SA2DT-A-3,5x5-D1, SA2DT-A-3,5x5-D2 |  |
| 3.5x5.5 | 201 | Gravur / Kreuz / Holz | SAKZ-A-3.5x5.5, SAKZ-A-3.5x5.5-D0, SAKZ-A-3.5x5.5-D1 |  |
| 3.75x5 | 79 | UV / Rechteckig / Song Cover / Holz | SAHCUV-H-3.75x5, SAHCUV-H-3.75x5-D1, SAHCUV-H-3.75x5-D2 |  |
| 4x5.5 | 960 | Gravur / Oval / Acryl | SAO-A-4x5.5, SAO-A-4x5.5-D0, SAO-A-4x5.5-D1 |  |
| 4.5x4.5 | 521 | Gravur / Puzzle / Leder | SAP-A-4.5x4.5, SAP-A-4.5x4.5-D1, SAP-A-4.5x4.5-D10 |  |
| 4.5x5 | 4556 | UV / Rund Bild / Holz | SAH-A-4.5x5, SAH-A-4.5x5-D1, SAH-A-4.5x5-D10 |  |
| 5x2 | 1582 | Gravur / 2er / Acryl | SA2-A-5x2, SA2-A-5x2-D0, SA2-A-5x2-D1 |  |
| 5x4 | 940 | Gravur / Herz / Acryl | SAH-A-5x4, SAH-A-5x4-D0, SAH-A-5x4-D1 |  |
| 5x5 | 1343 | Gravur / Rund / Acryl | SAB-A-5x5, SAB-A-5x5-D0, SAB-A-5x5-D1 |  |
| 5x5.5 | 259 | Gravur / Engel / Holz | SAE-A-5x5.5, SAE-A-5x5.5-D0, SAE-A-5x5.5-D1 |  |
| 5x6 | 150 | Gravur / Anker / Holz | SAA-A-5x6, SAA-A-5x6-D0, SAA-A-5x6-D1 |  |
| 6x4 | 64 | Gravur / Rechteckig / Holz | SARE-H-6x4, SARE-H-6x4-D1, SARE-H-6x4-D2 |  |
| 6x5.5 | 425 | Gravur / 2er / Holz | SA2-A-6x5.5, SA2-A-6x5.5-D0, SA2-A-6x5.5-D1 |  |
| 400x400 | 1 | _Actionbilder, Eigenschaften usw / 2021 / Konfi Rohlinge |  |  |
| 1900x1900 | 2 | _Actionbilder, Eigenschaften usw / 2021 / Konfi Rohlinge |  |  |

### Türklingel
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 7x7 | 77 | Gravur / Edelstahl / Schäfer |  |  |
| 7x10 | 276 | UV / Lehmann |  |  |
| 8x8 | 336 | UV / Friedrich |  |  |
| 9x4 | 164 | Gravur / Edelstahl / König |  |  |
| 9x7 | 853 | UV / Richter |  |  |
| 9x9 | 189 | Gravur / Hauptmann / Edelstahl |  |  |
| 9x12 | 405 | UV / Lehmann |  |  |
| 10x4 | 82 | Gravur / Edelstahl / König |  |  |
| 10x7 | 372 | Gravur / Edelstahl / Weber |  |  |
| 10x10 | 424 | UV / Elmers |  |  |
| 10x13 | 81 | Gravur / _Designer Türklingel / Acryl + Edelstahl + Acryl | DTK-AV2A-10x13, DTK-AV2A-10x13-D1, DTK-AV2A-10x13-D10 |  |
| 11x6 | 81 | Gravur / Schiefer / Funke |  |  |
| 11x8 | 594 | Gravur / _Designer Türklingel / Acryl + Edelstahl / Homberg | DTKO-AV2A-11x8, DTKO-AV2A-11x8-D1, DTKO-AV2A-11x8-D10 |  |
| 11x9 | 243 | Gravur / Acryl / Wagner |  |  |
| 11x14 | 320 | UV / Lehmann |  |  |
| 12x6.5 | 123 | Gravur / _Designer Türklingel / Acryl + Edelstahl / Dreesmann | DTK-AV2A-12x6,5, DTK-AV2A-12x6,5-D1, DTK-AV2A-12x6,5-D10 |  |
| 12x9 | 487 | Gravur / Edelstahl / Weber |  |  |
| 12x12 | 378 | UV / Elmers |  |  |
| 12x13 | 118 | Gravur / _Designer Türklingel / Acryl + Edelstahl / Bartels | DTK-AV2A-12x13, DTK-AV2A-12x13-D1, DTK-AV2A-12x13-D10 |  |
| 12x18 | 109 | Gravur / _Designer Türklingel / Acryl + Edelstahl / Förster | DTK-AV2A-12x13-D1, DTK-AV2A-12x13-D10, DTK-AV2A-12x13-D11 |  |
| 13x10 | 301 | Gravur / Schiefer / Richter |  |  |
| 13x11 | 54 | Gravur / Schiefer / Wagner |  |  |
| 13x23 | 45 | Gravur / _Designer Türklingel / Acryl + Edelstahl / Scherer | DTK-AV2A-13x23, DTK-AV2A-13x23-D1, DTK-AV2A-13x23-D10 |  |
| 14x10 | 39 | Gravur / _Designer Türklingel / Edelstahl + Acryl Satiniert | DTK-AV2A-14x10, DTK-AV2A-14x10-D1, DTK-AV2A-14x10-D10 |  |
| 14x11 | 357 | Gravur / Edelstahl / Weber |  |  |
| 15x12 | 84 | Gravur / _Designer Türklingel / Acryl + Edelstahl / Wundermann | DTKO-AV2A-15x12, DTKO-AV2A-15x12-D1, DTKO-AV2A-15x12-D10 |  |

### Hausnummern
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 12x18 | 101 | Gravur / Acryl + Edelstahl | HN-AV2A-12x18, HN-AV2A-12x18-D1, HN-AV2A-12x18-D10 |  |
| 14x22 | 90 | Gravur / Schiefer | HN-S-14x22, HN-S-14x22-D1, HN-S-14x22-D10 |  |
| 15x20 | 142 | Gravur / Acryl | HN-A-15x20, HN-A-15x20-D1, HN-A-15x20-D10 |  |
| 15x25 | 100 | Gravur / Acryl + Edelstahl | HN-AV2A-15x25, HN-AV2A-15x25-D1, HN-AV2A-15x25-D10 |  |
| 15x30 | 54 | UV / Mit Abstandshalter / Acryl | HNRUV-A-15x30, HNRUV-A-15x30-D1, HNRUV-A-15x30-D2 |  |
| 16x5 | 20 | UV / Mit Abstandshalter / Edelstahl + Acryl | HNRUV2-A-16x5, HNRUV2-A-16x5-D1, HNRUV2-A-16x5-D2 |  |
| 16x10 | 46 | UV / Normal / Edelstahl + Acryl | HNRUV-A-16x10-D0, HNRUV-A-16x10-D1, HNRUV-A-16x10-D2 |  |
| 16x11 | 140 | Gravur / Acryl | HN-A-16x11, HN-A-16x11-D1, HN-A-16x11-D10 |  |
| 16x16 | 263 | Gravur / Acryl | HN-A-16x16, HN-A-16x16-D1, HN-A-16x16-D10 |  |
| 16x20 | 147 | Gravur / Acryl + Edelstahl | HN-AV2A-16x20, HN-AV2A-16x20-D1, HN-AV2A-16x20-D10 |  |
| 18x12 | 295 | Gravur / Acryl + Edelstahl | HN-AV2A-18x12, HN-AV2A-18x12-D1, HN-AV2A-18x12-D10 |  |
| 18x14 | 52 | UV / Normal / Edelstahl + Acryl | HNRUV-A-18x14-D0, HNRUV-A-18x14-D1, HNRUV-A-18x14-D2 |  |
| 20x15 | 162 | Gravur / Schiefer | HN-S-20x15, HN-S-20x15-D1, HN-S-20x15-D10 |  |
| 20x16 | 239 | Gravur / Acryl + Edelstahl | HN-AV2A-20x16, HN-AV2A-20x16-D1, HN-AV2A-20x16-D10 |  |
| 20x20 | 446 | Gravur / Acryl | HN-A-20x20, HN-A-20x20-D1, HN-A-20x20-D10 |  |
| 20x25 | 267 | Gravur / Acryl | HN-A-20x25, HN-A-20x25-D1, HN-A-20x25-D10 |  |
| 20x30 | 454 | Gravur / Acryl | HN-A-20x30, HN-A-20x30-D1, HN-A-20x30-D10 |  |
| 20x40 | 119 | Gravur / Schiefer | HN-S-20x40, HN-S-20x40-D1, HN-S-20x40-D10 |  |
| 21x10 | 469 | Gravur / Acryl | HN-A-21x10, HN-A-21x10-D1, HN-A-21x10-D10 |  |
| 21x14 | 116 | Gravur / Acryl + Edelstahl | HN-AV2A-21x14, HN-AV2A-21x14-D1, HN-AV2A-21x14-D10 |  |
| 22x14 | 43 | Gravur / Schiefer | HN-S-22x14, HN-S-22x14-D1, HN-S-22x14-D10 |  |
| 22x18 | 52 | Gravur / Oval / Acryl | HNRO-A-22x18, HNRO-A-22x18-D0, HNRO-A-22x18-D1 |  |
| 22x22 | 187 | Gravur / Acryl + Edelstahl | HN-AV2A-22x22, HN-AV2A-22x22-D1, HN-AV2A-22x22-D10 |  |
| 23x12 | 194 | Gravur / Acryl | HN-A-23x12, HN-A-23x12-D1, HN-A-23x12-D10 |  |
| 23x23 | 196 | Gravur / Acryl | HN-A-23x23, HN-A-23x23-D1, HN-A-23x23-D10 |  |
| 24x15 | 52 | Gravur / Oval / Acryl | HNRO-A-24x15, HNRO-A-24x15-D0, HNRO-A-24x15-D1 |  |
| 24x16 | 186 | Gravur / Acryl | HN-A-24x16, HN-A-24x16-D1, HN-A-24x16-D10 |  |
| 24x30 | 59 | Gravur / Schwarz satiniert+klar | HNRSG-A-24x30, HNRSG-A-24x30-D0, HNRSG-A-24x30-D1 |  |
| 25x15 | 321 | Gravur / Schiefer | HN-AV2A-25x15, HN-AV2A-25x15-D1, HN-AV2A-25x15-D10 |  |
| 25x20 | 142 | Gravur / Acryl | HN-A-25x20, HN-A-25x20-D1, HN-A-25x20-D10 |  |
| 26x13 | 196 | Gravur / Acryl | HN-A-26x13, HN-A-26x13-D1, HN-A-26x13-D10 |  |
| 26x26 | 49 | Gravur / Schwarz satiniert+klar | HNRSG-A-26x26, HNRSG-A-26x26-D0, HNRSG-A-26x26-D1 |  |
| 27x22 | 52 | Gravur / Oval / Acryl | HNRO-A-27x22, HNRO-A-27x22-D0, HNRO-A-27x22-D1 |  |
| 28x18 | 83 | UV / Normal / Edelstahl + Acryl | HNRUV-A-28x18, HNRUV-A-28x18-D1, HNRUV-A-28x18-D10 |  |
| 30x8 | 232 | Gravur / Acryl | HN-A-30x8, HN-A-30x8-D1, HN-A-30x8-D10 |  |
| 30x16 | 59 | Gravur / Schwarz satiniert+klar | HNRSG-A-30x16, HNRSG-A-30x16-D0, HNRSG-A-30x16-D1 |  |
| 30x20 | 568 | Gravur / Acryl | HN-A-30x20, HN-A-30x20-D1, HN-A-30x20-D10 |  |
| 30x24 | 54 | Gravur / Schwarz satiniert+klar | HNRSG-A-30x24, HNRSG-A-30x24-D0, HNRSG-A-30x24-D1 |  |
| 30x30 | 38 | Gravur / Ausschnitt | HNRA-A-30x30-D1, HNRA-A-30x30-D2, HNRA-A-30x30-D3 |  |
| 30x40 | 120 | Gravur / Schiefer | HN-S-30x40, HN-S-30x40-D1, HN-S-30x40-D10 |  |
| 32x18 | 142 | Gravur / Acryl | HN-A-32x18, HN-A-32x18-D1, HN-A-32x18-D10 |  |
| 32x20 | 53 | Gravur / Oval / Acryl | HNRO-A-32x20, HNRO-A-32x20-D0, HNRO-A-32x20-D1 |  |
| 36x20 | 32 | Gravur / Premium / Acryl+Kunststoff+V2A | HSP-A-36x20, HSP-A-36x20-D1, HSP-A-36x20-D2 |  |
| 38x10 | 229 | Gravur / Acryl | HN-A-38x10, HN-A-38x10-D1, HN-A-38x10-D10 |  |
| 40x30 | 72 | UV / Holz Ausschnitt | HNR3D-A-40x30, HNR3D-A-40x30-D0, HNR3D-A-40x30-D1 |  |
| 42x28 | 186 | Gravur / Acryl | HN-A-42x28, HN-A-42x28-D1, HN-A-42x28-D10 |  |
| 56x18 | 120 | Gravur / Schiefer | HN-S-56x18, HN-S-56x18-D1, HN-S-56x18-D10 |  |
| 60x30 | 119 | Gravur / Schiefer | HN-S-60x30, HN-S-60x30-D1, HN-S-60x30-D10 |  |

### Kordelschilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 12x8 | 32 | UV / Rechteckig / Acryl | TSKUV-A-12x8, TSKUV-A-12x8-D1, TSKUV-A-12x8-D2 |  |
| 15x9 | 560 | Gravur / Rechteckig / Acryl | KSRE-A-15x9, KSRE-A-15x9-D0, KSRE-A-15x9-D1 |  |
| 15x20 | 213 | UV / Rechteckig / Holz | KSREUV-H-15x20, KSREUV-H-15x20-D1, KSREUV-H-15x20-D10 |  |
| 16x12 | 62 | UV / Oval / Holz | KSOUV-H-16x12, KSOUV-H-16x12-D1, KSOUV-H-16x12-D10 |  |
| 16x16 | 37 | UV / Rund | KSRUUV-H-16x16, KSRUUV-H-16x16-D1, KSRUUV-H-16x16-D2 |  |
| 18x12 | 182 | UV / Rechteckig / Acryl | TSKUV-A-18x12, TSKUV-A-18x12-D1, TSKUV-A-18x12-D10 |  |
| 19x10 | 32 | UV / Rechteckig / Holz | KSREUV-H-19x10, KSREUV-H-19x10-D1, KSREUV-H-19x10-D2 |  |
| 20x6 | 4 | UV / Rechteckig / Acryl | KSREUV-A-20x6-D1 |  |
| 20x10 | 1311 | Gravur / Rechteckig / Acryl | KS-S-20x10, KS-S-20x10-D1, KS-S-20x10-D10 |  |
| 20x15 | 1724 | UV / Rechteckig / Holz | KS-S-20x15, KS-S-20x15-D1, KS-S-20x15-D10 |  |
| 20x16 | 59 | UV / Herz / Acryl | KSHUV-A-20x16, KSHUV-A-20x16-D1, KSHUV-A-20x16-D10 |  |
| 20x20 | 1050 | Gravur / Quadratisch / Acryl | KS-S-20x20, KS-S-20x20-D1, KS-S-20x20-D10 |  |
| 20x25 | 832 | Gravur / Rechteckig / Acryl | KS-S-20x25, KS-S-20x25-D1, KS-S-20x25-D10 |  |
| 21x10 | 114 | UV / Abgerundete Ecken | KSREUV-A-21x10-D1, KSREUV-A-21x10-D10, KSREUV-A-21x10-D12 |  |
| 22x14 | 139 | Gravur / Schiefer | KS-S-22x14, KS-S-22x14-D1, KS-S-22x14-D10 |  |
| 24x15 | 27 | UV / Rechteckig / Holz | KSREUV-H-24x15, KSREUV-H-24x15-D1, KSREUV-H-24x15-D2 |  |
| 24x16 | 72 | UV / Rechteckig / Acryl | TSKUV-A-24x16, TSKUV-A-24x16-D1, TSKUV-A-24x16-D10 |  |
| 25x20 | 23 | UV / Herz / Holz | KSH-H-25x20, KSH-H-25x20-D0, KSH-H-25x20-D1 |  |
| 30x18 | 20 | UV / Rechteckig / Holz | KSREUV-H-30x18, KSREUV-H-30x18-D1, KSREUV-H-30x18-D2 |  |
| 30x20 | 1079 | Gravur / Rechteckig / Acryl | KS-S-30x20, KS-S-30x20-D1, KS-S-30x20-D10 |  |

### Gedenkstandbilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 8x9 | 117 | UV / Standfiguren / Acryl | GDSF-A-8x9, GDSF-A-8x9-D1, GDSF-A-8x9-D2 |  |
| 10x15 | 100 | Gravur / Standbogen / Acryl | GDSBO-A-10x15, GDSBO-A-10x15-D1, GDSBO-A-10x15-D2 |  |
| 10x16 | 59 | Gravur / Standbogen / Acryl | GDSBO-A-10x16, GDSBO-A-10x16-D1, GDSBO-A-10x16-D2 |  |
| 12x13.5 | 127 | UV / Standfiguren / Acryl | GDSF-A-12x13.5, GDSF-A-12x13.5-D1, GDSF-A-12x13.5-D2 |  |
| 14x14 | 621 | Gravur / [Archiv] / Standherzen / Acryl / NEU | GDSH-A-14x14, GDSH-A-14x14-D1, GDSH-A-14x14-D10 |  |
| 14x28.5 | 938 | Gravur / [Archiv] / Standherzen - Gebogen / Acryl | GDSHG-A-14x28.5, GDSHG-A-14x28.5-D1, GDSHG-A-14x28.5-D10 | ja |
| 16x18 | 42 | Gravur / Standfiguren / Acryl | GDSF-A-16x18, GDSF-A-16x18-D1, GDSF-A-16x18-D2 |  |
| 18x13 | 818 | Gravur / [Archiv] / Standherzen / Acryl / NEU | GDSH-A-18x13, GDSH-A-18x13-D1, GDSH-A-18x13-D10 |  |
| 18x18 | 509 | Gravur / [Archiv] / Standherzen / Acryl / NEU | GDSH-A-18x18, GDSH-A-18x18-D1, GDSH-A-18x18-D10 |  |
| 18x28 | 597 | Gravur / [Archiv] / Standherzen - Spitz / Acryl | GDSHS-A-18x28, GDSHS-A-18x28-D1, GDSHS-A-18x28-D10 | ja |
| 18x28.5 | 682 | Gravur / [Archiv] / Standherzen - Gebogen / Acryl | GDSHG-A-18x28.5, GDSHG-A-18x28.5-D1, GDSHG-A-18x28.5-D10 | ja |
| 18.5x19 | 62 | Gravur / Standfiguren / Acryl | GDSF-A-18.5x19, GDSF-A-18.5x19-D1, GDSF-A-18.5x19-D2 |  |
| 18.5x20.5 | 144 | UV / Standfiguren / Acryl | GDSF-A-18.5x20.5, GDSF-A-18.5x20.5-D1, GDSF-A-18.5x20.5-D2 |  |
| 20x8.5 | 60 | UV / Infinity Foto / Holz | GDINF-A-20x8.5, GDINF-A-20x8.5-D1, GDINF-A-20x8.5-D2 |  |
| 20x15.5 | 29 | Gravur / Standfiguren / Acryl | GDSF-A-20x15.5, GDSF-A-20x15.5-D1 |  |
| 20.5x17 | 62 | Gravur / Standfiguren / Acryl | GDSF-A-20.5x17, GDSF-A-20.5x17-D1, GDSF-A-20.5x17-D2 |  |
| 21x17.5 | 75 | Gravur / Raute | GDSF-A-21x17.5, GDSF-A-21x17.5-D1, GDSF-A-21x17.5-D2 |  |
| 22x13.5 | 62 | Gravur / Standfiguren / Acryl | GDSF-A-22x13.5, GDSF-A-22x13.5-D1, GDSF-A-22x13.5-D2 |  |
| 26x19 | 631 | Gravur / [Archiv] / Standherzen / Acryl / NEU | GDSH-A-26x19, GDSH-A-26x19-D1, GDSH-A-26x19-D10 |  |
| 30x12.5 | 524 | Gravur / Infinity Pfoten / Acryl | GDINF-A-30x12.5, GDINF-A-30x12.5-D1, GDINF-A-30x12.5-D2 |  |
| 30x13 | 155 | UV / Infinity Herzen / Holz | GDINFFUV-A-30x12.5, GDINFFUV-A-30x12.5-D1, GDINFFUV-A-30x12.5-D2 |  |

### Firmenschilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 16x16 | 349 | Gravur / Edelstahl | FS-A-16x16, FS-A-16x16-D0, FS-A-16x16-D1 |  |
| 16x20 | 65 | UV / Acryl | FS-A-16x20, FS-A-16x20-D0, FS-A-16x20-D1 |  |
| 18x12 | 463 | Gravur / Acryl+Edelstahl | FS-A-18x12, FS-A-18x12-D1, FS-A-18x12-D10 |  |
| 20x15 | 580 | Gravur / Acryl | FS-A-20x15, FS-A-20x15-D1, FS-A-20x15-D10 |  |
| 20x16 | 66 | UV / Acryl | FS-A-20x16, FS-A-20x16-D0, FS-A-20x16-D1 |  |
| 20x20 | 680 | Gravur / Acryl | FS-A-20x20, FS-A-20x20-D1, FS-A-20x20-D10 |  |
| 20x30 | 29 | Gravur / Schiefer | FS-S-20x30, FS-S-20x30-D0, FS-S-20x30-D1 |  |
| 22x22 | 680 | Gravur / Acryl | FS-A-22x22, FS-A-22x22-D1, FS-A-22x22-D10 |  |
| 23x12 | 41 | UV / Acryl | FS-A-23x12, FS-A-23x12-D0, FS-A-23x12-D1 |  |
| 25x20 | 24 | Gravur / Schiefer | FS-S-25x20, FS-S-25x20-D0, FS-S-25x20-D1 |  |
| 26x26 | 198 | Gravur / Acryl | FS-A-26x26, FS-A-26x26-D1, FS-A-26x26-D10 |  |
| 28x28 | 198 | Gravur / Acryl | FS-A-28x28, FS-A-28x28-D1, FS-A-28x28-D10 |  |
| 30x20 | 711 | Gravur / Acryl | ALT, FS-A-30x20, FS-A-30x20-D1 |  |
| 30x30 | 680 | Gravur / Acryl | FS-A-30x30, FS-A-30x30-D1, FS-A-30x30-D10 |  |
| 40x20 | 24 | Gravur / Schiefer | FS-S-40x20, FS-S-40x20-D0, FS-S-40x20-D1 |  |
| 40x30 | 696 | Gravur / Acryl | FS-A-40x30, FS-A-40x30-D0, FS-A-40x30-D1 |  |
| 40x40 | 538 | Gravur / Acryl | FS-A-40x40, FS-A-40x40-D1, FS-A-40x40-D10 |  |
| 50x30 | 41 | UV / Acryl | FS-A-50x30, FS-A-50x30-D0, FS-A-50x30-D1 |  |
| 60x30 | 24 | Gravur / Schiefer | FS-S-60x30, FS-S-60x30-D0, FS-S-60x30-D1 |  |

### Anhänger
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 6x6 | 3 | Schulkinder Anhänger |  |  |
| 6x8 | 185 | Ostereier Anhänger / UV / Acryl | OA-A-6x8, OA-A-6x8-D1, OA-A-6x8-D10 |  |
| 7.5x10 | 184 | Ostereier Anhänger / UV / Acryl | OA-A-7.5x10, OA-A-7.5x10-D1, OA-A-7.5x10-D10 |  |
| 8x8 | 158 | Schulkinder Anhänger | SASK-H-8x8, SASK-H-8x8-D1, SASK-H-8x8-D10 |  |
| 10x10 | 3 | Schulkinder Anhänger |  |  |

### Kreuze
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 10.5x15 | 105 | UV / Taufe / Acryl | KZTUV-A-10,5x15, KZTUV-A-10,5x15-D1, KZTUV-A-10,5x15-D10 |  |
| 11x20 | 315 | Gravur | KZ-A-11x20, KZ-A-11x20-D0, KZ-A-11x20-D2 |  |
| 12x20 | 50 | UV / Taufe / Holz | KZTUV-H-12x20, KZTUV-H-12x20-D1, KZTUV-H-12x20-D2 |  |
| 14x25 | 70 | UV / Gedenk | KZUV-A-14x25, KZUV-A-14x25-D1, KZUV-A-14x25-D10 |  |
| 14.8x20 | 105 | UV / Taufe / Acryl | KZTUV-A-14,8x20, KZTUV-A-14,8x20-D1, KZTUV-A-14,8x20-D10 |  |
| 21.5x30 | 80 | Gravur / Schiefer | KZ-S-21,5x30, KZ-S-21,5x30-D1, KZ-S-21,5x30-D10 |  |
| 22x40 | 376 | UV / Gedenk | KZ-A-22x40, KZ-A-22x40-D0, KZ-A-22x40-D1 |  |
| 23x33 | 517 | Gravur | KZ-A-23x33, KZ-A-23x33-D1, KZ-A-23x33-D10 |  |
| 23.5x40 | 514 | Gravur | KZ-A-23.5x40, KZ-A-23.5x40-D1, KZ-A-23.5x40-D10 |  |
| 24x33.5 | 185 | Gravur / Schiefer / _Archiv | KZ-S-24x33.5, KZ-S-24x33.5-D1, KZ-S-24x33.5-D10 | ja |
| 27x39 | 197 | Gravur | KZ-A-27x39, KZ-A-27x39-D0, KZ-A-27x39-D1 |  |
| 32x48 | 161 | Gravur | KZ-A-32x48, KZ-A-32x48-D0, KZ-A-32x48-D1 |  |
| 35x50 | 168 | Gravur | KZ-A-35x50, KZ-A-35x50-D0, KZ-A-35x50-D1 |  |

### Hochzeitsschilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 9x6 | 225 | Gravur / Retro 1 / Kunststoff | HZSR1-A-9x6, HZSR1-A-9x6-D0, HZSR1-A-9x6-D1 |  |
| 12x4 | 47 | Gravur / Oval / Edelstahl | HZSO-V2A-12x4, HZSO-V2A-12x4-D0, HZSO-V2A-12x4-D1 |  |
| 12x8 | 227 | Gravur / Retro 2 / Kunststoff | HZSR2-A-12x8, HZSR2-A-12x8-D0, HZSR2-A-12x8-D1 |  |
| 15x8 | 225 | Gravur / Oval / Kunststoff | HZSO-A-15x8, HZSO-A-15x8-D0, HZSO-A-15x8-D1 |  |
| 15x10 | 225 | Gravur / Rechteckig / Kunststoff | HZS-A-15x10, HZS-A-15x10-D0, HZS-A-15x10-D1 |  |
| 21x7 | 219 | Gravur / Oval / Kunststoff | HZSO-A-21x7, HZSO-A-21x7-D0, HZSO-A-21x7-D1 |  |
| 21x12 | 216 | Gravur / Oval / Kunststoff | HZSO-A-21x12, HZSO-A-21x12-D0, HZSO-A-21x12-D1 |  |
| 22.5x19.5 | 46 | Gravur / Herz / Edelstahl | HZSH-V2A-22.5x19.5, HZSH-V2A-22.5x19.5-D0, HZSH-V2A-22.5x19.5-D1 |  |

### Boxenschilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 14x15 | 21 | Gravur / Silhouetten / Acryl | BSS-A-14x15, BSS-A-14x15-D0 |  |
| 15x8 | 111 | Gravur / Edelstahl | BS-V2A-15x8, BS-V2A-15x8-D0, BS-V2A-15x8-D1 |  |
| 18x15 | 21 | Gravur / Silhouetten / Acryl | BSS-A-18x15, BSS-A-18x15-D0 |  |
| 19x25 | 21 | Gravur / Silhouetten / Acryl | BSS-A-19x25, BSS-A-19x25-D0 |  |
| 20x18.5 | 28 | Gravur / Silhouetten / Acryl | BSS-A-20x18.5, BSS-A-20x18.5-D0, BSS-A-20x18.5-D1 |  |
| 20x30 | 103 | UV / Aludibond | BSUV-A-20x30, BSUV-A-20x30-D1, BSUV-A-20x30-D2 |  |
| 25x24 | 21 | Gravur / Silhouetten / Acryl | BSS-A-25x24, BSS-A-25x24-D0 |  |
| 26x19 | 21 | Gravur / Silhouetten / Acryl | BSS-A-26x19, BSS-A-26x19-D0 |  |
| 30x20 | 1031 | Gravur / Schiefer | BS-A-30x20, BS-A-30x20-D1, BS-A-30x20-D10 |  |
| 32x24.5 | 22 | Gravur / Silhouetten / Acryl | BSS-A-32x24.5, BSS-A-32x24.5-D0 |  |

### Kalender
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 40x60 | 146 | UV | KSUV-40x60, KSUV-40x60-D1, KSUV-40x60-D10 |  |
| 50x75 | 233 | UV |  |  |
| 60x40 | 587 | UV |  |  |
| 75x50 | 12 | UV | KUV1-75x50, KUV1-75x50-D1 |  |

### Tierschilder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 10x6.5 | 19 | UV | TSUV-A-10x6.5, TSUV-A-10x6.5-D1 |  |
| 10x15 | 37 | UV | TSUV-A-10x15, TSUV-A-10x15-D1, TSUV-A-10x15-D2 |  |
| 12x8 | 24 | UV | TSUV-A-12x8, TSUV-A-12x8-D1, TSUV-A-12x8-D2 |  |
| 15x10 | 91 | UV / Hundeschilder / Aludibond | TSUV-A-15x10, TSUV-A-15x10-D1, TSUV-A-15x10-D2 |  |
| 16x16 | 28 | UV | TSUV-A-16x16, TSUV-A-16x16-D1, TSUV-A-16x16-D2 |  |
| 20x15 | 213 | UV / Hundeschilder / Aludibond | TSUV-A-20x15, TSUV-A-20x15-D1, TSUV-A-20x15-D2 |  |
| 20x16 | 28 | UV | TSUV-A-20x16, TSUV-A-20x16-D1, TSUV-A-20x16-D2 |  |
| 20x30 | 23 | UV | TSUV-A-20x30, TSUV-A-20x30-D1, TSUV-A-20x30-D2 |  |
| 23x12 | 41 | UV | TSUV-A-23x12, TSUV-A-23x12-D1, TSUV-A-23x12-D2 |  |
| 25x20 | 33 | UV | TSUV-A-25x20, TSUV-A-25x20-D1, TSUV-A-25x20-D2 |  |
| 30x20 | 254 | UV / Hundeschilder / Aludibond | TSUV-A-30x20, TSUV-A-30x20-D1, TSUV-A-30x20-D10 |  |
| 40x30 | 28 | UV | TSUV-A-40x30, TSUV-A-40x30-D1, TSUV-A-40x30-D2 |  |
| 50x30 | 28 | UV | TSUV-A-50x30, TSUV-A-50x30-D1, TSUV-A-50x30-D2 |  |

### Geldgeschenk
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 12x18 | 31 | UV / Geldausschnitt / Acryl | GGAUV-A-12x18, GGAUV-A-12x18-D1, GGAUV-A-12x18-D2 |  |
| 15x20 | 86 | UV / Wandbild mit gefaltetem Geld / Acryl | WBCAH-A-15x20, WBCAH-A-15x20-D1, WBCAH-A-15x20-D2 |  |
| 18x12 | 71 | UV / Geldausschnitt / Acryl | GGAUV-A-18x12, GGAUV-A-18x12-D1, GGAUV-A-18x12-D10 |  |
| 20x20 | 107 | Gravur / Geld gefaltet / Schiefer | HZS-S-20x20, HZS-S-20x20-D1, HZS-S-20x20-D2 |  |
| 20x30 | 149 | UV / Hochzeit Clipart Wandbild Standbild | GGAUV-A-20x30, GGAUV-A-20x30-D1, GGAUV-A-20x30-D2 |  |
| 24x30 | 60 | UV / Wandbild mit gefaltetem Geld / Leinwand | WBGG-LW-24x30, WBGG-LW-24x30-D1, WBGG-LW-24x30-D10 |  |
| 25x25 | 22 | Gravur / Geld gefaltet / Schiefer | HZS-S-25x25, HZS-S-25x25-D1, HZS-S-25x25-D2 |  |
| 30x20 | 16 | UV / Geldausschnitt / Acryl | GGAUV-A-30x20, GGAUV-A-30x20-D1, GGAUV-A-30x20-D2 |  |
| 30x40 | 60 | UV / Wandbild mit gefaltetem Geld / Leinwand | WBGG-LW-30x40, WBGG-LW-30x40-D1, WBGG-LW-30x40-D10 |  |

### Tierzubehör
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 2.9x5 | 68 | Hundemarken / Holz / DogTag | HMDT-V2A-2.9x5-D1, HMDT-V2A-2.9x5-D2, HMDT-V2A-2.9x5-D3 |  |
| 3x3 | 122 | Hundemarken / Holz / Rund | HMRG-V2A-3x3-D1, HMRG-V2A-3x3-D2, HMRG-V2A-3x3-D3 |  |
| 3x3.5 | 46 | Hundemarken / Holz / Herz | HMH-H-3x3.5, HMH-H-3x3.5-D0, HMH-H-3x3.5-D1 |  |
| 3.1x2.1 | 88 | Hundemarken / Holz / Knochen | HMKK-H-3.1x2.1, HMKK-H-3.1x2.1-D0, HMKK-H-3.1x2.1-D1 |  |
| 3.8x2.5 | 64 | Hundemarken / Holz / Knochen | HMKM-H-3.8x2.5, HMKM-H-3.8x2.5-D0, HMKM-H-3.8x2.5-D1 |  |
| 3.8x3.3 | 46 | Hundemarken / Holz / Herz | HMH-H-3.8x3.3, HMH-H-3.8x3.3-D0, HMH-H-3.8x3.3-D1 |  |
| 3.8x3.8 | 146 | Hundemarken / Holz / Rund | HMRG-H-3.8x3.8, HMRG-H-3.8x3.8-D0, HMRG-H-3.8x3.8-D1 |  |
| 3.8x4.8 | 46 | Hundemarken / Holz / Pfote | HMP-H-3.8x4.8, HMP-H-3.8x4.8-D0, HMP-H-3.8x4.8-D1 |  |
| 5x2 | 2 | Hundemarken / Alu / Partner |  |  |
| 5x2.9 | 63 | Hundemarken / Holz / DogTag | HMDT-V2A-5x2,9-D1, HMDT-V2A-5x2,9-D2, HMDT-V2A-5x2,9-D3 |  |
| 5.2x3.7 | 76 | Hundemarken / Holz / Knochen | HMKG-H-5.2x3.7, HMKG-H-5.2x3.7-D0, HMKG-H-5.2x3.7-D1 |  |

### Frühstücksbrettchen
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 20x13 | 91 | UV | FBUV-H-20x13, FBUV-H-20x13-D1, FBUV-H-20x13-D10 |  |
| 22.5x15 | 180 | Gravur | FB-H-22.5x15, FB-H-22.5x15-D1, FB-H-22.5x15-D10 |  |

### Monogramme
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 22x14 | 166 | Monogramm 1 | MG-S-22x14, MG-S-22x14-D1, MG-S-22x14-D10 |  |
| 30x20 | 428 | Monogramm 2 | MG-S-30x20, MG-S-30x20-D1, MG-S-30x20-D10 |  |

### Radiergummi
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 3.5x3.5 | 295 | UV | RG-RG-35x35, RG-RG-35x35-D1, RG-RG-35x35-D10 |  |
| 5.3x2.6 | 295 | UV | RG-RG-53x26, RG-RG-53x26-D1, RG-RG-53x26-D10 |  |

### Hunde-Ecke
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 100x60 | 243 |  | HEUV-AD-100x60, HEUV-AD-100x60-D1, HEUV-AD-100x60-D10 |  |
| 80x60 | 232 |  | HEUV-AD-80x60, HEUV-AD-80x60-D1, HEUV-AD-80x60-D10 |  |

### Blumenstecker
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 13x38.7 | 26 | Herbst / Eichhörnchen | BSTE-V2A-13x38,7, BSTE-V2A-13x38,7-D1, BSTE-V2A-13x38,7-D2 |  |
| 15x38.7 | 26 | Herbst / Pilz | BSTP-V2A-15x38,7, BSTP-V2A-15x38,7-D1, BSTP-V2A-15x38,7-D2 |  |
| 16x32.5 | 21 | Herbst / Igel | BSTI-V2A-16x32,5, BSTI-V2A-16x32,5-D1, BSTI-V2A-16x32,5-D2 |  |
| 16x38 | 16 | Herbst / Blatt 2 | BSTB2-V2A-16x38, BSTB2-V2A-16x38-D1 |  |
| 16x38.7 | 26 | Herbst / Eichhörnchen | BSTE-V2A-16x38,7, BSTE-V2A-16x38,7-D1, BSTE-V2A-16x38,7-D2 |  |
| 16x40 | 46 | Herbst / Rund | BSTR-V2A-16x40, BSTR-V2A-16x40-D1, BSTR-V2A-16x40-D2 |  |
| 17x38.7 | 26 | Herbst / Pilz | BSTP-V2A-17x38,7, BSTP-V2A-17x38,7-D1, BSTP-V2A-17x38,7-D2 |  |
| 18x35 | 21 | Herbst / Blatt 1 | BSTB1-V2A-18x35, BSTB1-V2A-18x35-D1, BSTB1-V2A-18x35-D2 |  |
| 19x32.5 | 21 | Herbst / Igel | BSTI-V2A-19x32,5, BSTI-V2A-19x32,5-D1, BSTI-V2A-19x32,5-D2 |  |
| 19x40 | 12 | Herbst / Rund | BSTR-V2A-19x40, BSTR-V2A-19x40-D1, BSTR-V2A-19x40-D2 |  |

### Flachmann
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 9.5x8.5 | 167 |  | FM-V2A-9.5x8.5, FM-V2A-9.5x8.5-D1, FM-V2A-9.5x8.5-D10 |  |
| 9.5x10.5 | 165 |  | FM-V2A-9.5x10.5, FM-V2A-9.5x10.5-D1, FM-V2A-9.5x10.5-D10 |  |
| 9.5x12 | 163 |  | FM-V2A-9.5x12, FM-V2A-9.5x12-D1, FM-V2A-9.5x12-D10 |  |

### Lesehilfe
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 16x4.5 | 77 | UV / Lesehilfe mit Zahlen | LH-H-16x4,5, LH-H-16x4,5-D1, LH-H-16x4,5-D2 |  |
| 18x5 | 77 | UV / Lesehilfe mit Zahlen | LH-H-18x5, LH-H-18x5-D1, LH-H-18x5-D2 |  |
| 21x5.8 | 22 | Gravur | LH-H-21x5,8, LH-H-21x5,8-D1, LH-H-21x5,8-D2 |  |

### Lesezeichen
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 5x17 | 79 | UV / Acryl | LZ-A-5x17, LZ-A-5x17-D1, LZ-A-5x17-D10 |  |
| 17x5 | 257 | UV / Acryl | LZ-A-17x5, LZ-A-17x5-D1, LZ-A-17x5-D10 |  |

### Puzzle
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 30x22.5 | 113 | Holz / [Archiv] |  | ja |

### Erinnerungskiste
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 30x20 | 301 | UV / Kinder | EKE-H-30x20, EKE-H-30x20-D1, EKE-H-30x20-D2 |  |

### Messlatten
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 20x100 | 107 |  | MLUV-H-20x100, MLUV-H-20x100-D1, MLUV-H-20x100-D10 |  |
| 20x70 | 105 |  | MLUV-H-20x70-D1, MLUV-H-20x70-D10, MLUV-H-20x70-D11 |  |
| 30x90 | 26 |  | MLFUV-H-30x90-D1, MLFUV-H-30x90-D2, MLFUV-H-30x90-D3 |  |

### Cake Topper
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 6x12.3 | 38 | UV / Acryl | CTUV-A-6x12,3, CTUV-A-6x12,3-D1, CTUV-A-6x12,3-D2 |  |
| 10x17.4 | 32 | UV / Acryl | CTUV-A-10x17.4, CTUV-A-10x17.4-D1, CTUV-A-10x17.4-D2 |  |
| 12x20 | 32 | UV / Acryl | CTUV-A-12x20, CTUV-A-12x20-D1, CTUV-A-12x20-D2 |  |
| 12.5x23 | 71 | Gravur / Acryl | CT-A-12.5x23-D1, CT-A-12.5x23-D2, CT-A-12.5x23-D3 |  |

### Stiftehalter
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 10x10 | 201 | UV | STHUV-H-10x10, STHUV-H-10x10-D100, STHUV-H-10x10-D101 |  |

### Stundenpläne
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 30x20 | 189 | Acryl | SP-A-30x20, SP-A-30x20-D1, SP-A-30x20-D10 |  |

### Schiefer mit Foto
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 9x15 | 37 | UV | SFUV-S-9x15, SFUV-S-9x15-D1, SFUV-S-9x15-D10 |  |
| 14x22 | 36 | UV | SFUV-S-14x22, SFUV-S-14x22-D1, SFUV-S-14x22-D10 |  |
| 20x30 | 80 | UV | SFUV-S-20x30, SFUV-S-20x30-D1, SFUV-S-20x30-D10 |  |

### Adventskalender
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 30x27.5 | 4 | Geweih / Holz | AK-H-30x27,5-D1 |  |
| 50x17.5 | 20 |  | AKUV-H-50x17.5, AKUV-H-50x17.5-D1, AKUV-H-50x17.5-D2 |  |
| 50x25 | 60 |  | AKUV-H-50x25, AKUV-H-50x25-D1, AKUV-H-50x25-D10 |  |
| 50x30 | 35 |  | AKUV-H-50x30, AKUV-H-50x30-D1, AKUV-H-50x30-D2 |  |
| 50x33.5 | 15 | Geweih / Holz | AKUV-H-50x33.5, AKUV-H-50x33.5-D1 |  |

### Briefkasten
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 17x9 | 21 | Gravur / Edelstahl | BK-V2A-17x9, BK-V2A-17x9-D1, BK-V2A-17x9-D2 |  |
| 33x16 | 89 | Gravur / Acryl | BK-A-33x16, BK-A-33x16-D0, BK-A-33x16-D1 |  |
| 36x7 | 12 | Gravur / Edelstahl | BK-V2A-36x7, BK-V2A-36x7-D1, BK-V2A-36x7-D2 |  |
| 36x20 | 10 | Gravur / Edelstahl | BK-V2A-36x20, BK-V2A-36x20-D1 |  |
| 36x26.5 | 12 | Gravur / Edelstahl | BK-V2A-36x26,5, BK-V2A-36x26,5-D1, BK-V2A-36x26,5-D2 |  |

### Postkarte
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 15x10 | 138 | Gravur | PK-H-15x10, PK-H-15x10-D1, PK-H-15x10-D10 |  |

### Gedenktafeln Sternenkinder
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 20x15 | 32 |  | GTSK-S-20x15, GTSK-S-20x15-D1, GTSK-S-20x15-D2 |  |
| 22x14 | 16 |  | GTSK-S-22x14, GTSK-S-22x14-D1, GTSK-S-22x14-D2 |  |
| 30x20 | 32 |  | GTSK-S-30x20, GTSK-S-30x20-D1, GTSK-S-30x20-D2 |  |
| 40x30 | 32 |  | GTSK-S-40x30, GTSK-S-40x30-D1, GTSK-S-40x30-D2 |  |

### Untersetzer
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 10x10 | 47 | Rund | USPUV-H-10x10-D1, USPUV-H-10x10-D2, USRUV-H-10x10 |  |

### Blumenkübel
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 10x10 | 69 | UV | BK-H-10x10, BK-H-10x10-D1, BK-H-10x10-D10 |  |

### Belohnungstafel
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 30x20 | 68 | Acryl | BT-A-30x20, BT-A-30x20-D1, BT-A-30x20-D2 |  |

### Grillzange
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 32x2 | 40 | Holz | GZ-H-32x2, GZ-H-32x2-D1, GZ-H-32x2-D10 |  |

### Buffetplatte
| Größe | Ordner | Kontext (häufigster Pfad) | SKU-Beispiel | nur Archiv |
| --- | --- | --- | --- | --- |
| 22x22 | 1 | Schiefer / Gravur |  |  |
| 28x28 | 1 | Schiefer / Gravur |  |  |
| 30x20 | 1 | Schiefer / Gravur |  |  |
| 35.5x35.5 | 1 | Schiefer / Gravur |  |  |
| 40x30 | 1 | Schiefer / Gravur |  |  |

