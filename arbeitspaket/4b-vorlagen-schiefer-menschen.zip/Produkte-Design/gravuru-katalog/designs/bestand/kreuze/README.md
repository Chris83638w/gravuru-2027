# Bestandsdesigns Kreuze – aus dem Server-Bestand extrahiert

154 Designs (über Größen und Materialien zusammengefasst), gelesen aus den Corel-Bögen (`[CDR]`) und Konfigurator-Paketen auf `V:\Produkte\Gedenktafeln`. Je Design ein Ordner `Zielgruppe/Unterkategorie/<Schlüssel>/` mit `design.svg` (Text bleibt Text, Motive als Pfade, Maße in mm), `design.json` (Texte, Schriften, Lage, Varianten, Kategorie) und `preview.png`. UV-Designs aus Paketen tragen zusätzlich `product.json` und die Ebenen (`Bild_*.png`, `*.svg`).

**Kategorien sind Vorschläge aus den Texten** – Korrektur in [`KREUZE-DESIGNS.xlsx`](KREUZE-DESIGNS.xlsx) (gelbe Spalten), Übersichtsbögen je Kategorie in `_uebersicht/`.

| Zielgruppe | Unterkategorie | Designs |
| --- | --- | --- |
| Allgemein | Allgemein | 87 |
| Anlass | Geburtstag | 1 |
| Anlass | Liebe | 7 |
| Familie | Kinder | 9 |
| Familie | Paar | 1 |
| Sprüche | Spruch | 19 |
| Tiere | Hund | 6 |
| Tiere | Katze | 3 |
| Tiere | Tiere allgemein | 2 |
| Trauer | Gedenken | 1 |
| Trauer | Sternenkind | 2 |
| offen | offen | 16 |

| Reihe | Designs |
| --- | --- |
| KZ-A · Gravur Acryl | 60 |
| KZ-S · Gravur Schiefer | 34 |
| KZUV-A · UV Acryl | 33 |
| KZTUV-A · UV Acryl | 19 |
| KZTUV-H · UV Holz | 8 |

## Regeln

- Eigene Motive dieser Designs bleiben beim Design (keine Übernahme in `motive/`).
- Alte Größen sind nur dokumentiert (`sizesInStock`); welche Größen die Linie künftig hat, entscheidet der Nutzer.
- Texte sind Beispieltexte des Bestands (Kundenfelder im Konfigurator); Schriften sind die im Bestand verwendeten – Ersatz für nicht freigegebene Schriften folgt je Linie.
- Lücken: Designs ohne lesbaren Text (`offen`) stammen aus reinen Bildpaketen; dort hilft nur Sichtprüfung über `preview.png`.
