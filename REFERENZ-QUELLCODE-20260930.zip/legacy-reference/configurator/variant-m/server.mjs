import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import {exportAcrylicPDF} from './acrylic-export.mjs';
import {Workbench,workbenchRoute} from '../../automation/product-pipeline/workbench.mjs';
import {build,HERE,ROOT,OUTPUT} from './build.mjs';
const pilotPath=process.argv.find(v=>v.startsWith('--pilot='))?.slice('--pilot='.length);
const outputDirectory=pilotPath?path.join(OUTPUT,'pilots','d201'):OUTPUT;
const result=build({pilotPath,outputDirectory});
const port=Number(process.argv.find(v=>v.startsWith('--port='))?.split('=')[1]||8947);
const dataRoot=process.argv.find(v=>v.startsWith('--workbench='))?.slice('--workbench='.length);
const workbench=dataRoot?new Workbench({root:dataRoot}):null,sessionToken=randomBytes(32).toString('hex');
const workshopUI=path.join(ROOT,'platform/sources/workshop/public');
async function readBody(req,limit=45000000){if(!req.headers['content-type']?.startsWith('application/json'))throw Object.assign(Error('JSON erwartet.'),{status:415});let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>limit)throw Object.assign(Error('Datei zu groß.'),{status:413});chunks.push(chunk);}return JSON.parse(Buffer.concat(chunks));}
if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Ungültiger Port.');
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.txt':'text/plain; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.gz':'application/gzip'};
http.createServer(async(req,res)=>{
  try{
    if(![`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host)){res.writeHead(403).end();return;}
    const origin='http://'+req.headers.host;
    if(req.headers.origin&&req.headers.origin!==origin||req.headers['sec-fetch-site']==='cross-site'){res.writeHead(403).end();return;}
    const routeUrl=new URL(req.url,origin);
    if(routeUrl.pathname==='/api/acrylic/export'&&req.method==='POST'){
      const pdf=await exportAcrylicPDF(await readBody(req));
      const printOutput=path.join(ROOT,'output/pdf');fs.mkdirSync(printOutput,{recursive:true});fs.writeFileSync(path.join(printOutput,'Acrylglas-Roland-Rueckseite.pdf'),pdf);
      res.writeHead(200,{'Content-Type':'application/pdf','Cache-Control':'no-store','Content-Disposition':'attachment; filename="Acrylglas-Roland-Rueckseite.pdf"'}).end(pdf);return;
    }
    if(workbench&&routeUrl.pathname==='/api/session'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'}).end(JSON.stringify({token:sessionToken}));return;}
    if(workbench&&routeUrl.pathname.startsWith('/api/product-workbench')){
      if(req.method==='POST'&&req.headers['x-gravuru-token']!==sessionToken){res.writeHead(403).end();return;}
      const send=data=>res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'}).end(JSON.stringify(data));
      await workbenchRoute(workbench,req,res,routeUrl,{body:readBody,send});return;
    }
    if(!['GET','HEAD'].includes(req.method)){res.writeHead(405).end();return;}
    const url=new URL(req.url,'http://127.0.0.1'),pathname=decodeURIComponent(url.pathname);
    let file;
    if(pathname==='/')file=path.join(HERE,'index.html');
    else if(workbench&&['/produktanlage.html','/produktanlage.css','/produktanlage.mjs','/produktanlage-library.mjs','/produktanlage-products.mjs','/produktanlage-shopify.mjs','/produktanlage-option-images.mjs'].includes(pathname))file=path.join(workshopUI,pathname.slice(1));
    else if(workbench&&/^\/materialreferenzen\/[\w.-]+\.(png|jpg|webp)$/.test(pathname))file=path.join(workshopUI,pathname.slice(1));
    else if(pathname.startsWith('/acrylic-assets/')&&/^\/acrylic-assets\/[a-z0-9-]+\.png$/.test(pathname))file=path.join(ROOT,'designs/acrylic-unser-anfang',pathname.split('/').pop());
    else if(pathname==='/assistant.js')file=path.join(outputDirectory,'assistant.js');
    else if(pathname==='/api/guides')file=path.join(outputDirectory,'guides.json');
    else if(['/models.json','/editor.html'].includes(pathname))file=path.join(outputDirectory,pathname.slice(1));
    else if(pathname==='/labrador/motif.json')file=path.join(ROOT,'designs/aosu-labrador/motif.json');
    else if(pathname==='/labrador/michroma-vectors.json')file=path.join(ROOT,'designs/aosu-labrador/assets/michroma-vectors.json');
    else {
      const paths=[['/_runtime/',path.join(ROOT,'designs/aosu-labrador/runtime')],
        ['/platform/sources/app/shared/',path.join(ROOT,'platform/sources/app/shared')],
        ['/configurator/variant-m/',HERE]];
      const match=paths.find(([prefix])=>pathname.startsWith(prefix));
      if(!match){res.writeHead(404).end();return;}
      const [prefix,base]=match,rel=pathname.slice(prefix.length);
      if(!rel||rel.split(/[\\/]/).some(p=>p==='..'||p.startsWith('.'))||(!pathname.startsWith('/_runtime/')&&!/\.(?:mjs|js|css)$/.test(rel))){res.writeHead(404).end();return;}
      file=path.resolve(base,rel);
      const real=fs.realpathSync(file),relative=path.relative(fs.realpathSync(base),real);
      if(relative.startsWith('..')||path.isAbsolute(relative)){res.writeHead(404).end();return;}
    }
    if(!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
    const bytes=fs.readFileSync(file);
    res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Content-Length':bytes.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',
      'Content-Security-Policy':"default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data: blob:; font-src 'self' data:; frame-src 'self'; object-src 'none'; frame-ancestors 'self'"});
    res.end(req.method==='HEAD'?undefined:bytes);
  }catch(error){if(req.url?.startsWith('/api/'))res.writeHead(error.status||400,{'Content-Type':'application/json'}).end(JSON.stringify({error:error.message}));else res.writeHead(404).end('Nicht gefunden');}
}).listen(port,'127.0.0.1',()=>console.log(JSON.stringify({...result,url:'http://127.0.0.1:'+port+'/',scope:'local-review-only'})));
