const $=s=>document.querySelector(s),escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=c=>new Intl.NumberFormat('de-DE',{style:'currency',currency:'EUR'}).format(c/100);
export function installAiDesign({state,api,setBusy,notify,onSaved}){
 document.body.insertAdjacentHTML('beforeend',`<dialog id="ai-design-dialog" aria-labelledby="ai-design-title">
 <header class="dialog-header"><div><p class="eyebrow">GESTALTUNGSHILFE</p><h2 id="ai-design-title">Mit KI gestalten</h2></div><button type="button" id="ai-close" aria-label="KI-Gestaltung schließen">×</button></header>
 <p id="ai-target"></p><p>Texte, Anordnung, Farben und vorhandene Motive bearbeiten. Der Vorschlag bleibt bis zur Übernahme ein eigener Entwurf.</p>
 <p id="ai-connection" role="status"></p><p id="ai-budget" class="field-help"></p>
 <form id="ai-design-form"><label for="ai-instruction">Was möchtest du ändern?</label><textarea id="ai-instruction" rows="4" maxlength="4000" required placeholder="Zum Beispiel: Ordne den Namen mittig über dem Foto an und setze die Lebensdaten darunter."></textarea>
 <div class="ai-preserve"><label><input id="ai-preserve-text" type="checkbox" checked> Vorhandene Texte und Schriften erhalten</label><label><input id="ai-preserve-photos" type="checkbox" checked> Fotofelder unverändert lassen</label></div>
 <p class="field-help">Dein Auftrag, Texte, Elementmaße und Bibliotheksbezeichnungen werden an OpenAI gesendet. Fotos und Bestellungen werden nicht übertragen. Neue KI-Bilder sind hier noch nicht verfügbar.</p>
 <button type="submit" class="primary" id="ai-generate" disabled>Vorschlag anfordern</button></form>
 <p id="ai-error" class="message error" role="alert" hidden></p><p id="ai-progress" role="status"></p>
 <section id="ai-review" hidden><h3>Vorschlag prüfen</h3><p id="ai-summary"></p><div class="ai-comparison"><figure><figcaption>Bisheriger Stand</figcaption><div id="ai-before"></div></figure><figure><figcaption>KI-Vorschlag</figcaption><div id="ai-after"></div></figure></div>
 <p>Die Übernahme speichert eine neue Version. Bisherige Versionen bleiben im Verlauf erhalten. Preise und Kundenrechte werden nicht geändert.</p></section>
 <div class="dialog-actions"><button type="button" id="ai-cancel-job" hidden>Auftrag abbrechen</button><button type="button" class="primary" id="ai-apply" hidden>Als neue Version übernehmen</button></div>
 <details class="ai-history"><summary>Bisherige KI-Aufträge</summary><div id="ai-jobs"></div></details>
 </dialog>`);
 const dialog=$('#ai-design-dialog');let target=null,job=null,budget=null,timer=null,serial=0,applying=false,creating=false,requestId=null;
 const labels={running:'Wird erstellt',review:'Zur Prüfung',invalid:'Nicht übernehmbar',uncertain:'Antwort unbestätigt',cost_review:'Kosten prüfen',discarded:'Verworfen',applied:'Übernommen'};
 const error=e=>{$('#ai-error').textContent=e.message;$('#ai-error').hidden=false;};
 function controls(){const running=job?.status==='running';$('#ai-generate').disabled=creating||applying||running||!budget?.enabled||budget.availableCents<budget.reservationCents;$('#ai-apply').hidden=job?.status!=='review';$('#ai-apply').disabled=applying;$('#ai-cancel-job').hidden=!['review','running'].includes(job?.status);$('#ai-cancel-job').disabled=applying;$('#ai-cancel-job').textContent=running?'Auftrag abbrechen':'Vorschlag verwerfen';$('#ai-close').disabled=applying;}
 function renderBudget(b){budget=b;$('#ai-connection').textContent=b.enabled?'OpenAI-Zugang ist eingerichtet.':b.reason;$('#ai-budget').textContent=`Monat ${b.month}: ${money(b.accountedCents)} verbucht oder reserviert von ${money(b.limitCents)}. Pro Auftrag werden vorsorglich bis zu ${money(b.reservationCents)} reserviert und nach bestätigter Antwort verrechnet. Diese Werkstatt rechnet mit einem Sicherheitspuffer; die OpenAI-Rechnung kann abweichen.`;controls();}
 async function history(){const active=target;const d=await api(`/api/workshop/products/${active.productId}/ai-design`);if(!dialog.open||target!==active)return;renderBudget(d.budget);$('#ai-jobs').innerHTML=d.jobs.length?d.jobs.map(j=>`<button type="button" data-ai-job="${escape(j.id)}">${escape(labels[j.status]||j.status)} · ${escape(j.instruction.slice(0,100))}</button>`).join(''):'Noch keine KI-Aufträge für dieses Produkt.';}
 function show(result){job=result.job;if(result.budget)renderBudget(result.budget);$('#ai-review').hidden=!result.after;$('#ai-before').innerHTML=result.before||'';$('#ai-after').innerHTML=result.after||'';$('#ai-summary').textContent=job.summary;$('#ai-progress').textContent=job.status==='running'?'Der Vorschlag wird erstellt. Du kannst das Fenster schließen; der Auftrag bleibt erhalten.':job.message||`${labels[job.status]||job.status}${job.chargedCents!==null?' · '+money(job.chargedCents)+' im Werkstattbudget verbucht':''}`;controls();}
 async function inspect(id){clearTimeout(timer);const seq=++serial;try{const result=await api(`/api/workshop/ai-design/${id}`);if(seq!==serial||!dialog.open)return;show(result);if(job.status==='running')timer=setTimeout(()=>inspect(id),1200);else await history();}catch(e){if(seq===serial&&dialog.open){error(e);$('#ai-progress').textContent='Verbindung unterbrochen. Den bestehenden Auftrag über „Bisherige KI-Aufträge“ prüfen; keine automatische Neuanforderung.';}}}
 function close(){if(!applying)dialog.close();}
 $('#ai-close').addEventListener('click',close);dialog.addEventListener('cancel',e=>{if(applying)e.preventDefault();});dialog.addEventListener('close',()=>{clearTimeout(timer);serial++;});
 for(const el of [$('#ai-instruction'),$('#ai-preserve-text'),$('#ai-preserve-photos')])el.addEventListener('input',()=>{requestId=null;});
 $('#ai-design-form').addEventListener('submit',async e=>{
  e.preventDefault();if(creating||applying||job?.status==='running'||!budget?.enabled||!e.currentTarget.reportValidity())return;
  if(state.dirty||state.record?.id!==target.productId||state.record?.revision!==target.revision){error(Error('Bitte zuerst den aktuellen Produktstand speichern und die KI-Gestaltung erneut öffnen.'));return;}
  const active=target;creating=true;$('#ai-error').hidden=true;controls();requestId??='air_'+crypto.randomUUID();
  try{const result=await api(`/api/workshop/products/${target.productId}/ai-design`,{method:'POST',body:{requestId,expectedRevision:target.revision,designId:target.designId,instruction:$('#ai-instruction').value,preserveText:$('#ai-preserve-text').checked,preservePhotos:$('#ai-preserve-photos').checked}});if(target!==active||!dialog.open)return;show(result);await history();await inspect(result.job.id);}
  catch(e){if(target===active&&dialog.open){error(e);await history().catch(()=>{});}}finally{creating=false;controls();}
 });
 $('#ai-cancel-job').addEventListener('click',async()=>{if(!job||applying)return;try{show(await api(`/api/workshop/ai-design/${job.id}/cancel`,{method:'POST',body:{}}));clearTimeout(timer);serial++;await history();}catch(e){error(e);}});
 $('#ai-apply').addEventListener('click',async()=>{
  if(!job||job.status!=='review'||applying)return;
  if(state.dirty||state.record?.id!==target.productId||state.record?.revision!==job.expectedRevision){error(Error('Der Produktstand wurde geändert. Bitte zuerst den Konflikt klären; der KI-Vorschlag bleibt erhalten.'));return;}
  applying=true;setBusy(true);controls();try{const result=await api(`/api/workshop/ai-design/${job.id}/apply`,{method:'POST',body:{expectedRevision:job.expectedRevision}});await onSaved(result.record);notify('KI-Vorschlag als neue Version gespeichert.');dialog.close();}catch(e){error(e);}finally{applying=false;setBusy(false);controls();}
 });
 $('#ai-jobs').addEventListener('click',e=>{const b=e.target.closest('[data-ai-job]');if(b)inspect(b.dataset.aiJob);});
 document.addEventListener('click',async e=>{
  const b=e.target.closest('[data-ai-design]');if(!b||state.busy||!state.record)return;
  if(state.dirty){notify('Bitte zuerst deine Änderungen speichern. Danach kann die KI auf diesem Stand arbeiten.','info');return;}
  const d=state.draft.config?.profile.designs.find(d=>d.id===b.dataset.aiDesign);if(!d||state.record.status==='archived')return;
  clearTimeout(timer);serial++;target={productId:state.record.id,revision:state.record.revision,designId:d.id};job=null;budget=null;requestId=null;$('#ai-review').hidden=true;$('#ai-error').hidden=true;$('#ai-progress').textContent='';$('#ai-connection').textContent='Verbindung wird geprüft …';$('#ai-budget').textContent='';$('#ai-jobs').textContent='';$('#ai-target').textContent=`${state.record.document.name} · ${d.name} · Stand ${target.revision}`;controls();dialog.showModal();$('#ai-instruction').focus();try{await history();}catch(e){error(e);}
 });
}
