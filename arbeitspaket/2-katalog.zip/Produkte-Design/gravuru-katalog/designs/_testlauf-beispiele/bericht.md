# Zerlegung in.pdf

19 Designs, Platte 190 × 80 mm, Quelle SHA-256 `f3436e0470ba3caa…`

| Design | Textfelder | Texte | Motive | Schriften | Hinweise |
| --- | --- | --- | --- | --- | --- |
| beispiele-01 | 2 | Nelkenstraße | 32 | 0 | Michroma | Hausnummer-Platzhalter 32 → 7 |
| beispiele-02 | 2 | 32 | Nelkenstraße | 0 | Michroma | Hausnummer-Platzhalter 32 → 12 |
| beispiele-03 | 0 |  | 1 |  | kein echter Text – Schrift vermutlich in Kurven umgewandelt (nicht bearbeitbar) |
| beispiele-04 | 3 | Familie Niemann | 32 | Nelkenstraße | 3 | Michroma | Hausnummer-Platzhalter 32 → 25 |
| beispiele-05 | 2 | Nelkenstraße | 32 | 2 | Michroma | Hausnummer-Platzhalter 32 → 48 |
| beispiele-06 | 3 | 32 | Familie | Niemann | 1 | Alex Brush, Cinzel | Hausnummer-Platzhalter 32 → 9 |
| beispiele-07 | 3 | 32 | Nelkenstraße | Familie Niemann | 1 | Cinzel, Great Vibes | Hausnummer-Platzhalter 32 → 16; 1 leere Textobjekte ignoriert |
| beispiele-08 | 3 | Nelkenstr. | 32 | Niemann | 1 | Homage, Rounded Elegance | Hausnummer-Platzhalter 32 → 31 |
| beispiele-09 | 2 | Nelkenstraße | 32 | 1 | Fjalla One | Schrift nicht in der Werkstatt: Fjalla One; Hausnummer-Platzhalter 32 → 5; 1 leere Textobjekte ignoriert |
| beispiele-10 | 3 | 32 | Familie | Niemann | 11 | Champagne&Limousines, Rounded Elegance | Hausnummer-Platzhalter 32 → 22; Schrift nicht in der Werkstatt: Champagne&Limousines |
| beispiele-11 | 3 | 32 | Familie | Niemann | 1 | Allura, MINIMALIST | Hausnummer-Platzhalter 32 → 64 |
| beispiele-12 | 4 | Herzlich Willkommen | in der | 32 | Nelkenstraße | 1 | Rounded Elegance | Hausnummer-Platzhalter 32 → 11 |
| beispiele-13 | 3 | Willkommen bei | Familie | Niemann | 1 | Ashley, Champagne&Limousines | Schrift nicht in der Werkstatt: Champagne&Limousines |
| beispiele-14 | 3 | Post für | Familie | Niemann | 2 | Cinzel, Rounded Elegance |  |
| beispiele-15 | 4 | 32 | Nelkenstr. | Familie | Niemann | 61 | Champagne&Limousines, Cinzel | Hausnummer-Platzhalter 32 → 19; Schrift nicht in der Werkstatt: Champagne&Limousines |
| beispiele-16 | 3 | Nelkenstr. 32 | Familie | Niemann | 19 | Champagne&Limousines, Great Vibes | Schrift nicht in der Werkstatt: Champagne&Limousines |
| beispiele-17 | 3 | 32 | Familie | Niemann | 1 | Champagne&Limousines, MINIMALIST | Hausnummer-Platzhalter 32 → 14; Schrift nicht in der Werkstatt: Champagne&Limousines |
| beispiele-18 | 2 | Familie Niemann | 32 | 1 | Allura, Rounded Elegance | Hausnummer-Platzhalter 32 → 43 |
| beispiele-19 | 3 | Familie Niemann | 32 | Nelkenstr. | 1 | Cinzel, Homage | Hausnummer-Platzhalter 32 → 8 |
