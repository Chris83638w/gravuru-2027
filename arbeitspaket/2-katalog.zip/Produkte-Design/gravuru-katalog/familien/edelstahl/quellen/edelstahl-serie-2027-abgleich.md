# Edelstahl-Serie 2027 → Familie steel-door-signs

Quelle: P:\00_Christopher\Edelstahlschilder 2027\Edelstahlschilder_final_CDR_2.xlsx (SHA-256 1c27161c5d77…), Zeichnung C:\Users\Christopher Koch\Downloads\EDELSTAHL_SCHILDER_NEUE_GROESSEN_v2.svg (SHA-256 d5a021410ec2…), 81 Zeilen.
**40 Grundpreise geändert, 5 Größen neu, 14 übersprungen, 4 offen.** Geschrieben.

## Grundpreise (Excel von Chris, Familie hatte Shop „Variante C“ vom 16.10.2026)

| Größe | alt | neu | Quelle | Hinweis |
| --- | --- | --- | --- | --- |
| GR-ES-RE-50X20-T15 | 8.99 € | 7.99 € | chris | ✓ CDR; Leerzeichen in Größe entfernt; Preis 7,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 8,99 € |
| GR-ES-RE-80X20-T15 | 8.99 € | 9.49 € | chris | ✓ CDR; Preis 9,49 € (Vorgabe Chris); Shop „Variante C“ hat noch 8,99 € |
| GR-ES-RE-120X52P5-T15 | 12.99 € | 17.99 € | excel | ✓ CDR; Gewicht aus Katalog |
| GR-ES-RE-400X175-T15 | 83.99 € | 87.99 € | excel | ✓ CDR; Gewicht aus Katalog |
| GR-ES-RE-90X30-T15 | 8.99 € | 9.99 € | chris | ✓ CDR; Preis 9,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 8,99 €; Gewicht aus Katalog |
| GR-ES-RE-150X50-T15 | 15.99 € | 16.99 € | excel | ✓ CDR; Gewicht aus Katalog |
| GR-ES-RE-180X60-T15 | 21.99 € | 22.99 € | excel | ✓ CDR; Gewicht aus Katalog |
| GR-ES-RE-240X80-T15 | 30.99 € | 32.99 € | excel | ✓ CDR; Preis 28,99 → 30,99 € (wie im Shop „Variante C“); Gewicht aus Katalog |
| GR-ES-RE-270X90-T15 | 36.99 € | 39.99 € | excel | ✓ CDR; Gewicht aus Katalog |
| GR-ES-RE-80X53P3-T15 | 9.99 € | 13.99 € | chris | ✓ CDR; Preis 13,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 9,99 € |
| GR-ES-RE-90X60-T15 | 10.99 € | 14.99 € | chris | ✓ CDR; Preis 14,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 10,99 € |
| GR-ES-RE-150X100-T15 | 29.99 € | 23.99 € | excel | ✓ CDR |
| GR-ES-RE-180X120-T15 | 32.99 € | 29.99 € | excel | ✓ CDR |
| GR-ES-RE-210X140-T15 | 43.99 € | 39.99 € | excel | ✓ CDR; Gewicht aus Katalog |
| GR-ES-RE-240X160-T15 | 45.99 € | 49.99 € | excel | ✓ CDR; Gewicht aus Katalog |
| GR-ES-RE-300X200-T15 | 69.99 € | 79.99 € | excel | ✓ CDR; Leerzeichen in Größe entfernt; 2 Löcher rechts/links mittig |
| GR-ES-RE-420X280-T15 | 139.99 € | 109.99 € | excel | Abstand 400 → 390; Gewicht aus Katalog |
| GR-ES-AB-80X53P3-T15 | 9.99 € | 13.99 € | chris | ✓ CDR; Preis 13,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 9,99 € |
| GR-ES-AB-90X60-T15 | 10.99 € | 14.99 € | chris | ✓ CDR; Preis 14,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 10,99 € |
| GR-ES-AB-150X100-T15 | 29.99 € | 23.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (29,99 €) |
| GR-ES-AB-180X120-T15 | 32.99 € | 29.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (32,99 €) |
| GR-ES-AB-210X140-T15 | 43.99 € | 39.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (43,99 €); Gewicht aus Katalog |
| GR-ES-AB-240X160-T15 | 45.99 € | 49.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (45,99 €); Gewicht aus Katalog |
| GR-ES-AB-300X200-T15 | 69.99 € | 79.99 € | excel | ✓ CDR; 2 Löcher rechts/links mittig; Preis aus Shop „Variante C“ (69,99 €) |
| GR-ES-AB-420X280-T15 | 139.99 € | 109.99 € | excel | Abstand 400 → 390; Preis aus Shop „Variante C“ (139,99 €); Gewicht aus Katalog |
| GR-ES-QU-80X80-T15 | 13.99 € | 14.99 € | chris | ✓ CDR; Preis 14,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 13,99 € |
| GR-ES-QU-100X100-T15 | 20.99 € | 19.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (20,99 €) |
| GR-ES-QU-120X120-T15 | 28.99 € | 22.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (28,99 €) |
| GR-ES-QU-160X160-T15 | 38.99 € | 34.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (38,99 €) |
| GR-ES-OV-90X60-T15 | 10.99 € | 14.99 € | chris | ✓ CDR; Preis 14,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 10,99 €; Gewicht aus Katalog |
| GR-ES-OV-150X100-T15 | 29.99 € | 23.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (29,99 €); Gewicht aus Katalog |
| GR-ES-OV-180X120-T15 | 32.99 € | 29.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (32,99 €); Gewicht aus Katalog |
| GR-ES-OV-210X140-T15 | 43.99 € | 39.99 € | excel | ✓ CDR; Leerzeichen in Größe entfernt; Preis aus Shop „Variante C“ (43,99 €); Gewicht aus Katalog |
| GR-ES-OV-240X160-T15 | 45.99 € | 49.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (45,99 €); Gewicht aus Katalog |
| GR-ES-OV-300X200-T15 | 69.99 € | 79.99 € | excel | Rand ergänzt: 8; Preis aus Shop „Variante C“ (69,99 €) |
| GR-ES-EL-150X50-T15 | 15.99 € | 16.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (15,99 €); Gewicht aus Katalog |
| GR-ES-EL-180X60-T15 | 21.99 € | 22.99 € | excel | ✓ CDR; Leerzeichen in Größe entfernt; Preis aus Shop „Variante C“ (21,99 €); Gewicht aus Katalog |
| GR-ES-OV-150X80-T15 | 24.99 € | 21.99 € | chris | ✓ CDR; Preis 21,99 € (Vorgabe Chris); Shop „Variante C“ hat noch 24,99 € |
| GR-ES-OV-225X120-T15 | 40.99 € | 33.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (40,99 €); Gewicht aus Katalog |
| GR-ES-OV-300X159P9-T15 | 56.99 € | 59.99 € | excel | ✓ CDR; Preis aus Shop „Variante C“ (56,99 €); Gewicht aus Katalog |

## Neue Größen

| Schlüssel | Serie | Grundpreis | Quelle | Hinweis |
| --- | --- | --- | --- | --- |
| GR-ES-R-65X65-T15 | TR-V2A-6,5x6,5 | 13.99 € | chris | ✓ CDR; Preis 13,99 € (Vorgabe Chris); Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop) |
| GR-ES-R-85X85-T15 | TR-V2A-8,5x8,5 | offen | vorschlag | ✓ CDR; Preis 15,99 € – Vorschlag Claude: Fläche 72 cm² → wie 15x5 (75 cm²); Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop) |
| GR-ES-R-120X120-T15 | TR-V2A-12x12 | offen | vorschlag | ✓ CDR; Gewicht berechnet; Preis 28,99 € – Vorschlag Claude: wie Quadrat 12x12; Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop) |
| GR-ES-R-160X160-T15 | TR-V2A-16x16 | offen | vorschlag | linkes Loch fehlte in der alten CDR – in v2 ergänzt (148 mm); Gewicht berechnet; Preis 38,99 € – Vorschlag Claude: wie Quadrat 16x16; Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop) |
| GR-ES-R-200X200-T15 | TR-V2A-20x20 | offen | vorschlag | ✓ CDR; Gewicht berechnet; Preis 47,99 € – Vorschlag Claude: wie Quadrat 20x20; Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop) |

## Übersprungen (Entscheidung nötig)

- TRT1-V2A-9x6 (Retro 1 (eckig), 9 × 6 cm, 1499 ct, chris): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT1-V2A-12x8 (Retro 1 (eckig), 12 × 8 cm, 1999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT1-V2A-15x10 (Retro 1 (eckig), 15 × 10 cm, 2399 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT1-V2A-18x12 (Retro 1 (eckig), 18 × 12 cm, 2999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT1-V2A-21x14 (Retro 1 (eckig), 21 × 14 cm, 3999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT1-V2A-24x16 (Retro 1 (eckig), 24 × 16 cm, 4999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT1-V2A-30x20 (Retro 1 (eckig), 30 × 20 cm, 7999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT2-V2A-9x6 (Retro 2 (geschwungen), 9 × 6 cm, 1499 ct, chris): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT2-V2A-12x8 (Retro 2 (geschwungen), 12 × 8 cm, 1999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT2-V2A-15x10 (Retro 2 (geschwungen), 15 × 10 cm, 2399 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT2-V2A-18x12 (Retro 2 (geschwungen), 18 × 12 cm, 2999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT2-V2A-21x14 (Retro 2 (geschwungen), 21 × 14 cm, 3999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT2-V2A-24x16 (Retro 2 (geschwungen), 24 × 16 cm, 4999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque
- TRT2-V2A-30x20 (Retro 2 (geschwungen), 30 × 20 cm, 7999 ct, vorschlag): freie Kontur – Familienschema v2 kennt nur rect/ellipse/plaque

## Offen

- GR-ES-R-85X85-T15: Grundpreis offen – Serie schlägt 1599 ct vor (✓ CDR; Preis 15,99 € – Vorschlag Claude: Fläche 72 cm² → wie 15x5 (75 cm²); Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop))
- GR-ES-R-120X120-T15: Grundpreis offen – Serie schlägt 2399 ct vor (✓ CDR; Gewicht berechnet; Preis 28,99 € – Vorschlag Claude: wie Quadrat 12x12; Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop))
- GR-ES-R-160X160-T15: Grundpreis offen – Serie schlägt 3499 ct vor (linkes Loch fehlte in der alten CDR – in v2 ergänzt (148 mm); Gewicht berechnet; Preis 38,99 € – Vorschlag Claude: wie Quadrat 16x16; Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop))
- GR-ES-R-200X200-T15: Grundpreis offen – Serie schlägt 4799 ct vor (✓ CDR; Gewicht berechnet; Preis 47,99 € – Vorschlag Claude: wie Quadrat 20x20; Optionen wie übrige Formen (Vorschlag, Rund noch nicht im Shop))

## Hinweise

- GR-ES-AB-300X200-T15: Gewicht Familie 706 g, Serie 707 g – unverändert
- GR-ES-OV-300X159P9-T15: Höhe 159,9 → 160 mm laut Zeichnung v2 (159.999 mm), Schlüssel bleibt

## Familie ohne Serienzeile (unverändert)

- GR-ES-EL-300X100-T15
