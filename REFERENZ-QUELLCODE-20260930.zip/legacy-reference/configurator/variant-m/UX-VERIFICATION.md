# Variante M – UX und Materialprofile, 24.09.2026

Basis: `272e82d6e3c55527149c0bf7d9c660bec0868c1b`, Aufgabenbranch
`feat/variante-m-profile-20260924`. Remote-Basis und Koordinationsbranch wurden vor
der Arbeit gelesen. Christopher gab den besprochenen Entwurf mit „Setze es um“ frei
und ergänzte anschließend Holz, Schiefer, Edelstahl und UV-Druck mit Farbwähler.

## Umgesetzt

- Die vorhandene M-Runtime bleibt Basis. Neue Oberfläche mit fünf Reitern,
  konsistenter grüner Farbgebung, großer Desktopvorschau und mobiler Vollbildansicht.
- Schriftwahl in eigenem Fenster: acht echte Vektorproben des ausgewählten Texts,
  Vor/Zurück, Übernehmen. Kein zweiter Dropdown und kein dauerhaft riesiges Schriftraster.
- Schriftgrößenwert mindestens 4 mm, Textgröße, Position und Drehung direkt bearbeitbar.
- Meine Inhalte zeigt sämtliche Designobjekte, auch Vorlage und Gestaltungslinien.
  Sichtbarkeit, Sperre, Verschieben, Skalieren, Löschen und Ebenensteuerung. Die
  technischen Klingel-/Bohrkonturen bleiben außerhalb der Kundenobjekte im Profil.
- Bestseller, Kategorien/Suche und mittiges Mehr anzeigen. Designs in kleinen Seiten.
- Fotos/Logos bis vier Dateien kombiniert, je sichtbarer Datei 999 Cent. JPG/PNG/WebP,
  maximal 15 MB und 40 Megapixel; Browserdekodierung zusätzlich zum MIME-Test.
  Keine privaten Dateien in Git, keine Netzwerkübertragung. Fotos als Platzhalter,
  Logos im Gravurfarbprofil bzw. in Originalfarben bei UV-Druck.
- Entwürfe bleiben in der geöffneten Sitzung. Kein Kunden-Dateidownload vor Kauf.
  Der Speichern-Dialog benennt die fehlende echte Kontoverbindung.
- Der vorhandene Assistent wird nur im Build abgeleitet. Lokale Hilfe, Vorschau,
  Vorlesen mit Gerätestimme sowie lokale Rückgängig-/Wiederholen-Aktionen. Kein
  erfundener KI-Endpunkt, keine automatische Übertragung von Chat/Design/Uploads.
- Aktuelle Profilfarben: Holz `#49301d`, Schiefer `#e8e9e5`, Edelstahl `#191919`,
  Acryl `#e1e4e5`; UV-Druck behält `color-print`, mit Farbwähler pro Element.
- Materialdemos tragen lokale Bindungen und keinen Verkaufspreis. Keine Produkt-IDs
  oder Preise aus Schiefer auf neue Holz-/Edelstahlartikel übernommen.

## Tatsächlich ausgeführt

| Prüfung | Ergebnis |
| --- | --- |
| Automatische Verträge | 22 Tests für Profile, Preise, Optionen, Geometrie, Entwürfe, Uploadregeln, Schriftseiten und Datenbereinigung erfolgreich |
| Bestehende Produktpipeline | Alle 20 Tests erfolgreich; keine Shopmutation |
| Ressourcen | Build prüft weiter 104 Originalressourcen; keine Inventar-Neuberechnung als Ersatz |
| Start | Lokaler Node-Server auf 127.0.0.1:8947, sechs auswählbare Prüfmodelle |
| Schriftfenster | 8 Proben, Auswahl Kalam und Übernahme getestet. Mobil 390 × 844: Fenster ca. 558 px hoch, scrollHeight 556 = clientHeight 556; kein inneres Scrollen erforderlich |
| Mindestwert | Im Browser 2 eingetragen; nach Übernahme 4 mm. Eingabereihenfolge gegenüber ursprünglichen M-Ereignissen korrigiert |
| Inhalte | Motiv aus/ein, sperren/entsperren, gesperrtes Löschen deaktiviert, Löschen geprüft |
| Gestaltungslinie | Strichdesign: Linie horizontal auf 82 mm verschoben, gelöscht, per Rückgängig wiederhergestellt |
| AOSU Preis | Enthaltenes Labrador-Motiv einmalig kostenlos; Basis 49,99 EUR. Verdeckte Bolzen: 55,98 EUR |
| Uploads | Unpersönliches bestehendes Repository-PNG als Testdatei: ein Foto + drei Logos, 69,95 EUR bei Schieferbasis 29,99; weitere Uploadschaltflächen deaktiviert |
| Profile im Browser | Holzobjekte `#49301d`, Edelstahl `#191919`, Acryl `#e1e4e5`, UV-Text auf `#e63329` geändert; Schiefer mit Foto gestartet |
| Foto aus | Holz-Demo ohne Foto-Schaltfläche; Logo weiterhin separat zulässig |
| Hilfe | Vorhandenes Assistentenfenster und passende Schrittanleitung mit aktueller Vorschau geöffnet. Hilfe zusätzlich innerhalb der großen Vorschau geöffnet. Vorlesen implementiert, Audiowiedergabe nicht abgehört |
| Desktop/Mobil | Sichtprüfung bei 1280 × 960 und 390 × 844. Schriftwahl und feste Preisleiste geprüft. Kein physisches Smartphone/Screenreader-Testlabor |
| Proportionen | Mobile Querformatvorschau: Element und SVG jeweils 261 × 174 px, Verhältnis 3:2 |
| Maßbeschriftung | Mobile AOSU-Vorschau: zwischen Unterkante des Maßlinienbereichs und Textoberkante 6 px Abstand |
| Fehler | Während der durchgeführten Aktionen keine erfassten Browser-Konsolenfehler |

Die Browserautomatisierung erwischte einmal ein geschütztes Leerzeichen in einer
Optionsbezeichnung nicht; Auswahl anschließend mit dem im DOM gelesenen Wert GWS
erfolgreich. Eine Tastaturaktion zum Scrollen auf body lief ins Timeout; sie ist kein
Touch-Scrollnachweis. Bedienung und Abstände wurden danach über sichtbare Elemente geprüft.

## Noch offen, ausdrücklich nicht als fertig freigegeben

1. Authentifizierte Kontospeicherung/-wiederherstellung mit privatem Uploadspeicher.
   Keine Speicherung in localStorage als vermeintliches Kundenkonto.
2. Serverprüfung von Profilrevision, Uploads, Aufpreisen, Varianten und Bestellbindung.
   Client-Metadaten sind kein Freibrief für kostenlose Motive oder bezahlte Downloads.
3. PNG erst nach serverseitig bestätigter Zahlung, kontobezogene kurzlebige Download-URL.
   Interne alte Exportfunktionen bleiben erhalten; neue Uploads/alle Konturebenen
   benötigen noch einen vollständigen Backend-/Fertigungsabgleich.
4. Persönlicher KI-Chat mit vorhandenem geschütztem Server. Aktuell lokale Direkthilfe.
5. Drei vor Implementierung gestellte Detailfragen ohne Antwort: Kundenkonto auch zum
   Kaufen verpflichtend? 4 mm als reale Buchstabenhöhe oder Schriftgrößenwert? Auch
   ausgeblendete Dateien berechnen? Im lokalen UI gilt vorläufig: numerische 4 mm,
   nur sichtbare Uploads berechnen; keine verbindliche Checkout-Kontopflicht gesetzt.
6. Alle Produktkonturen, naturgetreue Schieferkanten und Produktionsfarbabnahme bleiben
   eigene Aufgaben. Die Materialdemos sind technische Flächen, keine Produktfotos.
7. Vollständiger visueller Vergleich sämtlicher M-Altinteraktionen und echte mobile
   Touch-Gesten noch nicht abschließend nachgewiesen. Keine vollständige M-Freigabe.

Main, Shopify, Plesk, historische Referenzen und der fremde Ordner `products/` bleiben
unverändert. Dieser Stand ist eine lokale Umsetzung auf dem Aufgabenbranch, kein Deployment.

