/* Product-scoped launcher, including automatic completion of a new product transfer. */
(()=>{'use strict';
 async function mount(host){
  if(host.dataset.ready)return;host.dataset.ready='true';
  let binding;try{binding=JSON.parse(host.dataset.gravuruM?atob(host.dataset.gravuruM):host.querySelector('[data-gravuru-binding]').textContent);}catch{return;}
  if(!/^\d+$/.test(binding.productId))return;
  const area=document.querySelector('product-info')||document.querySelector('main')||document.body,info=area.querySelector('[id^="ProductInfo-"]')||area.querySelector('.product__info-container')||area;
  const button=host.querySelector('button');if(!button)return;
  const anchor=info.querySelector('.product__block--title')||info.querySelector('h1');if(anchor)anchor.after(host);
  const style=document.createElement('style');style.textContent='[data-gravuru-m]{display:block!important;margin:18px 0}[data-gravuru-m] button{width:100%;padding:16px;border:0;border-radius:7px;background:#246449;color:white;font-family:inherit;font-weight:600;font-size:17px;cursor:pointer}[data-gravuru-m] p{font-size:13px;margin:8px 0} .gravuru-m-dialog{margin:0;padding:0;width:100vw;max-width:100vw;height:100dvh;max-height:100dvh;border:0;background:#f7f7f3}.gravuru-m-dialog iframe{width:100%;height:calc(100% - 44px);border:0;display:block}.gravuru-m-back{height:44px;border:0;background:#edf4ee;color:#274a3d;padding:0 18px;font-size:16px;cursor:pointer}';document.head.append(style);
  for(const node of area.querySelectorAll('product-form,variant-selects,.shopify-payment-button,.product-form__buttons'))node.hidden=true;
  area.dataset.gravuruOwner=binding.productId;const hide=document.createElement('style');hide.textContent=['product-form','variant-selects','.shopify-payment-button','.product-form__buttons'].map(s=>'[data-gravuru-owner="'+binding.productId+'"] '+s).join(',')+'{display:none!important}';area.append(hide);
  host.hidden=false;
  if(!window.GravuruReadiness.isReady(binding)){
   button.disabled=true;button.textContent='Konfigurator wird vorbereitet …';
   host.querySelector('p').textContent='Die Produktübertragung läuft noch. Der Konfigurator erscheint hier automatisch, sobald er bereit ist.';
   try{binding=await window.GravuruReadiness.waitForBinding({initial:binding,readNext:async()=>{
    const url=new URL(location.href);url.hash='';url.searchParams.set('_gravuru_status',String(Date.now()));
    const response=await fetch(url,{credentials:'same-origin',cache:'no-store',headers:{Accept:'text/html'},signal:AbortSignal.timeout(15000)});
    if(!response.ok)throw Error('Produktstatus nicht erreichbar.');
    return window.GravuruReadiness.readBinding(new DOMParser().parseFromString(await response.text(),'text/html'),binding.productId);
   }});}catch(error){button.textContent='Konfigurator noch nicht bereit';host.querySelector('p').textContent=error.message;return;}
  }
  button.disabled=false;button.textContent='Jetzt personalisieren';host.querySelector('p').textContent='Design auswählen, Text gestalten und eigenes Foto hochladen.';
  const dialog=document.createElement('dialog');dialog.className='gravuru-m-dialog';dialog.setAttribute('aria-label','Produkt personalisieren');
  const close=document.createElement('button');close.className='gravuru-m-back';close.type='button';close.textContent='← Zurück zum Produkt';
  const frame=document.createElement('iframe');frame.title='Produkt personalisieren';const session=crypto.randomUUID(),origin=new URL(binding.url).origin;
  let loaded=false,busy=false;
  const open=()=>{if(!loaded){frame.src=binding.url+'#'+new URLSearchParams({origin:location.origin,session});loaded=true;}dialog.showModal();document.documentElement.style.overflow='hidden';};
  close.onclick=()=>dialog.close();dialog.addEventListener('close',()=>{document.documentElement.style.overflow='';button.focus();});dialog.append(close,frame);document.body.append(dialog);
  button.addEventListener('click',open);area.addEventListener('submit',e=>{if(e.target.matches('form[action*="/cart/add"]')&&!e.target.dataset.gravuruOrder){e.preventDefault();e.stopImmediatePropagation();open();}},true);
  window.addEventListener('message',async e=>{
   if(e.origin!==origin||e.source!==frame.contentWindow||e.data?.session!==session)return;
   const m=e.data;if(m.type==='gravuru-preview-close'){dialog.close();return;}if(m.type!=='gravuru-cart-submit'||busy)return;
   try{
    if(m.productId!=='gid://shopify/Product/'+binding.productId||!/^\d+$/.test(m.variantId)||!Number.isInteger(m.quantity)||m.quantity<1||m.quantity>99||!Number.isSafeInteger(m.priceCents)||!Array.isArray(m.assets)||m.assets.length<6||m.assets.length>14)throw Error('Die Produktzuordnung ist unvollständig.');
    busy=true;close.disabled=true;
    const response=await fetch('/variants/'+m.variantId+'.js',{credentials:'same-origin',cache:'no-store'});if(!response.ok)throw Error('Die gewählte Ausführung ist nicht erreichbar. Bitte erneut versuchen.');const variant=await response.json();
    if(!binding.variants.includes(String(variant.id))||variant.price!==m.baseVariantCents||!variant.available)throw Error('Die Ausführung oder ihr Preis wurde geändert. Bitte die Produktseite neu öffnen.');
    const form=document.createElement('form');form.method='POST';form.action='/cart/add';form.enctype='multipart/form-data';form.dataset.gravuruOrder='true';form.hidden=true;
    const field=(name,value)=>{const input=document.createElement('input');input.type='hidden';input.name=name;input.value=String(value);form.append(input);};
    field('id',m.variantId);field('quantity',m.quantity);field('return_to','/cart');
    for(const [name,value] of Object.entries(m.properties||{})){if(!/^[\w ÄÖÜäöüß×-]{1,80}$/.test(name)||typeof value!=='string'||value.length>1000)throw Error('Ungültige Gestaltungsangabe.');field('properties['+name+']',value);}
    let bytes=0;
    for(const asset of m.assets){if(!(asset.blob instanceof Blob)||!asset.blob.size||asset.blob.size>30*1024*1024||!['image/png','image/jpeg','image/webp','image/svg+xml','application/pdf','application/json'].includes(asset.blob.type)||!/^[\w ÄÖÜäöüß-]{1,80}$/.test(asset.property)||!/^[a-z0-9.-]{1,80}$/.test(asset.name))throw Error('Eine Gestaltungsdatei konnte nicht übertragen werden.');bytes+=asset.blob.size;const input=document.createElement('input');input.type='file';input.name='properties['+asset.property+']';const data=new DataTransfer();data.items.add(new File([asset.blob],asset.name,{type:asset.blob.type}));input.files=data.files;form.append(input);}
    if(bytes>100*1024*1024)throw Error('Die Bilder sind zusammen zu groß. Bitte kleinere Bilder verwenden.');document.body.append(form);form.submit();
   }catch(error){busy=false;close.disabled=false;frame.contentWindow.postMessage({type:'gravuru-cart-error',session,message:error.message},origin);}
  });
 }
 for(const host of document.querySelectorAll('[data-gravuru-m]'))mount(host).catch(()=>{const p=host.querySelector('p');if(p)p.textContent='Der Konfigurator konnte nicht geladen werden. Bitte die Produktseite erneut öffnen.';});
})();
