# Gedenktafeln Schiefer 22 × 14 – Tiere mit Foto (Master, Lieferform 2)

24 Designs aus Corel-PDFs (Chris, 20.10.2026, Ordner „D200-D249 Tier mit Foto“; D218 auf Wunsch von Chris weggelassen, `weglassen` in der Zuordnung), zerlegt mit `scripts/read-pdf-designs.py` (Repo gravuru-2027):

- **Texte bleiben Text** (Schrift, Größe, Grundlinie aus dem PDF; Felder `name`, `daten`, `spruch`).
- **Motive** hellgrau als Pfade, nach Nähe zu Motivgruppen zusammengefasst (`motiv-<n>`).
- **Fotofeld** `foto-1`: Musterfoto samt Button „Foto-Upload hier klicken“ als **ein Bild** (`foto-1.png`, freigestellt mit der PDF-Maske). Im Konfigurator Platzhalter; Klick lädt das Kundenfoto; **wird nicht graviert**.
- **Alle Elemente verschiebbar** (`design.json` `movable: true`).
- Zuordnung Hund/Katze: [`../gedenktafeln-22x14-zuordnung.json`](../gedenktafeln-22x14-zuordnung.json) (Themen `hundegedenktafeln`, `katzengedenktafeln`). Ersatzschriften: [`../../schriften/ersatz-gedenktafeln-22x14.json`](../../schriften/ersatz-gedenktafeln-22x14.json) – Originalschrift steht als `fontOriginal` im Design, Größe auf die Originalbreite angepasst.
- Linie [`linien/gedenktafeln-22x14-tiere.json`](../../linien/gedenktafeln-22x14-tiere.json): 6 Produkte (4 Hund, 2 Katze), je Produkt nur die Designs der Tierart, `startDesign` = Hauptbild = erstes Design im Konfigurator. Hauptbilder: `_hauptbilder/` (aus dem Konfigurator gerendert).

Neu erzeugen: `python3 -I scripts/read-pdf-designs.py --pdf <pdf-ordner> --out <katalog>/designs/gedenktafeln-22x14 --flach --katalog <katalog> --zuordnung <katalog>/designs/gedenktafeln-22x14-zuordnung.json --ersatz <katalog>/schriften/ersatz-gedenktafeln-22x14.json`

| D | Name | Tier | Schriften | Original (ersetzt) | Hinweis |
| --- | --- | --- | --- | --- | --- |
| D200 | Sheila | Katze | Lato, Stylish | Arial Italic |  |
| D204 | Wilson | Hund | Betsy Bailey, Poppins ExtraLight | Poppins ExtraLight |  |
| D207 | Susi | Hund | Baby Boho Script, Bellefair | – |  |
| D209 | Sammy | Hund | Poppins ExtraLight, Sunflower | Poppins ExtraLight |  |
| D210 | Charly | Hund | Cinzel, Homage | – |  |
| D212 | Daisy | Hund | Allura | – |  |
| D213 | Cooper | Hund | Great Vibes, Libre Baskerville | Georgia, Mondevilla | Blumenkranz und Kreis sind Teil des Fotobildes (kein eigenes Motiv) |
| D214 | Rocky | Hund | Bellefair, Hello Georgia | – |  |
| D215 | Drago | Hund | Cinzel | – |  |
| D216 | Bruno | Katze | Ashley, Poppins ExtraLight | Poppins ExtraLight | Platzhalter zeigt „Dein Foto“ statt Button „Foto-Upload hier klicken“ |
| D217 | Bella | Katze | Cormorant Garamond, Homage | Centaur |  |
| D220 | Emma | Hund | Allura, Cormorant Garamond | Centaur |  |
| D222 | Sunny | Hund | Arvo, Sweetie | – |  |
| D223 | Felix | Katze | Cormorant Garamond, Stylish | Centaur |  |
| D224 | Luna | Hund | Arvo, Desyrel | – |  |
| D225 | Minnie | Hund | Allura, Stylish, Tangerine | Tangerine Bold |  |
| D227 | Mogli | Katze | Allura, Dancing Script, Kaushan Script | Amarillo, Ampera |  |
| D228 | Marley | Hund | Betsy Bailey, Caviar Dreams | – |  |
| D229 | Sissi | Hund | Allura, Stylish | – |  |
| D231 | Hier | Hund | Great Vibes, Montserrat Light | Anthoni Signature, Champagne & Limousines |  |
| D233 | Josie | Hund | Cinzel, Homage | – |  |
| D234 | Bunny | Kleintier | Great Vibes, Montserrat Light | Champagne & Limousines | Kaninchen – in keinem der 6 Produkte (nur Hund/Katze) |
| D235 | Macho | Pferd | Homage, Montserrat Light | Champagne & Limousines | Pferd – in keinem der 6 Produkte (nur Hund/Katze) |
| D236 | Molly | Hund | Betsy Bailey | – |  |
