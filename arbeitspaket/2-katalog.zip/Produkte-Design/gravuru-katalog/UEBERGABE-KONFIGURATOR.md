# Übergabe an die Konfigurator-KI

22.10.2026. Vollständiger Code und Anleitung: [gravuru-2027 / Übergabe](https://github.com/Chris83638w/gravuru-2027/blob/task/katalog-struktur-20261022/docs/handoffs/2026-10-22-katalog-und-neuer-konfigurator.md).

- [struktur.json](struktur.json): elf aktive Linien, 48 Unterkategorien, fünf aktuelle Hauptprodukte, sechs ältere Parallelprodukte, ein archivierter Artikel.
- [Acrylserie](serien/acryl-tuerschilder-2027.json): 798 Varianten mit exakter Kontur und interner Konfiguration/Revision, gleiche SW/AN-Preise.
- [Edelstahlserie](serien/edelstahl-tuerschilder-2027.json): 399 lokale Varianten; keine behauptete Bindung an ältere Shopify-Artikel.
- [Hunde-Serie](serien/hunde-gedenktafeln-22x14-2027.json): vier aktuelle Produkte, je 48 Varianten, 16 Designs; neue bestätigte Bohrdaten in separater Familie.

Die Shopify Variant IDs für den Warenkorb sind live anhand der vollständigen SKU zu lesen. Interne cfg-IDs niemals als Shopify-Variantenkennungen verwenden. Shopifystatus ist ein datierter Abgleich der genannten Produkte, keine Vollinventur des Shops. Serverkorrekturen können neuer sein als das lokale Quellpaket.

Die Kundenanbindung wird mit dem neuen Konfigurator erledigt. Keine Produktveröffentlichung durch diesen Abgleich. README und KATALOG wurden aus den Quellen aktualisiert; ältere PDF-/Excel-Ausgaben bleiben historische Ableitungen bis zu einer bewussten Neuerzeugung.
