# Materialien

Materialdatenbank – je Material: Stärken, Verfahren, Farben, Gravurseite, Gravurfarbe, Lieferform/Zuschnitt. Noch nicht als Datei angelegt (geplant: `materialien/<material>.json`). Bekannt laut Nutzer:

| Material | Stärke | Verfahren | Bemerkung |
| --- | --- | --- | --- |
| Edelstahl | 1,5 mm | Gravur (dunkel) | Türschilder; Bohrbilder je Größe, Shop-Abgleich vollständig |
| Acrylglas schwarz / anthrazit (AA/AS) | 5 mm | Gravur von hinten (hell) | Namens-/Hausnummernschilder mit Abstandshaltern |
| Acrylglas schwarz satiniert + schwarz (S/S) | 3 mm + 3 mm | Front von vorn graviert | Rückplatte rundum 10 mm größer, Abstandsringe |
| Acrylglas Türschilder (schwarz/anthrazit) | 3 mm | Gravur | normale Bohrlöcher; Familie offen |
| Schiefer natur / premium | offen | Gravur (hell) | eingeschränkte Größen, eigene Lochlagen – Daten vom Nutzer ausstehend |
| Alu-Dibond weiß | 3 mm | **Druck** (vollflächig, Material als Hintergrund möglich) | eckig ohne Radius, Ø 4 mm; Randabstand/Preise offen |
