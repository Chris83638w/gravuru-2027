# Designs

> **Gestaltung:** Für alle Designs gilt der [Design-Master](DESIGN-MASTER.md) (Chris, 29.10.2026).

Ordner je Formatreihe, darin je Design ein Ordner nach **Lieferform 2** (`design.svg` mit Ebenen `text-<n>` als echtem Text, `motiv-<n>`, `deko-<n>`, `foto-<n>`; `design.json`; optional `original.png`). Eigene Motive des Nutzers, die mit einem Design kommen, bleiben in diesem Design-Ordner (`deko-`/`motiv-`-Ebenen) und werden nicht in die Bibliothek `motive/` übernommen. Master in der kleinsten Größe der Reihe; umgerechnete Größen entstehen per Skript (`transfer-design-series.py`, Auftrag #4) und liegen daneben.

`_testlauf-beispiele/`: 19 Hausnummern-/Namensschilder aus `Beispiele.pdf` (17.10.2026), automatisch zerlegt mit `scripts/split-corel-design-sheet.py`. **Nur Testlauf**: Plattenmaß 190 × 80 liegt in keiner Formatreihe, 8 Schriften fehlen, Design 03 hat Text in Kurven. Bericht: `bericht.md`, Übersicht mit echten Schriften: `uebersicht.png`.

## Zuordnung zu Unterkategorien (Themen)

Jedes Design trägt in `design.json` ein Feld `themes` mit einer oder mehreren Themen-Kennungen aus `themen.json` (z. B. `["kinderzimmerschilder", "gedenktafeln"]`). Dasselbe Design – etwa ein Standherz – kann so unter „Kinder“ und unter „Andenken“ erscheinen, ohne doppelt gepflegt zu werden. Der Shop zeigt je Unterkategorie die Designs ihres Themas; die Linie liefert die Platte.

## Alte Größen aus dem Bestand

Bestandsdesigns vom Server können in Größen vorliegen, die es nicht mehr gibt. Regel: Die Familie (aus der Zeichnung) bestimmt die gültigen Größen. Ein Bestandsdesign wird der Formatreihe zugeordnet, in die es passt (Seitenverhältnis ±1 %), und auf die gültigen Größen umgerechnet; passt es in keine Reihe, wird es als „alte Größe – nur Einpassen“ gekennzeichnet und nicht automatisch übernommen. Alte Größen werden nie als neue Größen in die Familie aufgenommen, ohne dass der Nutzer es sagt.

## Bestandsdesigns

Aus dem Server extrahierte Designs liegen je Linie unter `designs/bestand/<linie>/` (Zielgruppe/Unterkategorie/Schlüssel), mit Excel zur Korrektur. Erste Linie: [Gedenktafeln](bestand/gedenktafeln/README.md).

## Kennungen für Varianten (Paket M · Claude, 24.10.2026)

Grundlage ist die Corel-Konvention von gravuru: `<Linie/Form>-<Material>-<Format in cm>-D<n>`. **Dieselbe D-Nummer ist dasselbe Design** über Größen, Materialien und Formen eines Bogens hinweg. Beispiele: D1 „Rosenberg“ in `TRE-V2A-9x3`, `TO-V2A-9x6`, `TO-A-9x6` und `TAE-A-8x5`. D204 „Wilson“ in `GT-S-22x14` und `GT-S-30x20` (Bogen „D200-D249 Tier mit Foto“). Die Nummern gelten nur innerhalb eines Bogens: `GT-V2A-30x20` (Edelstahl-Gedenktafeln, D0–D11) und die Herz-Bögen zählen eigenständig.

1. **Nur anderes Material oder Verfahren: keine Variante.** Das Design bekommt nur ein weiteres Ziel (Familie). Der Materialcode der Kennung bleibt der des Master-Bogens. So gilt auch der Bestandsbogen `GT-S-30x20` heute für Schiefer, Acryl, Premium-Schiefer und Acryl + Edelstahl.
2. **Anderes Format:** Nur das Format wird getauscht, die D-Nummer bleibt: `GT-S-22x14-D204` → `GT-S-30x20-D204`. Vorbild ist `TO-V2A-21x14-D36` → `TO-V2A-9x6-D36`. Das Format steht in cm wie bei den Bögen. Gibt es den Bogen schon (Bestand oder Lieferform 2), gilt dessen Schreibweise. Sonst ganze Zahlen ohne Nachkommastellen und Dezimalpunkt (`12x10.5`).
3. **Andere Form oder Linie:** Das Kürzel kommt aus vorhandenen Bögen der Ziel-Linie bzw. -Form (`TO`, `TAE`, `TQ`, `GT` …), die D-Nummer bleibt. Gibt es kein Kürzel, wird nichts angelegt: Dashboard und Bericht zeigen „Kennung offen“, Claude entscheidet. Kürzel werden nicht erfunden.
4. **Kollisionen.** Geprüft wird gegen `designs/*/*/design.json`, alle `designs/*/index.json` und `designs/bestand/**/design.json`. Nie überschreiben, nie still umbenennen.
   - **Kennung frei:** Die Variante wird angelegt.
   - **Kennung in Lieferform 2 vorhanden:**
     - Ist es das Original selbst oder eine Variante desselben Originals (`varianteVon`), entsteht keine zweite Variante; das Ziel kommt zu diesem Design.
     - Hat das Design das Ziel schon, gilt „schon vorhanden“ mit Link.
     - Sonst „Kennung belegt“: beide Vorschauen nebeneinander. Das Team kann „Ziel zu <Kennung> hinzufügen“ wählen (nach der Konvention meist dasselbe Design). Sonst wird nichts angelegt und der Fall kommt in den Bericht.
   - **Kennung nur im Bestand vorhanden:** „Bestandsfassung vorhanden“. Nach der Konvention ist das die eigene Fassung des Teams in diesem Format, und sie ist besser als automatisches Einpassen. Es wird nichts automatisch angelegt, das Dashboard zeigt die Bestandsvorschau. Die Übernahme in Lieferform 2 ist ein eigenes Paket.
5. **Ordner und Felder:**
   - Ordner: Die Variante liegt im Reihenordner, dessen Designs dasselbe Präfix haben (alles vor `-D<n>`). Gibt es keinen, entsteht ein neuer Ordner nach dem Muster des Ursprungsordners, mit getauschtem Format in dessen Einheit (`gedenktafeln-22x14` → `gedenktafeln-30x20`; Edelstahl-Ordner in mm). Der Ordner bekommt eine `index.json`.
   - `katalog.series` = Ordnername, `katalog.key` = `<Ordner>-D<n>` (wie `build-design-reihe.py`).
   - Neues Feld `varianteVon`: Kennung des Originals.
   - `transfer.from`/`fromKey`: geometrische Quelle (beim automatischen Einpassen das Original), dazu `scale`, `offsetMm`, Abweichung in %, `decided` und `by` aus der Sitzung.

**Beispiel:** Schiefer-Hundedesign `GT-S-22x14-D204` (Wilson) → Edelstahl 30 × 20.
- Kennung `GT-S-30x20-D204`, Ordner `designs/gedenktafeln-30x20/`, `katalog.key` `gedenktafeln-30x20-D204`, `varianteVon` `GT-S-22x14-D204`.
- Edelstahl 30 × 20 (`gedenktafel-30x20-edelstahl`) ist ein Ziel dieses einen Designs. Weitere Ziele derselben Variante wären möglich (Acryl schwarz/anthrazit, Schiefer natur/premium 30 × 20), jeweils als Vorschlag, mit eigener Passung und eigener Freigabe.
- Nicht `GT-V2A-30x20-D204`: Das ist ein fremder Bogen mit eigener Nummerierung.
- Heute ist die Kennung im Bestand belegt (`bestand/gedenktafeln/Tiere/Allgemein/gravur-rechteck-D204`, Bogen „D200-D249 Tier mit Foto.cdr“). Das Dashboard zeigt deshalb „Bestandsfassung vorhanden“. Das gilt für alle 24 Designs in `gedenktafeln-22x14`.
- Auch die Formate der Edelstahl-Türschilder sind schon vollständig belegt (z. B. jede D-Nummer aus `TRE-V2A-9x3` gibt es auch in `TRE-V2A-8x2`).
- Automatisches Einpassen betrifft also vor allem neue Designs ohne Corel-Bogen.

## Familienziele und Freigaben (Paket M)

Ein Master hat eine geordnete Liste `ziele`. Jedes Ziel nennt eine vorhandene Familien-ID und seine eigene Freigabe; höchstens 100 Ziele, jede Familie einmal. Beispiel eines offenen Ziels:

```json
{
  "ziele": [
    { "familie": "gedenktafel-22x14-schiefer-natur", "freigabe": null }
  ]
}
```

`freigabe` ist `null` oder ein Objekt mit `status: "offen" | "freigegeben"`, `am` und `von`. Das Dashboard setzt Zeit und Urheber aus der Sitzung. Vorschläge bestätigen fügt ausschließlich offene Ziele hinzu. Vorschau, Schriftstatus und Passung werden je Ziel geprüft; eine Freigabe für Schiefer öffnet kein Edelstahlziel. Inhaltsänderungen am Master setzen alle Ziel-Freigaben auf offen zurück und protokollieren die vorherigen Werte. Themen werden mit Kennungen aus `themen.json` gepflegt.

Sobald `ziele` vorhanden ist, ist ausschließlich diese Liste maßgeblich, auch bei `[]`. Das frühere globale `freigabe` bleibt als historische Quelle erhalten und ist kein Ersatz für eine fehlende Ziel-Freigabe. Ohne `ziele` wird die eigene Familie anhand Material, Verfahren, Form, vorhandener Größen und Linienbindungen bestimmt. Mehrdeutige Fälle bleiben gesperrt.

Migration im Code-Repo: `node scripts/migrate-design-targets.mjs --katalog <pfad> --json <bericht-außerhalb-des-katalogs>`, danach ausdrücklich `--apply`. Der Dry-run zeigt Master, eindeutige/mehrdeutige Fälle und Freigabezähler. Apply ergänzt nur eindeutig bestimmte Ziele; jede JSON-/Protokolländerung ist atomar. Wiederholen ändert bereits migrierte Dateien nicht. In Paket M wurde Apply ausschließlich in einer privaten Testkopie ausgeführt; dieser Dokumentations-PR migriert keine echten Designs.

Ein Design erscheint in einer Linie über Ziele ihrer Familien. Import und Shop-Abgleich benötigen die Freigabe genau der betreffenden Familie sowie passende Form, Größe und Gestaltung. Diagnoseoptionen für nicht freigegebene Designs erlauben keinen schreibenden Import oder Shop-Abgleich.

Familien dürfen optional `outdoorSuitable: true | false | null` angeben. Fehlend oder null bedeutet **unbekannt**; aus Material oder Verfahren wird kein Wert abgeleitet. Das ersetzt keine Material-/Maschinenabnahme.
