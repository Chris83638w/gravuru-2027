import test from 'node:test';
import assert from 'node:assert/strict';
import {transferDraft,draftInput} from '../workbench-shopify.mjs';
const pack=()=>({product:{id:'P-unit-test',revision:1,data:{title:'Test',sku:'TEST',configurator:'variant-m'},designs:[{id:'D1',sha256:'abc'}]},config:{basePriceCents:2490,profile:{designs:[{id:'D1'}],geometry:{width:220,height:140},optionGroups:[{values:[{id:'OHNE',label:'Ohne',priceCents:0}]}]}},shopify:{handle:'gravuru-p-unit-test',description:'Beschreibung'}});
function mock(){let live=null,mutations=0;return {get live(){return live;},get mutations(){return mutations;},fetcher:async(url,options)=>{const {query,variables}=JSON.parse(options.body);let data;
 if(query.startsWith('query'))data={shop:{myshopifyDomain:'gravuru-design.myshopify.com',currencyCode:'EUR'},products:{nodes:live?[structuredClone(live)]:[],pageInfo:{hasNextPage:false}}};
 else if(query.includes('productSet')){mutations++;const i=variables.input;live={id:'gid://shopify/Product/1',handle:i.handle,title:i.title,descriptionHtml:i.descriptionHtml,status:i.status,seo:i.seo,tags:i.tags,collections:{nodes:i.collections.map(id=>({id})),pageInfo:{hasNextPage:false}},updatedAt:'r'+mutations,source:i.metafields?{value:i.metafields[0].value}:live.source,manifest:i.metafields?{value:i.metafields[1].value}:live.manifest,variants:{nodes:i.variants.map((v,j)=>({id:v.id||'gid://shopify/ProductVariant/'+j,sku:v.sku,price:v.price,selectedOptions:v.optionValues.map(o=>({name:o.optionName,value:o.name}))})),pageInfo:{hasNextPage:false}}};data={productSet:{product:{id:live.id},userErrors:[]}};}
 else{mutations++;live.manifest={value:variables.metafields[1].value};data={metafieldsSet:{userErrors:[]}};}
 return {ok:true,json:async()=>({data})};}};}
test('Shopify: Entwurf zurücklesen, wiederholte Übertragung überspringen, Ergänzungen mit gleicher Varianten-ID',async()=>{
 const p=pack(),m=mock(),journal=[];let result=await transferDraft(p,{token:'mock-only',fetcher:m.fetcher,journal:r=>journal.push(r)});
 assert.equal(result.state,'DRAFT_VERIFIED');assert.equal(m.mutations,1);const variant=m.live.variants.nodes[0].id;
 result=await transferDraft(p,{token:'mock-only',fetcher:m.fetcher,previous:result});assert.equal(m.mutations,1);
 p.product.revision++;p.product.designs.push({id:'D2',sha256:'def'});p.config.profile.designs.push({id:'D2'});
 result=await transferDraft(p,{token:'mock-only',fetcher:m.fetcher,previous:result});assert.equal(m.live.variants.nodes[0].id,variant);assert.equal(JSON.parse(m.live.manifest.value).designs.length,2);assert.equal(m.live.status,'DRAFT');assert.equal(m.mutations,3);
 m.live.title='Extern geändert';await assert.rejects(transferDraft(p,{token:'mock-only',fetcher:m.fetcher,previous:result}),/außerhalb/);assert.equal(m.mutations,3);
 m.live.status='ACTIVE';await assert.rejects(transferDraft(p,{token:'mock-only',fetcher:m.fetcher,previous:result}),/bereits aktiv/);
});
test('Shopify: Unklare Übertragung wird protokolliert, kein automatischer zweiter Schreibversuch',async()=>{
 const m=mock(),journal=[];let writes=0;await assert.rejects(transferDraft(pack(),{token:'mock-only',journal:r=>journal.push(r),fetcher:async(u,o)=>{if(JSON.parse(o.body).query.startsWith('mutation')){writes++;throw Error('timeout');}return m.fetcher(u,o);}}),/timeout/);
 assert.equal(writes,1);assert.equal(journal.at(-1).state,'NEEDS_RECONCILIATION');
});
test('Shopify: Ohne Werkstattzugang keine Anfrage; Preis und Veröffentlichung ausdrücklich festgelegt',async()=>{
 await assert.rejects(transferDraft(pack(),{fetcher:()=>assert.fail('Kein Zugriff erlaubt')}),/Verbindung/);
 const input=draftInput(pack());assert.equal(input.status,'DRAFT');assert.equal(input.variants[0].price,'24.90');assert.equal(JSON.parse(input.metafields[1].value).customerEnabled,false);
});
test('Shopify: SEO, Tags, Kategorie und neue URL werden am gleichen Entwurf aktualisiert',async()=>{
 const p=pack(),m=mock();p.product.data.seoTitle='Tiergedenktafel';p.product.data.seoDescription='Mit Foto gestalten';p.product.data.tags='Schiefer, Foto';p.shopify.collectionIds=['gid://shopify/Collection/3'];
 let result=await transferDraft(p,{token:'mock-only',fetcher:m.fetcher});const id=result.id;
 assert.equal(m.live.seo.title,'Tiergedenktafel');assert.deepEqual(m.live.tags,['Schiefer','Foto']);assert.equal(m.live.collections.nodes[0].id,p.shopify.collectionIds[0]);
 p.shopify.handle='tiergedenktafel-neue-url';p.product.revision++;result=await transferDraft(p,{token:'mock-only',fetcher:m.fetcher,previous:result});assert.equal(result.id,id);assert.equal(m.live.handle,p.shopify.handle);
});
