# Acrylic configurator visual check — 2026-09-30

Source visual truth: `C:/Users/Mikail Erdem/Downloads/ChatGPT-Bild 29. Sept. 2026, 09_43_55.png` (1086 × 1448).

Implementation: `http://127.0.0.1:8951/?model=acryl`.
Latest browser screenshot: `output/qa/eiche-v2.png`, 1280 × 720 desktop viewport, screenshot density 1.
State: 150 × 200 mm, original example photo, oak base, no wall mount, €24.98.
Product scene is approximately 393 × 524 CSS px. Compare the scene region, not the surrounding editor, against the source at the same aspect ratio. Source and browser capture were opened together in the same comparison tool input; no claim of pixel-level comparison is made.

## Findings

- **P1 — Name typography still differs.** FreestyleAcryl is heavier and more casual than the fine connected calligraphy in the source. This is visible in the full-view comparison and the vector print render `output/pdf/print-check.png`. Match a suitable licensed font before claiming a 1:1 reproduction. The sample raster is not being passed off as editable text.
- **P2 — Scene lighting differs.** The generated scene is warmer/darker and its tabletop horizon more pronounced than the supplied image. Acrylic reflections and six individual base images are photographic assets, but they are visualizations rather than verified photographs of the actual products. Further visual matching remains actionable for strict source fidelity.
- The lower text, pin and heart fit above the maximum insertion area. Current template bottom is at or above 190 mm on the normalized 200 mm plate, reserving 7 mm insertion plus 3 mm clearance. This deliberate composition adjustment follows the latest request that the entire design remain visible.

## Required fidelity surfaces

- Typography: editable vector text; name-font mismatch remains P1. Copy is preserved.
- Spacing: photo and heading/name hierarchy retained; lower elements deliberately raised. Safe-area bounds also apply to rotated customer elements. At 1280 × 720, the product itself fits above the fixed price bar. Small text is naturally reduced at preview scale.
- Colors: burgundy/neutral artwork retained; customer palette remains available. Background is warmer than reference (P2). CMYK export is separately validated, without asserting a production-approved ICC profile.
- Images: original photo source retained; six generated transparent base assets, clear acrylic edges and layered insertion geometry. No scene/base images enter the print file. Upload hint is now near the photo's lower edge so it no longer covers faces.
- Copy/content: source wording retained; upload hint and physical options are additions required for configurator use.

## Comparison history and evidence

1. Earlier base previews lacked convincing material appearance. All six were replaced with photographic generated assets and per-asset alignment anchors. Browser evidence: `output/qa/buche-v2.png`, `eiche-v2.png`, `nussbaum-v2.png`, `klar-v2.png`, `satiniert-v2.png`, `holz-flach-v2.png`.
2. Preview tools and insertion could obscure lower content. Tools were moved below the scene; template lower elements were raised and constrained to a safe area. All six captures show the slogan and heart above the base.
3. Upload hint previously covered faces. It was moved to the bottom of the photo; post-fix evidence is `output/qa/eiche-v2.png`. The other five captures predate only this hint-position change.
4. Full scene and focused lettering/print render were inspected; font and lighting differences remain unresolved as listed above. Print render uses an uploaded test photo, so its photo content is intentionally different and is not used to judge original-photo fidelity.

## Functional and print verification

- Browser: six base choices and their prices verified, both sizes checked, wall mount can be added independently. Photo replacement and text/preset-color changes exercised. Fixed template geometry is enforced in normalization and event handling.
- Console errors: checked; none recorded for current page.
- Native contract + acrylic tests: 19 passed; covers all 42 size/base/wall combinations and rotated-object safe area.
- Print regression tests: 2 passed, including both sizes, preserved image dimensions, CMYK photo XObjects, named RDG_WHITE, alpha retained for color/white, mirrored once per pass, CutContour and rejection of external content.
- Actual browser export: `output/pdf/Acrylglas-Roland-Rueckseite.pdf`, 200 × 266.7 mm. Image dimensions remain 1122 × 1402; color image DeviceCMYK; separate RDG_WHITE image; no RGB paint operators or inline RGB images. Rendered and inspected at `output/pdf/print-check.png`.
- Remaining verification: mobile layout, actual VersaWorks/material ICC proof and physical product dimensions/photographs. Shopify publication and GitHub upload are not completed by this local visual iteration.

## Implementation checklist

1. Match the source's fine calligraphic name font.
2. Match scene lighting more closely for strict 1:1 acceptance.
3. Verify with actual product photographs/dimensions and the production RIP/material profile.

final result: blocked

Reason: strict 1:1 visual fidelity still has the P1 font and P2 lighting differences above. The six-base visibility iteration and technical export checks are complete; this is not a production-release approval.
