# Quadratisch – Lieferform 2 (edelstahl-gravur-80x80)

Quelle: Bögen TQ-V2A-8x8, TQ-V2A-16x16, TQ-V2A-20x20 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**70 Designs**, davon 2 mit Produktionsfassung, 9 mit Themenvorschlag (unsicher), 3 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TQ-V2A-8x8 | GR-ES-QU-80X80-T15 | 67 | 6 | 2 | 2 |
| TQ-V2A-16x16 | GR-ES-QU-160X160-T15 | 70 | 3 | 0 | 3 |
| TQ-V2A-20x20 | GR-ES-QU-200X200-T15 | 70 | 3 | 1 | 1 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TQ-V2A-8x8-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 3 |  | Michroma |  |  |
| TQ-V2A-8x8-D2 | Zwei Zeilen, versetzt | D2 Schäfer | familienschilder, namensschilder |  | 3 |  | Michroma |  |  |
| TQ-V2A-8x8-D3 | Zwei Zeilen mit Trennlinie | D3 Beckmann | familienschilder, namensschilder |  | 3 |  | Michroma |  |  |
| TQ-V2A-8x8-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 3 |  | Michroma |  |  |
| TQ-V2A-8x8-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 3 |  | Michroma |  |  |
| TQ-V2A-8x8-D6 | Familie mit Anker und Spruch | D6 Erdmann | familienschilder, namensschilder |  | 3 |  | Ashley, Cinzel |  |  |
| TQ-V2A-8x8-D7 | Hier wohnt Familie mit Segelboot | D7 Fischer | familienschilder, namensschilder |  | 3 |  | Great Vibes, Montserrat Light |  |  |
| TQ-V2A-8x8-D9 | Vor- und Nachname mit Leuchtturm | D9 Groner | familienschilder, namensschilder |  | 3 |  | Homage, Montserrat Light |  |  |
| TQ-V2A-8x8-D10 | Zwei Vornamen und Nachname mit Laubbaum und Spruch | D10 Altmann | familienschilder, namensschilder |  | 3 |  | Comfortaa, Homage | ja |  |
| TQ-V2A-8x8-D12 | Herzlich Willkommen bei Familie mit Pusteblume | D12 Bohlmann | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Homage, Raleway |  |  |
| TQ-V2A-8x8-D14 | Familie mit Blumenwiese | D14 Wagner | familienschilder, namensschilder |  | 3 |  | Raleway, Welcome |  | Schrift ohne Datei im Katalog: Welcome |
| TQ-V2A-8x8-D15 | Herzlich Willkommen bei Familie mit Blumenwiese | D15 Familie Kuhlmann | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Ashley, Raleway | ja | motiv-1 um 0.0/-0.1 mm nach innen (stand über die Kante); Produktionsfassung: motiv-1 um 0.0/-0.1 mm nach innen (stand über die Kante); Produktionsfassung auch auf TQ-V2A-20x20 |
| TQ-V2A-8x8-D16 | Willkommen bei Vor- und Nachname mit Rose | D16 Laura | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Libre Baskerville |  |  |
| TQ-V2A-8x8-D17 | Willkommen bei Familie mit Blütenranke | D17 Schneider | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Cinzel, Italianno |  |  |
| TQ-V2A-8x8-D18 | Zwei Namen mit Pusteblume | D18 Felix Becker | familienschilder, namensschilder |  | 3 |  | Allura |  |  |
| TQ-V2A-8x8-D19 | Herzlich Willkommen bei Vor- und Nachname mit Rose | D19 Ursel Mayer | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Bellefair, Great Vibes |  |  |
| TQ-V2A-8x8-D20 | Familie mit Lebensbaum, Serifenschrift | D20 Familie | familienschilder, namensschilder |  | 3 |  | Libre Baskerville |  |  |
| TQ-V2A-8x8-D21 | Familie mit Sonne, Spruch und Vornamen | D21 Familie Lehmann | familienschilder, namensschilder |  | 3 |  | Comic Sans MS, Daniel |  | „Hier leben,…“: Zeilenabstand 8.4 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Schrift ohne Datei im Katalog: Comic Sans MS; Schrift ohne Datei im Katalog: Comic Sans MS |
| TQ-V2A-8x8-D22 | Familie mit Haus-Skizze und Spruch | D22 Schmittberger | familienschilder, namensschilder |  | 3 |  | Dancing Script, Libre Baskerville |  |  |
| TQ-V2A-8x8-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 3 |  | Rochester |  |  |
| TQ-V2A-8x8-D24 | Zuhause von Familie mit Haus und Herz | D24 Zuhause von | familienschilder, namensschilder |  | 3 |  | Homage, Raleway |  |  |
| TQ-V2A-8x8-D25 | Hier wohnt Familie mit Haus, Herz und Gründungsjahr | D25 Goldmann | familienschilder, namensschilder |  | 3 |  | Allura, Cinzel |  |  |
| TQ-V2A-8x8-D26 | Vor- und Nachname mit Glocke | D26 Schröder | familienschilder, namensschilder |  | 3 |  | Michroma |  |  |
| TQ-V2A-8x8-D27 | Zwei Vornamen und Nachname mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 3 |  | Michroma |  |  |
| TQ-V2A-8x8-D28 | Vor- und Nachname mit Fußball | D28 Schulze | familienschilder, namensschilder |  | 3 |  | Michroma |  |  |
| TQ-V2A-8x8-D29 | Herzlich Willkommen bei Familie mit Hundewelpe und Hundename | D29 Familie | familienschilder, namensschilder, hundeschilder, willkommensschilder |  | 3 |  | Ashley, Raleway |  | „Herzlich Willkommen…“: Zeilenabstand 7.7 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original) |
| TQ-V2A-8x8-D30 | Familie mit Hundekopf und Hundename | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 3 |  | Raleway |  |  |
| TQ-V2A-8x8-D31 | Zuhause von Familie mit Hund-Silhouette | D31 Familie Fischer | familienschilder, namensschilder, hundeschilder |  | 3 |  | Ashley, Cinzel |  |  |
| TQ-V2A-8x8-D32 | Familie mit Pfote und Hundename, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 3 |  | Homage, Michroma |  |  |
| TQ-V2A-8x8-D33 | Familie mit Pfoten und Hundename | D33 Wegner | familienschilder, namensschilder, hundeschilder |  | 3 |  | Raleway, Sweetie |  |  |
| TQ-V2A-8x8-D34 | Willkommen bei Familie mit Katze und Katzenname | D34 Willkommen bei | familienschilder, namensschilder, katzenschilder, willkommensschilder |  | 3 |  | Allura, Libre Baskerville |  |  |
| TQ-V2A-8x8-D35 | Hier leben – zwei Vornamen und Nachname mit Katze und Katzenname | D35 mit Oskar | familienschilder, namensschilder, katzenschilder |  | 3 |  | Michroma, Sweetie |  |  |
| TQ-V2A-8x8-D36 | Familie mit Schnörkel-Ornament und Spruch | D36 Familie Jäger | familienschilder, namensschilder |  | 3 |  | Libre Baskerville |  |  |
| TQ-V2A-8x8-D37 | Vor- und Nachname mit Unendlichkeitszeichen | D37 Hannah | familienschilder, namensschilder |  | 3 |  | Great Vibes |  |  |
| TQ-V2A-8x8-D38 | Zwei Namen mit Herzen, Schreibschrift | D38 Olivia Sander | familienschilder, namensschilder | hochzeitsschilder | 3 |  | Italianno |  |  |
| TQ-V2A-8x8-D39 | Herzlich Willkommen bei Familie mit Schnörkel-Herz | D39 Wilkommen | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Great Vibes |  |  |
| TQ-V2A-8x8-D40 | Willkommen bei Vor- und Nachname mit Eule | D40 Willkommen | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Dancing Script |  |  |
| TQ-V2A-8x8-D41 | Familie mit Kolibri | D41 Vogel | familienschilder, namensschilder |  | 3 |  | Ashley, Raleway |  |  |
| TQ-V2A-8x8-D42 | Vor- und Nachname mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 3 |  | Homage, Montserrat Light |  |  |
| TQ-V2A-8x8-D43 | Familie mit Taubenpaar, Serifenschrift | D43 Krone | familienschilder, namensschilder |  | 3 |  | Libre Baskerville |  |  |
| TQ-V2A-8x8-D44 | Zwei Vornamen und Nachname mit Vogelpaar im Herz | D44 Ruprecht | familienschilder, namensschilder | hochzeitsschilder | 3 |  | Allura, Raleway |  |  |
| TQ-V2A-8x8-D45 | Hier wohnt Vor- und Nachname mit Vogel | D45 König | familienschilder, namensschilder |  | 3 |  | Cinzel, Rochester |  |  |
| TQ-V2A-8x8-D46 | Familie mit Vogelpaar auf Zweig | D46 Vogel | familienschilder, namensschilder |  | 3 |  | Ashley, Raleway |  |  |
| TQ-V2A-8x8-D47 | Herzlich Willkommen bei Vor- und Nachname mit Vogel auf Zweig | D47 Carla | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Sweetie |  |  |
| TQ-V2A-8x8-D48 | Familie mit Schmetterlingen | D48 Schumacher | familienschilder, namensschilder |  | 3 |  | Allura, Raleway |  |  |
| TQ-V2A-8x8-D49 | Zwei Eulen auf Zweig (ohne Text) | D49 | familienschilder | namensschilder | 2 | GR-ES-QU-80X80-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TQ-V2A-8x8-D50 | Drei Eulen auf Zweig (ohne Text) | D50 | familienschilder | namensschilder | 2 | GR-ES-QU-80X80-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TQ-V2A-8x8-D51 | Vier Eulen auf Zweig (ohne Text) | D51 | familienschilder | namensschilder | 2 | GR-ES-QU-80X80-T15 |  |  | Bogen enthält nur das Motiv, keinen Text – im Konfigurator ergänzt der Kunde den Text; prüfen, ob so gewollt |
| TQ-V2A-8x8-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 3 |  | Ashley |  |  |
| TQ-V2A-8x8-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 3 |  | Ashley, Montserrat Light |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TQ-V2A-8x8-D54 | Familie mit Lilie, Serifenschrift | D54 Kampmann | familienschilder, namensschilder |  | 3 |  | Libre Baskerville |  |  |
| TQ-V2A-8x8-D55 | Hier wohnt Familie mit Schnörkel und Herz | D55 Hier wohnt | familienschilder, namensschilder |  | 3 |  | Allura, Montserrat Light |  |  |
| TQ-V2A-8x8-D56 | Familie mit Schnörkel-Ornament | D56 Schielmann | familienschilder, namensschilder |  | 3 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TQ-V2A-8x8-D57 | Familie mit Herz-Ranken-Ornament | D57 Pielstädt | familienschilder, namensschilder |  | 3 |  | Cinzel, Italianno |  |  |
| TQ-V2A-8x8-D58 | Familie mit Herzranke und Spruch | D58 Feldkamp | familienschilder, namensschilder |  | 3 |  | Comfortaa, Italianno |  |  |
| TQ-V2A-8x8-D59 | Zwei Vornamen und Nachname mit Rosen-Ornament | D59 Richter | familienschilder, namensschilder |  | 3 |  | Italianno |  |  |
| TQ-V2A-8x8-D60 | Familie mit Ornament und Spruch | D60 Willkommen bei uns | familienschilder, namensschilder, willkommensschilder |  | 3 |  | Allura, Cinzel |  |  |
| TQ-V2A-8x8-D61 | Zwei Vornamen und Nachname mit Zweigen und Herz | D61 Kampmann | familienschilder, namensschilder |  | 3 |  | Montserrat Light, Sweetie |  |  |
| TQ-V2A-8x8-D62 | Familie mit Schlüssel und Linie | D62 Schielmann | familienschilder, namensschilder |  | 3 |  | Fineliner Script, Raleway |  | Schrift ohne Datei im Katalog: Fineliner Script |
| TQ-V2A-8x8-D63 | Familie mit Wimpelkette, Serifenschrift | D63 Poller | familienschilder, namensschilder |  | 3 |  | Libre Baskerville |  |  |
| TQ-V2A-8x8-D64 | Familie mit Eck-Ornamenten, Serifenschrift | D64 Schötter | familienschilder, namensschilder |  | 3 |  | Cinzel |  |  |
| TQ-V2A-8x8-D65 | Hier wohnt Familie mit Vornamen und Herzen | D65 Familie Wegner | familienschilder, namensschilder |  | 3 |  | Homage, Raleway |  |  |
| TQ-V2A-8x8-D66 | Mr. & Mrs. mit Herzen und Nachname | D66 Westermann | familienschilder, namensschilder, hochzeitsschilder |  | 3 |  | Raleway |  |  |
| TQ-V2A-8x8-D67 | Initialen mit Ringen und Nachname | D67 Trautmann | familienschilder, namensschilder, hochzeitsschilder |  | 3 |  | Antic Slab, Great Vibes |  |  |
| TQ-V2A-8x8-D68 | Familie mit Pfeil nach links | D68 Reimer | familienschilder, namensschilder | hinweisschilder | 3 |  | Michroma |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TQ-V2A-8x8-D69 | Familie mit Pfeil nach rechts, Serifenschrift | D69 Maier | familienschilder, namensschilder | hinweisschilder | 3 |  | Libre Baskerville |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TQ-V2A-8x8-D70 | Zwei Vornamen und Nachname mit Pfeil nach oben | D70 Mükmann | familienschilder, namensschilder | hinweisschilder | 3 |  | Cinzel, Italianno |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TQ-V2A-8x8-D71 | Familie mit Pfeil nach unten | D71 Kleester | familienschilder, namensschilder | hinweisschilder | 3 |  | Comfortaa |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TQ-V2A-8x8-D72 | Achtung Videoüberwachung mit Familie | D72 Hübner | hinweisschilder, familienschilder |  | 3 |  | Antic Slab, Cinzel |  |  |
| TQ-V2A-8x8-D73 | Kein Eingang mit STOP | D73 Kein | hinweisschilder |  | 3 |  | Lato, Libre Baskerville |  |  |

## Abweichende Doppel (prüfen)

| Bogen | Doppel | von | grün |
| --- | --- | --- | --- |
| TQ-V2A-8x8 | TQ-V2A-8x8-D14-DOPPELT2 | TQ-V2A-8x8-D14 | ja |
| TQ-V2A-8x8 | TQ-V2A-8x8-D18-DOPPELT2 | TQ-V2A-8x8-D18 | ja |
| TQ-V2A-16x16 | TQ-V2A-16x16-D18-DOPPELT2 | TQ-V2A-16x16-D18 | ja |
| TQ-V2A-16x16 | TQ-V2A-16x16-D15-DOPPELT2 | TQ-V2A-16x16-D15 | ja |
| TQ-V2A-16x16 | TQ-V2A-16x16-D14-DOPPELT2 | TQ-V2A-16x16-D14 | ja |
| TQ-V2A-20x20 | TQ-V2A-20x20-D14-DOPPELT2 | TQ-V2A-20x20-D14 | ja |

## Schriften ohne Datei im Katalog

- Comic Sans MS: 1 Designs (TQ-V2A-8x8-D21)
- Fineliner Script: 2 Designs (TQ-V2A-8x8-D56, TQ-V2A-8x8-D62)
- Welcome: 1 Designs (TQ-V2A-8x8-D14)
