# Foto-Upload und Abschlussleiste – 27.09.2026

Basis Aufgabenbranch `task/konfigurator-bedienung-20260927`, Remote-HEAD vor Sicherung `d8429a4635e09b08b3932af1b7d408216dabd422`. Lokale gezielte Quellkopie ohne Git; vorhandene Originale erhalten.

- Interaktive Freistell-/Radierwerkzeuge entfernt. Zuschnitt, Drehen, Spiegeln und Undo bleiben; Ja/Nein für die spätere Freistellung durch Gravuru bleibt erhalten.
- Nach erfolgreichem Upload oder Ersetzen wird die zugehörige Fotokarte fokussiert und sichtbar gescrollt; bei mehreren Dateien einmal zur letzten erfolgreichen Datei. Reduzierte Bewegung wird berücksichtigt.
- Abschlussdialog: eigener scrollbarer Inhalt, Preis und Abschlussbuttons bleiben unten sichtbar. Farben unverändert bis zur gewünschten Screenshotabstimmung. Echter Warenkorb weiterhin nicht angeschlossen und ehrlich deaktiviert.
- Syntaxprüfungen bestanden; 28 bestehende Contract-/UX-/Bildverarbeitungstests bestanden. Browser: Upload auf Desktop, Drehen/Übernehmen, Ersetzen bei 390 × 844 und Sprung zur Fotokarte geprüft. Nur vorhandene Repository-Testbilder verwendet. Abschlussdialog bei 390 × 844 visuell geprüft: Preis und Buttons trotz überlangem Inhalt sichtbar. Kein echter Geräte-/Checkouttest.

## Verbindliche Anschlussentscheidungen und vorhandener Server

Nutzer bestätigt echten Shopify-Warenkorb, 15 % nur auf das zweite Exemplar derselben Gestaltung und Nutzung des bestehenden Plesk-Servers. Ausdrücklich keinen zweiten Server anlegen. Rabattbasis/Aufpreise und Mengen über zwei sind noch nicht umgesetzt. Keine Rabatt- oder Checkoutfreigabe behaupten.

Plesk am 27.09. nach Nutzeranmeldung nur gelesen: Domain `gravuru-designwerkstatt.de`, Node 24.21.0 aktiviert, production, Anwendungsstamm `/gravuru-werkstatt`, Dokumentenstamm `/gravuru-werkstatt/webroot`, Start `app.cjs`. Startdatei verlangt Teamanmeldung/HTTPS und vorhandene SQLite-Daten außerhalb des öffentlichen Webroots; startet `scripts/server.cjs`. Keine Secrets gelesen, kein Neustart, keine Installation oder Serveränderung.

Live-Serverquelle enthält bereits `product-entry.cjs` vor den normalen Werkstattrouten. Dieser bindet die bestehende Produktanlage über `private/product-runtime/current.json` und `automation/product-pipeline/shopify-workbench-server.mjs` ein; unter anderem `/produktanlage`, `/produkt-konfigurator`, `/api/product-workbench` und `/api/product-session`. `customer-orders.cjs`, Backupmodule und Produktprofile sind bereits vorhanden. Vorhandene Werkstattseite hatte beim Öffnen der Betriebsseite erneut eine Anmeldung verlangt; angezeigte ältere Dashboardzahlen sind deshalb kein frisch verifizierter Datenbestand.

Aktueller GitHub-Stand der Produktanlage gelesen: `feat/variante-m-profile-20260924`, `9824e81d647ea538be257fdd3696d7de120ea0c5`, `PROJECT/GEMEINSAMER-STAND.md` und `PROJECT/UEBERGABE-PRODUKTANLAGE-2026-09-27.md`. Dort ist die bestehende Shopify-App mit Serverziel `/produktanlage.html`, privater Produktablage und erfolgreichem separatem Shopify-DRAFT dokumentiert. Der zentrale Wegweiser war in diesem Punkt älter. Fremde Tests nicht erneut durchgeführt; öffentliche Kundenruntime, Warenkorb, Bestellung und Produktion sind auch dort ausdrücklich offen.

Read-only Shopify-Abgleich: Shop `gravuru-design.myshopify.com`, AOSU Pro Produkt `16124413084028` vorhanden. Lokale AOSU-Prüffassung hat weiterhin null-Variantenbindungen; Preis-/Foto-/Motiv-Aufschläge und gesicherte Bestellübergabe müssen vollständig verbunden werden. Keine Shopify-Mutation.

Nächster begrenzter Schritt: auf dem vorhandenen Produktserver die konkrete öffentliche Kunden-/Foto-/Bestellschnittstelle und aktuelle Quellbasis abgleichen, dann kompatible Erweiterung planen. Keine ältere komplette Quellkopie über die inzwischen weiterentwickelte Serverruntime installieren. Die SSH-Einrichtung der Übergabe gehört zum anderen Rechner; auf diesem Rechner nicht als verfügbar voraussetzen. Main, Shopify, Plesk und öffentliche Netlify-Seite unverändert; lokale UI-Korrekturen auf Aufgabenbranch sichern, kein Merge.

---

# Entscheidung 27.09.2026: Freistellung durch Gravuru, ohne Photoroom

Nutzer hat einen echten Photoroom-Test selbst durchgeführt und den Original-/Ergebnisvergleich im Chat gezeigt (Hund, Sandbox-Wasserzeichen). Ergebnis genügt ihm nicht; ausdrückliche Entscheidung: Photoroom weglassen. Der separate lokale Testserver auf Port 8965 wurde beendet und die Nichterreichbarkeit geprüft. Damit sind die nur dort im RAM gehaltenen Schlüssel-/Cachewerte nicht mehr im laufenden Server verfügbar. Keine Anbieter-Kontolöschung oder Schlüsselwiderruf durch Codex.

Aktueller Kundenablauf: „Sollen wir dein Foto freistellen?“ – „Ja, Hintergrund entfernen“ / „Nein, Hintergrund behalten“. Freistellung inklusive, persönliche Prüfung und bei Bedarf manuelle Nachbearbeitung durch Gravuru vor Fertigung; Vorschau bleibt Original. Keine pauschale Behauptung „besser als jede KI“. Bestehende Auswahlwerte/default remove, Entwurfsspeicherung und Abschlussübersicht bleiben erhalten. Echte Bestell-/Fertigungsübertragung weiterhin offen. Photoroom ist nicht im Konfigurator eingebunden und wird nicht weiter integriert. Frühere Testquellen bleiben als historische Arbeit erhalten; Startanleitung unten ist kein Auftrag zum Neustart.

Basis remote 3036a6759146b90f00149e0120d4405fb2e6404a, lokale completion.mjs vor Änderung identisch mit GitHub. Syntaxprüfung und 25 vorhandene contract-/ux-Tests bestanden. Neuer Hinweis vom laufenden Konfigurator auf Port 8963 geliefert. Kein erneuter Foto-Browserdurchlauf für diese Textänderung. Kein Merge oder Deployment, Main/Shopify/Plesk unverändert.

---

# Auswahl und Gestaltungsabschluss – 27.09.2026

## Basis und Grenzen
Aufgabenbranch `task/konfigurator-bedienung-20260927`; bestätigte Basis `541327158f6bfd24d2fa522cec1691f15c9df2eb`, Reservierungscommit `59592a3c62bc8d110630b88ecb35a4ab906e6910`. Lokale gezielte Quellkopie ohne `.git`, keine vollständige neue Repository-Inventur. Nur dieser Aufgabenbereich geändert; kein Merge, keine Veröffentlichung, keine Shopify-/Plesk-Änderung.

## Umsetzung
- Einheitliche sichtbare Haken bei aktiven Design-, Farb-, Schrift-, Kategorie- und Befestigungs-Auswahlkacheln; keine Haken auf reinen Aktionsbuttons.
- Befestigungskacheln mit einfachen UI-Icons, Bezeichnung und vorhandenen Aufpreisen; bestehende Auswahl-/Preislogik bleibt zuständig.
- Lupe mit Pluszeichen für Designvorschau.
- Mobile Mehrfachtextauswahl kompakter; Foto-/Logo-Upload flacher, hochgeladene Bilder über volle Panelbreite.
- Bestseller-Motive direkt offen: vier Kacheln, Mehr/Weniger anzeigen ohne innere Scrollsperre; daneben Zugang zu allen Motiven.
- Pro Foto Auswahl `uxPhotoBackground: remove | keep`, standardmäßig `remove`. Original unverändert, Auswahl bleibt bei Dateiersatz, Duplikation/Designwechsel über die bestehende Objektübernahme und im bereinigten Entwurf erhalten. Validator erlaubt nur gültige Werte für Foto-Uploads. Zwei neue Tests für Entwurfsspeicherung und Validierung.
- Nutzer hat bestätigt: Freistellung im Fotopreis enthalten, Vorschau zunächst Original, Aufbereitung vor Fertigung. Entsprechende kundenverständliche Hinweise eingebaut.
- „Gestaltung fertig – weiter“ führt zur Übersicht mit unveränderter Produktvorschau, Ausführung/Befestigung, Texten, Foto-Aufbereitung, Menge und Gesamtpreis. Vorhandene Überlagerungs-/mechanische Hinweise bleiben bedienbar und ignorierbar. Weiter bearbeiten führt zurück. Echter Warenkorb weiterhin deaktiviert und ausdrücklich als noch nicht verbunden gekennzeichnet.

## Prüfungen und Start
```sh
node configurator/variant-m/server.mjs --port=8963
node --test configurator/variant-m/contract.test.mjs configurator/variant-m/ux.test.mjs configurator/variant-m/image-processing.test.mjs configurator/variant-m/usability.test.mjs configurator/variant-m/customer-tools.test.mjs configurator/variant-m/workflow.test.mjs automation/product-pipeline/tests/pipeline.test.mjs
node configurator/variant-m/export-public.mjs
```
65 Tests bestanden. Lokaler Export: 102 Dateien, 28 Module, 104 Originalressourcen anhand vorhandener Prüfsummen verifiziert. Kein Upload dieses Exports.
Browser: Befestigung Verdeckte Bolzen +5,99 ergibt 55,98; Abschluss zeigt diese Auswahl. Foto-Testupload +9,99 ergibt 65,97; Wechsel auf Hintergrund behalten erscheint korrekt in der Abschlussübersicht. Bestseller zeigen vier, erweitert acht Kacheln. Desktop-Übersicht und mobiler Upload bei 390 × 844 visuell geprüft. Keine Browserfehler im korrigierten Stand. Ein anfänglicher MutationObserver-Konflikt wurde behoben: Haken ändern hidden nur bei tatsächlicher Zustandsänderung, damit die Designlistenbeobachtung nicht dauerhaft neu ausgelöst wird.

## Photoroom – Recherche, noch keine Anbindung
Nutzer fragte während der Umsetzung nach Photoroom. Offizielle Dokumentation gelesen:
- https://docs.photoroom.com/remove-background-api-basic-plan/quickstart-guide
- https://docs.photoroom.com/remove-background-api-basic-plan/pricing
- https://www.photoroom.com/api/pricing
Die Remove Background API nennt 0,02 USD pro Aufruf; konkrete Vertrags-/Tarifbedingungen vor Aktivierung prüfen. Empfohlener Folgeschritt: Qualitätsvergleich mit ausgewählten Testfotos, danach separate serverseitige Anbindung mit erhaltenem Original, wiederverwendeter Freistellung und Kostenbegrenzung. Keine Zugangsdaten eingerichtet, keine Fotos an Photoroom übertragen und keine kostenpflichtigen Aufrufe ausgeführt.

## Offener nächster Schritt
Nutzerabnahme der UI. Photoroom-Qualitätstest und echte Warenkorb-/Fertigungsanbindung sind separate Schritte. Die neue Fotoanweisung ist im Entwurfsformat vorbereitet; eine erfolgte Übertragung in eine produktive Bestellung wird nicht behauptet. Echte iOS-/Android-Geräte und sämtliche Produkt-/Schriftkombinationen sind noch nicht vollständig getestet.
