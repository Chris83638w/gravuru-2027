| Spalte | Zeile | Platte mm | Form | Löcher | Lage | Randabstand mm | Rückplatte mm |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | 150 × 100 | Eckig | 2 | left-right | 10.0 | 170 × 120 |
| 1 | 2 | 180 × 120 | Eckig | 2 | left-right | 10.0 | 200 × 140 |
| 1 | 3 | 240 × 160 | Eckig | 2 | left-right | 15.0 | 260 × 180 |
| 1 | 4 | 300 × 200 | Eckig | 2 | left-right | 15.0 | 320 × 220 |
| 1 | 5 | 360 × 240 | Eckig | 2 | left-right | 15.0 | 380 × 260 |
| 1 | 6 | 420 × 280 | Eckig | 2 | left-right | 15.0 | 440 × 300 |
| 2 | 1 | 150 × 100 | Eckig | 4 | corners | 10.0 | 170 × 120 |
| 2 | 2 | 180 × 120 | Eckig | 4 | corners | 10.0 | 200 × 140 |
| 2 | 3 | 240 × 160 | Eckig | 4 | corners | 15.0 | 260 × 180 |
| 2 | 4 | 300 × 200 | Eckig | 4 | corners | 15.0 | 320 × 220 |
| 2 | 5 | 360 × 240 | Eckig | 4 | corners | 15.0 | 380 × 260 |
| 2 | 6 | 420 × 280 | Eckig | 4 | corners | 15.0 | 440 × 300 |
| 3 | 1 | 150 × 80 | Oval | 2 | left-right | 10.0 | 170 × 100 |
| 3 | 2 | 225 × 120 | Oval | 2 | left-right | 10.0 | 245 × 140 |
| 3 | 3 | 300 × 160 | Oval | 2 | left-right | 15.0 | 320 × 180 |
| 4 | 1 | 150 × 100 | Oval | 2 | left-right | 10.0 | 170 × 120 |
| 4 | 2 | 180 × 120 | Oval | 2 | left-right | 10.0 | 200 × 140 |
| 4 | 3 | 210 × 140 | Oval | 2 | left-right | 15.0 | 230 × 160 |
| 4 | 4 | 240 × 160 | Oval | 2 | left-right | 15.0 | 260 × 180 |
| 4 | 5 | 300 × 200 | Oval | 2 | left-right | 15.0 | 320 × 220 |
| 5 | 1 | 210 × 70 | Eckig | 2 | left-right | 10.0 | 230 × 90 |
| 5 | 2 | 240 × 70 | Eckig | 2 | left-right | 10.0 | 260 × 90 |
| 5 | 3 | 270 × 90 | Eckig | 2 | left-right | 10.0 | 290 × 110 |
| 5 | 4 | 360 × 120 | Eckig | 2 | left-right | 15.0 | 380 × 140 |
| 5 | 5 | 450 × 150 | Eckig | 2 | left-right | 15.0 | 470 × 170 |
| 6 | 1 | 160 × 160 | Eckig | 2 | left-right | 10.0 | 180 × 180 |
| 6 | 2 | 200 × 200 | Eckig | 2 | left-right | 10.0 | 220 × 220 |
| 6 | 3 | 260 × 260 | Eckig | 2 | left-right | 15.0 | 280 × 280 |
| 6 | 4 | 300 × 300 | Eckig | 2 | left-right | 15.0 | 320 × 320 |
| 7 | 1 | 160 × 160 | Eckig | 4 | corners | 10.0 | 180 × 180 |
| 7 | 2 | 200 × 200 | Eckig | 4 | corners | 10.0 | 220 × 220 |
| 7 | 3 | 260 × 260 | Eckig | 4 | corners | 15.0 | 280 × 280 |
| 7 | 4 | 300 × 300 | Eckig | 4 | corners | 15.0 | 320 × 320 |
| 8 | 1 | 180 × 120 | Eingezogene Ecken R11.6 | 2 | left-right | 10.0 | 200 × 140 R12.9 |
| 8 | 2 | 210 × 140 | Eingezogene Ecken R13.5 | 2 | left-right | 10.0 | 230 × 160 R14.8 |
| 8 | 3 | 240 × 160 | Eingezogene Ecken R15.5 | 2 | left-right | 10.0 | 260 × 180 R16.8 |
| 8 | 4 | 300 × 200 | Eingezogene Ecken R19.3 | 2 | left-right | 15.0 | 320 × 220 R20.6 |
