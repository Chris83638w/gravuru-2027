# Entscheidung 27.09.2026: Freistellung durch Gravuru, ohne Photoroom

Nutzer hat einen echten Photoroom-Test selbst durchgeführt und den Original-/Ergebnisvergleich im Chat gezeigt (Hund, Sandbox-Wasserzeichen). Ergebnis genügt ihm nicht; ausdrückliche Entscheidung: Photoroom weglassen. Der separate lokale Testserver auf Port 8965 wurde beendet und die Nichterreichbarkeit geprüft. Damit sind die nur dort im RAM gehaltenen Schlüssel-/Cachewerte nicht mehr im laufenden Server verfügbar. Keine Anbieter-Kontolöschung oder Schlüsselwiderruf durch Codex.

Aktueller Kundenablauf: „Sollen wir dein Foto freistellen?“ – „Ja, Hintergrund entfernen“ / „Nein, Hintergrund behalten“. Freistellung inklusive, persönliche Prüfung und bei Bedarf manuelle Nachbearbeitung durch Gravuru vor Fertigung; Vorschau bleibt Original. Keine pauschale Behauptung „besser als jede KI“. Bestehende Auswahlwerte/default remove, Entwurfsspeicherung und Abschlussübersicht bleiben erhalten. Echte Bestell-/Fertigungsübertragung weiterhin offen. Photoroom ist nicht im Konfigurator eingebunden und wird nicht weiter integriert. Frühere Testquellen bleiben als historische Arbeit erhalten; Startanleitung unten ist kein Auftrag zum Neustart.

Basis remote 3036a6759146b90f00149e0120d4405fb2e6404a, lokale completion.mjs vor Änderung identisch mit GitHub. Syntaxprüfung und 25 vorhandene contract-/ux-Tests bestanden. Neuer Hinweis vom laufenden Konfigurator auf Port 8963 geliefert. Kein erneuter Foto-Browserdurchlauf für diese Textänderung. Kein Merge oder Deployment, Main/Shopify/Plesk unverändert.

---

# Photoroom: separater lokaler Sandbox-Test

27.09.2026, Codex. Nutzerauftrag: Photoroom ausprobieren, zuerst Testzugang einrichten.
Basis: task/konfigurator-bedienung-20260927 bei f5e62e163a67abc944221a1eb9d6f333f849ded3; Reservierung f674615431bbe18a22fb05270e0d6aa5b8009d74.
Lokale gezielte Quellkopie ohne .git; bestehende Quellen unverändert erhalten. Keine Integration in Koordinationsbranch/main, kein Deployment, keine Shopify-/Plesk-Änderung.

## Start / Wiederherstellung

Node.js 24; keine zusätzlichen Pakete erforderlich. Diese sechs photoroom-Dateien reichen für den separaten Testserver. Vom Repository-Stamm:

```powershell
node configurator/variant-m/photoroom-test-server.mjs --port=8965
```

http://127.0.0.1:8965/ öffnen. Neuen Schlüssel selbst in das Passwortfeld einfügen, „Testzugang hinterlegen“ wählen. Erst die Verarbeitung eines Testfotos validiert den Schlüssel bei Photoroom. Netzwerkzugriff auf https://image-api.photoroom.com ist erforderlich. Lokale Sitzung wurde nach Netzwerkfreigabe neu gestartet; anonymer Abruf /openapi HTTP 200. Das ist noch kein authentifizierter API-Nachweis.

Schlüssel nur im Arbeitsspeicher des lokalen Prozesses, kein Schreiben in Dateien, localStorage oder Protokolle. Der Server liefert den Schlüssel nie zurück. Nach Neustart neu eingeben; mit „Zugang entfernen“ aus dem aktiven Serverzustand entfernen. Nicht im Chat/Repository/URL ablegen. Ein im Chat genannter alter Schlüssel ist nicht übernommen worden; Widerruf erfolgt durch den Nutzer im Anbieter-Dashboard.

Eigene Testdatei auswählen, „Freistellung testen“ sendet genau diese Datei an Photoroom. Original und Antwort werden nebeneinander angezeigt; Originaldatei bleibt unverändert. Seite/Server speichern die Bilder nicht auf Platte. Anbieter verarbeitet das ausdrücklich gewählte Foto; keine Aussage über dessen Aufbewahrungsregeln. Keine vorhandenen privaten Werkstattbilder automatisch hochladen.

## Implementierung / Grenzen

- Ausschließlich Sandbox: POST https://image-api.photoroom.com/v2/edit; sandbox_-Präfix wird serverseitig erzwungen, kein Produktionsschalter. Transparente Ausgabe, removeBackground=true, referenceBox=originalImage, export.format=png; keine neuen Hintergründe, Schatten oder generativen Motivänderungen.
- Sandbox-Ausgabe mit Wasserzeichen, keine Produktionsdatei. Anbieterlimits laut offizieller Dokumentation bis 1.000 kostenlose Sandbox-Aufrufe pro Monat / 100 pro Tag; tatsächliche Kontoberechtigung erst mit Nutzerzugang prüfen.
- Nur 127.0.0.1, exakter Host, Origin-/Cross-Site-Prüfung, sitzungsgebundener POST-Token, kein CORS. Feste Photoroom-Zieladresse, keine URL-Eingaben/Weiterleitungen. Keine geheimen Werte in Fehlerantworten.
- PNG/JPEG/WebP, 15 MB Eingabe; Browser prüft Dekodierung und höchstens 40 MP. Server prüft Signatur/Größe, vollständige serverseitige Dekodierung ist für einen späteren öffentlichen Betrieb noch erforderlich. PNG-Antwort bis 25 MB, Timeout 60 Sekunden.
- Maximal ein laufender Aufruf; 20 Versuche pro Serverprozess; keine automatische Wiederholung. Ergebnisse identischer Eingaben werden nur im RAM zwischengespeichert, maximal fünf / 50 MB. Anbieterfehler lassen Original erhalten. Abmelden verhindert die Übernahme noch laufender Ergebnisse.
- Noch keine Anbindung an Konfigurator-Fotoobjekte, Entwurfs-/Bestellspeicherung, Produktionsübergabe oder öffentlichen Server. Bestehende Konfigurator-/Exportdateien wurden nicht geändert; neue Testdateien werden vom bestehenden expliziten Browser-Export nicht importiert.
- Keine echte API-Freistellung, Kanten-/Qualitätsprüfung oder Konto-/Tarifprüfung durchgeführt. Benutzer muss Schlüssel selbst eingeben und Foto selbst zum Test senden. Erst danach reversible Übernahme in den Konfigurator planen; Produktionszugang/Preise separat festlegen.

## Tatsächliche Prüfung

```powershell
node --test configurator/variant-m/photoroom-sandbox.test.mjs
```

6 Tests bestanden: erzwungener Sandbox-Request/Geometrieparameter/Cache; Größen-/Typablehnung; neutrale Anbieter-/Netzwerkfehler ohne Geheimnisse und ohne Retry; Ergebnisformat/Aufruflimit; Parallelaufrufe/Abmelden bei laufendem Aufruf; echter lokaler HTTP-Server mit Host-/Origin-/Tokenprüfungen, Konfiguration, PNG-Rückgabe, ungültigem JSON und Abmeldung. Anbieterantworten sind gemockt; keine echten Fotos extern gesendet. Früher erster Testlauf 5/6 wegen fetch-Testclient mit ignoriertem Host-Header; Hostprüfung anschließend mit node:http korrekt ausgeführt, 6/6.

Testseite im In-App-Browser geöffnet, Standardansicht/Sichtbarkeit der Eingaben, deaktivierter Testbutton ohne Zugang/Foto und visuelles Layout geprüft. Kein abgeschlossener Browser-Fotodurchlauf und kein physischer Mobiltest.

## Offizielle Quellen

- https://docs.photoroom.com/getting-started/introduction.md
- https://docs.photoroom.com/image-editing-api-plus-plan/sandbox-mode
- https://docs.photoroom.com/image-editing-api-plus-plan/quickstart-guide.md
- https://docs.photoroom.com/image-editing-api-plus-plan/positioning.md

Nächster Schritt: Nutzer testet ein freigegebenes Foto, Kanten/Fell/Haare und Erhalt aller Motive gemeinsam beurteilen; danach Konfiguratorintegration mit Original/Freistellung-Wahl. Keine automatische Synchronisierung anderer Aufgaben: diese müssen den Ergebniscommit samt diesem Nachweis lesen.
