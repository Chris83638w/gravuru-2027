// Storefront API transport. Cart IDs (including their secret key) stay server-side.
// https://shopify.dev/docs/storefronts/headless/building-with-the-storefront-api/cart/manage
import {isIP} from 'node:net';
export const VARIANTS_QUERY=`query GravuruVariantCheck($ids: [ID!]!) {
 nodes(ids: $ids) { ... on ProductVariant { id availableForSale price { amount currencyCode } } }
}`;
export const CART_CREATE=`mutation GravuruCartCreate($input: CartInput!) {
 cartCreate(input: $input) {
  cart { id checkoutUrl cost { subtotalAmount { amount currencyCode } }
   lines(first: 100) { nodes { id quantity attributes { key value } merchandise { ... on ProductVariant { id } } } pageInfo { hasNextPage } }
  }
  userErrors { field message code }
 }
}`;
export function cents(money){
 if(money?.currencyCode!=='EUR'||typeof money.amount!=='string'||!/^\d+(?:\.\d{1,2})?$/.test(money.amount))throw Error('Shopify-Preis muss in EUR vorliegen.');
 const [whole,fraction='']=money.amount.split('.'),value=Number(whole)*100+Number(fraction.padEnd(2,'0'));
 if(!Number.isSafeInteger(value))throw Error('Shopify-Preis ist zu groß.');return value;
}
export function createStorefront({shop='gravuru-design.myshopify.com',fetcher=fetch,checkoutHosts=['gravuru.de','www.gravuru.de','gravuru-design.myshopify.com']}={}){
 if(!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop))throw Error('Ungültiger Shop.');
 async function request(query,variables,buyerIp){
  if(!isIP(buyerIp||''))throw Error('Verifizierte Käufer-IP fehlt.');
  const response=await fetcher('https://'+shop+'/api/2026-07/graphql.json',{method:'POST',redirect:'error',signal:AbortSignal.timeout(30000),headers:{'Content-Type':'application/json','Shopify-Storefront-Buyer-IP':buyerIp},body:JSON.stringify({query,variables})});
  if(!response.ok)throw Error('Shopify ist momentan nicht erreichbar.');const data=await response.json();
  if(data.errors?.length||!data.data)throw Error('Shopify konnte die Anfrage nicht bestätigen.');return data.data;
 }
 return {
  async verify(lines,buyerIp){
   const ids=[...new Set(lines.map(l=>l.variantId))];if(ids.length<1||ids.length>100)throw Error('Ungültige Warenkorbpositionen.');
   const data=await request(VARIANTS_QUERY,{ids},buyerIp);
   for(const line of lines){const live=data.nodes.find(n=>n?.id===line.variantId);if(!live?.availableForSale||cents(live.price)!==line.unitCents)throw Error('Artikelpreis oder Verfügbarkeit hat sich geändert. Bitte Auswahl erneut prüfen.');}
  },
  async create({lines,packageId,fingerprint,expectedCents},buyerIp){
   const attributes=[{key:'_gravuru_package',value:packageId},{key:'_gravuru_snapshot',value:fingerprint}];
   const input={lines:lines.map(l=>({merchandiseId:l.variantId,quantity:l.quantity,attributes})),attributes:[{key:'Gravuru Gestaltung',value:packageId}]};
   const data=await request(CART_CREATE,{input},buyerIp),result=data.cartCreate;
   if(result?.userErrors?.length||!result?.cart)throw Error('Shopify konnte den Warenkorb nicht übernehmen.');
   const cart=result.cart,url=new URL(cart.checkoutUrl);
   if(url.protocol!=='https:'||url.username||url.password||!checkoutHosts.includes(url.hostname))throw Error('Unerwartete Shopify-Checkoutadresse.');
   if(cart.lines.pageInfo.hasNextPage||cart.lines.nodes.length!==lines.length||cents(cart.cost.subtotalAmount)!==expectedCents)throw Error('Shopify-Warenkorbpreis weicht von der geprüften Gestaltung ab.');
   for(const line of lines){const found=cart.lines.nodes.find(n=>n.merchandise?.id===line.variantId);if(!found||found.quantity!==line.quantity||attributes.some(a=>!found.attributes.some(b=>b.key===a.key&&b.value===a.value)))throw Error('Shopify hat die Gestaltung nicht vollständig übernommen.');}
   return {id:cart.id,checkoutUrl:cart.checkoutUrl,subtotalCents:expectedCents};
  }
 };
}
