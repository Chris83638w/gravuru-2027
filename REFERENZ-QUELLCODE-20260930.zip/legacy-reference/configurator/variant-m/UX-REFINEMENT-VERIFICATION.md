# Variante M – Foto- und Bedienverbesserungen

Stand: 25.09.2026. Basis `50d0bd84cbfbadcd05c3db9f4bd267702d80a470`,
Aufgabenbranch `feat/variante-m-profile-20260924`. Die Prüfungen betreffen die lokale
Vorschau auf Port 8947, keine veröffentlichte Shopoberfläche.

## Geänderter Umfang

- Das hochgeladene Foto wird tatsächlich angezeigt. Dies ersetzt die frühere Vorgabe
  einer reinen Uploadbox. Fotos verwenden das Originalbild; Logos behalten die
  bestehende profilabhängige Gravurfarbe beziehungsweise UV-Originalfarben.
- Bildeditor: Original-, Quadrat-, Hoch-/Querformat und Rundmaske, Zoom, Ausschnitt
  verschieben, 90-Grad-Drehung, Spiegeln, ähnliche verbundene Hintergrundfarbe entfernen,
  Radieren, Wiederherstellen, Bearbeitung rückgängig und zum Original zurückkehren.
- Gemeinsame Eckgriffe zum Skalieren und Drehgriff für ausgewählte Texte, Motive,
  Fotos und Logos. Zusätzlich Tastaturbedienung und Werkzeugleiste unter der Vorschau
  für Plus/Minus, Drehen, Winkel, Zentrieren, Duplizieren und Löschen. Gesperrte
  Elemente bleiben geschützt; Uploads werden nicht über Duplizieren vervielfacht.
- Desktop: Werkzeuge/Reiter unter der Vorschau. Einheitliche Icon-Größe, Vollbild
  links im Bild. Maße dauerhaft sichtbar, feine Linien mit Endstrichen, Beschriftung
  neben/unter der Linie. Hilfslinien-Schalter mittig darunter.
- Mobil: Zurück und Entwurf speichern nebeneinander, klar getrennt. Kleine aktuelle
  Produktvorschau oben beim Scrollen; Antippen öffnet die große Vorschau. Hilfe bleibt
  in der unteren Leiste erreichbar. Meine Inhalte unter den Bedienfeldern.
- Texteingaben wachsen beim Bearbeiten bis 200 px und klappen beim Verlassen auf
  44 px zurück. Text hinzufügen ist an der Eingabespalte ausgerichtet.
- Befestigung deutlicher und Dropdowntexte lesbar. Kategorieauswahl mit vorhandenen
  Motivsymbolen, Pfeilen und horizontalem Wischen auf Auswahlleiste/Motivraster.
- Bestseller: zunächst fünf Motive plus Mehr-Kachel; erweitert alle acht vorhandenen
  Bestseller plus Weniger-Kachel. Auch die Katalogpagination nutzt Rasterkacheln.
- Weiter/Fertig ergänzt die freien Reiter. Fertig öffnet die große Kontrollvorschau,
  löst keine Bestellung aus und umgeht keine vorhandenen Bestellrestriktionen.

## Tatsächlich ausgeführte Prüfungen

| Prüfung | Ergebnis |
| --- | --- |
| Automatische Tests | 45 bestanden, 0 fehlgeschlagen: Produktpipeline, bestehende M-Verträge, UX und drei neue Bild-/Skalierungsprüfungen |
| Syntax/Build | Neue und geänderte Module syntaktisch geprüft; Build erfolgreich, sechs Prüfmodelle, 104 Originalressourcen prüfsummengleich |
| Fotoupload | Öffentliches vorhandenes AOSU-PNG aus dem Repository gewählt; tatsächliches SVG-image mit lokaler Blob-URL statt Platzhalter; 49,99 + 9,99 = 59,98 EUR |
| Bildbearbeitung | Quadratischer/runder Zuschnitt, Drehen, Spiegeln, Hintergrund anklicken, Übernehmen und erneutes Öffnen ausgeführt; bearbeitete Blob-URL wechselt, Aufpreis bleibt unverändert |
| Original/Rückgängig | Nach rundem Zuschnitt Original wiederhergestellt: Arbeitsausgabe 445 × 1200; Rückgängig wieder 1200 × 1200. Original bleibt separat erhalten |
| Radieren/Wiederherstellen | Zeigergeste über sichtbares Bild; transparenter Strich sichtbar und anschließend über Wiederherstellen wieder gefüllt. Canvas-Proportionen korrigiert, damit Pinselposition dem Zeiger entspricht |
| Elemente | Plus/Minus und 15-Grad-Drehung bei Upload; Tastatur am Griff; tatsächliches Ziehen am Textgriff in mobiler Vollbildansicht vergrößert Text, Ziehen am Drehgriff dreht ihn, Rückgängig geprüft |
| Maße | Dünne Maßlinien mit Endstrichen, 160-mm-Text unterhalb, 280-mm-Text links daneben; mobile Darstellung visuell kontrolliert |
| Mobil | 390 × 844 CSS-Pixel: Eingabe wächst bis zur benötigten Höhe und fällt beim Verlassen auf 44 px zurück; Text hinzufügen, Schrittwechsel, feste Miniatur und Öffnen der Großansicht geprüft |
| Motive | Kategorie Tiere: 6 von 13, Mehr-Kachel erweitert auf 12 von 13. Tatsächlicher horizontaler Zeigerzug Tiere → Anker; kein versehentliches Öffnen des Kategorie-Fensters nach Korrektur |
| Bestseller | Fünf plus Mehr, anschließend acht plus Weniger im mobilen Browser geprüft |
| Hilfe | Untere Hilfe-Schaltfläche öffnet die vorhandene lokale Hilfe auch in der Großansicht |
| Desktop | Zusätzlich 1280 × 960 CSS-Pixel, Bildeditor und die Anordnung unter der Vorschau visuell geprüft |

Testbefehl aus Repository-Hauptordner:

```powershell
node --test configurator/variant-m/contract.test.mjs configurator/variant-m/ux.test.mjs configurator/variant-m/image-processing.test.mjs automation/product-pipeline/tests/pipeline.test.mjs
node configurator/variant-m/build.mjs
```

Browserprüfungen sind manuell über die Browsersteuerung ausgeführt, kein dauerhaftes
automatisches End-to-End-Testpaket. Keine Prüfung auf physischem Smartphone, mit
Screenreader oder für alle Bildformate/Hintergründe. Ein Versuch, Canvas-Pixel über
die eingeschränkte Browser-DOM-Schnittstelle auszulesen, war dort nicht unterstützt;
Radieren und Wiederherstellen wurden deshalb visuell kontrolliert.

## Bilddaten und Grenzen

- Keine externe Bildbearbeitungsbibliothek, kein kostenpflichtiger Dienst. Freistellung
  ist deterministisch: verbundene ähnliche Farben plus manueller Radierer. Sie ist
  keine KI-Motivsegmentierung und garantiert keine automatische Haar-/Fellerkennung.
- Arbeitsbild maximal 1600 px lange Kante, bearbeitete Vorschau maximal 1200 px.
  Das Original-File bleibt unverändert in derselben Browsersitzung. Dies ist noch kein
  hochauflösender, nichtdestruktiver Fertigungsauftrag an die Werkstatt.
- Dateien und bearbeitete Bilder bleiben in einer lokalen Map/Blob-URL. Kein Upload
  an Shopify/Server, kein Eintrag in Git, Kundenkonto, URL-Parameter oder localStorage.
  Neuladen/Produktwechsel kann diese Sitzung verwerfen. Maximal vier Dateien kombiniert,
  je sichtbarer Datei 9,99 EUR; Bearbeiten zählt nicht als weiterer Upload.
- Fotos zeigen das Bild als Gestaltungshilfe. Die spätere Gravurwirkung und die
  Backend-Ausgabe mit Foto/Konturen sind noch separat zu entwickeln und abzunehmen.
- Kontospeicherung, private Uploadablage, serverseitige Preis-/Bestellprüfung,
  Zahlungsnachweis für PNG-Download und persönliche KI-Anbindung weiterhin offen.
  Die drei offenen Geschäftsfragen aus `UX-VERIFICATION.md` bleiben offen.
- Kein Main-/Koordinationsmerge und keine Shopify-/Plesk-Veröffentlichung. Historische
  Referenzen und fremde unversionierte Dateien unter `products/` unverändert.

