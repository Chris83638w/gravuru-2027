# Tuerschilder – Übersicht der Bestandsdesigns

361 Designs (dazu 1402 Varianten desselben Designs in anderer Form/Farbe/Material, in der Excel als „Variante von“), vorsortiert nach Zielgruppe und Unterkategorie. Unter jedem Bild: Schlüssel · Sicherheit der Zuordnung · Materialien. Korrekturen in [`TUERSCHILDER-DESIGNS.xlsx`](TUERSCHILDER-DESIGNS.xlsx).

Sprungmarken: [Allgemein – Allgemein (42)](#allgemein-allgemein) · [Familie – Familie (245)](#familie-familie) · [Familie – Willkommen (5)](#familie-willkommen) · [Hinweis – Bitte und Verbot (1)](#hinweis-bitte-und-verbot) · [Hinweis – Privat und Eingang (6)](#hinweis-privat-und-eingang) · [Sprüche – Spruch (5)](#spr-che-spruch) · [Tiere – Hund (1)](#tiere-hund) · [Tiere – Kleintier (1)](#tiere-kleintier) · [offen – offen (55)](#offen-offen)

## Allgemein – Allgemein

42 Designs

![Allgemein – Allgemein](_uebersicht/Allgemein-Allgemein.png)

## Familie – Familie

245 Designs

![Familie – Familie](_uebersicht/Familie-Familie-1.png)

![Familie – Familie](_uebersicht/Familie-Familie-2.png)

![Familie – Familie](_uebersicht/Familie-Familie-3.png)

![Familie – Familie](_uebersicht/Familie-Familie-4.png)

![Familie – Familie](_uebersicht/Familie-Familie-5.png)

## Familie – Willkommen

5 Designs

![Familie – Willkommen](_uebersicht/Familie-Willkommen.png)

## Hinweis – Bitte und Verbot

1 Designs

![Hinweis – Bitte und Verbot](_uebersicht/Hinweis-Bitte und Verbot.png)

## Hinweis – Privat und Eingang

6 Designs

![Hinweis – Privat und Eingang](_uebersicht/Hinweis-Privat und Eingang.png)

## Sprüche – Spruch

5 Designs

![Sprüche – Spruch](_uebersicht/Sprüche-Spruch.png)

## Tiere – Hund

1 Designs

![Tiere – Hund](_uebersicht/Tiere-Hund.png)

## Tiere – Kleintier

1 Designs

![Tiere – Kleintier](_uebersicht/Tiere-Kleintier.png)

## offen – offen

55 Designs

![offen – offen](_uebersicht/offen-offen.png)

