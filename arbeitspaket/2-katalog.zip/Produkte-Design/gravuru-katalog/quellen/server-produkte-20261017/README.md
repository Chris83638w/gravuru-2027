# Quellen vom Firmenserver `\\bi-srv01-fs01\Neue-Struktur\Produkte` (= `V:\Produkte`), gelesen 17.10.2026

Nur gelesen, nichts auf dem Server verändert. Dateien hier sind Momentaufnahmen.

| Datei | Inhalt | Ausgewertet in |
| --- | --- | --- |
| `_ordnerliste.txt.gz` | Ordnerliste des gesamten Produktbaums (459 510 Ordner, 57 Produktordner; Struktur Produkt \ Verfahren \ Form/Material \ Größe \ SKU \ FPD-Exporte) | `linien/_inventar/inventar.md` (`scripts/inventory-product-tree.py`) |
| `Bestand.xlsm` | Produktregister: je Produkt Verfahren → Form → Material → Größe mit Status Produktbilder/Fancy/Amazon/Import (1 326 Größen, 33 Produkte) | `linien/_inventar/bestand.md`, `bestand.csv` (`scripts/inventory-bestand-xlsm.py`) |
| `Produkte Schriftartenhäufigkeit.xlsx` | Schriftnutzung je Design-Ordner (322 Schriften × 3 430 SKU-Designordner) | noch nicht ausgewertet – Grundlage für Schrift-Sets je Linie |
| `Formular Neue Artikel.pdf` | internes Anlageformular: Artikelbezeichnung, Artikelnummer, SKU Amazon/Gravuru, Größe & Preis, Befestigung & Preis, Fotoupload, Fotobearbeitung, Material, Hintergrundplatte, Zubehör, Childs, Pflichtfelder Amazon, Max. Zeichen, Schriftarten, Schriftfarbe wählbar, Designvarianten, Surface | Vorlage für die Pflichtfelder einer Familie/Linie im Katalog |
