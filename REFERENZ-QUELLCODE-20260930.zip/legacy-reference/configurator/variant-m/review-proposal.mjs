// Isolated visual discussion view. Activated only by ?review=1, not production.
export function installReviewProposal({el,r,config,showTab,selected,changeObject}){
 const $=s=>r.querySelector(s);
 const style=document.createElement('style');style.textContent=`
 .ux-tabs{grid-template-columns:repeat(4,minmax(0,1fr))!important}
 #ux-tab-design,#ux-panel-design,.acryl-export,.acryl-preview-note,.ux-preview-size{display:none!important}
 .ux-color-palette .ux-swatches{display:grid!important;grid-template-columns:repeat(6,44px)!important;gap:12px!important;justify-content:start!important}
 .ux-color-palette .ux-swatches button{width:44px!important;height:44px!important;min-width:44px!important;min-height:44px!important;max-width:44px!important;max-height:44px!important;aspect-ratio:1!important;border-radius:50%!important;padding:0!important;box-sizing:border-box!important;flex:none!important}
 .ux-color-palette .ux-swatches button[aria-pressed=true]{outline:2px solid #18614f;outline-offset:3px}
 .acryl-handle-overlay{position:absolute;left:7.9%;top:3.45%;width:84.3%;height:82.6%;z-index:30;pointer-events:none}
 .acryl-handle-overlay .ux-selection-handles{position:absolute;inset:0;z-index:30}
 .acryl-handle-overlay button{pointer-events:auto}
 .ux-tabs button[hidden]{display:none!important}
 @media(max-width:760px){.ux-color-palette .ux-swatches{grid-template-columns:repeat(6,36px)!important;gap:10px!important}.ux-color-palette .ux-swatches button{width:36px!important;height:36px!important;min-width:36px!important;min-height:36px!important;max-width:36px!important;max-height:36px!important}.ux-shell .ux-tabs{gap:0!important}.ux-shell .ux-tabs button{font-size:12px!important}}
 `;r.append(style);
 const tab=$('#ux-tab-design');if(tab){tab.hidden=true;tab.disabled=true;tab.tabIndex=-1;}
 for(const label of r.querySelectorAll('.ux-color-palette label'))for(const node of label.childNodes)if(node.nodeType===3&&node.textContent.includes('Eigene Farbe'))node.textContent='Ausgewählte Farbe ';
 $('.acryl-export')?.remove();
 const raw=el.uxObjectSVG;
 el.uxObjectSVG=function(o){let svg=raw.call(this,o);if(o.id==='photo-main')svg=svg.replace('translate(0 46)','translate(0 31)').replace('x="-37" y="-7" width="74" height="14"','x="-53" y="-9" width="106" height="18"').replace('font-size="3.5"','font-size="4.2"').replace('Hier eigenes Foto hochladen','Hier tippen &amp; eigenes Foto hochladen').replace('y="4.5" font-size="2.8"','y="5.5" font-size="3.1"');return svg;};
 const overlay=document.createElement('div');overlay.className='acryl-handle-overlay';$('.stage').append(overlay);const handles=$('.ux-selection-handles');if(handles)overlay.append(handles);
 const priorSync=el.sync;el.sync=function(...args){const result=priorSync.apply(this,args);const footer=$('.acryl-details');if(footer)footer.textContent=footer.textContent.replace(/ · [\d.,]+ mm im Sockel/,'');const input=$('#ux-size');if(input&&r.activeElement!==input)input.value=String(Math.round(Number(input.value)));return result;};
 r.addEventListener('input',e=>{if(e.target.id==='ux-size'&&e.target.value!==''){e.stopImmediatePropagation();changeObject('size',Math.round(Number(e.target.value)));}},true);
 // Reuse the existing double-tap editing interaction and native text controls.
 showTab('options');el.sync();
}
