// Private persistence for the EXISTING Plesk application. Does not start a server.
import fs from 'node:fs';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {createHash, randomBytes, randomUUID} from 'node:crypto';

export const sha256 = value => createHash('sha256').update(value).digest('hex');
const fail = (message, status=400) => { throw Object.assign(Error(message), {status}); };
const within=(root,target)=>{const rel=path.relative(root,target);return !rel||(!rel.startsWith('..'+path.sep)&&rel!=='..'&&!path.isAbsolute(rel));};
export const canonical = value => {
 if(value===null||typeof value!=='object')return JSON.stringify(value);
 if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';
 return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}';
};

export class CheckoutStore {
 constructor({directory,webroot,now=()=>Date.now(),maxBytes=512*1024*1024}){
  if(!path.isAbsolute(directory||'')||!path.isAbsolute(webroot||''))fail('Private Ablage und Webroot ausdrücklich angeben.');
  // Resolve existing parents before mkdir, including symlinks/junctions.
  const resolveTarget=p=>fs.existsSync(p)?fs.realpathSync(p):path.join(fs.realpathSync(path.dirname(p)),path.basename(p));
  const target=resolveTarget(directory),publicRoot=fs.realpathSync(webroot);
  if(within(publicRoot,target))fail('Bestelldaten dürfen nicht im öffentlichen Webroot liegen.');
  fs.mkdirSync(target,{recursive:true,mode:0o700});
  const dbPath=path.join(target,'customer-checkout.sqlite');
  if(fs.existsSync(dbPath)&&fs.lstatSync(dbPath).isSymbolicLink())fail('Datenbank darf kein Link sein.');
  this.now=now;this.maxBytes=maxBytes;this.db=new DatabaseSync(dbPath);
  fs.chmodSync(dbPath,0o600);
  this.db.exec(`PRAGMA journal_mode=DELETE; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
   CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, expires INTEGER NOT NULL);
   CREATE TABLE IF NOT EXISTS assets(id TEXT PRIMARY KEY, session_hash TEXT NOT NULL REFERENCES sessions(token_hash), sha256 TEXT NOT NULL, mime TEXT NOT NULL, bytes BLOB NOT NULL, created INTEGER NOT NULL, UNIQUE(session_hash,sha256));
   CREATE TABLE IF NOT EXISTS packages(id TEXT PRIMARY KEY, session_hash TEXT NOT NULL REFERENCES sessions(token_hash), request_key TEXT NOT NULL, fingerprint TEXT NOT NULL, snapshot TEXT NOT NULL, status TEXT NOT NULL, cart TEXT, created INTEGER NOT NULL, UNIQUE(session_hash,request_key));`);
 }
 close(){this.db.close();}
 transaction(fn){this.db.exec('BEGIN IMMEDIATE');try{const r=fn();this.db.exec('COMMIT');return r;}catch(e){this.db.exec('ROLLBACK');throw e;}}
 session(){
  // One database-wide ceiling, not a separate service or unbounded in-memory map.
  if(this.db.prepare('SELECT count(*) AS n FROM sessions WHERE expires>?').get(this.now()).n>=500)fail('Bitte später erneut versuchen.',429);
  const token=randomBytes(32).toString('base64url');
  this.db.prepare('INSERT INTO sessions VALUES (?,?)').run(sha256(token),this.now()+86400000);return token;
 }
 authorize(token){
  if(typeof token!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(token))fail('Gestaltungssitzung fehlt.',401);
  const key=sha256(token),s=this.db.prepare('SELECT expires FROM sessions WHERE token_hash=?').get(key);
  if(!s||s.expires<=this.now())fail('Gestaltungssitzung abgelaufen.',401);return key;
 }
 // validateImage must fully decode with the host's existing sharp installation.
 async upload(token,bytes,mime,validateImage){
  const owner=this.authorize(token);
  if(!Buffer.isBuffer(bytes)||!bytes.length||bytes.length>15*1024*1024)fail('Bild bis 15 MB erforderlich.',413);
  if(!['image/jpeg','image/png','image/webp'].includes(mime)||typeof validateImage!=='function')fail('Bildprüfung erforderlich.');
  await validateImage(bytes,mime);
  return this.transaction(()=>{
   this.authorize(token);const digest=sha256(bytes);
   const old=this.db.prepare('SELECT id,sha256,mime FROM assets WHERE session_hash=? AND sha256=?').get(owner,digest);if(old)return old;
   const total=this.db.prepare('SELECT coalesce(sum(length(bytes)),0) AS n FROM assets').get().n;
   const own=this.db.prepare('SELECT count(*) AS n FROM assets WHERE session_hash=?').get(owner).n;
   if(total+bytes.length>this.maxBytes||own>=16)fail('Uploadgrenze erreicht. Bitte die Werkstatt kontaktieren.',429);
   const id=randomUUID();this.db.prepare('INSERT INTO assets VALUES (?,?,?,?,?,?)').run(id,owner,digest,mime,bytes,this.now());return {id,sha256:digest,mime};
  });
 }
 asset(owner,id){const a=this.db.prepare('SELECT id,sha256,mime FROM assets WHERE id=? AND session_hash=?').get(id,owner);if(!a)fail('Foto fehlt oder gehört zu einer anderen Sitzung.');return a;}
 prepare(token,key,snapshot,photos){
  const owner=this.authorize(token);
  if(typeof key!=='string'||!/^[\w-]{16,80}$/.test(key))fail('Ungültige Vorgangskennung.');
  if(!Array.isArray(photos)||photos.length>4)fail('Maximal vier Foto-/Logo-Zuordnungen.');
  const seen=new Set();
  const refs=photos.map(p=>{
   if(!p||typeof p.objectId!=='string'||seen.has(p.objectId)||!['photo','logo'].includes(p.kind))fail('Ungültige Bildzuordnung.');seen.add(p.objectId);
   if(p.kind==='photo'&&!['remove','keep'].includes(p.background))fail('Freistellwunsch fehlt.');
   return {objectId:p.objectId,kind:p.kind,...(p.kind==='photo'?{background:p.background}:{}),original:this.asset(owner,p.originalId),rendered:this.asset(owner,p.renderedId)};
  });
  const data=canonical({schema:'gravuru-private-checkout/v1',snapshot,photos:refs});
  if(Buffer.byteLength(data)>2_000_000)fail('Gestaltung ist zu groß.',413);
  const fingerprint=sha256(data);
  return this.transaction(()=>{
   const old=this.db.prepare('SELECT * FROM packages WHERE session_hash=? AND request_key=?').get(owner,key);
   if(old){if(old.fingerprint!==fingerprint)fail('Dieser Vorgang gehört zu einer anderen Gestaltung.',409);return this.record(old);}
   if(this.db.prepare('SELECT count(*) AS n FROM packages WHERE session_hash=?').get(owner).n>=10||this.db.prepare('SELECT count(*) AS n FROM packages').get().n>=1000)fail('Ablagegrenze erreicht. Bitte die Werkstatt kontaktieren.',429);
   const id=randomUUID();this.db.prepare('INSERT INTO packages VALUES (?,?,?,?,?,?,?,?)').run(id,owner,key,fingerprint,data,'prepared',null,this.now());return this.record(this.db.prepare('SELECT * FROM packages WHERE id=?').get(id));
  });
 }
 record(r){return {id:r.id,sha256:r.fingerprint,status:r.status,cart:r.cart?JSON.parse(r.cart):null};}
 claim(token,id){const owner=this.authorize(token);return this.transaction(()=>{
  const r=this.db.prepare('SELECT * FROM packages WHERE id=? AND session_hash=?').get(id,owner);if(!r)fail('Gestaltung nicht gefunden.',404);
  if(r.status==='ready')return {...this.record(r),claimed:false};
  if(r.status!=='prepared')fail('Übertragung wird geprüft. Bitte nicht erneut bestellen.',409);
  this.db.prepare("UPDATE packages SET status='submitting' WHERE id=?").run(id);return {...this.record(r),claimed:true};
 });}
 finish(id,cart){this.db.prepare("UPDATE packages SET status='ready',cart=? WHERE id=? AND status='submitting'").run(JSON.stringify(cart),id);}
 uncertain(id){this.db.prepare("UPDATE packages SET status='uncertain' WHERE id=? AND status='submitting'").run(id);}
 // Staff-side restore/production lookup only. No public HTTP download route.
 restore(id){const r=this.db.prepare('SELECT * FROM packages WHERE id=?').get(id);if(!r)fail('Gestaltung nicht gefunden.',404);const data=JSON.parse(r.snapshot);if(sha256(canonical(data))!==r.fingerprint)fail('Gestaltungsprüfsumme stimmt nicht.');
  const photos=data.photos.map(p=>({...p,original:this.restoreAsset(p.original),rendered:this.restoreAsset(p.rendered)}));return {...data,photos,status:r.status};}
 restoreAsset(ref){const r=this.db.prepare('SELECT * FROM assets WHERE id=?').get(ref.id);if(!r||sha256(r.bytes)!==ref.sha256)fail('Bildprüfsumme stimmt nicht.');return {...ref,bytes:Buffer.from(r.bytes)};}
}

export function imageValidator(sharp){return async(bytes,mime)=>{
 const formats={'image/jpeg':'jpeg','image/png':'png','image/webp':'webp'};
 const image=sharp(bytes,{limitInputPixels:40_000_000,failOn:'warning'}),m=await image.metadata();
 if(m.format!==formats[mime]||!m.width||!m.height||m.width*m.height>40_000_000||(m.pages||1)!==1)fail('Bitte ein einzelnes gültiges JPG-, PNG- oder WebP-Bild wählen.');
 await image.clone().raw().toBuffer(); // Decode the full image before accepting it.
};}
