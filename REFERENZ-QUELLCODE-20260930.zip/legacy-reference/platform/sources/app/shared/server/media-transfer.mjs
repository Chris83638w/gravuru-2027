// Transport-independent orchestration. Adapters must use the provided stable
// operation key; a lost response is reconciled, never blindly uploaded again.
export async function ensurePublishedMedia(store,reference,adapter,{fetcher=fetch}={}){
 if(!adapter?.target||typeof adapter.upload!=='function')throw Error('Medien-Uploadadapter fehlt.');
 const media=store.get(reference);let op=store.planUpload(media,adapter.target);
 if(op.remote_id&&op.url)return store.verifyUpload(op.id,{fetcher});
 if(op.status!=='planned'){
  const recovered=await adapter.reconcile?.({idempotencyKey:op.id,sha256:media.sha256,mimeType:media.mimeType});
  if(!recovered?.remoteId||!recovered?.url)throw Error('Upload-Ergebnis ist noch unklar. Vor einem erneuten Upload muss die vorhandene Datei abgeglichen werden.');
  store.recordUpload(op.id,recovered);return store.verifyUpload(op.id,{fetcher});
 }
 store.beginUpload(op.id);
 try{
  const result=await adapter.upload({idempotencyKey:op.id,sha256:media.sha256,mimeType:media.mimeType,bytes:store.readBytes(media)});
  store.recordUpload(op.id,result);
 }catch(error){store.uncertainUpload(op.id,error.message);throw error;}
 return store.verifyUpload(op.id,{fetcher});
}
export async function prepareMediaRelease(store,{channel,productId,productRevision,entries},adapters,options={}){
 if(!['shopify','amazon'].includes(channel)||![productId,productRevision].every(v=>typeof v==='string'&&v.trim()&&v.length<=200&&!/[\x00-\x1f]/.test(v)))throw Error('Kanal oder Produktrevision ist ungültig.');
 if(!Array.isArray(entries)||!entries.length)throw Error('Medienzuordnungen fehlen.');
 // Validate all references and slots before the first external upload.
 const slots=new Set();
 for(const e of entries){if(typeof e.slot!=='string'||!e.slot.trim()||e.slot.length>200||/[\x00-\x1f]/.test(e.slot)||slots.has(e.slot)||adapters[e.target]?.target!==e.target||typeof adapters[e.target]?.upload!=='function')throw Error('Medienfeld oder Uploadziel fehlt oder ist doppelt.');slots.add(e.slot);store.readBytes(e);}
 const bindings=[];
 for(const entry of entries){const op=await ensurePublishedMedia(store,entry,adapters[entry.target],options);bindings.push({slot:entry.slot,mediaId:entry.mediaId,revisionId:entry.revisionId,uploadId:op.id});}
 return store.createRelease({channel,productId,productRevision,bindings});
}
