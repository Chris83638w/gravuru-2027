import {inspectMedia} from './media-inspect.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {createHash,randomUUID} from 'node:crypto';

const hash=b=>createHash('sha256').update(b).digest('hex');
const now=()=>new Date().toISOString();
const roles=new Set(['original-vector','original-photo','font','product-preview','amazon-overlay','thumbnail','photo-mask','mounting-diagram','production-vector']);
function noLinks(filename){for(let p=path.resolve(filename);;p=path.dirname(p)){if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('Medienablage darf keine symbolischen Verknüpfungen enthalten.');if(path.dirname(p)===p)break;}}
function publicRecipe(value){
 if(typeof value==='string'&&(/(?:https?:|file:|data:|[a-z]:[\\/]|^[/\\])/i.test(value)||value.length>1000))throw Error('Dateipfade und eingebettete Medien gehören in die Quelle, nicht in das Bearbeitungsrezept.');
 if(value&&typeof value==='object')for(const [key,v] of Object.entries(value)){if(/password|token|secret|cookie|authorization|base64|^path$|^url$/i.test(key))throw Error('Private Angaben im Bearbeitungsrezept.');publicRecipe(v);}
 return value;
}
function publicMetadata(m){
 const out={};for(const key of ['widthPx','heightPx','viewBox','bounds','motifBoundsVersion','fontId','fontFamily','fontStyle','fontFormat','validation'])if(m[key]!==undefined)out[key]=m[key];publicRecipe(out);
 for(const key of ['widthPx','heightPx'])if(out[key]!==undefined&&(!Number.isInteger(out[key])||out[key]<=0))throw Error('Ungültige Pixelmaße.');
 if(out.viewBox!==undefined&&(!Array.isArray(out.viewBox)||out.viewBox.length!==4||!out.viewBox.every(Number.isFinite)||out.viewBox[2]<=0||out.viewBox[3]<=0))throw Error('Ungültige Vektorfläche.');
 if(out.motifBoundsVersion!==undefined&&![0,1].includes(out.motifBoundsVersion))throw Error('Unbekannte Motivraum-Version.');
 for(const key of ['fontId','fontFamily','fontStyle','fontFormat','validation'])if(out[key]!==undefined)text(out[key],key);
 if(out.bounds!==undefined&&(!['x','y','width','height'].every(k=>Number.isFinite(out.bounds?.[k]))||out.bounds.width<=0||out.bounds.height<=0))throw Error('Ungültige Motivgrenzen.');
 return out;
}
const text=(value,name,max=200)=>{if(typeof value!=='string'||!value.trim()||value.length>max||/[\x00-\x1f]/.test(value))throw Error('Ungültig: '+name);return value;};
export function canonical(value){
 if(value===null||typeof value==='string'||typeof value==='boolean')return JSON.stringify(value);
 if(typeof value==='number'&&Number.isFinite(value))return JSON.stringify(value);
 if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';
 if(value&&Object.getPrototypeOf(value)===Object.prototype)return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}';
 throw Error('Metadaten müssen endliches JSON enthalten.');
}
export class MediaStore{
 constructor(root,{publicOrigins=[]}={}){
  this.root=path.resolve(root);noLinks(this.root);fs.mkdirSync(this.root,{recursive:true});this.blobRoot=path.join(this.root,'blobs');noLinks(this.blobRoot);fs.mkdirSync(this.blobRoot,{recursive:true});
  this.origins=new Set(publicOrigins.map(origin=>{const u=new URL(origin);if(u.protocol!=='https:'||u.username||u.password||u.pathname!=='/'||u.search||u.hash)throw Error('Öffentliche Herkunft muss ein HTTPS-Origin sein.');return u.origin;}));
  for(const suffix of ['','-wal','-shm','-journal'])noLinks(path.join(this.root,'media.sqlite'+suffix));
  this.db=new DatabaseSync(path.join(this.root,'media.sqlite'));if(this.db.prepare('PRAGMA user_version').get().user_version>1){this.db.close();throw Error('Diese Medienbank benötigt eine neuere Programmversion.');}this.db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
   CREATE TABLE IF NOT EXISTS media(id TEXT PRIMARY KEY,business_key TEXT NOT NULL UNIQUE,label TEXT NOT NULL,role TEXT NOT NULL,created_at TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS revisions(id TEXT PRIMARY KEY,media_id TEXT NOT NULL REFERENCES media(id),sha256 TEXT NOT NULL,mime_type TEXT NOT NULL,byte_length INTEGER NOT NULL,source_json TEXT NOT NULL,parent_media TEXT,parent_revision TEXT REFERENCES revisions(id),transform_json TEXT,metadata_json TEXT NOT NULL,fingerprint TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(media_id,fingerprint));
   CREATE TABLE IF NOT EXISTS uploads(id TEXT PRIMARY KEY,target TEXT NOT NULL,sha256 TEXT NOT NULL,mime_type TEXT NOT NULL,status TEXT NOT NULL,remote_id TEXT,url TEXT,verified_at TEXT,error TEXT,updated_at TEXT NOT NULL,UNIQUE(target,sha256,mime_type));
   CREATE TABLE IF NOT EXISTS releases(id TEXT PRIMARY KEY,fingerprint TEXT NOT NULL UNIQUE,manifest_json TEXT NOT NULL,created_at TEXT NOT NULL);
   PRAGMA user_version=1;`);
 }
 close(){this.db.close();}
 blobPath(sha){if(!/^[a-f0-9]{64}$/.test(sha))throw Error('Ungültiger Inhaltshash.');const filename=path.join(this.blobRoot,sha);noLinks(filename);return filename;}
 transaction(fn){this.db.exec('BEGIN IMMEDIATE');try{const result=fn();this.db.exec('COMMIT');return result;}catch(e){this.db.exec('ROLLBACK');throw e;}}
 importBytes(input,bytes){
  if(input.visibility!=='public-product')throw Error('Dieses Register nimmt nur öffentliche Produktmedien auf; keine Bestell- oder Kundenfotos.');
  const key=text(input.key,'Medienkennung'),label=text(input.label,'Name');if(!roles.has(input.role))throw Error('Unbekannte Medienrolle.');
  if(!(bytes instanceof Uint8Array)||!bytes.length||bytes.length>50*1024*1024)throw Error('Mediendatei muss 1 Byte bis 50 MB enthalten.');
  const inspected=inspectMedia(bytes,input.mimeType),b=inspected.bytes,sha=hash(b);
  for(const key of ['widthPx','heightPx','viewBox','fontFormat'])if(input.metadata?.[key]!==undefined&&inspected.metadata[key]!==undefined&&canonical(input.metadata[key])!==canonical(inspected.metadata[key]))throw Error('Medienmetadaten widersprechen dem Dateiinhalt: '+key);
  const checkedMetadata={...(input.metadata||{}),...inspected.metadata};
  if(input.role==='font'&&!input.mimeType.startsWith('font/'))throw Error('Schrift benötigt eine Original-Schriftdatei.');
  if(['original-vector','production-vector'].includes(input.role)&&!['image/svg+xml','application/pdf'].includes(input.mimeType))throw Error('Vektorrolle benötigt eine SVG- oder PDF-Datei.');
  if(input.role==='original-photo'&&!['image/png','image/jpeg','image/webp'].includes(input.mimeType))throw Error('Originalfoto benötigt eine Rasterbilddatei.');
  if(!input.parent&&(!input.source||!Object.keys(input.source).length))throw Error('Die Herkunft des Originals fehlt.');
  publicRecipe(input.transform);publicMetadata(input.metadata||{});
  const source=canonical(input.source||{}),metadata=canonical(checkedMetadata),transform=input.transform===undefined?null:canonical(input.transform);
  if(source.length+metadata.length+(transform?.length||0)>64000)throw Error('Medienmetadaten sind zu groß.');
  if(Boolean(input.parent)!==Boolean(transform))throw Error('Ein Derivat braucht Originalreferenz und Transformationsparameter.');
  if(input.parent&&(!input.transform?.recipe||!input.transform?.version))throw Error('Die Bearbeitung benötigt Rezept und Version.');
  const parent=input.parent?this.get(input.parent):null;
  const fingerprint=hash(canonical({sha,mimeType:input.mimeType,source:JSON.parse(source),metadata:JSON.parse(metadata),parent:parent?{mediaId:parent.mediaId,revisionId:parent.revisionId}:null,transform:transform?JSON.parse(transform):null}));
  return this.transaction(()=>{
   let m=this.db.prepare('SELECT * FROM media WHERE business_key=?').get(key);
   if(m&&m.role!==input.role)throw Error('Die Medienkennung gehört bereits zu einer anderen Rolle.');
   if(m&&m.label!==label)throw Error('Die Medienkennung hat bereits einen anderen Namen.');
   if(!m){m={id:'media-'+randomUUID()};this.db.prepare('INSERT INTO media VALUES(?,?,?,?,?)').run(m.id,key,label,input.role,now());}
   const existing=this.db.prepare('SELECT id FROM revisions WHERE media_id=? AND fingerprint=?').get(m.id,fingerprint);
   if(existing){this.readBytes({mediaId:m.id,revisionId:existing.id});return {...this.get({mediaId:m.id,revisionId:existing.id}),reused:true};}
   const dest=this.blobPath(sha);
   if(fs.existsSync(dest)){if(hash(fs.readFileSync(dest))!==sha)throw Error('Gespeicherter Medieninhalt wurde verändert.');}
   else{const temp=path.join(this.blobRoot,'.'+randomUUID()+'.tmp'),fd=fs.openSync(temp,'wx');try{fs.writeFileSync(fd,b);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}fs.renameSync(temp,dest);if(process.platform!=='win32'){const directory=fs.openSync(this.blobRoot,'r');try{fs.fsyncSync(directory);}finally{fs.closeSync(directory);}}}
   const id='revision-'+randomUUID();
   this.db.prepare('INSERT INTO revisions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(id,m.id,sha,input.mimeType,b.length,source,parent?.mediaId??null,parent?.revisionId??null,transform,metadata,fingerprint,now());
   return {...this.get({mediaId:m.id,revisionId:id}),reused:false};
  });
 }
 importFile(input,filename){return this.importBytes(input,fs.readFileSync(filename));}
 get(ref){
  const row=this.db.prepare('SELECT r.*,m.business_key,m.label,m.role FROM revisions r JOIN media m ON m.id=r.media_id WHERE r.id=? AND m.id=?').get(ref?.revisionId||'',ref?.mediaId||'');
  if(!row)throw Error('Medienversion nicht gefunden.');
  return {mediaId:row.media_id,revisionId:row.id,key:row.business_key,label:row.label,role:row.role,sha256:row.sha256,mimeType:row.mime_type,byteLength:row.byte_length,source:JSON.parse(row.source_json),metadata:JSON.parse(row.metadata_json),parent:row.parent_revision?{mediaId:row.parent_media,revisionId:row.parent_revision}:null,transform:row.transform_json?JSON.parse(row.transform_json):null,createdAt:row.created_at};
 }
 list(){return this.db.prepare('SELECT media_id,id FROM revisions ORDER BY created_at,id').all().map(r=>this.get({mediaId:r.media_id,revisionId:r.id}));}
 readBytes(ref){const r=this.get(ref),b=fs.readFileSync(this.blobPath(r.sha256));if(hash(b)!==r.sha256||b.length!==r.byteLength)throw Error('Medieninhalt stimmt nicht mit der Version überein.');return b;}
 planUpload(ref,target){
  const r=this.get(ref);text(target,'Uploadziel',80);this.readBytes(ref);
  const id='upload-'+hash(canonical({target,sha256:r.sha256,mimeType:r.mimeType}));
  this.db.prepare('INSERT OR IGNORE INTO uploads(id,target,sha256,mime_type,status,updated_at) VALUES(?,?,?,?,?,?)').run(id,target,r.sha256,r.mimeType,'planned',now());
  return this.upload(id);
 }
 upload(id){const r=this.db.prepare('SELECT * FROM uploads WHERE id=?').get(id);if(!r)throw Error('Uploadvorgang fehlt.');return {...r};}
 beginUpload(id){this.upload(id);const changed=this.db.prepare("UPDATE uploads SET status='in-progress',updated_at=? WHERE id=? AND status='planned'").run(now(),id);if(changed.changes!==1)throw Error('Upload wurde bereits begonnen; zuerst vorhandenes Ergebnis abgleichen.');return this.upload(id);}
 uncertainUpload(id,message){this.upload(id);this.db.prepare("UPDATE uploads SET status='uncertain',error=?,updated_at=? WHERE id=? AND status='in-progress'").run(String(message).slice(0,500),now(),id);return this.upload(id);}
 publicUrl(value){const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.hash||!this.origins.has(u.origin))throw Error('Dateiadresse gehört nicht zu einer zugelassenen öffentlichen Herkunft.');if([...u.searchParams.keys()].some(k=>/token|signature|credential|authorization|password|expires|^key$|^auth$|^x-amz-|^x-goog-/i.test(k)))throw Error('Öffentliche Produktdateien benötigen eine dauerhafte Adresse ohne Zugangstoken.');return u.href;}
 recordUpload(id,{remoteId,url}){
  return this.transaction(()=>{
  const old=this.upload(id);text(remoteId,'Dateikennung');url=this.publicUrl(url);
  if(old.remote_id&&(old.remote_id!==remoteId||old.url!==url))throw Error('Upload ist bereits einer anderen Datei zugeordnet.');
  if(old.status==='verified')return old;
  this.db.prepare("UPDATE uploads SET status='uploaded',remote_id=?,url=?,error=NULL,updated_at=? WHERE id=?").run(remoteId,url,now(),id);return this.upload(id);
  });
 }
 async verifyUpload(id,{fetcher=fetch}={}){
  const row=this.upload(id);if(!row.url)throw Error('Eine geplante Adresse ist kein bestätigter Upload.');this.publicUrl(row.url);
  try{
   const response=await fetcher(row.url,{redirect:'error',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(20000)});
   if(!response.ok||response.redirected)throw Error('Öffentliche Datei ist nicht anonym und direkt erreichbar.');
   if(response.url&&new URL(response.url).href!==row.url)throw Error('Unerwartete Weiterleitung.');
   const mime=response.headers?.get('content-type')?.split(';')[0].trim().toLowerCase();
   if(mime!==row.mime_type)throw Error('Öffentlicher Dateityp stimmt nicht überein.');
   let content;
   if(response.body?.getReader){const reader=response.body.getReader(),chunks=[];let size=0;try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>50*1024*1024){await reader.cancel();throw Error('Öffentliche Mediendatei ist zu groß.');}chunks.push(Buffer.from(value));}content=Buffer.concat(chunks);}finally{reader.releaseLock();}}
   else content=Buffer.from(await response.arrayBuffer());
   if(content.length>50*1024*1024||hash(content)!==row.sha256)throw Error('Öffentlicher Dateiinhalt stimmt nicht mit der Medienversion überein.');
   this.db.prepare("UPDATE uploads SET status='verified',verified_at=?,error=NULL,updated_at=? WHERE id=?").run(now(),now(),id);
  }catch(e){this.db.prepare("UPDATE uploads SET status='failed',verified_at=NULL,error=?,updated_at=? WHERE id=?").run(String(e.message).slice(0,500),now(),id);throw e;}
  return this.upload(id);
 }
 createRelease({channel,productId,productRevision,bindings}){
  return this.transaction(()=>{
  if(!['shopify','amazon'].includes(channel))throw Error('Unbekannter Kanal.');text(productId,'Produktkennung');text(productRevision,'Produktrevision');
  if(!Array.isArray(bindings)||!bindings.length)throw Error('Medienzuordnungen fehlen.');
  const slots=new Set();const media=bindings.map(binding=>{
   text(binding.slot,'Medienfeld');if(slots.has(binding.slot))throw Error('Medienfeld doppelt belegt.');slots.add(binding.slot);
   const r=this.get(binding),u=this.upload(binding.uploadId);this.readBytes(r);
   if(u.status!=='verified'||u.sha256!==r.sha256||u.mime_type!==r.mimeType)throw Error('Eine Medienzuordnung ist ungeprüft oder gehört zu einer anderen Datei.');this.publicUrl(u.url);
   const ancestry=[];let parent=r.parent;
   while(parent){const p=this.get(parent);this.readBytes(p);ancestry.push({mediaId:p.mediaId,revisionId:p.revisionId,sha256:p.sha256,role:p.role,mimeType:p.mimeType,metadata:publicMetadata(p.metadata),transform:p.transform});parent=p.parent;if(ancestry.length>30)throw Error('Zu viele Bearbeitungsschritte.');}
   return {slot:binding.slot,mediaId:r.mediaId,revisionId:r.revisionId,sha256:r.sha256,mimeType:r.mimeType,byteLength:r.byteLength,role:r.role,metadata:publicMetadata(r.metadata),url:u.url,remoteId:u.remote_id,uploadId:u.id,verifiedAt:u.verified_at,transform:r.transform,ancestry};
  });
  const payload={schema:'gravuru-media-release/v1',channel,productId,productRevision,media};const fingerprint=hash(canonical(payload));
  const existing=this.db.prepare('SELECT manifest_json FROM releases WHERE fingerprint=?').get(fingerprint);if(existing)return JSON.parse(existing.manifest_json);
  const manifest={...payload,releaseId:'release-'+randomUUID(),createdAt:now()};
  this.db.prepare('INSERT INTO releases VALUES(?,?,?,?)').run(manifest.releaseId,fingerprint,JSON.stringify(manifest),manifest.createdAt);return manifest;
  });
 }
 release(id){const row=this.db.prepare('SELECT manifest_json FROM releases WHERE id=?').get(id);if(!row)throw Error('Medienfreigabe fehlt.');return JSON.parse(row.manifest_json);}
 backup(destination){
  const dest=path.resolve(destination);noLinks(dest);if(fs.existsSync(dest))throw Error('Sicherungsziel existiert bereits.');
  fs.mkdirSync(dest,{recursive:true});const dbFile=path.join(dest,'media.sqlite');
  // VACUUM INTO creates a consistent snapshot, including any current WAL.
  this.db.prepare('VACUUM INTO ?').run(dbFile);
  const saved=new DatabaseSync(dbFile,{readOnly:true});let hashes;
  try{hashes=saved.prepare('SELECT DISTINCT sha256 FROM revisions ORDER BY sha256').all().map(r=>r.sha256);}finally{saved.close();}
  const folder=path.join(dest,'blobs');fs.mkdirSync(folder);
  for(const digest of hashes){const bytes=fs.readFileSync(this.blobPath(digest));if(hash(bytes)!==digest)throw Error('Sicherungsquelle wurde verändert.');const fd=fs.openSync(path.join(folder,digest),'wx');try{fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
  const report={schema:'gravuru-media-backup/v1',createdAt:now(),databaseSha256:hash(fs.readFileSync(dbFile)),blobCount:hashes.length,blobHashes:hashes};
  fs.writeFileSync(path.join(dest,'backup-info.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});return report;
 }
}
