# Produktlinien und Unterkategorien

**Benennung:** Linie = das physische Produkt (Material + Bauart, entspricht einer oder mehreren Familien). Unterkategorie = Thema/Zielgruppe innerhalb der Linie. Name im Shop: „<Linie> – <Unterkategorie>“, z. B. „Edelstahl Türschilder – Hundeschilder“. Dieselbe Unterkategorie (Thema) kann in mehreren Linien vorkommen und ist in [../themen.json](../themen.json) einmal definiert (Schrift-Set, Motivkategorien, Design-Tags); die Linie legt Familien, angebotene Größen, Optionen und Preise fest, die Unterkategorie überschreibt nur, was abweicht.

Maßgeblich sind die JSON-Dateien `linien/<linie>.json`; die Gesamtübersicht steht in [../KATALOG.md](../KATALOG.md). Stand 17.10.2026: Vorschlag Claude, vom Nutzer zu bestätigen (Linien und Unterkategorien aus seinen Nennungen; „usw.“ ergänzt).

| Linie | Unterkategorien (Vorschlag) | Familien | Stand |
| --- | --- | --- | --- |
| **Acrylglas Schilder mit Abstandshaltern (AA / AS / S/S)** | Hausnummern, Namensschilder, Familienschilder, Firmen- und Praxisschilder, Willkommensschilder, Hundeschilder | acryl-aa-abstandshalter, acryl-as-abstandshalter, acryl-ss-abstandshalter | Familien da, Preise offen |
| **Acrylglas Türschilder 3 mm** | Namensschilder, Familienschilder, Hundeschilder, Hochzeitsschilder, Firmen- und Praxisschilder, Hinweisschilder | offen | Familie offen |
| **Alu-Dibond 30 × 20 (Druck)** | Gedenktafeln, Hausnummern, Hundeschilder, Geschenkartikel, Wanddeko | offen | Familie offen (3 mm, eckig, Ø 4, 2/4 Löcher oder Schrauben, selbstklebend glatt/rau, vollflächiger Druck) |
| **Brettchen** | Namensschilder, Familienschilder, Hochzeitsschilder, Geschenkartikel | offen | Familie offen |
| **Edelstahl Türschilder** | Namensschilder, Familienschilder, Hausnummern, Hundeschilder, Katzenschilder, Hochzeitsschilder, Firmen- und Praxisschilder, Willkommensschilder, Hinweisschilder, Pferdeschilder | steel-door-signs | Familie vollständig (61 Größen, 16 Befestigungen) |
| **Gedenktafeln 30 × 20** | Gedenktafeln, Tiergedenktafeln | gedenktafel-30x20-edelstahl, gedenktafel-30x20-schiefer-natur, gedenktafel-30x20-schiefer-premium, gedenktafel-30x20-acryl-schwarz, gedenktafel-30x20-acryl-anthrazit | Schiefer natur vollständig, Rest offen |
| **Lineale** | Namensschilder, Geschenkartikel, Firmen- und Praxisschilder | offen | Familie offen |
| **Pferdeschilder (Boxen- und Stallschilder)** | Pferdeschilder, Hinweisschilder | offen | Familie offen |
| **Schlüsselanhänger** | Namensschilder, Hochzeitsschilder, Hundeschilder, Firmen- und Praxisschilder, Geschenkartikel | offen | Familie offen |
| **Stifthalterdosen** | Namensschilder, Geschenkartikel, Firmen- und Praxisschilder | offen | Familie offen |
| **Türklingeln / Funkklingelschilder** | Namensschilder, Hausnummern, Firmen- und Praxisschilder | offen | Familie offen |

## Themen (wiederverwendbar)

| Thema | Schrift-Set | Motivkategorien der Bibliothek | Design-Tags |
| --- | --- | --- | --- |
| Namensschilder (`namensschilder`) | `tuerschilder` | Ornamente, Linien mit Verzierungen, Herzen | name, familie |
| Familienschilder (`familienschilder`) | `tuerschilder` | Figuren, Herzen, Haus, Bäume | familie, willkommen |
| Hausnummern (`hausnummern`) | `hausnummern` | Haus, Linien mit Verzierungen | hausnummer, strasse |
| Hundeschilder (`hundeschilder`) | `hundeschilder` | Hunderassen, Hunde, Pfoten | hund, warnung, name |
| Katzenschilder (`katzenschilder`) | `hundeschilder` | Katzen, Pfoten | katze, name |
| Pferdeschilder (`pferdeschilder`) | `pferdeschilder` | Pferde, Brandzeichen | pferd, box, stall, besitzer |
| Hochzeitsschilder (`hochzeitsschilder`) | `andenken` | Hochzeit, Herzen, Infinity, Schleifen | hochzeit, paar, datum |
| Firmen- und Praxisschilder (`firmenschilder`) | `firmenschilder` | Berufe & Gewerbe, Hinweise - Piktogramme, Social Media | firma, praxis, oeffnungszeiten |
| Willkommensschilder (`willkommensschilder`) | `tuerschilder` | Blumen, Schmetterlinge, Ornamente, Herzen | willkommen, familie |
| Hinweisschilder (`hinweisschilder`) | `firmenschilder` | Hinweise - Piktogramme, Pfeile | hinweis, bitte, verbot |
| Gedenktafeln (`gedenktafeln`) | `andenken` | Kreuze, Engel, Symbole Religion, Kerzen, Bäume, Vögel | gedenken, trauer, mensch |
| Tiergedenktafeln (`tiergedenktafeln`) | `andenken` | Hunde, Katzen, Pferde, Pfoten, Regenbogen, Flügel | gedenken, tier, regenbogenbruecke |
| Baby- und Geburtsschilder (`babyschilder`) | `geschenkartikel` | Baby, Sterne, Sonne - Mond - Wolken | geburt, baby, name, datum |
| Kinderzimmerschilder (`kinderzimmerschilder`) | `geschenkartikel` | Tiere, Sterne, Regenbogen, Figuren | kind, name |
| Geschenkartikel (`geschenkartikel`) | `geschenkartikel` | Geburtstag, Jubiläum, Muttertag, Vatertag, Weihnachten, Ostern | geschenk, anlass |
| Wanddeko (`wanddeko`) | `geschenkartikel` | Ornamente, Sternzeichen, Urlaub, Musik, Sport | deko, spruch |

## Ausführungen innerhalb eines Materials (Paket M)

Optionales Feld in `linien/<linie>.json`: `"ausfuehrungen": {"modus": "produkte"}` oder `{"modus": "varianten"}`. Es legt fest, ob beispielsweise Acrylfarben, Holzarten oder Schiefer natur/premium innerhalb dieser Linie eigene Produkte oder Varianten sind. Ohne Feld bleibt die Entscheidung unbekannt. Paket M validiert und zeigt diese Angabe, erzeugt daraus aber keine Produkte oder Shop-Varianten. Es wurden keine Werte für bestehende Linien erfunden. Gravur und Druck sowie verschiedene Materialien bleiben nach Chris' Vorgabe getrennte Produkte.
