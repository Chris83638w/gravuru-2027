# Bestandsdesigns Tierschilder – aus dem Server-Bestand extrahiert

35 Designs (über Größen und Materialien zusammengefasst), gelesen aus den Corel-Bögen (`[CDR]`) und Konfigurator-Paketen auf `V:\Produkte\Gedenktafeln`. Je Design ein Ordner `Zielgruppe/Unterkategorie/<Schlüssel>/` mit `design.svg` (Text bleibt Text, Motive als Pfade, Maße in mm), `design.json` (Texte, Schriften, Lage, Varianten, Kategorie) und `preview.png`. UV-Designs aus Paketen tragen zusätzlich `product.json` und die Ebenen (`Bild_*.png`, `*.svg`).

**Kategorien sind Vorschläge aus den Texten** – Korrektur in [`TIERSCHILDER-DESIGNS.xlsx`](TIERSCHILDER-DESIGNS.xlsx) (gelbe Spalten), Übersichtsbögen je Kategorie in `_uebersicht/`.

| Zielgruppe | Unterkategorie | Designs |
| --- | --- | --- |
| Allgemein | Allgemein | 15 |
| Familie | Familie | 2 |
| Hinweis | Bitte und Verbot | 6 |
| Tiere | Hund | 9 |
| Tiere | Katze | 1 |
| Tiere | Tiere allgemein | 2 |

| Reihe | Designs |
| --- | --- |
| TSUV-A · UV Acryl | 12 |
| TSK-S · Gravur Schiefer Knochen | 10 |
| TSBUV-AD · UV Alu-Dibond | 6 |
| TSFUV-AD · UV Alu-Dibond | 4 |
| TSHUV-AD · UV Alu-Dibond | 3 |

## Regeln

- Eigene Motive dieser Designs bleiben beim Design (keine Übernahme in `motive/`).
- Alte Größen sind nur dokumentiert (`sizesInStock`); welche Größen die Linie künftig hat, entscheidet der Nutzer.
- Texte sind Beispieltexte des Bestands (Kundenfelder im Konfigurator); Schriften sind die im Bestand verwendeten – Ersatz für nicht freigegebene Schriften folgt je Linie.
- Lücken: Designs ohne lesbaren Text (`offen`) stammen aus reinen Bildpaketen; dort hilft nur Sichtprüfung über `preview.png`.
