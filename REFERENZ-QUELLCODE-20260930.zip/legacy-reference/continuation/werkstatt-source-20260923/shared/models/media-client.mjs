// Same-origin read-only catalog. Files are loaded only when requested by the editor.
export function createMediaClient({base='/api/media',fetcher=fetch,createUrl=blob=>URL.createObjectURL(blob),revokeUrl=url=>URL.revokeObjectURL(url)}={}){
 if(!/^\/[a-zA-Z0-9/_-]+$/.test(base)||base.startsWith('//'))throw Error('Medienkatalog muss zur eigenen Anwendung gehören.');
 const jobs=new Map(),urls=new Set();let disposed=false;
 async function request(path){if(disposed)throw Error('Medienkatalog wurde geschlossen.');const response=await fetcher(path,{credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('Medien konnten nicht geladen werden. Bitte erneut versuchen.');return response;}
 function key(ref){if(!ref||!/^media-[a-f0-9-]{36}$/i.test(ref.mediaId)||!/^revision-[a-f0-9-]{36}$/i.test(ref.revisionId))throw Error('Ungültige Medienrevision.');return ref.mediaId+'/'+ref.revisionId;}
 return Object.freeze({
  async list(input={}){const query=new URLSearchParams();for(const [k,v] of Object.entries(input))query.set(k,String(v));return (await request(base+'?'+query)).json();},
  load(ref){
   const id=key(ref);if(jobs.has(id))return jobs.get(id);
   const job=(async()=>{
    const item=await (await request(base+'/'+id)).json();
    if(item.mediaId!==ref.mediaId||item.revisionId!==ref.revisionId||!item.previewable||!['image/png','image/jpeg','image/webp'].includes(item.mimeType)||!Number.isFinite(item.width)||item.width<=0||!Number.isFinite(item.height)||item.height<=0||!Number.isSafeInteger(item.byteLength)||item.byteLength<=0||item.byteLength>50*1024*1024||!/[a-f0-9]{64}/.test(item.sha256)||item.sha256.length!==64)throw Error('Medienbeschreibung ist ungültig.');
    const response=await request(base+'/'+id+'/content');
    if(response.headers.get('content-type')?.split(';')[0]!==item.mimeType)throw Error('Bildformat stimmt nicht mit der Medienrevision überein.');
    const chunks=[];let length=0;
    if(response.body?.getReader){const reader=response.body.getReader();try{while(true){const result=await reader.read();if(result.done)break;length+=result.value.byteLength;if(length>item.byteLength)throw Error('Bildgröße stimmt nicht mit der Medienrevision überein.');chunks.push(result.value);}}catch(error){await reader.cancel();throw error;}finally{reader.releaseLock();}}
    else{const buffer=new Uint8Array(await response.arrayBuffer());length=buffer.byteLength;chunks.push(buffer);}
    if(length!==item.byteLength)throw Error('Bilddatei ist unvollständig.');
    const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
    const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
    if(digest!==item.sha256)throw Error('Bildinhalt stimmt nicht mit der gespeicherten Revision überein.');
    if(disposed)throw Error('Medienkatalog wurde geschlossen.');
    const url=createUrl(new Blob([bytes],{type:item.mimeType}));urls.add(url);
    return {mediaId:item.mediaId,revisionId:item.revisionId,label:item.label,role:item.role,mimeType:item.mimeType,width:item.width,height:item.height,url};
   })().catch(error=>{jobs.delete(id);throw error;});jobs.set(id,job);return job;
  },
  dispose(){disposed=true;for(const url of urls)revokeUrl(url);urls.clear();jobs.clear();}
 });
}
