# Oval ab 12x4 – Lieferform 2 (edelstahl-gravur-oval-120x40)

Quelle: Bögen TO-V2A-12x4, TO-V2A-24x8 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**53 Designs**, davon 1 mit Produktionsfassung, 6 mit Themenvorschlag (unsicher), 0 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TO-V2A-12x4 | GR-ES-EL-120X40-T15 | 53 | 20 | 1 | 0 |
| TO-V2A-24x8 | GR-ES-EL-240X80-T15 | 53 | 20 | 0 | 0 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TO-V2A-12x4-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-12x4-D2 | Zwei Zeilen, versetzt | D2 Niedermeier | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-12x4-D3 | Zwei Zeilen mit Trennlinie | D3 Schäfer | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-12x4-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-12x4-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-12x4-D6 | Familie mit Anker | D6 Erdmann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-12x4-D7 | Hier wohnt Familie mit Segelboot | D7 Fischer | familienschilder, namensschilder |  | 2 |  | Great Vibes, Montserrat Light |  |  |
| TO-V2A-12x4-D8 | Zwei Vornamen und Nachname mit Leuchtturm | D8 Kerstin & Ralf Meyer | familienschilder, namensschilder |  | 2 |  | Ashley, Cinzel |  | „Heimathafen …“: Zeilenabstand 5.5 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original) |
| TO-V2A-12x4-D9 | Vor- und Nachname mit Leuchtturm | D9 Charlotte Groner | familienschilder, namensschilder |  | 2 |  | Homage, Raleway |  |  |
| TO-V2A-12x4-D10 | Zwei Vornamen und Nachname mit Laubbaum | D10 Altmann | familienschilder, namensschilder |  | 2 |  | Comfortaa |  |  |
| TO-V2A-12x4-D12 | Herzlich Willkommen bei Familie mit Pusteblume | D12 Bohlmann | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Homage, Raleway |  |  |
| TO-V2A-12x4-D20 | Familie mit Lebensbaum, Serifenschrift | D20 Familie | familienschilder, namensschilder |  | 2 |  | Libre Baskerville | ja |  |
| TO-V2A-12x4-D22 | Familie mit Haus-Skizze, Serifenschrift | D22 Schmittberger | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TO-V2A-12x4-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 2 |  | Rochester |  |  |
| TO-V2A-12x4-D24 | Zuhause von Familie mit Haus und Herz | D24 Familie Hellwig | familienschilder, namensschilder |  | 2 |  | Homage, Raleway |  |  |
| TO-V2A-12x4-D25 | Hier wohnt Familie mit Haus und Herz | D25 Goldmann | familienschilder, namensschilder |  | 2 |  | Allura, Cinzel |  |  |
| TO-V2A-12x4-D26 | Vor- und Nachname mit Glocke | D26 Zimmermann | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-12x4-D27 | Zwei Vornamen und Nachname mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 2 |  | Michroma |  |  |
| TO-V2A-12x4-D29 | Herzlich Willkommen bei Familie mit Hundewelpe und Hundename | D29 Familie Kuhlmann | familienschilder, namensschilder, hundeschilder, willkommensschilder |  | 2 |  | Ashley, Raleway |  |  |
| TO-V2A-12x4-D30 | Familie mit Hundekopf und Hundename | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 2 |  | Raleway |  |  |
| TO-V2A-12x4-D31 | Zuhause von Familie mit Hund-Silhouette | D31 Familie Fischer | familienschilder, namensschilder, hundeschilder |  | 2 |  | Ashley, Cinzel |  |  |
| TO-V2A-12x4-D32 | Familie mit Pfote und Hundename, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 2 |  | Homage, Michroma |  |  |
| TO-V2A-12x4-D33 | Familie mit Pfoten und Hundename | D33 mit Lucky | familienschilder, namensschilder, hundeschilder |  | 2 |  | Cinzel, Tangerine |  |  |
| TO-V2A-12x4-D34 | Familie mit Katze und Katzenname, Serifenschrift | D34 Albrecht | familienschilder, namensschilder, katzenschilder |  | 2 |  | Allura, Libre Baskerville |  |  |
| TO-V2A-12x4-D35 | Hier leben – zwei Vornamen und Nachname mit Katze und Katzenname | D35 mit Oskar | familienschilder, namensschilder, katzenschilder |  | 2 |  | Michroma, Sweetie |  |  |
| TO-V2A-12x4-D37 | Vor- und Nachname mit Unendlichkeitszeichen | D37 Hannah Ludwig | familienschilder, namensschilder |  | 2 |  | Great Vibes |  |  |
| TO-V2A-12x4-D38 | Zwei Namen mit Herzen, Schreibschrift | D38 Olivia Sander | familienschilder, namensschilder | hochzeitsschilder | 2 |  | Italianno |  |  |
| TO-V2A-12x4-D42 | Nachname mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 2 |  | Homage |  |  |
| TO-V2A-12x4-D43 | Familie mit Taubenpaar, Serifenschrift | D43 Familie Krone | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TO-V2A-12x4-D44 | Zwei Vornamen und Nachname mit Vogelpaar im Herz | D44 Ruprecht | familienschilder, namensschilder | hochzeitsschilder | 2 |  | Allura, Raleway |  |  |
| TO-V2A-12x4-D45 | Hier wohnt Vor- und Nachname mit Vogel | D45 König | familienschilder, namensschilder |  | 2 |  | Cinzel, Rochester |  |  |
| TO-V2A-12x4-D46 | Familie mit Vogelpaar auf Zweig | D46 Vogel | familienschilder, namensschilder |  | 2 |  | Ashley, Raleway |  |  |
| TO-V2A-12x4-D47 | Herzlich Willkommen bei Vor- und Nachname mit Vogel auf Zweig | D47 Carla Sonneburg | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Sweetie |  |  |
| TO-V2A-12x4-D48 | Familie mit Schmetterlingen | D48 Schumacher | familienschilder, namensschilder |  | 2 |  | Allura, Raleway |  |  |
| TO-V2A-12x4-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 2 |  | Ashley |  |  |
| TO-V2A-12x4-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 2 |  | Ashley, Montserrat Light |  |  |
| TO-V2A-12x4-D54 | Familie mit Lilie, Serifenschrift | D54 Kampmann | familienschilder, namensschilder |  | 2 |  | Libre Baskerville |  |  |
| TO-V2A-12x4-D55 | Hier wohnt Familie mit Schnörkel und Herz | D55 Hier wohnt | familienschilder, namensschilder |  | 2 |  | Allura, Montserrat Light |  |  |
| TO-V2A-12x4-D56 | Familie mit Schnörkel-Ornament | D56 Familie | familienschilder, namensschilder |  | 2 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TO-V2A-12x4-D57 | Familie mit Herz-Ranken-Ornament | D57 Pielstädt | familienschilder, namensschilder |  | 2 |  | Cinzel, Italianno |  | Text „Pielstädt“ um 0.0/-0.8 mm nach innen (Textkasten stand über) |
| TO-V2A-12x4-D58 | Familie mit Herzranke | D58 Schreinert | familienschilder, namensschilder |  | 2 |  | Comfortaa, Dancing Script |  |  |
| TO-V2A-12x4-D59 | Zwei Vornamen und Nachname mit Rosen-Ornament | D59 Langhagen | familienschilder, namensschilder |  | 2 |  | Italianno |  |  |
| TO-V2A-12x4-D60 | Familie mit Ornament und Spruch | D60 Familie Hampel | familienschilder, namensschilder, willkommensschilder |  | 2 |  | Allura, Cinzel |  |  |
| TO-V2A-12x4-D61 | Nachname mit Zweigen und Herz | D61 Kampmann | familienschilder, namensschilder |  | 2 |  | Sweetie |  |  |
| TO-V2A-12x4-D62 | Familie mit Schlüssel und Linie | D62 Schielmann | familienschilder, namensschilder |  | 2 |  | Fineliner Script, Raleway |  | Schrift ohne Datei im Katalog: Fineliner Script |
| TO-V2A-12x4-D65 | Hier wohnt Familie mit Vornamen und Herzen | D65 Familie Wegner | familienschilder, namensschilder |  | 2 |  | Homage, Raleway |  |  |
| TO-V2A-12x4-D66 | Mr. & Mrs. mit Herzen und Nachname | D66 Westermann | familienschilder, namensschilder, hochzeitsschilder |  | 2 |  | Raleway |  |  |
| TO-V2A-12x4-D67 | Initialen mit Ringen und Nachname | D67 Trautmann | familienschilder, namensschilder, hochzeitsschilder |  | 2 |  | Antic Slab, Great Vibes |  |  |
| TO-V2A-12x4-D68 | Familie mit Pfeil nach links | D68 Familie Reimer | familienschilder, namensschilder | hinweisschilder | 2 |  | Michroma |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TO-V2A-12x4-D69 | Familie mit Pfeil nach rechts, Serifenschrift | D69 Maier | familienschilder, namensschilder | hinweisschilder | 2 |  | Libre Baskerville |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TO-V2A-12x4-D70 | Zwei Vornamen und Nachname mit Pfeil nach oben | D70 Mükmann | familienschilder, namensschilder | hinweisschilder | 2 |  | Cinzel, Italianno |  |  |
| TO-V2A-12x4-D71 | Familie mit Pfeil nach unten | D71 Kleester | familienschilder, namensschilder | hinweisschilder | 2 |  | Comfortaa |  |  |
| TO-V2A-12x4-D73 | Kein Eingang mit STOP | D73 Kein | hinweisschilder |  | 2 |  | Lato, Libre Baskerville |  |  |

## Schriften ohne Datei im Katalog

- Fineliner Script: 2 Designs (TO-V2A-12x4-D56, TO-V2A-12x4-D62)
