"""Extract local font outlines, copy unchanged preview assets, keep photo source original."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'acrylic-python-deps'))
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
import json,shutil,hashlib
HERE=Path(__file__).resolve().parent
root=HERE.parents[1]
out=root/'designs/acrylic-unser-anfang'
out.mkdir(parents=True,exist_ok=True)
fonts={}
for label,filename in [('Garamond Acryl','GARA.TTF'),('Freestyle Acryl','FREESCPT.TTF')]:
    font=TTFont(Path('C:/Windows/Fonts')/filename);glyphset=font.getGlyphSet();cmap=font.getBestCmap();glyphs={}
    for point,glyph in cmap.items():
        if point<32 or point>383:continue
        pen=SVGPathPen(glyphset);glyphset[glyph].draw(pen)
        glyphs[chr(point)]={'a':font['hmtx'][glyph][0],'d':pen.getCommands()}
    fonts[label]={'regular':{'units':font['head'].unitsPerEm,'glyphs':glyphs}}
# Native vector symbols corresponding to the simple pin and heart in the source.
motifs=[{'key':'acryl-heart','name':'Herz','category':'Liebe','bounds':[0,0,24,24],'svgFragment':'<path d="M12 22L3 13C-6 3 7 -3 12 5C17 -3 30 3 21 13Z" fill="currentColor" fill-rule="nonzero"/>'},
{'key':'acryl-pin','name':'Ort','category':'Symbole','bounds':[0,0,24,32],'svgFragment':'<path d="M12 32C8 24 0 17 0 12C0 -4 24 -4 24 12C24 17 16 24 12 32ZM12 6C4 6 4 18 12 18C20 18 20 6 12 6Z" fill="currentColor" fill-rule="evenodd"/>'}]
(out/'resources.json').write_text(json.dumps({'fonts':fonts,'motifs':motifs},ensure_ascii=False),encoding='utf-8')
original=Path(r'C:\Users\Mikail Erdem\Downloads\ChatGPT-Bild 29. Sept. 2026, 09_43_55.png')
shutil.copy2(original,out/'reference.png')
assets=root.parent/'acrylic-implementation-assets'
for source in assets.glob('*.png'):shutil.copy2(source,out/source.name)
(out/'source.json').write_text(json.dumps({'sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'source':str(original)}),encoding='utf-8')
print('Resources ready; original photo kept unchanged; preview assets separate from print.')
