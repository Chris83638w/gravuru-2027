import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {prepareConfig} from './contract.mjs';
import {profileForProduct} from '../../automation/product-pipeline/lib/core.mjs';
import {PROCESSING_PROFILES,MATERIAL_COLORS} from '../../platform/sources/app/shared/models/processing-profiles.mjs';
import {localAssistant,GUIDES} from './help.mjs';
import {makeLocalPilot} from './local-pilot.mjs';
import {makeAcrylicConfig} from './acrylic-product.mjs';
import {measureText} from '../../platform/sources/app/shared/models/doorbell-preview.mjs';
export const HERE=path.dirname(fileURLToPath(import.meta.url));
export const ROOT=path.resolve(HERE,'../..');
export const OUTPUT=path.join(HERE,'.preview');
const read=file=>JSON.parse(fs.readFileSync(path.join(ROOT,file),'utf8').replace(/^\uFEFF/,''));
export function build({pilotPath,outputDirectory=OUTPUT}={}){
  // Immutable inputs are checked against their existing inventory, not a refreshed baseline.
  const inventory=read('designs/aosu-labrador/RESOURCE-INVENTORY.json');
  for(const item of inventory){
    const bytes=fs.readFileSync(path.join(ROOT,item.path));
    if(bytes.length!==item.bytes||createHash('sha256').update(bytes).digest('hex')!==item.sha256)throw Error('Referenz-Prüfsumme abweichend: '+item.path);
  }
  const baseline=read('references/aosu-upgrade-2026-09-21/verification/profile-source.json');
  baseline.designs.unshift(read('designs/aosu-labrador/design.json'));
  baseline.features.orderEnabled=false;baseline.features.productionConfirmed=false;
  baseline.binding={kind:'local-review',productId:null};
  for(const v of baseline.purchasing.variants)v.variantId=null;
  const job=read('automation/product-pipeline/jobs/hunde-gedenktafeln.json');
  const universal=prepareConfig({profile:profileForProduct(job,job.products[0].productId,job.products[0].handle),basePriceCents:job.basePriceCents,extraMotifCents:job.extraMotifCents,photo:{enabled:true,mode:'upload-only'}});
  const compat=structuredClone(baseline);
  compat.designs=universal.profile.designs;compat.purchasing.basePriceCents=universal.basePriceCents;
  compat.purchasing.bellModel=universal.profile.name;
  compat.geometry={...compat.geometry,bell:{x:-1000,y:-1000,width:0,height:0},bellImageBounds:{x:-1000,y:-1000,width:0,height:0},cutPaths:[]};
  const models=[{key:'aosu',name:'AOSU Pro · Labrador',legacy:baseline,universal:null},
    {key:'schiefer',name:'Schiefer · 30 × 20 cm · Fotoupload',legacy:compat,universal}];
  // Explicitly unbound material specimens: no copied Shopify product IDs or invented product prices.
  for(const processing of PROCESSING_PROFILES.filter(p=>p.id!=='slate-engraving')){
    const sample=structuredClone(universal),p=sample.profile;
    p.id='materialdemo-'+processing.id;p.revision='ux-materialdemo-20260924';p.name=processing.name+' · Materialdemo';
    p.binding={kind:'local-review',productId:'local-'+processing.id};p.optionGroups=[];
    p.processing={profileId:processing.id};p.material.kind=processing.materialKind||'other';p.material.color=MATERIAL_COLORS[p.material.kind];
    p.designs=[{...structuredClone(p.designs[0]),name:'Materialprobe',objects:p.designs[0].objects.filter(o=>o.type!=='photoSlot'&&!o.id.endsWith('-photo-frame')).map(o=>({...o,text:o.type==='text'?'Dein Text':o.text,customerEditable:true}))}];
    sample.photo={enabled:false,mode:'upload-only'};sample.logo={enabled:true};sample.demo=true;sample.basePriceCents=0;
    const legacySample=structuredClone(compat);legacySample.designs=p.designs;legacySample.purchasing.basePriceCents=0;legacySample.purchasing.bellModel=p.name;
    models.push({key:processing.id,name:p.name,legacy:legacySample,universal:prepareConfig(sample)});
  }
  if(pilotPath){
    const bundle=JSON.parse(fs.readFileSync(pilotPath,'utf8').replace(/^\uFEFF/,''));
    const pilot=prepareConfig(makeLocalPilot(bundle,universal)),legacy=structuredClone(compat);
    legacy.designs=pilot.profile.designs;legacy.purchasing.basePriceCents=0;legacy.purchasing.bellModel=pilot.profile.name;
    models.push({key:'d201',name:pilot.profile.name,legacy,universal:pilot});
  }
  const acrylicDir=path.join(ROOT,'designs/acrylic-unser-anfang');
  if(fs.existsSync(path.join(acrylicDir,'resources.json'))){
    const resources=JSON.parse(fs.readFileSync(path.join(acrylicDir,'resources.json'),'utf8'));
    const sourceInfo=JSON.parse(fs.readFileSync(path.join(acrylicDir,'source.json'),'utf8'));
    const acrylic=makeAcrylicConfig(universal,resources,sourceInfo.sha256);
    for(const o of acrylic.profile.designs[0].objects.filter(o=>o.type==='text')){measureText(o,resources.fonts);if(o.id==='names'){o.size*=118/o.w;measureText(o,resources.fonts);}}
    const acrylicLegacy=structuredClone(compat);acrylicLegacy.designs=acrylic.profile.designs;acrylicLegacy.purchasing.basePriceCents=1499;acrylicLegacy.purchasing.bellModel=acrylic.profile.name;
    models.push({key:'acryl',name:acrylic.profile.name,legacy:acrylicLegacy,universal:prepareConfig(acrylic)});
  }
  fs.mkdirSync(outputDirectory,{recursive:true});
  fs.writeFileSync(path.join(outputDirectory,'assistant.js'),localAssistant(fs.readFileSync(path.join(ROOT,'platform/sources/assistant/static/gravuru-chat.js'),'utf8')));
  fs.writeFileSync(path.join(outputDirectory,'guides.json'),JSON.stringify({enabled:true,guides:GUIDES,account_url:'https://gravuru-design.myshopify.com/account'}));
  fs.writeFileSync(path.join(outputDirectory,'models.json'),JSON.stringify(models));
  let source=fs.readFileSync(path.join(ROOT,'references/aosu-upgrade-2026-09-21/verification/editor-source.html'),'utf8');
  function replaceOnce(from,to){if(source.split(from).length!==2)throw Error('M-Anker ist nicht eindeutig: '+from.slice(0,90));source=source.replace(from,to);}
  const urls=JSON.parse(source.match(/<script[^>]*id="preview-urls"[^>]*>([\s\S]*?)<\/script>/)[1]);
  for(const [key,value] of Object.entries(urls))urls[key]=Array.isArray(value)?value.map(u=>'/_runtime/'+u.split('/').pop()):'/_runtime/'+value.split('/').pop();
  source=source.replace(/(<script[^>]*id="preview-urls"[^>]*>)[\s\S]*?(<\/script>)/,(_,a,b)=>a+JSON.stringify(urls)+b);
  replaceOnce('<base href="/" target="_top">','<base href="/" target="_self">');
  // The internal editor belongs to its immediate workshop host. Shopify may wrap
  // that host in a cross-origin frame, and private runtime assets need its cookie.
  source=source.replaceAll('window.top','window.parent')
    .replaceAll("credentials:'omit'","credentials:'same-origin'")
    .replaceAll('credentials:"omit"','credentials:"same-origin"');
  replaceOnce("let shown=16,signature='',compareSignature='';","let shown=Number.MAX_SAFE_INTEGER,signature='',compareSignature='';");
  replaceOnce("shown=6;renderGallery();","shown=Number.MAX_SAFE_INTEGER;renderGallery();");
  replaceOnce("render();grid.children[firstNew]?.focus({preventScroll:true});","render();");
  replaceOnce("const filtered=all.filter(e=>(!category.value||e.category===category.value)&&(!needle||(e.name+' '+e.category).toLocaleLowerCase('de').includes(needle)));",
    "const score=e=>el.uxMotifScore?el.uxMotifScore(e,needle):(!needle||(e.name+' '+e.category).toLocaleLowerCase('de').includes(needle)?1:0);const filtered=all.filter(e=>(!category.value||e.category===category.value)&&score(e)>0).sort((a,b)=>score(b)-score(a));");
  // Embedded PDF fonts may contain only the source glyphs. Keep the font picker usable.
  replaceOnce("const family=el.fontData[object.font],face=family[object.bold?'bold':'regular'];","const family=el.fontData[object.font],face=family[object.bold?'bold':'regular']||family.regular;");
  replaceOnce("const glyph=face.glyphs[ch]||face.glyphs['?'];","const glyph=face.glyphs[ch]||face.glyphs['?']||{d:'',a:face.units*.5};");
  replaceOnce('const all=[...entries,...original],categories=',
    'const all=[...entries,...original].filter(e=>!window.GravuruTemplateOnlyMotifKeys?.has(e.key)),categories=');
  replaceOnce('await customElements.whenDefined(\'gravuru-configurator\');',
    "const adapter=await import('/configurator/variant-m/adapter.mjs');if(window.parent.UniversalConfig)adapter.installUniversal(window.parent.UniversalConfig);await customElements.whenDefined('gravuru-configurator');");
  replaceOnce('prepareMotifGeometry(entries);',
    'if(!window.parent.UniversalConfig){Object.assign(catalog.fonts,window.parent.LabradorFonts);entries.unshift(window.parent.LabradorMotif);}const localResources=window.parent.UniversalConfig?.localResources;if(localResources)Object.assign(catalog.fonts,localResources.fonts);prepareMotifGeometry(entries);if(localResources)entries.unshift(...localResources.motifs);window.GravuruTemplateOnlyMotifKeys=new Set((localResources?.motifs||[]).filter(m=>m.embeddedOnly===true||localResources.motive_in_bibliothek===false).map(m=>m.key));window.GravuruMotifCategories=entries.filter(e=>!window.GravuruTemplateOnlyMotifKeys.has(e.key)).map(({key,name,category})=>({key,name,category}));');
  replaceOnce('await mount(form.value);',
    "await mount(form.value);const specimen=host.querySelector('gravuru-configurator');if(!window.parent.UniversalConfig){specimen.chooseDesign('FK-LABRADOR-MICHROMA-01');adapter.hardenDoorbell(specimen);}specimen.$('[data-setting=guides]').checked=false;specimen.cfg.orderEnabled=false;specimen.cfg.demo=true;specimen.sync();const ux=await import('/configurator/variant-m/ux.mjs');await ux.installUX(specimen,window.parent.UniversalConfig,window.parent.GravuruModelProfile);");
  for(const item of read('designs/aosu-labrador/image-source-verification.json'))source=source.replaceAll(item.url,'/_runtime/images/'+item.name);
  fs.writeFileSync(path.join(outputDirectory,'editor.html'),source);
  return {verifiedResources:inventory.length,models:models.length,editorBytes:Buffer.byteLength(source)};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(build()));
