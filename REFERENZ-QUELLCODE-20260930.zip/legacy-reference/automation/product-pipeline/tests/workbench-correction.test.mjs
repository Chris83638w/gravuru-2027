import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {Workbench,defaultProduct,availableFonts} from '../workbench.mjs';
import {roundDesign,fitObject,editorTextSize} from '../../../configurator/variant-m/design-edit.mjs';
import {checkDesign} from '../workbench-checks.mjs';
import {measureText} from '../../../platform/sources/app/shared/models/doorbell-preview.mjs';

test('Gedrehte Texte werden mit echten Schriftmaßen und zwei Dezimalstellen eingepasst',()=>{
 const fonts=availableFonts(),o={id:'text',type:'text',text:'Längerer Name',font:'Open Sans',size:32.12999,x:219.9954,y:140.0001,w:3,h:4,rotation:23.1271,bold:false};measureText(o,fonts);
 const fitted=fitObject(o,{width:220,height:140});assert(Object.values(fitted).filter(v=>typeof v==='number').every(v=>Math.abs(v*100-Math.round(v*100))<1e-8));
 assert.deepEqual(checkDesign({id:'ROUND',name:'Rundung',marks:[],objects:[fitted]},fonts,defaultProduct()),[]);
 assert.equal(roundDesign({objects:[{...o,x:147.10561}]}).objects[0].x,147.11);assert.equal(editorTextSize(4.25),4.25);assert.equal(editorTextSize(2.55),2.55);
});

test('Aktuelle PDF wird ersetzt, Vorgänger erhalten und editierbare Texte wieder eingelesen',{skip:!process.env.GRAVURU_PDF_PYTHON},async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'gravuru-correction-')),w=new Workbench({root}),p=w.create({...defaultProduct(),description:'Test',basePrice:29.99});
 const design={id:'ROUNDTRIP',name:'Arbeitsfassung',marks:[],objects:[{id:'name',type:'text',text:'Cooper',font:'Open Sans',bold:false,size:9,x:110,y:30,w:40,h:10,rotation:0},{id:'photo',type:'photoSlot',photoShape:'rect',fieldKey:'photo-test',required:true,x:60,y:80,w:50,h:65,rotation:0}]};
 const bundle={schema:'gravuru-pdf-import/v1',geometry:{width:220,height:140},design,resources:{scope:'local-review-only',fonts:{'Open Sans':availableFonts()['Open Sans']},motifs:[]},errors:[],issues:[]};
 const dir=path.join(w.dir(p.id),'imports','source');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'1.json'),JSON.stringify(bundle));p.designs=[{id:design.id,importId:'source',page:1,source:'original.pdf',errors:[],issues:[],fonts:['Open Sans'],objects:2}];w.save(p,1);
 let result=await w.changeWithPdf(p.id,design.id,{expectedRevision:2,action:'edit',design});assert(!result.workingPdfError,result.workingPdfError);const first=w.workingPdfInfo(p.id,design.id);assert(first);
 design.objects.push({id:'anchor',type:'motif',motif:'import-59b5854feb26a2bf2754a477',x:180,y:95,w:15,h:20,rotation:0});design.objects[0].text='Buddy\nFür immer';design.objects[0].size=10.25555;
 result=await w.changeWithPdf(p.id,design.id,{expectedRevision:3,action:'edit',design});assert(!result.workingPdfError,result.workingPdfError);const current=w.workingPdfInfo(p.id,design.id);assert.equal(first.path,current.path);assert.notEqual(first.sha256,current.sha256);assert(fs.existsSync(path.join(w.dir(p.id),'pdf-verlauf',design.id,'3.pdf')));
 assert.equal(fs.readdirSync(path.dirname(current.path)).filter(f=>f.endsWith('.pdf')).length,1);
 const second=w.create({...defaultProduct(),description:'Zweites Produkt',basePrice:29.99}),bytes=fs.readFileSync(current.path),imported=await w.upload(second.id,{expectedRevision:1,name:'ROUNDTRIP.pdf',base64:bytes.toString('base64')});
 const restored=w.bundle(second.id,imported.product.designs[0]).design;assert.equal(restored.id,design.id);assert.equal(restored.objects[0].text,'Buddy\nFür immer');assert.equal(restored.objects[0].size,10.26);assert.equal(restored.objects[1].type,'photoSlot');assert.equal(w.bundle(second.id,imported.product.designs[0]).resources.motifs.length,1);assert.deepEqual(imported.product.designs[0].errors,[]);
 assert((await w.upload(p.id,{expectedRevision:4,name:'ROUNDTRIP.pdf',base64:bytes.toString('base64')})).duplicate);
 await w.changeWithPdf(p.id,design.id,{expectedRevision:4,action:'delete'});assert.equal(w.workingPdfInfo(p.id,design.id),null);assert(!fs.existsSync(current.path));
 await w.changeWithPdf(p.id,design.id,{expectedRevision:5,action:'restore'});assert(w.workingPdfInfo(p.id,design.id));
});

