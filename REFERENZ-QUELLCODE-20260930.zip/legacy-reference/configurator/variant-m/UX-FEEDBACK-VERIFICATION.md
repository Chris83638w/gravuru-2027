# Variante M: große feste Vorschau, Ausrichtung und Auswahlflächen

Stand: 25.09.2026. Lokale Umsetzung auf `feat/variante-m-profile-20260924`.
Ausgangscommit: `6c396e785abb21b89133c8d10acc34e7caa9648b`.
Diese Rückmeldungen ersetzen die bisherigen Angaben zu Canvasüberschrift,
Design-Scrollbalken, kleiner Produktminiatur und Position der Hilfewerkzeuge.

## Abgestimmter Umfang

- Beim ersten und erneuten Öffnen: kein Objekt ausgewählt, Optionen geöffnet.
  Der vorhandene Sitzungsentwurf bleibt beim erneuten Öffnen desselben Produkts erhalten.
- Mobile Produktminiatur 2,4-mal so groß: Bildfläche von 43 × 49 auf
  103,2 × 117,6 CSS-Pixel. Der feste Bereich ist 132 px hoch; die Reiter folgen
  darunter. Antippen öffnet Vollbild. Der Regler im normalen Canvas bleibt erhalten.
- Keine Überschrift „Klingelschild personalisieren“. Vollbild mit kürzerem Abstand
  zwischen Hinweis und Produkt. Desktop bleibt zweispaltig.
- Rückgängig, Wiederholen und Hilfe links im Canvas über den Hilfslinien;
  Maßbeschriftung, Werkzeugreihe und Hilfslinien liegen getrennt.
- Drehen oberhalb, Löschen direkt am ausgewählten Element; vier Skaliergriffe bleiben.
- Hilfslinien zeigen Textmittelpunkte und Ausrichtungsanker. Die neue Ziehbedienung
  verwendet wieder den vorhandenen Snap-Algorithmus (Mitte und Kanten anderer
  sichtbarer Objekte). Hilfslinien werden nur in der Bearbeitungsansicht ergänzt.
- „Text mittig ausrichten“ ist im Textbereich auch ohne ausgewählte Zeile erreichbar.
- Schriftliste mit Überschriften „Dein Text“ / „Schriftname“ und kurzer Erklärung.
- „Bestseller Motive“ zunächst geschlossen. Mehr/Weniger ohne Pfeile.
- Designauswahl mit Verlauf am unteren Rand und „Alle anzeigen (Anzahl)“.
  Erweiterte Liste wächst mit der Seite, kein eigener Scrollbalken. Abgeschnittene
  Karten sind bis zum Erweitern nicht per Tastatur erreichbar.
- Foto-/Logofläche mit Artwahl, Dateiauswahl, Ablegen per Drag-and-drop und Miniaturen.
  Hochgeladene Bilder werden sofort übernommen. Bearbeiten, Ersetzen, rotes Entfernen.
  Dateiauswahl und Drop verwenden dieselben Grenzen: insgesamt vier, je 9,99 EUR,
  JPG/PNG/WebP bis 15 MB und maximal 40 Megapixel. Bei vier Dateien verständlicher Hinweis.
- UV-Druck: zwölf Standardfarben, acht Pastellfarben und eigener Farbwähler für Text,
  Motive, Gestaltungslinien und Logos. Fotos bleiben in ihren Originalfarben.
  Logos können zwischen einfarbiger Vorschau und Originalfarben wechseln.
- Native `preserveColors`-Eigenschaft nur für Motive; Logo-Vorschau nutzt eigenen
  lokalen Entwurfswert `uxLogoTint`. Dadurch keine falsche Validierungsfehlermeldung
  beim Färben von Text oder Logos. Lokale Logos tragen Upload-IDs statt erfundener
  veröffentlichter Medienreferenzen; Produktionsvalidator und Freigabe unverändert.

## In dieser Runde tatsächlich geprüft

Chromium/In-App-Browser an `http://127.0.0.1:8947/`:

- AOSU, 390 × 844: Einstieg ohne Auswahl, Optionen aktiv; kein unnötiger Titel,
  Produkt komplett, Maße von Werkzeugen getrennt, Hilfe links oberhalb Hilfslinien.
- 17 Designs über Verlauf/„Alle anzeigen“ öffnen und wieder reduzieren. Bestseller
  anfänglich geschlossen, Bezeichnung und pfeillose Mehr-Schaltflächen geprüft.
- Text auswählen, Plus betätigen (13 mm); feste Miniatur mit tatsächlich 117,6 px
  SVG-Höhe kontrolliert. Antippen öffnet die große Vorschau.
- Direkte Löschtaste entfernt „Müller“; Rückgängig stellt den Text wieder her.
- Hilfslinien mit Textankern sichtbar. Reale Zeigerbewegung bei ausgewähltem Text
  nach unten mit leichtem seitlichem Versatz: Mittelpunkt rastet bei x = 80 mm ein.
- Verlassen und erneutes Öffnen desselben Produkts: Optionen und keine Auswahl,
  vorhandene Gestaltung bleibt erhalten.
- Foto über echten Dateidialog geladen, Miniatur sichtbar und Preis 49,99 → 59,98 EUR.
  Verwendet wurde nur die vorhandene Repository-Klingel-PNG, kein Kundenfoto.
- UV-Profil: Text auf Rot gesetzt; gerenderter SVG-Füllwert `#c93232`, keine
  Validierungsmeldung. Standard- und Pastellpalette sowie eigener Farbwähler sichtbar.
- UV-Logo über Dateidialog geladen, Rosé gewählt; korrekte RGB-Werte in SVG-Filter
  geprüft. „Originalfarben verwenden“ entfernt diesen Filter, weiterhin keine Warnung.
- Schriftliste visuell auf Mobil geprüft: Kundentext links, Schriftname rechts.
- Vollbild visuell mit korrektem Zurück-Button und engem Abstand zum Produkt geprüft.
- 1280 × 960: Vorschau links, Bedienung rechts. Browserkonsole ohne neue Fehler.

Automatisch: 52 Tests erfolgreich; drei neue Regressionstests für Farbtypen,
Originalfarben/Entwurfsflags und lokale Logo-Referenzen. Build prüft unverändert
104 Originalressourcen per SHA-256. `git diff --check` ohne Fehler.

```powershell
node --test configurator/variant-m/contract.test.mjs configurator/variant-m/ux.test.mjs configurator/variant-m/image-processing.test.mjs configurator/variant-m/usability.test.mjs automation/product-pipeline/tests/pipeline.test.mjs
node configurator/variant-m/build.mjs
```

## Grenzen

- Browser bei Mobilmaßen, kein physischer Smartphone- oder Safari/iOS-Nachweis.
  Dateiablage per realem Betriebssystem-Drag-and-drop nicht separat ausgeführt;
  Dateidialog geprüft, gemeinsame Grenzprüfung automatisiert abgedeckt.
- Einfarbige Rasterlogos verwenden die vorhandene luminanzbasierte Maske:
  Weiß wird transparent, dunkle Bereiche erhalten die gewählte Farbe. Keine neue
  Vektorisierung oder professionelle Freistell-API, Originaldateien bleiben erhalten.
- Bestellen, dauerhafte Kontospeicherung, geschützte Uploads, PNG nach Kauf und
  Produktionsdaten sind weiterhin nicht verbunden. Der Warenkorb bleibt deaktiviert.
  Lokale Farbdarstellung ist kein Nachweis eines Farbmanagement-/Fertigungsworkflows.
- Mindestgröße 4 nominale Schriftmillimeter in ganzen Schritten und Randabstand
  0 mm aus der vorherigen Runde bleiben bestehen; keine neue Produktgeometrie,
  Preise, Profil-IDs oder Shopify-Zuordnungen. Keine Änderungen an Main/Shopify/Plesk.
- Fremdes unversioniertes `products/` nicht aufgenommen. Aufgabenbranch separat sichern.

Nächster Schritt: Christopher prüft die überarbeitete Bedienung am eigenen Smartphone.

