# Daniel

Lizenz laut Nutzerliste (Schriftarten-Uebersicht-Lizenz, 30.09.2026): Daniel Midgley – frei, auch kommerziell.
Datei übernommen am 17.10.2026 aus dem Schriftenordner des Nutzers (`_fpd_pr_fonts`, Fancy-Product-Designer-Bestand der WooCommerce-Seite), Originalname `Daniel Bold.ttf`.
Lizenztext nicht beigelegt – bei Bedarf vom Anbieter nachreichen.

**Hinweis:** gefunden wurde nur der Schnitt *Bold*; Regular und Black fehlen noch.
