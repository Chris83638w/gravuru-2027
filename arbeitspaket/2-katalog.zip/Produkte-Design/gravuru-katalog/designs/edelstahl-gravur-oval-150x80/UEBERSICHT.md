# Oval ab 15x8 – Lieferform 2 (edelstahl-gravur-oval-150x80)

Quelle: Bögen TO-V2A-15x8 (`designs/bestand/boegen/`), Familie `steel-door-signs`. Master je Designnummer aus dem kleinsten Bogen mit grüner Überschrift, 1:1 auf die Familiengröße übertragen. Erzeugt mit `scripts/build-design-reihe.py` (Repo gravuru-2027); Namen/Themen aus `zuordnung.json`.

**64 Designs**, davon 0 mit Produktionsfassung, 6 mit Themenvorschlag (unsicher), 0 zu prüfen.

| Bogen | Familiengröße | grün | rot | Produktion | Doppel abweichend |
| --- | --- | --- | --- | --- | --- |
| TO-V2A-15x8 | GR-ES-OV-150X80-T15 | 64 | 9 | 0 | 0 |

| Design | Name | Bogenname | Themen | Vorschlag | Größen | nicht wählbar | Schriften | Prod. | Hinweise |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TO-V2A-15x8-D1 | Zwei Zeilen, mittig | D1 Rosenberg | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D2 | Zwei Zeilen, versetzt | D2 Niedermeier | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D3 | Zwei Zeilen mit Trennlinie | D3 Schäfer | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D4 | Zwei Zeilen, versetzt mit Linie | D4 Hoffmann | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D5 | Zwei Zeilen mit Zierlinien | D5 Schneider | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D6 | Familie mit Anker | D6 Erdmann | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D7 | Hier wohnt Familie mit Segelboot | D7 Familie Fischer | familienschilder, namensschilder |  | 1 |  | Great Vibes, Montserrat Light |  |  |
| TO-V2A-15x8-D8 | Zwei Vornamen und Nachname mit Leuchtturm | D8 Meyer | familienschilder, namensschilder |  | 1 |  | Ashley, Cinzel |  | „Heimathafen …“: Zeilenabstand 8.5 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original) |
| TO-V2A-15x8-D9 | Vor- und Nachname mit Leuchtturm | D9 Groner | familienschilder, namensschilder |  | 1 |  | Homage, Raleway |  |  |
| TO-V2A-15x8-D10 | Zwei Vornamen und Nachname mit Laubbaum | D10 Altmann | familienschilder, namensschilder |  | 1 |  | Comfortaa |  |  |
| TO-V2A-15x8-D12 | Herzlich Willkommen bei Familie mit Pusteblume | D12 Bohlmann | familienschilder, namensschilder, willkommensschilder |  | 1 |  | Homage, Raleway |  |  |
| TO-V2A-15x8-D13 | Familie mit Pusteblume, Serifenschrift | D13 Neumann | familienschilder, namensschilder |  | 1 |  | Cinzel, Homage |  |  |
| TO-V2A-15x8-D17 | Hier wohnt Familie mit Blütenranke | D17 Schneider | familienschilder, namensschilder |  | 1 |  | Cinzel, Italianno |  |  |
| TO-V2A-15x8-D18 | Zwei Namen mit Pusteblume | D18 Felix Becker | familienschilder, namensschilder |  | 1 |  | Allura |  |  |
| TO-V2A-15x8-D19 | Herzlich Willkommen bei Vor- und Nachname mit Rose | D19 Ursel Mayer | familienschilder, namensschilder, willkommensschilder |  | 1 |  | Bellefair, Great Vibes |  |  |
| TO-V2A-15x8-D20 | Familie mit Lebensbaum, Serifenschrift | D20 Neumann | familienschilder, namensschilder |  | 1 |  | Libre Baskerville |  |  |
| TO-V2A-15x8-D21 | Familie mit Sonne, Spruch und Vornamen | D21 Familie Lehmann | familienschilder, namensschilder |  | 1 |  | Comic Sans MS, Daniel |  | „Hier leben, …“: Zeilenabstand 11.0 mm statt 1,2 × Größe – je Zeile ein Textfeld (Lage wie im Original); Schrift ohne Datei im Katalog: Comic Sans MS; Schrift ohne Datei im Katalog: Comic Sans MS |
| TO-V2A-15x8-D22 | Familie mit Haus-Skizze, Serifenschrift | D22 Schmittberger | familienschilder, namensschilder |  | 1 |  | Libre Baskerville |  |  |
| TO-V2A-15x8-D23 | Vor- und Nachname mit Haus | D23 Vanessa | familienschilder, namensschilder |  | 1 |  | Rochester |  |  |
| TO-V2A-15x8-D24 | Zuhause von Familie mit Haus und Herz | D24 Zuhause von | familienschilder, namensschilder |  | 1 |  | Homage, Raleway |  |  |
| TO-V2A-15x8-D25 | Hier wohnt Familie mit Haus und Herz | D25 Goldmann | familienschilder, namensschilder |  | 1 |  | Allura, Cinzel |  |  |
| TO-V2A-15x8-D26 | Vor- und Nachname mit Glocke | D26 Zimmermann | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D27 | Zwei Vornamen und Nachname mit Briefumschlag | D27 Meier | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D28 | Vor- und Nachname mit Fußball | D28 Schulze | familienschilder, namensschilder |  | 1 |  | Michroma |  |  |
| TO-V2A-15x8-D29 | Herzlich Willkommen bei Familie mit Hundewelpe und Hundename | D29 Familie | familienschilder, namensschilder, hundeschilder, willkommensschilder |  | 1 |  | Ashley, Raleway |  |  |
| TO-V2A-15x8-D30 | Familie mit Hundekopf und Hundename | D30 Berendt | familienschilder, namensschilder, hundeschilder |  | 1 |  | Raleway |  |  |
| TO-V2A-15x8-D31 | Zuhause von Familie mit Hund-Silhouette | D31 Familie Fischer | familienschilder, namensschilder, hundeschilder |  | 1 |  | Ashley, Cinzel |  |  |
| TO-V2A-15x8-D32 | Familie mit Pfote und Hundename, Schreibschrift | D32 Berger | familienschilder, namensschilder, hundeschilder |  | 1 |  | Homage, Michroma |  |  |
| TO-V2A-15x8-D33 | Familie mit Pfoten und Hundename | D33 Wegner | familienschilder, namensschilder, hundeschilder |  | 1 |  | Cinzel, Sweetie |  |  |
| TO-V2A-15x8-D34 | Willkommen bei Familie mit Katze und Katzenname | D34 Familie Albrecht | familienschilder, namensschilder, katzenschilder, willkommensschilder |  | 1 |  | Ashley, Libre Baskerville |  |  |
| TO-V2A-15x8-D35 | Hier leben – zwei Vornamen und Nachname mit Katze und Katzenname | D35 mit Oskar | familienschilder, namensschilder, katzenschilder |  | 1 |  | Michroma, Sweetie |  |  |
| TO-V2A-15x8-D36 | Familie mit Schnörkel-Ornament und Spruch | D36 Jäger | familienschilder, namensschilder |  | 1 |  | Libre Baskerville |  |  |
| TO-V2A-15x8-D37 | Vor- und Nachname mit Unendlichkeitszeichen | D37 Hannah | familienschilder, namensschilder |  | 1 |  | Great Vibes |  |  |
| TO-V2A-15x8-D38 | Zwei Namen mit Herzen, Schreibschrift | D38 Olivia Sander | familienschilder, namensschilder | hochzeitsschilder | 1 |  | Italianno |  |  |
| TO-V2A-15x8-D39 | Herzlich Willkommen bei Familie mit Schnörkel-Herz | D39 Herzlich Willkommen | familienschilder, namensschilder, willkommensschilder |  | 1 |  | Great Vibes |  |  |
| TO-V2A-15x8-D40 | Willkommen bei Vor- und Nachname mit Eule | D40 Willkommen | familienschilder, namensschilder, willkommensschilder |  | 1 |  | Dancing Script |  |  |
| TO-V2A-15x8-D41 | Familie mit Kolibri | D41 Vogel | familienschilder, namensschilder |  | 1 |  | Ashley, Raleway |  |  |
| TO-V2A-15x8-D42 | Vor- und Nachname mit Vogel, Schreibschrift | D42 Vogel | familienschilder, namensschilder |  | 1 |  | Homage, Montserrat Light |  |  |
| TO-V2A-15x8-D43 | Familie mit Taubenpaar, Serifenschrift | D43 Familie Krone | familienschilder, namensschilder |  | 1 |  | Libre Baskerville |  |  |
| TO-V2A-15x8-D44 | Zwei Vornamen und Nachname mit Vogelpaar im Herz | D44 Ruprecht | familienschilder, namensschilder | hochzeitsschilder | 1 |  | Allura, Raleway |  |  |
| TO-V2A-15x8-D45 | Hier wohnt Vor- und Nachname mit Vogel | D45 König | familienschilder, namensschilder |  | 1 |  | Cinzel, Rochester |  |  |
| TO-V2A-15x8-D46 | Herzlich Willkommen bei Vor- und Nachname mit Vogel auf Zweig | D46 Carla Sonneburg | familienschilder, namensschilder, willkommensschilder |  | 1 |  | Sweetie |  |  |
| TO-V2A-15x8-D47 | Familie mit Vogelpaar auf Zweig | D47 Vogel | familienschilder, namensschilder |  | 1 |  | Ashley, Raleway |  |  |
| TO-V2A-15x8-D48 | Familie mit Schmetterlingen | D48 Schumacher | familienschilder, namensschilder |  | 1 |  | Allura, Raleway |  |  |
| TO-V2A-15x8-D52 | Familie mit Herzen, Schreibschrift | D52 Familie | familienschilder, namensschilder |  | 1 |  | Ashley |  |  |
| TO-V2A-15x8-D53 | Zwei Vornamen und Nachname mit Herz | D53 Schmitt | familienschilder, namensschilder |  | 1 |  | Ashley, Montserrat Light |  |  |
| TO-V2A-15x8-D54 | Familie mit Lilie, Serifenschrift | D54 Kampmann | familienschilder, namensschilder |  | 1 |  | Libre Baskerville |  |  |
| TO-V2A-15x8-D55 | Hier wohnt Familie mit Schnörkel und Herz | D55 Hier wohnt | familienschilder, namensschilder |  | 1 |  | Allura, Montserrat Light |  |  |
| TO-V2A-15x8-D56 | Familie mit Schnörkel-Ornament | D56 Familie | familienschilder, namensschilder |  | 1 |  | Fineliner Script |  | Schrift ohne Datei im Katalog: Fineliner Script; Schrift ohne Datei im Katalog: Fineliner Script |
| TO-V2A-15x8-D57 | Familie mit Herz-Ranken-Ornament | D57 Pielstädt | familienschilder, namensschilder |  | 1 |  | Cinzel, Italianno |  |  |
| TO-V2A-15x8-D58 | Familie mit Herzranke und Spruch | D58 Feldkamp | familienschilder, namensschilder |  | 1 |  | Comfortaa, Italianno |  |  |
| TO-V2A-15x8-D59 | Zwei Vornamen und Nachname mit Rosen-Ornament | D59 Langhagen | familienschilder, namensschilder |  | 1 |  | Italianno |  |  |
| TO-V2A-15x8-D60 | Familie mit Ornament und Spruch | D60 Willkommen bei uns | familienschilder, namensschilder, willkommensschilder |  | 1 |  | Allura, Cinzel |  |  |
| TO-V2A-15x8-D61 | Zwei Vornamen und Nachname mit Zweigen und Herz | D61 Kampmann | familienschilder, namensschilder |  | 1 |  | Montserrat Light, Sweetie |  |  |
| TO-V2A-15x8-D62 | Familie mit Schlüssel und Linie | D62 Schielmann | familienschilder, namensschilder |  | 1 |  | Fineliner Script, Raleway |  | Schrift ohne Datei im Katalog: Fineliner Script |
| TO-V2A-15x8-D63 | Familie mit Wimpelkette, Serifenschrift | D63 Poller | familienschilder, namensschilder |  | 1 |  | Allura |  |  |
| TO-V2A-15x8-D65 | Hier wohnt Familie mit Vornamen und Herzen | D65 Familie Wegner | familienschilder, namensschilder |  | 1 |  | Homage, Raleway |  |  |
| TO-V2A-15x8-D66 | Mr. & Mrs. mit Herzen und Nachname | D66 Westermann | familienschilder, namensschilder, hochzeitsschilder |  | 1 |  | Raleway |  |  |
| TO-V2A-15x8-D67 | Initialen mit Ringen und Nachname | D67 Trautmann | familienschilder, namensschilder, hochzeitsschilder |  | 1 |  | Antic Slab, Great Vibes |  |  |
| TO-V2A-15x8-D68 | Familie mit Pfeil nach links | D68 Familie Reimer | familienschilder, namensschilder | hinweisschilder | 1 |  | Michroma |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TO-V2A-15x8-D69 | Familie mit Pfeil nach rechts, Serifenschrift | D69 Maier | familienschilder, namensschilder | hinweisschilder | 1 |  | Libre Baskerville |  | foto-1: Flächenform vom Bogenleser als Fotoplatzhalter gedeutet – als Motiv übernommen (Gravur ohne Foto) |
| TO-V2A-15x8-D70 | Zwei Vornamen und Nachname mit Pfeil nach oben | D70 Mükmann | familienschilder, namensschilder | hinweisschilder | 1 |  | Cinzel, Italianno |  |  |
| TO-V2A-15x8-D71 | Familie mit Pfeil nach unten | D71 Kleester | familienschilder, namensschilder | hinweisschilder | 1 |  | Comfortaa |  |  |
| TO-V2A-15x8-D73 | Kein Eingang mit STOP | D73 Kein | hinweisschilder |  | 1 |  | Lato, Libre Baskerville |  |  |

## Schriften ohne Datei im Katalog

- Comic Sans MS: 1 Designs (TO-V2A-15x8-D21)
- Fineliner Script: 2 Designs (TO-V2A-15x8-D56, TO-V2A-15x8-D62)
