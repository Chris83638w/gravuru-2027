import {createHash} from 'node:crypto';

// Server only: authenticated request is injected. Never install a Shopify token
// in the browser. GenericFile deliberately avoids Shopify image transforms;
// MediaStore verifies the returned public bytes against the original SHA-256.
export const SHOPIFY_MEDIA_OPERATIONS = Object.freeze({
  "FIND": "query GravuruMediaFind($query:String!){files(first:100,query:$query){nodes{__typename id alt fileStatus ... on GenericFile{url}} pageInfo{hasNextPage}}}",
  "STAGE": "mutation GravuruMediaStage($input:[StagedUploadInput!]!){stagedUploadsCreate(input:$input){stagedTargets{url resourceUrl parameters{name value}} userErrors{field message}}}",
  "CREATE": "mutation GravuruMediaCreate($files:[FileCreateInput!]!){fileCreate(files:$files){files{__typename id alt fileStatus ... on GenericFile{url}} userErrors{field message code}}}",
  "STATUS": "query GravuruMediaStatus($id:ID!){node(id:$id){... on GenericFile{__typename id alt fileStatus url}}}"
});
const EXTENSIONS=Object.freeze({'image/png':'png','image/jpeg':'jpg','image/webp':'webp','image/svg+xml':'svg','application/pdf':'pdf','application/json':'json','font/ttf':'ttf','font/otf':'otf','font/woff':'woff','font/woff2':'woff2','audio/mpeg':'mp3','audio/mp4':'m4a'});
const hash=v=>createHash('sha256').update(v).digest('hex');
function fail(message,code='MEDIA_UPLOAD_UNCERTAIN'){const e=Error(message);e.code=code;return e;}
function identity({idempotencyKey,sha256,mimeType}){
 if(typeof idempotencyKey!=='string'||!idempotencyKey.trim()||idempotencyKey.length>500||!/^[a-f0-9]{64}$/.test(sha256)||!Object.hasOwn(EXTENSIONS,mimeType))throw fail('Ungültige Medienidentität oder nicht unterstützter Dateityp.','MEDIA_INPUT_INVALID');
 const key=hash(idempotencyKey),filename='gravuru-media-'+sha256+'-'+key+'.'+EXTENSIONS[mimeType];
 return {filename,marker:'gravuru-media/v1/'+key+'/'+sha256};
}
function secureURL(value,predicate){
 let u;try{u=new URL(value);}catch{throw fail('Ungültige Shopify-Dateiadresse.','MEDIA_HOST_REJECTED');}
 if(u.protocol!=='https:'||u.username||u.password||u.port||!predicate(u))throw fail('Nicht erlaubte Shopify-Dateiadresse.','MEDIA_HOST_REJECTED');
 return u;
}
function defaultStageHost(u){
 return u.hostname==='shopify-staged-uploads.storage.googleapis.com'
 ||(u.hostname==='storage.googleapis.com'&&u.pathname.startsWith('/shopify-staged-uploads/'));
}
function checkErrors(payload){if(payload?.userErrors?.length)throw fail(payload.userErrors.map(e=>e.message).join(' · '),'SHOPIFY_USER_ERROR');}
export function createShopifyMediaAdapter({request,fetcher=fetch,target='shopify-files',wait=ms=>new Promise(r=>setTimeout(r,ms)),maxPolls=20,pollIntervalMs=500,requestTimeoutMs=30000,stageHostAllowed=defaultStageHost}={}){
 if(typeof request!=='function'||typeof fetcher!=='function'||target!=='shopify-files'||!Number.isInteger(maxPolls)||maxPolls<1||maxPolls>120||!Number.isFinite(pollIntervalMs)||pollIntervalMs<0||pollIntervalMs>10000||!Number.isFinite(requestTimeoutMs)||requestTimeoutMs<1)throw Error('Ungültige Shopify-Medienadapter-Einstellungen.');
 const inFlight=new Map();
 async function query(operation,variables){
  // A timeout never retries a mutation: it is an uncertain remote result.
  let timer;try{
   const response=await Promise.race([request(operation,variables),new Promise((_,reject)=>{timer=setTimeout(()=>reject(fail('Shopify-Antwort ist noch unklar.')),requestTimeoutMs);})]);
   if(response?.errors?.length)throw fail('Shopify konnte die Medienoperation nicht bestätigen.');
   return response?.data||response;
  }finally{clearTimeout(timer);}
 }
 function result(file,ident){
  if(file?.__typename!=='GenericFile'||!/^gid:\/\/shopify\/GenericFile\/\d+$/.test(file.id||'')||file.alt!==ident.marker)throw fail('Shopify-Datei passt nicht zur Medienidentität.');
  if(file.fileStatus==='FAILED')throw fail('Shopify-Dateiverarbeitung ist fehlgeschlagen.','MEDIA_PROCESSING_FAILED');
  if(file.fileStatus!=='READY')return null;
  const u=secureURL(file.url,u=>u.hostname==='cdn.shopify.com');
  if(decodeURIComponent(u.pathname.split('/').pop())!==ident.filename)throw fail('Shopify hat den Dateinamen unerwartet verändert.');
  return {remoteId:file.id,url:u.href};
 }
 async function ready(initial,ident){
  let file=initial;
  for(let n=0;n<=maxPolls;n++){
   const resolved=result(file,ident);if(resolved)return resolved;
   if(n===maxPolls)break;
   await wait(pollIntervalMs);
   file=(await query(SHOPIFY_MEDIA_OPERATIONS.STATUS,{id:file.id}))?.node;
  }
  throw fail('Shopify verarbeitet diese Datei noch. Später abgleichen, nicht erneut hochladen.');
 }
 async function find(ident){
  const conn=(await query(SHOPIFY_MEDIA_OPERATIONS.FIND,{query:'filename:"'+ident.filename+'"'}))?.files;
  if(!Array.isArray(conn?.nodes)||conn.pageInfo?.hasNextPage!==false)throw fail('Die vorhandenen Shopify-Dateien konnten nicht eindeutig abgeglichen werden.');
  // Shopify filename search may tokenize; exact metadata and final basename
  // provide identity even while PROCESSING has no URL yet.
  const matches=conn.nodes.filter(f=>f.alt===ident.marker||(f.url&&(()=>{try{return decodeURIComponent(new URL(f.url).pathname.split('/').pop())===ident.filename;}catch{return false;}})()));
  if(matches.length>1)throw fail('Mehrere Shopify-Dateien entsprechen dieser Medienidentität.','MEDIA_AMBIGUOUS');
  return matches.length?ready(matches[0],ident):null;
 }
 async function uploadOnce(input){
  const ident=identity(input),bytes=input.bytes;
  if(!(bytes instanceof Uint8Array)||!bytes.byteLength||hash(bytes)!==input.sha256)throw fail('Originaldatei stimmt nicht mit ihrer Prüfsumme überein.','MEDIA_INPUT_INVALID');
  const existing=await find(ident);if(existing)return existing;
  const staged=(await query(SHOPIFY_MEDIA_OPERATIONS.STAGE,{input:[{resource:'FILE',filename:ident.filename,mimeType:input.mimeType,fileSize:String(bytes.byteLength),httpMethod:'POST'}]}))?.stagedUploadsCreate;
  checkErrors(staged);
  if(staged?.stagedTargets?.length!==1)throw fail('Shopify hat kein eindeutiges Uploadziel bereitgestellt.');
  const stage=staged.stagedTargets[0];
  secureURL(stage.url,stageHostAllowed);secureURL(stage.resourceUrl,stageHostAllowed);
  if(!Array.isArray(stage.parameters)||stage.parameters.some(p=>typeof p.name!=='string'||typeof p.value!=='string'||p.name==='file'))throw fail('Ungültige Shopify-Uploadparameter.');
  const body=new FormData();
  for(const p of stage.parameters)body.append(p.name,p.value);
  body.append('file',new Blob([bytes],{type:input.mimeType}),ident.filename);
  const response=await fetcher(stage.url,{method:'POST',body,redirect:'error',signal:AbortSignal.timeout(requestTimeoutMs)});
  if(!response.ok)throw fail('Shopify-Dateiupload wurde nicht bestätigt.');
  let created;
  try{
   created=(await query(SHOPIFY_MEDIA_OPERATIONS.CREATE,{files:[{originalSource:stage.resourceUrl,filename:ident.filename,contentType:'FILE',duplicateResolutionMode:'RAISE_ERROR',alt:ident.marker}]}))?.fileCreate;
   checkErrors(created);
   if(created?.files?.length!==1)throw fail('Shopify-Dateianlage wurde nicht eindeutig bestätigt.');
  }catch(error){
   // Includes duplicate-name races and a lost fileCreate response. Never issue
   // another create here, even when search indexing has not caught up yet.
   const recovered=await find(ident);if(recovered)return recovered;
   throw fail('Shopify-Dateianlage ist unklar: '+error.message);
  }
  return ready(created.files[0],ident);
 }
 return Object.freeze({target,
  async reconcile(input){return find(identity(input));},
  upload(input){
   const ident=identity(input),key=ident.filename;
   if(inFlight.has(key))return inFlight.get(key);
   const promise=uploadOnce(input).finally(()=>inFlight.delete(key));
   inFlight.set(key,promise);return promise;
  }
 });
}

