# Bestand.xlsm – Produktregister (Server, gelesen 17.10.2026)

1326 Größenzeilen in 33 Produkten. Flaggen 1 = im alten System erledigt (Produktbilder / Fancy-Konfigurator / Amazon / Import).

| Produkt | Größen | Verfahren | Materialien | Fancy fertig | Amazon fertig |
| --- | --- | --- | --- | --- | --- |
| Adventskalender | 10 |  |  | 0 | 5 |
| Anhänger | 67 | Ostereier Anhänger, Tannenbaum Anhänger | Acryl, Acryl klar, Holz | 4 | 1 |
| Autoanhänger | 28 | Gravur, UV | Acryl, Holz | 28 | 22 |
| Blumenstecker | 10 | Herbst |  | 7 | 0 |
| Boxenschilder | 20 | Gravur, UV | Acryl | 18 | 16 |
| Briefkasten | 1 | Gravur |  | 1 | 1 |
| CakeTopper | 4 | Gravur, UV |  | 1 | 1 |
| Firmenschilder | 45 | Gravur, UV |  | 38 | 24 |
| Flachmann | 6 |  |  | 2 | 0 |
| Frühstücksbrettchen | 2 | Gravur, UV |  | 2 | 1 |
| Gedenkstandbilder | 42 | Gravur, UV | Acryl, Holz | 38 | 23 |
| Gedenktafeln | 59 | Gravur, UV | Herz | 51 | 36 |
| GedenktafelnSternenkinder | 6 | Gedenktafeln Sternenkinder |  | 3 | 1 |
| Grabstecker | 154 | Gravur, UV | Edelstahl, [Feste Design], [Feste Designs] | 36 | 101 |
| Grillzange | 1 | Holz |  | 1 | 0 |
| Hausnummern | 130 | Gravur, Holz Ausschnitt, UV | Acryl, Acryl + Edelstahl, Edelstahl, Edelstahl + Acryl, Holz + Edelstahl, Rechteckig, Schiefer, _mit Bohrlöchern | 87 | 92 |
| Hinweisschilder | 24 | Gravur, \Gravur\, \Gravur\Vorsicht Hund\ | Acryl, Edelstahl, Kunststoff, Oval, Rechteckig, Rund, [Archiv] | 15 | 16 |
| Hochzeitsschilder | 31 | Gravur | Acryl, Edelstahl, Kunststoff | 25 | 25 |
| HundeEcke | 4 | Über Eck 60x60 |  | 0 | 2 |
| Kalender | 3 | UV | 2 (31 Tage) | 0 | 0 |
| Kordelschilder | 41 | Gravur, UV | Acryl, Holz, Schiefer | 35 | 33 |
| Kreuze | 12 | Gravur, UV | Acryl, Holz | 7 | 3 |
| Messlatten | 6 |  |  | 1 | 1 |
| Monogramme | 2 | Vatertag |  | 0 | 0 |
| Namenschilder | 102 | Gravur, UV | Acryl, Acryl auf Edelstahl, Acryl+Edelstahl, Edelstahl, Holz, Schwarz klar, Schwarz satiniert | 86 | 84 |
| Schlüsselanhänger | 65 | Gravur, UV | Acryl, Clipart Pärchen, Holz, Leder, Rund, Song Cover | 47 | 36 |
| Standbilder | 65 | Gravur, UV | Acryl, Holz, Holz1 | 46 | 34 |
| Tierschilder | 13 | UV |  | 13 | 11 |
| Tierzubehör | 30 | Hundemarken | DogTag, Herz, Knochen, Partner, Pfote, Rund | 0 | 19 |
| Türklingel | 48 | \Funkklingeln\, \Funkklingeln\Acryl + Edelstahl\ | Abgerundete Ecken, Ausschnitt | 0 | 0 |
| Türschilder | 165 | Gravur, UV | Acryl, Acryl + Edelstahl, Edelstahl, Holz, Kunststoff | 29 | 133 |
| Untersetzer | 2 | Pilz, Rund |  | 0 | 1 |
| Wandbilder | 128 | Clipart, Collagen, Fingerabdruck, Gaming, Kalender, Kinder, Maps, Muttertag, Netflix, Personalisiert, Song Cover, Sternzeichen, Typo, Vatertag, Weltkarte, Whatsapp |  | 108 | 103 |

## Größen je Produkt, Verfahren und Material

### Adventskalender
- **–** · – · –: 27x41 (Baum)°, 30x15°, 30x20°, 30x24 (Landschaft)°, 30x27,5 (Geweih)°, 27x41 (Baum)°, 30x15°, 30x20°, 30x24 (Landschaft)°, 30x27,5 (Geweih)°

### Anhänger
- **Ostereier Anhänger** · UV · Acryl: 6x8, 7.5x10
- **Ostereier Anhänger** · UV · Holz: 6x8, 7.5x10°
- **Tannenbaum Anhänger** · Gravur · Acryl: 8°, 8x10,5 Schleife°
- **Tannenbaum Anhänger** · Gravur · Acryl klar: 8°, 8x10,5 Schleife°
- **Tannenbaum Anhänger** · UV · Acryl: 8°, 8x10,5 Schleife°
- **Tannenbaum Anhänger** · UV · Holz: 6, 8x10,5 Schleife°, 8x8 Herz°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10°, 6x6°, 8x8°, 10x10 a°, 6x6 a°, 8x8°

### Autoanhänger
- **Gravur** · Acryl · –: 4.7x7 Kreuz, 6.6x6.5 Blume, 7x7 Herz, 7x7 Raute, 7x7.5 Engel
- **Gravur** · Acryl Klar Satiniert · –: 4.7x7 Kreuz, 6.6x6.5 Blume, 7x7 Herz, 7x7 Raute, 7x7.5 Engel
- **Gravur** · Holz · –: 4.7x7 Kreuz, 6.6x6.5 Blume, 7x7 Herz, 7x7 Raute, 7x7.5 Engel
- **Gravur** · Leder · –: 4.7x7 Kreuz, 6.6x6.5 Blume, 7x7 Herz, 7x7 Raute, 7x7.5 Engel
- **Gravur** · Mit Ausschnitt · Acryl: 4.7x7 Kreuz
- **Gravur** · Mit Ausschnitt · Holz: 4.7x7 Kreuz
- **UV** · Holz · –: 4.7x7 Kreuz, 6.6x6.5 Blume, 7x7 Herz, 7x7 Raute, 7x7.5 Engel
- **UV** · Mit Ausschnitt · Acryl: 4.7x7 Kreuz

### Blumenstecker
- **Herbst** · Blatt 1 · –: 18x35
- **Herbst** · Blatt 2 · –: 16x38
- **Herbst** · Eichhörnchen · –: 13x38,7, 16x38,7°
- **Herbst** · Igel · –: 16x32,5, 19x32,5°
- **Herbst** · Pilz · –: 15x38,7, 17x38,7°
- **Herbst** · Rund · –: 16x40, 19x40

### Boxenschilder
- **Gravur** · Acryl · –: 30x20
- **Gravur** · Acryl + Edelstahl · –: 30x20
- **Gravur** · Edelstahl · –: 15x8, 30x20
- **Gravur** · Kunststoff · –: 30x20
- **Gravur** · Schiefer · –: 30x20
- **Gravur** · Silhouetten · Acryl: 14x15, 18x15, 19x25, 20x18.5, 25x24, 26x19, 32x24.5
- **UV** · Acryl · –: 20x30, 30x20
- **UV** · Acryl+Edelstahl · –: 30x20
- **UV** · Aludibond · –: 20x30, 30x20°
- **UV** · Holz · –: 30x20°
- **UV** · Schiefer · –: 30x20

### Briefkasten
- **Gravur** · Acryl · –: 33x16

### CakeTopper
- **Gravur** · Acryl · –: 12.5x23°
- **UV** · Acryl · –: 10x17.4°, 12x20°, 6x12.3

### Firmenschilder
- **Gravur** · Acryl · –: 18x12, 20x15, 20x20, 22x22, 26x26, 28x28, 30x20, 30x30, 40x30, 40x40
- **Gravur** · Acryl+Edelstahl · –: 18x12, 20x15, 20x20, 22x22, 23x12 (evtl. Raus), 30x20, 30x30, 40x30, 40x40
- **Gravur** · Edelstahl · –: 16x16°, 18x12, 20x15°, 20x20, 22x22, 30x20°, 30x30, 40x30°, 40x40
- **Gravur** · Schiefer · –: 16x16, 20x15°, 20x20, 20x30, 22x22, 25x20, 30x20°, 30x30, 40x20, 40x30°, 60x30
- **UV** · Acryl · –: 16x16, 16x20, 20x16, 23x12, 40x30, 50x30

### Flachmann
- **–** · – · –: 9.5x10.5, 9.5x12°, 9.5x8.5, 9.5x10.5°, 9.5x12°, 9.5x8.5°

### Frühstücksbrettchen
- **Gravur** · – · –: 22.5x15
- **UV** · – · –: 20x13

### Gedenkstandbilder
- **Gravur** · Infinity · Acryl: 20x8.5, 30x12.5
- **Gravur** · Infinity Foto · Acryl: 30x12.5
- **Gravur** · Infinity Herzen · Acryl: 30x12.5
- **Gravur** · Infinity Pfoten · Acryl: 30x12.5
- **Gravur** · Raute · –: 21x17.5
- **Gravur** · Standbogen · Acryl: 10x15, 10x16
- **Gravur** · Standfiguren · Acryl: 12x13.5, 16x18, 18.5x19, 18.5x20.5, 20.5x17, 20x15.5, 22x13.5, 8x9
- **Gravur** · Standherzen · Acryl: 14x14°, 18x13°, 18x18, 26x19°
- **Gravur** · Standherzen - Gebogen · Acryl: 14x28,5, 18x28,5
- **Gravur** · Standherzen - Spitz · Acryl: 14x28,5, 18x28
- **UV** · Infinity · Acryl: 30x12.5
- **UV** · Infinity · Holz: 30x12.5
- **UV** · Infinity Foto · Acryl: 30x13
- **UV** · Infinity Foto · Holz: 20x8.5, 30x12.5
- **UV** · Infinity Herzen · Acryl: 30x13
- **UV** · Infinity Herzen · Holz: 30x13
- **UV** · Infinity Pfoten · Acryl: 30x12.5°
- **UV** · Infinity Pfoten · Holz: 30x12.5
- **UV** · Standbogen · Acryl: 10x15
- **UV** · Standbogen · Holz: 10x16
- **UV** · Standfiguren · Acryl: 12x13.5, 18.5x20.5, 8x9
- **UV** · Standherz · Acryl: 14x14, 18x13
- **UV** · Standherz · Holz: 14x14, 18x13

### Gedenktafeln
- **Gravur** · Acryl · –: 20x10, 20x15, 20x16 - Herz, 20x20, 20x30, 30x20, 30x30°, 30x60, 40x20, 40x30°, 40x40, 60x30
- **Gravur** · Acryl + Edelstahl · –: 18x12, 20x10, 20x16, 22x22, 30x20, 40x30, 60x30
- **Gravur** · Edelstahl · –: 12x10.5, 20x20°, 21x10, 22x22, 30x20
- **Gravur** · Premium Schiefer · –: 20x15, 20x30, 30x20, 40x30
- **Gravur** · Schiefer · –: 16x15 - Herz, 20x10, 20x15, 20x16 - Herz, 20x20, 20x30, 25x10, 28.5x24 - Herz, 30x20, 30x60, 40x20, 40x30, 60x30
- **Gravur** · Schiefer · Herz: 18x13, 22x22, 24x19, 25x25, 26x19
- **UV** · Acryl · –: 30x20°, 40x30°
- **UV** · Acryl + Edelstahl · –: 30x20°, 40x30°
- **UV** · Edelstahl · –: 30x20
- **UV** · Granit · –: 20x15, 20x30, 30x20°, 40x30
- **UV** · Marmor · –: 20x20
- **UV** · Premium Schiefer · –: 20x30, 30x20
- **UV** · Schiefer · –: 30x20

### GedenktafelnSternenkinder
- **Gedenktafeln Sternenkinder** · – · –: 20x15, 30x20, 40x30, 20x15°, 30x20°, 40x30°

### Grabstecker
- **Gravur** · Engel · Edelstahl: 11x37,5, 16x37,5, 11x37,5, 16x37,5
- **Gravur** · Engel 2 · Edelstahl: 14x41,5, 18x41,5, 14x41,5°, 18x41,5°
- **Gravur** · Engel 3 · Edelstahl: 22x39,5, 29x39,5, 22x39,5°, 29x39,5°
- **Gravur** · Flügel · Edelstahl: 15x38°, 23x38, 15x38°, 23x38°
- **Gravur** · Herz · Edelstahl: 16x38°, 17x38°, 20x38, 16x38°, 17x38°, 20x38°
- **Gravur** · Herz liegend · Edelstahl: 16x36,5°, 21x36,5°, 16x36,5°, 21x36,5°
- **Gravur** · Herz mit Pfote · Edelstahl: 16x38°, 19,5x38°, 16x38°, 19,5x38°
- **Gravur** · Herz-Ausschnitt · Edelstahl: 15x36, 17x36, 20x36, 15x36°, 17x36°, 20x36°
- **Gravur** · Herz-Doppelrahmen · Edelstahl: 15x36, 17x36, 20x36, 15x36°, 17x36°, 20x36°
- **Gravur** · Herz-Rahmen · Edelstahl: 15x36°, 17x36°, 20x36, 15x36°, 17x36°, 20x36°
- **Gravur** · Hund · Edelstahl: 17x38,5, 21x38,5, 17x38,5°, 21x38,5°
- **Gravur** · Hund 2 · Edelstahl: 16x39, 21x39, 16x39°, 21x39°
- **Gravur** · Hund 3 - raus · Edelstahl: 16x39,5, 20x39,5, 16x39,5°, 20x39,5°
- **Gravur** · Hände · Edelstahl: 12x40, 16x40, 12x40°, 16x40°
- **Gravur** · Infinity Herzen · Edelstahl: 21x23 - alt, 23x36°, 30x36°, 21x23°, 23x36°, 30x36°
- **Gravur** · Katze · Edelstahl: 14x38,5, 17x38,5, 14x38,5°, 17x38,5°
- **Gravur** · Katze 2 · Edelstahl: 13x38, 16x38, 13x38°, 16x38°
- **Gravur** · Katze 2 - raus · Edelstahl: 11x27°
- **Gravur** · Kreuz · Edelstahl: 13x46°, 15x46°, 18x46, 13x46°, 15x46°, 18x46°
- **Gravur** · Kreuz 2 · Edelstahl: 14x29°, 19x38,5, 14x29°, 19x38,5°
- **Gravur** · Pfote · Edelstahl: 12x35,5°, 17x35,5°, 12x35,5°, 17x35,5°
- **Gravur** · Rund · Edelstahl: 16x40°, 19x40°, 16x40°, 19x40°
- **Gravur** · Stern · Edelstahl: 14x37°, 18x37, 14x37°, 18x37°
- **Gravur** · Stern 2 · Edelstahl: 22x36,5°, 29x36,5°, 22x36,5°, 29x36,5°
- **Gravur** · Wolke · Edelstahl: 17x33°, 22x33°, 17x33°, 22x33°
- **UV** · Flügel · –: 15x38°, 23x38°
- **UV** · Flügel · [Feste Designs]: 15x38°, 23x38°
- **UV** · Herz · –: 16x38°, 17x38°, 20x38°
- **UV** · Herz · [Feste Designs]: 16x38°, 17x38°, 20x38°
- **UV** · Herz liegend · –: 16x36.5, 21x36.5°
- **UV** · Herz liegend · [Feste Designs]: 16x36,5°, 21x36,5°
- **UV** · Hund · –: 17x38.5°, 21x38.5°
- **UV** · Hund · [Feste Designs]: 17x38,5°, 21x38.5°
- **UV** · Infinity Herz · –: 23x36°, 30x36°
- **UV** · Infinity Herz · [Feste Designs]: 23x36°, 30x36°
- **UV** · Katze · –: 14x38.5°, 17x38.5°
- **UV** · Katze · [Feste Design]: 14x38.5°, 17x38.5°
- **UV** · Kreuz · –: 13x46°, 15x46°, 18x46°
- **UV** · Kreuz · [Feste Designs]: 13x46°, 15x46°, 18x46°
- **UV** · Pfote · –: 12x35.5°, 17x35.5°
- **UV** · Pfote · [Feste Designs]: 12x35.5°, 17x35.5°
- **UV** · Rund · –: 16x40°, 19x40°
- **UV** · Rund · [Feste Designs]: 16x40°, 19x40°
- **UV** · Stern · –: 22x36.5
- **UV** · Wolke · –: 17x33°, 22x33
- **UV** · Wolke · [Feste Designs]: 17x33°, 22x33°

### Grillzange
- **Holz** · – · –: 32x2

### Hausnummern
- **Gravur** · 3D · Acryl + Edelstahl: 16x16, 18x12°, 20x16°, 22x22°, 25x15°, 30x20°, 40x30°
- **Gravur** · Abgerundete Ecken · Acryl: 30x8, 38x10
- **Gravur** · Acryl V2A · –: 16x16, 18x12, 18x12 x bündig, 20x16, 20x16 x bündig, 22x22, 25x15(25x13), 30x20(28x18), 30x20(30x18)
- **Gravur** · Ausschnitt · –: 16x16°, 18x12°, 20x16°, 20x30°, 22x22°, 25x15°, 30x20°, 30x30°
- **Gravur** · Ausschnitt · _mit Bohrlöchern: 16x16°, 18x12°, 20x16°, 20x30°, 22x22°, 25x15°, 30x20°, 30x30°
- **Gravur** · LED · –: 18x12°, 20x16°, 30x20°
- **Gravur** · Oval · Acryl: 22x18, 23x12, 24x15, 27x22, 32x20
- **Gravur** · Oval · Edelstahl: 21x10
- **Gravur** · Quadratisch · Acryl: 20x20
- **Gravur** · Quadratisch · Edelstahl: 16x16
- **Gravur** · Quadratisch · Schiefer: 10x10, 20x20
- **Gravur** · Rechteckig · Acryl: 20x25, 20x30°, 21x10, 24x16, 24x30, 26x13, 30x16, 30x20, 30x8, 38x10, 42x28
- **Gravur** · Rechteckig · Edelstahl: 18x12, 20x16, 20x30, 21x10, 25x15, 30x20
- **Gravur** · Rechteckig · Schiefer: 20x15, 20x30°, 20x40, 30x20, 30x40, 56x18, 60x30
- **Gravur** · Rund · Schiefer: 22x22
- **Gravur** · Schwarz satiniert+klar · –: 15x30 Bogen, 20x20, 20x25, 21x10, 22x18 halbrund, 23x12 oval, 24x15 abgerundete Seiten, 24x16, 24x30, 26x13, 27x22 halbrund, 30x16, 30x20, 30x8, 30x8 abgerundete Ecken, 32x20 abgerundete Seiten, 38x10 abgerundete Ecken, 42x28
- **Gravur** · Schwarz satiniert+klar · Rechteckig: 26x26, 30x24, 38x10
- **Holz Ausschnitt** · – · –: 16x16°, 16x20°, 20x16(18x14)°, 20x30°, 25x15°, 30x20(28x18)°, 40x30°
- **UV** · 3D · Holz + Edelstahl: 18x12°, 20x16°, 30x20°, 40x30°
- **UV** · Holz V2A · –: 18x12, 18x12 x bündig, 20x16, 20x16 x bündig, 30x20 x bündig
- **UV** · Mit Abstandshalter · Acryl: 15x30, 18x12, 20x15, 20x25, 22x22, 23x23, 30x20, 30x8, 38x10
- **UV** · Mit Abstandshalter · Edelstahl + Acryl: 16x10°, 16x5, 18x14°, 20x20, 21x10, 21x14°, 28x18°, 30x20°
- **UV** · Normal · Edelstahl + Acryl: 16x10, 18x14, 20x20, 28x18

### Hinweisschilder
- **Gravur** · Piktogramme · Oval: 12x4, 15x8, 21x12, 12x4, 15x8, 21x12_nicht skaliebar, 12x4, 15x8, 21x12
- **Gravur** · Piktogramme · Rechteckig: 12x8, 12x8, 12x8
- **Gravur** · Piktogramme · Rund: 6,5x6,5, 9x9, 9x9
- **Gravur** · Vorsicht Hund · Acryl: Personalisiert°
- **Gravur** · Vorsicht Hund · Edelstahl: Personalisiert°
- **Gravur** · Vorsicht Hund · Kunststoff: Personalisiert°
- **Gravur** · Vorsicht Hund · [Archiv]: 15x8°, 21x12°
- **\Gravur\Vorsicht Hund\** · [Archiv] · Oval: 12x4°, 15x8°
- **\Gravur\** · Vorsicht Hund · [Archiv]: 15x8°, 21x12°

### Hochzeitsschilder
- **Gravur** · Herz · Edelstahl: 22.5x19.5
- **Gravur** · Oval · Acryl: 15x8, 21x12, 21x7
- **Gravur** · Oval · Edelstahl: 15x8, 21x12, 21x7
- **Gravur** · Oval · Kunststoff: 15x8°, Schwarze Gravur, Weiße Gravur, 21x12°, Schwarze Gravur, Weiße Gravur, 21x7°, Schwarze Gravur, Weiße Gravur
- **Gravur** · Rechteckig · Acryl: 15x10
- **Gravur** · Rechteckig · Edelstahl: 15x10
- **Gravur** · Rechteckig · Kunststoff: 15x10°, Schwarze Gravur, Weiße Gravur
- **Gravur** · Retro 1 · Acryl: 9x6
- **Gravur** · Retro 1 · Edelstahl: 9x6
- **Gravur** · Retro 1 · Kunststoff: 9x6°, Schwarze Gravur, Weiße Gravur
- **Gravur** · Retro 2 · Acryl: 12x8
- **Gravur** · Retro 2 · Edelstahl: 12x8
- **Gravur** · Retro 2 · Kunststoff: 12x8°, Schwarze Gravur, Weiße Gravur

### HundeEcke
- **–** · – · –: 100x60°, 80x60°
- **Über Eck 60x60** · – · –: 100x60°, 80x60°

### Kalender
- **UV** · – · –: 40x60°, 50x75°
- **UV** · – · 2 (31 Tage): 60x40°

### Kordelschilder
- **Gravur** · Figuren · –: 20x10, 20x15, 20x20, 30x20
- **Gravur** · Herz · Schiefer: 15.2x15.2, 22.5x26.7
- **Gravur** · Quadratisch · Acryl: 20x20
- **Gravur** · Quadratisch · Schiefer: 20x20
- **Gravur** · Rechteckig · Acryl: 15x9, 20x10°, 20x15, 20x25, 30x20
- **Gravur** · Rechteckig · Schiefer: 15x9, 20x10°, 20x15, 20x25, 30x20
- **UV** · Abgerundete Ecken · –: 20x10, 20x15, 20x15 Tier 2
- **UV** · Herz · Acryl: 20x16
- **UV** · Herz · Holz: 25x20
- **UV** · Oval · Holz: 16x12
- **UV** · Rechteckig · Acryl: 12x8, 18x12, 20x10, 20x15, 20x15 Tier, 21x10, 24x16°, 30x20°
- **UV** · Rechteckig · Holz: 15x20, 19x10, 20x15, 20x15 - Herbst°, 24x15, 30x18, 30x20
- **UV** · Rund · –: 16x16, 20x20°

### Kreuze
- **Gravur** · – · –: 11x20, 22x40°, 23.5x40°, 23x33°, 27x39, 32x48, 35x50
- **UV** · Gedenk · –: 22x40°, 23x33
- **UV** · Taufe · Acryl: 10.5x15, 14.8x20°
- **UV** · Taufe · Holz: 12x20

### Messlatten
- **–** · – · –: 20x100°, 20x70°, 30x90, 20x100°, 20x70°, 30x90°

### Monogramme
- **–** · – · –: 30x20°
- **Vatertag** · Grill · –: 30x20°

### Namenschilder
- **Gravur** · Abgerundete Ecken · Acryl: 24x15, 38x10
- **Gravur** · Abgerundete Ecken · Schwarz klar: 24x15, 38x10
- **Gravur** · Abgerundete Ecken · Schwarz satiniert: 24x15, 30x8°, 38x10
- **Gravur** · Bogen · Acryl: 15x30
- **Gravur** · Bogen · Edelstahl: 15x30
- **Gravur** · Bogen · Schwarz klar: 15x30
- **Gravur** · Bogen · Schwarz satiniert: 15x30
- **Gravur** · Oval · Acryl: 22x18, 23x12, 27x22
- **Gravur** · Oval · Acryl auf Edelstahl: 15x8 (13x6), 21x10 (19x8)
- **Gravur** · Oval · Schwarz klar: 22x18, 23x12, 27x22
- **Gravur** · Oval · Schwarz satiniert: 22x18, 23x12, 27x22
- **Gravur** · Quadratisch · Acryl: 20x20
- **Gravur** · Quadratisch · Acryl auf Edelstahl: 12x12 (10x10), 16x16 (14x14), 22x22 (20x20)
- **Gravur** · Quadratisch · Schwarz klar: 20x20
- **Gravur** · Quadratisch · Schwarz satiniert: 20x20
- **Gravur** · Rechteckig · Acryl: 20x25, 21x10, 24x16, 25x20, 26x13, 30x16, 30x8, 38x10
- **Gravur** · Rechteckig · Acryl auf Edelstahl: 15x10 (13x8), 15x10 (15x8), 18x12 (16x10), 18x12 (18x10), 20x16 (18x14), 20x16 (20x14), 21x10 (19x8), 21x10 (21x8), 23x12 (21x10), 23x12 (23x10), 25x15 (23x12), 25x15 (25x13), 30x20 (28x18), 30x20 (30x18)
- **Gravur** · Rechteckig · Schwarz klar: 20x25, 21x10, 24x16, 25x20, 26x13, 30x16, 30x8, 38x10
- **Gravur** · Rechteckig · Schwarz satiniert: 21x10 (19x8), 22x27 (20x25), 23x12 (21x10)°, 23x30 (21x28)°, 26x18 (24x16), 27x22 (25x20), 28x15 (26x13), 30x8 (28x6)°, 32x10 (30x8), 32x18 (30x16), 40x12 (38x10)
- **Gravur** · _Neue Sortierung · Acryl+Edelstahl: 12x12(10x10)°, 15x10(13x8)°, 15x8(13x6) - Oval°, 16x16(14x14)°, 18x12(16x10)°, 20x16(18x14)°, 21x10(19x8)°, 21x10(19x8) - Oval°, 22x22(20x20)°, 23x12(21x10)°, 30x20(28x18)°
- **UV** · Herz · –: 25x20
- **UV** · Oval · Acryl: 23x12
- **UV** · Oval · Holz: 16x12
- **UV** · Quadratisch · Acryl: 16x16
- **UV** · Rechteckig · Acryl: 15x10, 16x20, 20x16, 23x12, 27x18, 29x15
- **UV** · Rechteckig · Acryl+Edelstahl: 16x5, 21x10, 30x20
- **UV** · Rechteckig · Holz: 15x20, 19x10, 20x15, 24x15, 30x18, 30x20
- **UV** · Rund · Holz: 16x16
- **UV** · _NEUE SORTIERUNG · –: 23x12, 29x15°

### Schlüsselanhänger
- **Gravur** · 2er · Acryl: 3,5x5°, 5x2, 6x5,5
- **Gravur** · 2er · Holz: 5x2°, 6x5.5
- **Gravur** · 2er · Leder: 5x2, 6x5.5
- **Gravur** · Anker · Acryl: 5x6
- **Gravur** · Anker · Holz: 5x6
- **Gravur** · Anker · Leder: 5x6
- **Gravur** · Blume · Acryl: 5x5
- **Gravur** · Blume · Holz: 5x5
- **Gravur** · Blume · Leder: 5x5
- **Gravur** · Engel · Acryl: 5x5.5
- **Gravur** · Engel · Holz: 5x5.5
- **Gravur** · Engel · Leder: 5x5.5
- **Gravur** · Herz · Acryl: 5x4°
- **Gravur** · Herz · Holz: 5x4
- **Gravur** · Herz · Leder: 5x4
- **Gravur** · Kalender · Acryl: 3.5x5, 4.5x5
- **Gravur** · Kalender · Holz: 3.5x5, 4.5x5
- **Gravur** · Kalender · Leder: 3.5x5, 4.5x5
- **Gravur** · Kreuz · Acryl: 3.5x5.5
- **Gravur** · Kreuz · Holz: 3.5x5.5
- **Gravur** · Kreuz · Leder: 3.5x5.5
- **Gravur** · Mit Ausschnitt · Acryl: 5x2
- **Gravur** · Mit Ausschnitt · Holz: 5x2
- **Gravur** · Mit Ausschnitt · Leder: 5x2
- **Gravur** · Oval · Acryl: 4x5.5
- **Gravur** · Oval · Holz: 4x5.5
- **Gravur** · Oval · Leder: 4x5.5
- **Gravur** · Puzzle · Acryl: 4.5x4.5, 4.5x5
- **Gravur** · Puzzle · Holz: 4.5x5
- **Gravur** · Puzzle · Leder: 4.5x4.5, 4.5x5
- **Gravur** · Rechteckig · Acryl: 3.5x5, 5x2
- **Gravur** · Rechteckig · Holz: 3.5x5, 5x2, 6x4
- **Gravur** · Rechteckig · Leder: 3.5x5, 5x2
- **Gravur** · Rund · Acryl: 5x5
- **Gravur** · Rund · Holz: 5x5
- **Gravur** · Rund · Leder: 5x5
- **UV** · Herz · –: 4.9x4.2 (5x4)°
- **UV** · Instagram · Acryl: 3.5x5°
- **UV** · Instagram · Holz: 3.5x5°
- **UV** · NFC · Rund: 4.5x5°, 4.5x5°
- **UV** · Rechteckig · Clipart Pärchen: Links°
- **UV** · Rechteckig · Song Cover: 3.75x5°, 4x5.5 (Links)°, 4x5.5 (Oben)°, 3.75x5°
- **UV** · Rund Bild · Acryl: 4.5x5°, Muttertag°, Vatertag
- **UV** · Rund Bild · Holz: 4.5x5°, 4.5x5°, 4.5x5°

### Standbilder
- **Gravur** · Geldgeschenk · Holz: Engel°, Fisch°
- **Gravur** · Infinity · Acryl: 20x8.5, 30x12.5
- **Gravur** · Infinity Foto · Acryl: 20x8.5°
- **Gravur** · Infinity Herzen · Acryl: 20x8.5, 30x12.5
- **Gravur** · Infinity Love · Acryl: 30x12.5
- **Gravur** · Raute · –: 21x17.5
- **Gravur** · Songcover · –: 15x20
- **Gravur** · Standbogen · Acryl: 10x16
- **Gravur** · Standfiguren · Acryl: 12x13.5, 16x18, 18.5x19, 18.5x20.5, 20.5x17, 20x15.5, 22x13.5, 8x9
- **Gravur** · Standherzen · Acryl: 14x14, 18x13, 18x18, 26x19
- **Gravur** · Standherzen - Gebogen · Acryl: 14x28,5, 18x28,5
- **Gravur** · Standherzen - Spitz · Acryl: 14x28,5, 18x28
- **UV** · Fuß · Acryl: 20x15
- **UV** · Fuß · Holz: 20x15
- **UV** · Geldgeschenk · Holz: Engel, Fisch
- **UV** · Infinity · Acryl: 30x12.5
- **UV** · Infinity · Holz: 30x12.5
- **UV** · Infinity Foto · Acryl: 20x8.5
- **UV** · Infinity Foto · Holz: 20x8.5
- **UV** · Infinity Herzen · Acryl: 30x13
- **UV** · Infinity Herzen · Holz: 20x8.5, 30x13
- **UV** · Infinity Love · Acryl: 30x12.5
- **UV** · Infinity Love · Holz: 20x8.5
- **UV** · Infinity Pfoten · Holz: 20x8.5
- **UV** · Kreis · Acryl: 16x16°, 25x25°
- **UV** · Netflix · –: 15x20, 20x15°, 20x30°, [Amazon-Import]°, 30x20°, [Amazon-Import]°, 40x60°, [Amazon-Import]°, 60x40°, [Amazon-Import]°
- **UV** · Songcover · Acryl: 15x20
- **UV** · Standbogen · Acryl: 10x15, 10x16°
- **UV** · Standbogen · Holz: 10x16
- **UV** · Standherz · Acryl: 14x14°, 18x13°, 18x18°, 26x19°
- **UV** · Standherz · Holz: 14x14, 18x13
- **UV** · Standherz · Holz1: 14x14, 18x13

### Tierschilder
- **UV** · – · –: 10x15, 10x6.5, 12x8, 15x10, 16x16, 20x15, 20x16, 20x30, 23x12, 25x20, 30x20, 40x30, 50x30

### Tierzubehör
- **Hundemarken** · Alu · DogTag: 2,9x5°, 5x2,9°
- **Hundemarken** · Alu · Herz: 3,8x3,3°, 3x3,5°
- **Hundemarken** · Alu · Knochen: 3,1x2,1°, 3,8x2,5°, 5,2x3,7°
- **Hundemarken** · Alu · Partner: 5x2°
- **Hundemarken** · Alu · Pfote: 3,8x4,8°
- **Hundemarken** · Alu · Rund: 3,8x3,8°, 3x3°
- **Hundemarken** · Edelstahl · DogTag: 2,9x5°, 5x2,9°
- **Hundemarken** · Edelstahl · Rund: 3,8x3,8°, 3x3°
- **Hundemarken** · Holz · DogTag: 2.9x5°, 5x2.9°
- **Hundemarken** · Holz · Herz: 3.8x3.3°, 3x3.5°
- **Hundemarken** · Holz · Knochen: 3.1x2.1°, 3.8x2.5°, 5.2x3.7°
- **Hundemarken** · Holz · Pfote: 3.8x4.8°
- **Hundemarken** · Holz · Rund: 3.8x3.8°, 3x3°
- **Hundemarken** · Leder · Knochen: 3,1x2,1°, 3,8x2,5°, 5,2x3,7°
- **Hundemarken** · Leder · Rund: 3,8x3,8°, 3x3°

### Türklingel
- **\Funkklingeln\** · Acryl + Edelstahl · Ausschnitt: 16x28°, 16x28(14x26)°, 16x28(14x28)°, 16x28(16x26)°, 24x20°, 24x20(22x18)°, 24x20(22x20)°, 24x20(24x18)°, 35x18°, 35x18(33x16)°, 35x18(33x18)°, 35x18(35x16)°, 16x28°, 16x28(14x26)°, 16x28(14x28)°, 16x28(16x26)°, 24x20°, 24x20(22x18)°, 24x20(22x20)°, 24x20(24x18)°, 35x18°, 35x18(33x16)°, 35x18(33x18)°, 35x18(35x16)°
- **\Funkklingeln\Acryl + Edelstahl\** · Ausschnitt · Abgerundete Ecken: 16x28°, 16x28(14x26)°, 16x28(14x28)°, 16x28(16x26)°, 24x20°, 24x20(22x18)°, 24x20(22x20)°, 24x20(24x18)°, 35x18°, 35x18(33x16)°, 35x18(33x18)°, 35x18(35x16)°, 16x28°, 16x28(14x26)°, 16x28(14x28)°, 16x28(16x26)°, 24x20°, 24x20(22x18)°, 24x20(22x20)°, 24x20(24x18)°, 35x18°, 35x18(33x16)°, 35x18(33x18)°, 35x18(35x16)°

### Türschilder
- **Gravur** · Acryl · –: 10x10°, 10x3,5°, 10x6,5 Oval°, 12x12°, 12x4°, 12x4 Oval°, 12x5,5°, 12x5,5 Abgerundete Ecken°, 12x8°, 12x8 Abgerundete Ecken°, 14x3°, 15x10°, 15x8 Oval°, 16x16°, 17x11 Oval°, 18x12°, 18x6 Oval°, 20x13 Oval°, 20x16°, 21x10°, 21x14°, 21x7 Oval°, 22,5x12 Oval°, 23x12°, 25x15°, 30x10 Oval°, 30x20°, 34x22 Oval°, 40x30°, 5x2°, 6x2°, 6x2 Abgerundete Ecken°, 6x4°, 7x2°, 7x2 Abgerundete Ecken°, 7x2 Abgerundete Seiten°, 8x2°, 8x3 Abgerundete Seiten°, 8x3,5°, 8x5°, 8x5 Abgerundete Ecken°, 8x8°, 9x6°
- **Gravur** · Acryl+Edelstahl · –: 10x6 (10x4), 12x12(10x10), 12x8(10x6), 12x8(12x6), 9x6(6x6), 9x6(7x4)°, 9x6(9x2,5), 9x6(9x4)
- **Gravur** · Edelstahl · –: 10x10°, 10x3,5°, 10x6,5 Oval°, 12x12°, 12x4°, 12x4 Oval°, 12x5,5°, 12x5,5 Abgerundete Ecken°, 12x8°, 12x8 Abgerundete Ecken°, 14x3°, 15x10°, 15x8 Oval°, 16x16°, 17x11 Oval°, 18x12°, 18x6 Oval°, 20x13 Oval°, 20x16°, 21x10°, 21x14°, 21x7 Oval°, 23x12°, 25x15°, 30x10 Oval°, 30x20°, 34x22 Oval°, 40x30°, 5x2°, 6x2°, 6x2 Abgerundete Ecken°, 6x4°, 7x2°, 7x2 Abgerundete Ecken°, 7x2 Abgerundete Seiten°, 8x2°, 8x3 Abgerundete Seiten°, 8x3,5°, 8x3,5 Abgerundete Ecken°, 8x5°, 8x5 Abgerundete Ecken°, 8x8°, 9x6°
- **Gravur** · Holz · –: 10x10, 10x3,5°, 12x8°, 15x10°, 7x2°, 8x3,5°, 9x6°
- **Gravur** · Kunststoff · –: 10x3,5°, 12x4°, 12x4 Oval°, 12x8°, 15x10°, 21x14°, 30x20°, 5x2°, 6x2°, 6x2 Abgerundete Ecken°, 6x4°, 7x2°, 7x2 Abgerundete Ecken°, 8x2°, 8x3 Abgerundete Seiten°, 8x3,5°, 8x5°, 9x6°
- **Gravur** · Retro 1 · Acryl: 9x6
- **Gravur** · Retro 1 · Edelstahl: 9x6, 9x6
- **Gravur** · Retro 1 · Kunststoff: 9x6°
- **Gravur** · Retro 2 · Acryl: 12x8
- **Gravur** · Retro 2 · Edelstahl: 12x8, 12x8
- **Gravur** · Retro 2 · Kunststoff: 12x8°
- **Gravur** · Schiefer · –: 10x10
- **UV** · Quadratisch · Acryl: 10x10
- **UV** · Quadratisch · Holz: 10x10, 12x12
- **UV** · Rechteckig · Edelstahl: 12x8 - Blätter, 15x10 - Blätter°, 18x12 - Blätter°, 20x16 - Blätter, 30x20 - Blätter°, 9x6
- **UV** · Rechteckig · Holz: 10x3.5, 10x5, 12x8, 15x10, 7x2, 8x3.5, 9x6
- **UV** · _Neue Sortierung · Acryl: 10x6.5 Oval, 12x8°, 15x10°, 15x8 Oval°, 16x7°, 17x11 Oval°, 18x12°, 20x13 Oval°, 23x10°, 24x16°, 29x15 Oval°, 30x20°, 34x22 Oval°, 8x3.5°, 9x6°
- **UV** · _Neue Sortierung · Acryl + Edelstahl: 12x8(10x6)°, 15x10(13x8)°, 18x12(16x10)°, 24x16(22x14)°, 30x20(28x18)°, 9x6(7x4)°

### Untersetzer
- **Pilz** · – · –: 10x10°
- **Rund** · – · –: 10x10°

### Wandbilder
- **Clipart** · Acryl · –: 15x20°, 20x30°, 40x60°
- **Clipart** · Leinwand · –: 24x30, 30x40, 60x80°
- **Collagen** · Acryl · –: 20x30°, 30x20, 40x30, 40x60, 50x30, 60x40
- **Collagen** · Alu-Dibond · –: 20x30, 30x20°, 40x60
- **Collagen** · Holz · –: 30x20
- **Collagen** · Leinwand · –: 24x30, 30x40
- **Fingerabdruck** · Leinwand · –: 30x40
- **Gaming** · Acryl · –: 40x60
- **Gaming** · Alu-Dibond · –: 40x60
- **Kalender** · Acryl · –: 15x20°, 20x30, 30x20, 40x30, 50x30
- **Kalender** · Alu-Dibond · –: 15x20°, 20x30, 30x20
- **Kinder** · Acryl · –: 40x60, 60x40
- **Kinder** · Alu-Dibond · –: 40x60
- **Kinder** · Holz · –: 40x60
- **Maps** · Acryl · –: 30x20, 40x30, 40x60, 50x30
- **Maps** · Alu-Dibond · –: 30x20, 40x60
- **Maps** · Holz · –: 30x20, 40x30, 40x60, 50x30
- **Muttertag** · – · –: 15x20, 20x30°, 40x60°
- **Netflix** · – · –: 15x20, 20x15°
- **Personalisiert** · Acryl · –: 15x20°, Wandbilder LED°, 20x30, 30x20, 40x30, 40x60
- **Personalisiert** · Alu-Dibond · –: 20x30, 30x20, 40x60
- **Personalisiert** · Holz · –: 15x20 - Herbst°, 30x20, 30x40, 40x30, 40x60, 50x30
- **Personalisiert** · Leinwand · –: 20x20, 24x30°, 25x25, 29x29, 30x24, 30x40, 40x30, 60x80, 80x60
- **Song Cover** · Acryl · –: 15x20, 20x30, 40x60°
- **Song Cover** · Alu-Dibond · –: 20x30
- **Song Cover** · Holz · –: 20x30
- **Sternzeichen** · Acryl · –: 20x30, 30x20, 40x30, 40x60, 50x30
- **Sternzeichen** · Alu-Dibond · –: 20x30, 30x20, 40x60
- **Sternzeichen** · Holz · –: 30x20°, 30x40, 40x30, 40x60, 50x30
- **Sternzeichen** · Leinwand · –: 24x30, 40x30
- **Typo** · Acryl · –: 30x20, 40x30, 40x60, 50x30
- **Typo** · Alu-Dibond · –: 20x30, 30x20, 40x60
- **Typo** · Holz · –: 30x20, 40x30, 40x60, 50x30
- **Typo** · Leinwand · –: 24x30, 40x30, 60x80, 80x60
- **Vatertag** · – · –: 15x20°, 20x30°, 40x60°
- **Weltkarte** · Acryl · –: 20x30, 30x20, 40x30, 50x30, 90x60
- **Weltkarte** · Alu-Dibond · –: 20x30, 30x20
- **Weltkarte** · Holz · –: 30x40, 40x30, 50x30, 90x60
- **Weltkarte** · Leinwand · –: 24x30, 30x40, 40x30, 60x80, 80x60
- **Whatsapp** · Acryl · –: 20x30
- **Whatsapp** · Alu-Dibond · –: 20x30

° = im Fancy-Konfigurator nicht fertig gemeldet
