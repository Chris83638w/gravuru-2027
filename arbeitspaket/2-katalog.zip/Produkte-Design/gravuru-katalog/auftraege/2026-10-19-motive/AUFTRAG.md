# Auftrag an ChatGPT · Neue Motive für die Gravuru-Motivbibliothek

Du erstellst **151 einfarbige Motive** für Gedenktafeln (Lasergravur auf Schiefer/Granit/Acryl, UV-Druck). Sie ergänzen unsere Bibliothek von 721 Motiven und werden später vom Kunden im Konfigurator gewählt oder in den neuen Designs (Auftrag „Gedenktafeln Zielgruppen“) eingesetzt. Die Liste steht in `motivliste.csv`: Kennung, Kategorie, Name, Beschreibung, Priorität (1 = zuerst, für die neuen Designs nötig; 2 = Bibliothek; 3 = wenn Zeit bleibt), Zielgruppe.

## Stil (gilt für jedes Motiv)
- **Einfarbig schwarz auf reinem Weiß.** Keine Graustufen, keine Schattierungen, keine Verläufe, kein Hintergrund, kein Rahmen, kein Text, keine Signatur.
- Stil wie `stilreferenz-motive.png`: **ruhige, elegante Flächensilhouette mit weißen Binnenlinien** (Holzschnitt-/Schablonenlogik), nicht Comic, nicht Icon, nicht fotorealistisch. Feine Details nur, wenn sie bei 40 mm Breite noch graviert werden können: kleinste Linie ≥ 1/150 der Motivbreite, kleinste Fläche ≥ 1/80.
- Jedes Motiv **geschlossen und freistehend**, zentriert, rundum mindestens 5 % Rand; Haupt-Ausrichtung wie in der Beschreibung (Seitenansicht/frontal/liegend). Zierlinien und Bänder im angegebenen Seitenverhältnis (3:1, 4:1), alles andere etwa quadratisch.
- **Einheitliche Handschrift** über alle Motive: gleiche Linienstärke, gleiche Detailtiefe, gleicher Realismusgrad. Tiere anatomisch richtig, aber reduziert; Rassen erkennbar an Silhouette und ein bis zwei typischen Merkmalen (Mähne, Ohren, Fellzeichnung angedeutet).
- Würdevoll: nichts Lustiges, keine Sprechblasen, keine Herzchen-Augen. Bei Sternenkindern besonders zurückhaltend.
- **Keine Marken, Logos, Typenschilder** (Traktor, Motorrad, Oldtimer, LKW markenneutral). Keine Nachzeichnung bekannter Figuren oder fremder Illustrationen – jedes Motiv neu.

## Lieferform
Bevorzugt **SVG** (ein Pfad oder wenige Pfade, `fill="#000"`, viewBox quadratisch, keine Strokes, keine Transformationen, keine eingebetteten Bilder). Wenn du nur Bilder erzeugen kannst: **PNG 2048 × 2048 px**, reines Schwarz (#000) auf reinem Weiß (#fff), ohne Antialiasing-Graustufen am besten; wir vektorisieren dann selbst.

Ordner je Kategorie, Dateiname = Kennung aus der Liste: `blumen/lilie.svg`, `katzen/maine-coon.png` … Dazu `motive.csv` (Kennung; Name; Kategorie; Datei; Format; Bemerkung) und je Kategorie ein Übersichtsbild aller Motive (Kontaktbogen), damit wir schnell prüfen können.

Bei Bildmodellen: ein Motiv je Bild, nie mehrere; bei Varianten dieselbe Kennung mit `-v2`. Wenn ein Motiv im Stil nicht gelingt, lieber weglassen und in der Bemerkung sagen warum, als etwas Halbes liefern.

## Prompt-Baustein (wenn du ein Bildmodell nutzt)
„Einfarbige Vektor-Illustration für Lasergravur: **[Beschreibung aus der Liste]**. Schwarze Silhouette mit feinen weißen Binnenlinien auf reinem weißen Hintergrund, elegant und ruhig, Holzschnitt-Stil, klare geschlossene Formen, keine Graustufen, keine Schattierung, keine Verläufe, kein Hintergrund, kein Rahmen, kein Text, Motiv zentriert mit Rand, [Ausrichtung].“ Englisch, falls das Modell das besser versteht: „monochrome black vector illustration for laser engraving, solid black silhouette with fine white inner lines on pure white background, elegant woodcut style, clean closed shapes, no gradients, no shading, no background, no frame, no text, centered with margin“.

## Abnahme
Wir prüfen automatisch: reines Schwarz/Weiß, Mindestlinienstärke, freistehend, Seitenverhältnis, keine Doppelmotive. Danach Vektorisierung (falls PNG), Normierung auf unser Format (viewBox 0 0 200 200, `fill="#000"`), Aufnahme in `motive/<Kategorie>/` mit Herkunft „ChatGPT-Auftrag 2026-10-19“. Was nicht passt, kommt mit Begründung zurück.
