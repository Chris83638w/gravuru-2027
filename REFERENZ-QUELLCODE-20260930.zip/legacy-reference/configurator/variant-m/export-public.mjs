import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {build,HERE,ROOT,OUTPUT} from './build.mjs';

// Export only the browser runtime, never the repository, server, tests or credentials.
const result=build();
const base=path.join(HERE,'.public-preview');fs.mkdirSync(base,{recursive:true});
const output=fs.mkdtempSync(path.join(base,'site-'));
const manifest=[];
function write(relative,bytes){
  if(path.isAbsolute(relative)||relative.split(/[\\/]/).includes('..'))throw Error('Invalid export path');
  const target=path.join(output,relative);fs.mkdirSync(path.dirname(target),{recursive:true});
  fs.writeFileSync(target,bytes);manifest.push({path:relative,bytes:Buffer.byteLength(bytes),sha256:createHash('sha256').update(bytes).digest('hex')});
}
const copy=(source,relative)=>write(relative,fs.readFileSync(source));
const modules=new Set();
function moduleFile(relative){
  if(modules.has(relative))return;
  if(!/^(configurator\/variant-m|platform\/sources\/app\/shared)\/.+\.mjs$/.test(relative)||/\.(test|spec)\.mjs$/.test(relative))throw Error('Unexpected browser import: '+relative);
  modules.add(relative);
  const source=fs.readFileSync(path.join(ROOT,relative),'utf8');write(relative,source);
  for(const match of source.matchAll(/(?:from\s*|import\s*\()\s*['"]([^'"]+)['"]/g)){
    const spec=match[1];if(!spec.startsWith('.'))throw Error('Unexpected external module: '+spec);
    moduleFile(path.posix.normalize(path.posix.join(path.posix.dirname(relative),spec)));
  }
}
for(const file of ['adapter.mjs','ux.mjs'])moduleFile('configurator/variant-m/'+file);
for(const file of ['ux.css','refinements.css','usability.css','customer-tools.css','workflow.css','completion.css'])copy(path.join(HERE,file),'configurator/variant-m/'+file);
for(const file of ['editor.html','models.json','assistant.js','guides.json'])copy(path.join(OUTPUT,file),file);
let index=fs.readFileSync(path.join(HERE,'index.html'),'utf8');
index=index.replace('<p>Produkt auswählen und personalisieren.</p>','<p>Produkt auswählen und personalisieren.</p><p class="notice">Testversion: Bestellungen und dauerhaftes Speichern sind noch nicht möglich. Ausgewählte Fotos bleiben in deiner geöffneten Browsersitzung.</p>');
write('index.html',index);
copy(path.join(ROOT,'designs/aosu-labrador/motif.json'),'labrador/motif.json');
copy(path.join(ROOT,'designs/aosu-labrador/assets/michroma-vectors.json'),'labrador/michroma-vectors.json');
const inventory=JSON.parse(fs.readFileSync(path.join(ROOT,'designs/aosu-labrador/RESOURCE-INVENTORY.json'),'utf8'));
for(const entry of inventory.filter(item=>item.path.startsWith('designs/aosu-labrador/runtime/'))){
  copy(path.join(ROOT,entry.path),entry.path.replace('designs/aosu-labrador/runtime/','_runtime/'));
}
write('_redirects','/api/guides /guides.json 200\n');
write('_headers',`/*
  X-Content-Type-Options: nosniff
  X-Robots-Tag: noindex, nofollow
  Referrer-Policy: strict-origin-when-cross-origin
  Cache-Control: no-cache
  Content-Security-Policy: default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data: blob:; font-src 'self' data:; frame-src 'self'; object-src 'none'; frame-ancestors 'self'
/*.mjs
  Content-Type: text/javascript; charset=utf-8
`);
write('robots.txt','User-agent: *\nDisallow: /\n');
write('policies/shipping-policy/index.html','<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Gravuru Testversion</title><body style="font:18px/1.6 Arial;max-width:640px;margin:40px auto;padding:20px"><h1>Gravuru Testversion</h1><p>Diese Testversion nimmt keine Bestellungen entgegen. Angezeigte Preise dienen zur Funktionsprüfung.</p><a href="/">Zur Testversion</a></body></html>');
write('netlify.toml','[build]\n  publish = "."\n');
// Kept outside the publish directory: audit data is not part of the public site.
fs.writeFileSync(output+'-manifest.json',JSON.stringify({sourceBuild:result,files:manifest},null,2));
console.log(JSON.stringify({directory:output,files:manifest.length,bytes:manifest.reduce((n,item)=>n+item.bytes,0),modules:modules.size,verifiedResources:result.verifiedResources}));
