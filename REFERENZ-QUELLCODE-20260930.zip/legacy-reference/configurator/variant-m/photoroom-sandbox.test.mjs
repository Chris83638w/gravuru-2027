import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {createSandbox,boundedBytes,imageType,MAX_INPUT} from './photoroom-sandbox.mjs';
import {createTestServer} from './photoroom-test-server.mjs';
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l9sAAAAASUVORK5CYII=','base64');
const fakeKey='test_credential_only_123456789';
const response=()=>new Response(png,{headers:{'content-type':'image/png'}});
test('all requests force sandbox mode, preserve geometry, omit filename, and cache repeats',async()=>{
 let calls=0;const s=createSandbox({fetchImpl:async(url,options)=>{calls++;assert.equal(url,'https://image-api.photoroom.com/v2/edit');assert.equal(options.headers['x-api-key'],'sandbox_'+fakeKey);assert.equal(options.redirect,'error');assert.equal(options.body.get('referenceBox'),'originalImage');assert.equal(options.body.get('removeBackground'),'true');assert.equal(options.body.get('export.format'),'png');assert.equal(options.body.get('imageFile').name,'test-photo.png');return response();}});
 await assert.rejects(s.remove(png),/zuerst/);s.configure(fakeKey);assert.deepEqual(await s.remove(png),png);assert.deepEqual(await s.remove(png),png);assert.equal(calls,1);assert.equal(JSON.stringify(s.status()).includes(fakeKey),false);
 s.configure('sandbox_'+fakeKey);await s.remove(png);assert.equal(calls,2);s.disconnect();assert.equal(s.status().configured,false);await assert.rejects(s.remove(png),/zuerst/);
});
test('reject unsupported/oversized input before any upstream request',async()=>{
 let calls=0;const s=createSandbox({fetchImpl:async()=>{calls++;return response();}});s.configure(fakeKey);
 await assert.rejects(s.remove(Buffer.from('<svg/>')),e=>e.status===415);await assert.rejects(s.remove(Buffer.alloc(MAX_INPUT+1)),e=>e.status===413);assert.equal(calls,0);assert.equal(imageType(png),'image/png');
 await assert.rejects(boundedBytes([Buffer.alloc(2),Buffer.alloc(3)],4),e=>e.status===413);
});
test('upstream error bodies and secrets never reach the user; no automatic retries',async()=>{
 let calls=0;const s=createSandbox({fetchImpl:async()=>{calls++;return new Response(fakeKey,{status:401});}});s.configure(fakeKey);
 await assert.rejects(s.remove(png),e=>e.status===502&&!e.message.includes(fakeKey)&&/Zugang/.test(e.message));assert.equal(calls,1);assert.equal(s.status().busy,false);
 const offline=createSandbox({fetchImpl:async()=>{throw Error(fakeKey);}});offline.configure(fakeKey);await assert.rejects(offline.remove(png),e=>!e.message.includes(fakeKey)&&e.status===502);
});
test('only PNG result accepted and attempts capped independently of key changes',async()=>{
 const s=createSandbox({maxCalls:1,fetchImpl:async()=>new Response('<html/>',{headers:{'content-type':'text/html'}})});s.configure(fakeKey);await assert.rejects(s.remove(png),/kein PNG/);s.configure(fakeKey);await assert.rejects(s.remove(png),e=>e.status===429);
});
test('only one upstream request at a time; disconnect prevents stale results',async()=>{
 let release;const s=createSandbox({fetchImpl:()=>new Promise(resolve=>{release=()=>resolve(response());})});s.configure(fakeKey);const pending=s.remove(png);await assert.rejects(s.remove(png),e=>e.status===409);assert.throws(()=>s.configure(fakeKey),/abwarten/);s.disconnect();release();await assert.rejects(pending,e=>e.status===409);assert.equal(s.status().busy,false);
});
test('local HTTP access requires exact Host, same origin and a session token; secrets not reflected',async t=>{
 const s=createSandbox({fetchImpl:async()=>response()}),server=createTestServer({sandbox:s});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));t.after(()=>{server.closeAllConnections();server.close();});
 const origin='http://127.0.0.1:'+server.address().port;
 const page=await fetch(origin+'/');assert.equal(page.status,200);assert.match(page.headers.get('content-security-policy'),/frame-ancestors 'none'/);
 const badHost=await new Promise((resolve,reject)=>{http.get(origin+'/api/status',{headers:{host:'example.test'}},res=>{res.resume();resolve(res.statusCode);}).on('error',reject);});assert.equal(badHost,403);
 assert.equal((await fetch(origin+'/api/status',{headers:{origin:'https://example.test'}})).status,403);
 assert.equal((await fetch(origin+'/api/connect',{method:'POST'})).status,403);
 const {token}=await (await fetch(origin+'/api/status')).json();
 const connected=await fetch(origin+'/api/connect',{method:'POST',headers:{'x-gravuru-token':token,'content-type':'application/json'},body:JSON.stringify({key:fakeKey})});assert.equal(connected.status,200);assert.equal((await connected.text()).includes(fakeKey),false);
 const removed=await fetch(origin+'/api/remove',{method:'POST',headers:{'x-gravuru-token':token,'content-type':'image/png'},body:png});assert.equal(removed.status,200);assert.deepEqual(Buffer.from(await removed.arrayBuffer()),png);
 const invalid=await fetch(origin+'/api/connect',{method:'POST',headers:{'x-gravuru-token':token,'content-type':'application/json'},body:'{"key":"'+fakeKey});assert.equal(invalid.status,400);assert.equal((await invalid.text()).includes(fakeKey),false);
 assert.equal((await fetch(origin+'/../photoroom-sandbox.mjs')).status,404);
 await fetch(origin+'/api/disconnect',{method:'POST',headers:{'x-gravuru-token':token}});assert.equal((await (await fetch(origin+'/api/status')).json()).configured,false);
});
