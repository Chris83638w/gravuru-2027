# Getrennte Werkstatt-Quellreferenz für spätere Fortsetzung

**Ergänzung 23.09.2026:** Der neue ausdrückliche Gesamtbereitstellungsauftrag ergänzt die vollständigen gefilterten App- und Werkstattquellen unter [platform](../../platform/README.md). Für die Weiterarbeit dort beginnen. Die folgende Beschreibung dokumentiert den früheren begrenzten 22-Dateien-Import; seine Quellen bleiben unverändert erhalten.

Dies ist **nicht** die Variante-M-Kundenruntime und **keine** neu bestätigte Live-Version. Nicht in die Labrador-Vorschau importieren. Lokaler Quellstand am 23.09.2026, deployed Commit unbekannt.

Gezielt aufgenommen wurden `StudioPage.jsx`, `ProductLineTabs.jsx`, deren statischer relativer Importabschluss und der statische Medienprovider: 22 Quelldateien. Die bestehenden Pfade bleiben innerhalb dieses separaten Verzeichnisses erhalten. Bytes unverändert; Herkunft und SHA-256 stehen im Labrador-Ressourceninventar. Die Dateien waren im Git-Ausgangsstand nicht an diesen Quellpfaden enthalten.

Abgedeckt sind Profil-/Optionsdaten, fünf Bearbeitungsprofile, Produktlinien, Designs, Vorschau, Geometrie-/Elementvalidierung, Shopify-Anfragen und Medienprovider. Externe statische Importabhängigkeit: `preact/hooks`. Der verwendete lokale Build-Paketstand nennt Preact 10.29.8 und esbuild 0.28.2 als Bereichsuntergrenzen; diese Quellreferenz wurde hier nicht neu gebündelt. Node 24.19.0 ist lokal vorhanden, für die Labrador-Vorschau aber nicht nötig. fflate 0.8.3 samt MIT-Lizenz enthalten.

## Versionszuordnung

Die lokale Übergabe vom 20.09.2026 nennt App `designwerkstatt-20260920-c` / ID 1135876931585 und Assets `studio.167bebfb3874.js`, `studio.1a6ba5d81298.css`. Das ist ein alter Prüfbericht, kein heutiger Hashvergleich zwischen diesen Quellen und dem veröffentlichten Bundle. Lokale STATUS-Dateien nennen zugleich E1/E2-Entwicklung. Daher keine Gleichsetzung mit der Live-Version und keine Vermischung mit dem geprüften Labrador-Renderer.

## Bereinigte Beispiele

- `examples/aosu-labrador.local.json`: technischer AOSU-Testdatensatz mit bestehender Gestaltung, ohne reale Produkt-/Variantenbindung; Bestellung/Fertigung deaktiviert.
- `examples/static-media.empty.json`: gültiger leerer Medienkatalog, keine Kundenmedien.
- `examples/local-settings.example.json`: vorgeschlagene lokale Einstellungen ohne Authentifizierung; keine Behauptung, dass die bestehende App diese Datei bereits einliest.

## Für vollständige Werkstatt-Fortsetzung weiterhin benötigt / ungeprüft

| Bestandteil | Gezielt festgestellter Stand | Vorgehen |
|---|---|---|
| Studio-App-Einstieg, Navigation, weitere Admin-Seiten und CSS | Lokal unter App-Stamm `studio/` und `extensions/app-home/src/pages/` vorhanden; nicht für diesen isolierten Importabschluss nötig | Separaten Versionsabgleich vor vollständiger Übernahme durchführen |
| Build-/Hosting-Adapter | Lokale `build-studio.cjs`, `build-hosting-release.cjs` enthalten persönliche Pfade und unterschiedliche Zwischenstände | Nicht als portable oder liveidentische Builds ausgeben; eigener Folgeauftrag |
| Authentifizierung, Shopify-App-Konfiguration und Backend | Source enthält API-Aufrufe, aber keine startfähige authentifizierte lokale Backend-Installation | Bereinigte Konfiguration erst nach Klärung des beabsichtigten Serverstands; keine .env/Token übernehmen |
| Medienregister | Lokales `work/media-library` enthält Daten- und Backupverzeichnisse; Client-/Providerverträge vorhanden | Datenbanken und Backups ausdrücklich nicht kopiert; Quell-/Schema-Version separat prüfen |
| Statischer Medienkatalog und 49 Produktmedien | Frühere Übergabe beschreibt Bestand; hier nicht aktuell inventarisiert | Leeres Fixture statt fremder/privater Datensammlung; kein Vollständigkeitsnachweis für diese 49 Dateien |
| Universelle Kundenruntime v2 / Launcher v6 | Lokale Zwischenstände dokumentiert, nicht als Variante M bestätigt | Nicht in dieses Paket gemischt |
| Amazon-Converter | Früher dokumentiert als Statusseite, kein belegter vollständiger Converter | Original-Amazon-Vorlage und Feldmapping separat klären |
| Maschinen-/Fertigungsausgabe, vollständiger Checkout | Kein neuer Nachweis | Separates Paket und Freigabe |

Das Paket sichert gezielt relevante Quellmodule und ihre Datenstrukturen, nicht das gesamte historische App-/Hostingprojekt. Keine Kunden-/Bestelldaten, Shop-Metaobject-Dumps oder Datenbanken enthalten. Kein neuer Authentifizierungs-, Speicher-, Publikations- oder Exporttest dieser Quellen durchgeführt.
