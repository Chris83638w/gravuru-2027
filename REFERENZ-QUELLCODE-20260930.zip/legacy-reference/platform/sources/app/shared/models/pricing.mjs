import {request} from './motifs.mjs';
export const MOTIF_PRODUCT_ID='gid://shopify/Product/16120817287548';
export const READ_PRICING=`query GravuruMotifPricing($id:ID!){product(id:$id){id title handle variants(first:25){nodes{id sku price} pageInfo{hasNextPage endCursor}}}}`;
export const WRITE_PRICING=`mutation GravuruMotifPricingSave($productId:ID!,$variants:[ProductVariantsBulkInput!]!){productVariantsBulkUpdate(productId:$productId,variants:$variants,allowPartialUpdates:false){productVariants{id price} userErrors{field message}}}`;
export function priceCents(value){
 const text=String(value).trim().replace(',','.');
 if(!/^\d{1,4}(\.\d{1,2})?$/.test(text))throw Error('Bitte einen Preis von 0,01 bis 9.999,99 € mit höchstens zwei Nachkommastellen eingeben.');
 const cents=Math.round(Number(text)*100);
 if(!Number.isSafeInteger(cents)||cents<1||cents>999999)throw Error('Der Motivpreis muss zwischen 0,01 und 9.999,99 € liegen.');
 return cents;
}
export function decodePricing(product){
 if(!product||product.id!==MOTIF_PRODUCT_ID||product.variants.pageInfo.hasNextPage)throw Error('Der Motivpreis-Artikel konnte nicht vollständig geladen werden.');
 const variants=product.variants.nodes.map(v=>({...v,count:Number(v.sku?.match(/^GR-MOTIV-(\d{2})$/)?.[1]),cents:Math.round(Number(v.price)*100)})).sort((a,b)=>a.count-b.count);
 if(variants.length!==20||variants.some((v,i)=>v.count!==i+1||!Number.isSafeInteger(v.cents)||v.cents<0))throw Error('Die Motivpreis-Zuordnung ist unvollständig. Bitte prüfen lassen.');
 const unitCents=variants[0].cents;
 return {id:product.id,handle:product.handle,unitCents,variants,consistent:unitCents>0&&variants.every(v=>v.cents===v.count*unitCents),fingerprint:JSON.stringify(variants.map(v=>[v.id,v.cents]))};
}
export async function loadPricing(){return decodePricing((await request(READ_PRICING,{id:MOTIF_PRODUCT_ID})).product);}
export async function savePricing(original,value){
 const cents=priceCents(value),latest=await loadPricing();
 if(latest.fingerprint!==original.fingerprint)throw Error('Die Preise wurden inzwischen geändert. Bitte neu laden und erneut speichern.');
 const variants=latest.variants.map(v=>({id:v.id,price:(v.count*cents/100).toFixed(2)}));
 const result=(await request(WRITE_PRICING,{productId:MOTIF_PRODUCT_ID,variants})).productVariantsBulkUpdate;
 if(result.userErrors?.length)throw Error(result.userErrors.map(e=>e.message).join(' · '));
 if(result.productVariants?.length!==20)throw Error('Shopify hat nicht alle Motivpreise bestätigt. Bitte neu laden.');
 const saved=await loadPricing();
 if(saved.unitCents!==cents||!saved.consistent)throw Error('Die gespeicherten Preise stimmen noch nicht überein. Bitte neu laden.');
 return saved;
}
