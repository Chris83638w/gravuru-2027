export const PRODUCT_LINES=['Klingelschilder','Türklingeln','Türschilder','Hausnummern','Schlüsselanhänger','Gedenktafeln & Erinnerungen','Geschenke & Dekoration','Weitere Produkte'];
export function productLine(item){
 const p=item.profile||item;
 if(p.kind==='layered-doorbell')return 'Klingelschilder';
 const text=String(p.productType||p.name||p.title||'').toLocaleLowerCase('de');
 if(/klingelschild|funkklingel|schild.*(?:klingel|doorbell)/.test(text))return 'Klingelschilder';
 if(/türklingel|tuerklingel|doorbell/.test(text))return 'Türklingeln';
 if(/schlüsselanhänger|schluesselanhaenger|keychain/.test(text))return 'Schlüsselanhänger';
 if(/gedenk|grab|erinner|andenken|urne/.test(text))return 'Gedenktafeln & Erinnerungen';
 if(/hausnummer/.test(text))return 'Hausnummern';
 if(/türschild|tuerschild|namensschild|briefkasten/.test(text))return 'Türschilder';
 if(/familienschild/.test(text))return 'Türschilder';
 if(/weihnacht|dekoration|geschenk|acrylanhänger|lunchbox|schulplan/.test(text))return 'Geschenke & Dekoration';
 return p.productType&&p.productType!=='Eigenes Produkt'?p.productType:'Weitere Produkte';
}
export function lineCounts(items){const counts=new Map(PRODUCT_LINES.map(n=>[n,0]));for(const item of items){const line=productLine(item);counts.set(line,(counts.get(line)||0)+1);}return [...counts];}
