# Bestandsdesigns Gedenktafeln-sternenkinder – aus dem Server-Bestand extrahiert

4 Designs (über Größen und Materialien zusammengefasst), gelesen aus den Corel-Bögen (`[CDR]`) und Konfigurator-Paketen auf `V:\Produkte\Gedenktafeln`. Je Design ein Ordner `Zielgruppe/Unterkategorie/<Schlüssel>/` mit `design.svg` (Text bleibt Text, Motive als Pfade, Maße in mm), `design.json` (Texte, Schriften, Lage, Varianten, Kategorie) und `preview.png`. UV-Designs aus Paketen tragen zusätzlich `product.json` und die Ebenen (`Bild_*.png`, `*.svg`).

**Kategorien sind Vorschläge aus den Texten** – Korrektur in [`GEDENKTAFELN-STERNENKINDER-DESIGNS.xlsx`](GEDENKTAFELN-STERNENKINDER-DESIGNS.xlsx) (gelbe Spalten), Übersichtsbögen je Kategorie in `_uebersicht/`.

| Zielgruppe | Unterkategorie | Designs |
| --- | --- | --- |
| Allgemein | Allgemein | 4 |

| Reihe | Designs |
| --- | --- |
| GTSK-S · Schiefer | 4 |

## Regeln

- Eigene Motive dieser Designs bleiben beim Design (keine Übernahme in `motive/`).
- Alte Größen sind nur dokumentiert (`sizesInStock`); welche Größen die Linie künftig hat, entscheidet der Nutzer.
- Texte sind Beispieltexte des Bestands (Kundenfelder im Konfigurator); Schriften sind die im Bestand verwendeten – Ersatz für nicht freigegebene Schriften folgt je Linie.
- Lücken: Designs ohne lesbaren Text (`offen`) stammen aus reinen Bildpaketen; dort hilft nur Sichtprüfung über `preview.png`.
