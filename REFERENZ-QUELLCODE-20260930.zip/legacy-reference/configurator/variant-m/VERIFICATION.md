# Prüfnachweis – 24.09.2026

Aufgabenbranch `feat/variante-m-profile-20260924`, Basis
`723eff50c833f09a0e49af88689242a133d6ad18`.
Koordinationsbranch am Beginn der Arbeit neu abgerufen und bei
`5ccd41b4438a093a443acf84fd6ff55ff5caaaa4` gelesen.

## Tatsächlich ausgeführte Prüfungen

| Prüfung | Ergebnis und Grenze |
| --- | --- |
| Build / Ressourcen | 104 Dateien gegen vorhandenes SHA-256-Inventar geprüft; zwei lokale Prüfmodelle gebaut. |
| Daten-/Preis-/Pipeline-Tests | 35 Tests erfolgreich: 15 neue Verträge plus 20 bestehende Pipeline-Tests. Keine Shopmutation durch diese Tests. |
| Fünf Profile | Bestehende native IDs mit identischem Datenvertrag akzeptiert; dunkle Edelstahlgravur ausdrücklich geprüft. Keine visuelle Abnahme aller fünf Materialien. |
| Foto aus | Vertrag bietet nur Vorlagen ohne Fotofeld an; reine Pflichtfoto-Vorlagen werden abgelehnt. Originaldaten unverändert. |
| Zehn Schieferdesigns | Alle zehn mit echten Schrift-/Motivressourcen validiert; Speichern/Lesen mit exakter Profilbindung erfolgreich. |
| Vorlagenbereiche | Verschieben/Löschen fester Foto-Slots über manipulierten Entwurf wird abgelehnt; unbekannte Motive/Optionen und fremde Revisionen ebenfalls. |
| Browserstart | Bestehende AOSU-M-Referenz und neue Schieferanbindung im lokalen Browser gestartet. Nachladen erst beim Öffnen im Einstiegscode. Kein separater Netzwerkmessbericht. |
| Textbedienung | Text geändert, Größensteuerung von 18 auf 19 mm benutzt; Name beim Designwechsel erhalten. |
| Preise | 29,99 EUR Grundpreis; mit B04 33,98 EUR. Zusätzliches Motiv +1,69 EUR, Rückgängig stellt vorherigen Preis her. Mengen/weitere Optionen in Vertragstests geprüft. |
| Neue Elemente | Text und Motiv mit tatsächlichen Produktmaßen hinzugefügt; keine ungültige alte Klingelposition. Geometrieprüfung bleibt aktiv. |
| Fotoauswahl | Vorhandenes unpersönliches Repository-PNG im Fotofeld gewählt. Status ausdrücklich nur lokal ausgewählt; kein Fotobild in Vorschau. Keine Serverübertragung. |
| Browser-Entwurf | „Luna“, Fotomedaillon, B04 als JSON heruntergeladen, Werte geändert, tatsächliche heruntergeladene Datei wieder geöffnet: Luna und 33,98 EUR wiederhergestellt. Dateiauswahl beim ersten Automationsversuch lief in Timeout, zweiter gleichzeitig gestarteter Klick/Chooser-Versuch erfolgreich. |
| Mobile Ansicht | 390 × 844 CSS-Pixel. Normale und große Vorschau Querformat; nach letzter Korrektur große Produktfläche 322 × 214,664 px, Verhältnis 300/200. Normale Produktfläche `touch-action:pan-y`, große Bearbeitungsfläche `none`. Innere mobile Designliste ohne eigene Scrollbegrenzung (`overflow:visible`). Kein physischer Touch-Gerätetest. |
| SVG-Download | Tatsächliche Browserdatei als XML gelesen: 300 mm × 200 mm, 54 Pfade, kein image-Element. Entwurf ohne Foto/Produktionsfreigabe. |
| PNG-Download | Tatsächliche Browserdatei 98.122 Bytes, gültige PNG-Signatur. Keine Fertigungs-/Druckmaßprüfung. |
| Browserfehler | Bei Text-/Motiv-/Downloadprüfung keine erfassten Konsolenfehler. |
| Lokaler Server | Einstieg, Editor und erlaubte Module HTTP 200; Repository-Dokument und `.git/config` HTTP 404; POST HTTP 405. |
| Zugangsdatenprüfung | Neue neun Dateien gezielt gelesen und zusätzlich gegen verbreitete Token-/Private-Key-Muster geprüft: kein Fund. Keine privaten Kundendateien aufgenommen. |

## Unveränderte Eingänge (SHA-256)

| Datei | SHA-256 |
| --- | --- |
| `references/aosu-upgrade-2026-09-21/verification/editor-source.html` | `fd716737e882098a636498817adfa7afac66103d8a4b4abafbccd337aef7adb2` |
| `references/aosu-upgrade-2026-09-21/verification/profile-source.json` | `7648c2538462e6f92f3e227ead91548d5d1812cb879aba328a89a6e4b713df4d` |
| `automation/product-pipeline/jobs/hunde-gedenktafeln.json` | `49d8c822d649297dac52a0fd3931f6dc8aa34b396de191b5fa632c394c2a1d8f` |

## Nicht geprüft / nicht fertig

Keine neue Live-Shopprüfung, kein Checkout, keine Bestellung, keine Zahlung, keine
Server-Fotoablage, keine Maschinenprobe. Die bestehende universelle Runtime-Freigabe
wurde nicht künstlich gesetzt. Der Adapter ist ein lokal getesteter Integrationsstand.
Schieferoberfläche/Bruchkanten und beliebige Produktkonturen bleiben offen.
Vollständige Funktionsgleichheit sämtlicher M-Funktionen ist noch nicht nachgewiesen.
Weitere Grenzen und der nächste Anschluss stehen in `README.md`.

Ausgeführte Tests sind kein Beleg, dass ein ACTIVE-Produkt bereits vollständig mit
Foto und Aufpreisen bestellbar ist. Der separate Werkstatt-Pilot wurde nicht vermischt.

