/* gravuru-variante-m-pdp.js — Inline-Skripte der Variante-M-Produktbeschreibung (Clean-Header, PDP-Enhancer, Tonspur/Voice-Help, Mobile-Scroll, Lieferzeit), 1:1 aus der Beschreibung von Produkt 16124413084028 ausgelagert (Stand 28.09.2026). Alle Blöcke sind IIFEs mit eigenen Guards; Reihenfolge wie in der Beschreibung. */
(()=>{
 function init(){
  const settings=document.querySelector('[data-gravuru-clean-header]');const header=document.querySelector('header.header');if(!settings||!header||header.dataset.gvClean)return;header.dataset.gvClean='true';
  const left=header.querySelector('.header__icons--left'),right=header.querySelector('.header__icons--right .header__buttons');const account=right?.querySelector('.account-button');if(account&&left){const copy=account.cloneNode(true);copy.className='gv-account-left';left.append(copy);}
  const input=header.querySelector('input[type="search"]');if(input&&right){const search=document.createElement('button');search.type='button';search.className='gv-search-focus';search.setAttribute('aria-label','Suche öffnen');search.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><circle cx="10.5" cy="10.5" r="7.2"/><path d="m16 16 5 5"/></svg>';search.addEventListener('click',()=>input.focus());right.prepend(search);}
  const messages=[...settings.querySelectorAll('[data-notice]')].map(e=>({text:e.textContent.trim(),url:e.dataset.noticeUrl||''})).filter(e=>e.text);if(!messages.length||document.querySelector('.gv-announcement'))return;
  const bar=document.createElement('div');bar.className='gv-announcement';bar.setAttribute('aria-label','Shophinweise');bar.innerHTML='<button type="button" aria-label="Hinweisleiste schließen">×</button><p></p><button type="button" aria-label="Hinweiswechsel pausieren"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M7 4v12M13 4v12"/></svg></button>';
  const first=header.closest('.header-section');first?.before(bar);const text=bar.querySelector('p'),pause=bar.lastElementChild,close=bar.firstElementChild;let index=0,paused=window.matchMedia('(prefers-reduced-motion: reduce)').matches,hover=false,focused=false;
  const icons={truck:'<path d="M2 5h12v12H2zM14 9h4l4 4v4h-3M14 17h1"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',chat:'<path d="M21 11a8 8 0 0 1-8 8H6l-4 3V11a9 9 0 1 1 19 0Z"/><path d="M7 9h9M7 13h6"/>',star:'<path d="m12 2 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z"/>',heart:'<path d="M20 4a5 5 0 0 0-8 2 5 5 0 0 0-8-2c-5 5 2 11 8 16 6-5 13-11 8-16Z"/>'};
  const update=()=>{const item=messages[index],message=item.text,icon=/Versand/i.test(message)?'truck':/Hilfe/i.test(message)?'chat':/Bewertungen|Kunden|Trustami/i.test(message)?'star':'heart';text.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true">'+icons[icon]+'</svg>';const label=document.createElement(item.url?'a':'span');label.textContent=message;if(item.url){label.href=item.url;label.target='_blank';label.rel='noopener noreferrer';label.setAttribute('aria-label',message+' (öffnet in neuem Tab)');}text.append(label);pause.setAttribute('aria-label',paused?'Hinweiswechsel starten':'Hinweiswechsel pausieren');pause.setAttribute('aria-pressed',String(paused));pause.innerHTML=paused?'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m6 3 10 7-10 7Z"/></svg>':'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M7 4v12M13 4v12"/></svg>';};update();if(messages.length<2)pause.hidden=true;
  const timer=setInterval(()=>{if(!bar.isConnected){clearInterval(timer);return;}if(paused||hover||focused||document.hidden||messages.length<2)return;index=(index+1)%messages.length;update();},3000);
  pause.addEventListener('click',()=>{paused=!paused;update();});close.addEventListener('click',()=>{clearInterval(timer);bar.remove();});bar.addEventListener('mouseenter',()=>hover=true);bar.addEventListener('mouseleave',()=>hover=false);bar.addEventListener('focusin',()=>focused=true);bar.addEventListener('focusout',e=>{if(!bar.contains(e.relatedTarget))focused=false;});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();document.addEventListener('shopify:section:load',init);
})();

(()=>{
 function enhance(source){
  const marker=source?.querySelector?.('[data-gravuru-pdp]')||document.querySelector('[data-gravuru-pdp]');
  const product=document.querySelector('product-info.section-main-product');
  if(!marker||!product||(product.dataset.gvPdpReady&&!source?.querySelector))return;
  if(product.dataset.gvPdpReady){for(const el of product.querySelectorAll('.gv-assurance,.gv-eyebrow,.gv-gallery-note,.gv-purchase-note'))if(!el.closest('[data-gravuru-pdp]'))el.remove();}
  product.dataset.gvPdpReady='true';
  const grid=product.querySelector('.product');
  const info=product.querySelector('.product__info-wrapper .product__blocks');
  const trust=marker.querySelector('.gv-assurance')?.cloneNode(true);
  if(trust&&info){const buy=info.querySelector('.product__block--buy_buttons');(buy||info).after(trust);if(!buy)info.append(trust);}
  const eyebrow=marker.querySelector('.gv-eyebrow')?.cloneNode(true);
  if(eyebrow&&info)info.prepend(eyebrow);
  const purchaseNote=marker.querySelector('.gv-purchase-note')?.cloneNode(true);
  const buy=info?.querySelector('.product__block--buy_buttons');
  if(purchaseNote&&buy)buy.append(purchaseNote);
  const galleryNote=marker.querySelector('.gv-gallery-note')?.cloneNode(true);
  if(galleryNote)product.querySelector('media-gallery')?.after(galleryNote);
  const payments=trust?.querySelector('.gv-payments');
  if(payments&&!payments.children.length){const icons=document.querySelectorAll('footer .payment-icons svg,footer .list-payment svg,footer .footer__payment svg,[role="contentinfo"] .list-payment svg');for(const icon of icons)payments.append(icon.cloneNode(true));}
  const story=product.querySelector('[data-gv-story]');
  const storyBlocks=[...product.querySelectorAll('.product__block--collapsible_tab')].filter(b=>b.querySelector('[data-gv-story]'));
  if(story){grid.append(story);for(const b of storyBlocks)b.classList.add('gv-hidden-description');}
  const details=product.querySelector('.product__blocks-below-media');
  if(details){details.classList.add('gv-product-details');grid.append(details);for(const block of product.querySelectorAll('.product__info-wrapper .product__block--collapsible_tab')){const title=block.querySelector('summary')?.textContent.trim();if([...details.querySelectorAll('summary')].some(s=>s.textContent.trim()===title))block.classList.add('gv-hidden-description');}}
  for(const block of product.querySelectorAll('.product__block--collapsible_tab')){const content=block.querySelector('.accordion__content,.accordion-details__content,.collapsible__content,.rte');if(content&&!content.textContent.trim())block.hidden=true;}
  for(const thumb of product.querySelectorAll('.product__thumbs-item')){thumb.tabIndex=0;thumb.setAttribute('role','button');const image=thumb.querySelector('img');thumb.setAttribute('aria-label',image?.alt||'Produktbild anzeigen');if(!thumb.dataset.gvKeyboard){thumb.dataset.gvKeyboard='true';thumb.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();thumb.click();}});}}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',enhance,{once:true});else enhance();
 document.addEventListener('shopify:section:load',event=>enhance(event.target));
})();

(()=>{
 function init(){
  const product=document.querySelector('product-info.section-main-product'),gallery=product?.querySelector('media-gallery');if(!gallery||!document.querySelector('[data-gravuru-pdp]')||gallery.dataset.gvGalleryV2)return;gallery.dataset.gvGalleryV2='true';
  const originals=[...gallery.querySelectorAll('.product__thumbs-item')];const viewer=gallery.querySelector('.product__media-gallery-viewer-wrap');const row=document.createElement('div');row.className='gv-thumbnails';row.setAttribute('role','group');row.setAttribute('aria-label','Produktbilder auswählen');
  for(const [index,original]of originals.entries()){const source=original.querySelector('img');if(!source)continue;const button=document.createElement('button');button.type='button';button.className='gv-thumbnail';button.dataset.mediaId=original.dataset.target;button.setAttribute('aria-label','Bild '+(index+1)+': '+source.alt);button.setAttribute('aria-pressed',String(index===0));const image=source.cloneNode(true);image.removeAttribute('is');image.alt='';image.sizes='(max-width:767px) 80px,120px';image.loading='lazy';button.append(image);button.addEventListener('click',()=>{if(gallery.sliderInstance?.slider)gallery.sliderInstance.slider.slideToLoop(index);});row.append(button);}
  if(row.children.length)gallery.after(row);for(const original of originals){original.tabIndex=-1;original.setAttribute('aria-hidden','true');}const nativeThumbs=gallery.querySelector('.product__media-gallery-thumbails');if(nativeThumbs){nativeThumbs.inert=true;nativeThumbs.setAttribute('aria-hidden','true');}
  const grid=product.querySelector('.product'),info=product.querySelector('.product__info-wrapper'),intro=document.createElement('div');intro.className='gv-mobile-intro';intro.hidden=true;grid.prepend(intro);const moving=[info?.querySelector('.product__block--title'),info?.querySelector('.product__block--price')].filter(Boolean).map(node=>{const anchor=document.createComment('Gravuru responsive position');node.before(anchor);return{node,anchor};});const mobile=window.matchMedia('(max-width:767px)');function reflow(){intro.hidden=!mobile.matches;for(const {node,anchor}of moving)if(mobile.matches)intro.append(node);else anchor.after(node);}reflow();mobile.addEventListener('change',reflow);
  let cta;
  if(document.getElementById('gravuru-funkklingel-product')){cta=document.createElement('button');cta.type='button';cta.className='gv-image-personalize';cta.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 4 5 5M4 20l5-1L21 7a2 2 0 0 0-5-5L4 14Z"/></svg>Personalisieren';cta.addEventListener('click',()=>product.querySelector('.product__info-wrapper .gravuru-fk-personalize')?.click());viewer.append(cta);}
  function sync(){const id=gallery.querySelector('.product__media-item.swiper-slide-active')?.dataset.mediaId;for(const b of row.children){const selected=String(b.dataset.mediaId===id);if(b.getAttribute('aria-pressed')!==selected)b.setAttribute('aria-pressed',selected);}if(cta)cta.disabled=!product.querySelector('.product__info-wrapper .gravuru-fk-personalize');}
  sync();new MutationObserver(sync).observe(product,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});
  const source=product.querySelector('[data-gv-audio-src]');const url=source?.dataset.gvAudioSrc;if(!url||!/^https:\/\//.test(url))return;
  const audio=document.createElement('audio');audio.src=url;audio.preload='metadata';const wrap=document.createElement('section');wrap.className='gv-audio';wrap.setAttribute('aria-label','Produktvorstellung anhören');wrap.innerHTML='<p class="gv-audio-heading">Dein Klingelschild – kurz erklärt <span>Christophers KI-Stimme · Hörprobe</span></p><div class="gv-audio-row"><button class="gv-audio-toggle" type="button" aria-label="Produktvorstellung abspielen"></button><div class="gv-audio-track"><input type="range" min="0" max="100" step="0.1" value="0" aria-label="Wiedergabeposition" disabled></div></div><div class="gv-audio-meta"><time>0:00</time><details><summary>Text mitlesen</summary><p></p></details></div><p class="gv-audio-status" role="status"></p>';
  wrap.querySelector('details p').textContent=source.textContent.trim();wrap.append(audio);row.after(wrap);const button=wrap.querySelector('button'),range=wrap.querySelector('input'),time=wrap.querySelector('time'),status=wrap.querySelector('[role=status]');const format=n=>Math.floor(n/60)+':'+String(Math.floor(n%60)).padStart(2,'0');
  function update(){button.innerHTML=audio.paused?'<svg viewBox="0 0 32 32" aria-hidden="true"><path d="m7 3 23 13L7 29Z"/></svg>':'<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M7 4h6v24H7zM20 4h6v24h-6z"/></svg>';button.setAttribute('aria-label',audio.paused?'Produktvorstellung abspielen':'Produktvorstellung pausieren');const valid=Number.isFinite(audio.duration)&&audio.duration>0;range.disabled=!valid;range.value=valid?audio.currentTime/audio.duration*100:0;time.textContent=format(audio.currentTime)+(valid?' / '+format(audio.duration):'');range.setAttribute('aria-valuetext',time.textContent);}
  button.addEventListener('click',async()=>{if(!audio.paused){audio.pause();return;}status.textContent='';try{await audio.play();}catch{status.textContent='Die Tonspur konnte nicht geladen werden. Bitte versuche es erneut oder lies den Text mit.';}});range.addEventListener('input',()=>{if(Number.isFinite(audio.duration))audio.currentTime=audio.duration*Number(range.value)/100;});for(const event of ['play','pause','ended','timeupdate','loadedmetadata'])audio.addEventListener(event,update);audio.addEventListener('error',()=>{status.textContent='Die Tonspur ist gerade nicht erreichbar. Der Text steht unter „Text mitlesen“.';});update();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();document.addEventListener('shopify:section:load',init);
})();

(()=>{
 if(window.GravuruVoiceHelpReady)return;window.GravuruVoiceHelpReady=true;
 const synth=window.speechSynthesis;let speaking=null,resetSpeech=()=>{},token=0;
 function stop(){token++;if(speaking&&synth)synth.cancel();speaking=null;resetSpeech();resetSpeech=()=>{};}
 function narrate(text,button,status,rate=0.94){
  if(speaking&&speaking.button===button){stop();return;}stop();
  if(!synth||!window.SpeechSynthesisUtterance){status.textContent='Dieses Gerät unterstützt die Hörprobe nicht. Du kannst alles im Text mitlesen.';return;}
  const voices=synth.getVoices(),german=voices.filter(v=>/^de(?:-|_)/i.test(v.lang));if(voices.length&&!german.length){status.textContent='Auf diesem Gerät ist keine deutsche Stimme verfügbar. Bitte lies den Text mit.';return;}
  const original=button.textContent,current=token,u=new SpeechSynthesisUtterance(text);u.lang='de-DE';u.rate=rate;u.pitch=1;u.voice=german.find(v=>v.localService)||german[0]||null;
  resetSpeech=()=>{button.textContent=original;button.setAttribute('aria-pressed','false');status.textContent='';};speaking={button,utterance:u};button.textContent='■ Vorlesen stoppen';button.setAttribute('aria-pressed','true');status.textContent='Computerstimme wird gestartet …';
  u.onstart=()=>{if(current===token)status.textContent='Wird vorgelesen · Computerstimme';};u.onend=()=>{if(current===token){speaking=null;resetSpeech();status.textContent='Zu Ende vorgelesen.';}};u.onerror=e=>{if(current!==token)return;speaking=null;resetSpeech();if(e.error!=='canceled'&&e.error!=='interrupted')status.textContent='Die Stimme ist gerade nicht verfügbar. Bitte lies den Text mit.';};synth.speak(u);
 }
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});window.addEventListener('pagehide',stop);
 const steps=[
  {title:'Vorlage und Ausführung wählen',text:'Wähle zuerst eines der sechzehn Designs. Den Edelstahlrahmen und die Acrylfarbe kannst du unabhängig davon auswählen. Jedes Design lässt sich mit jeder Rahmenform kombinieren.',target:'.c-design-section',kind:'design'},
  {title:'Deinen Text ändern',text:'Unter Deine Texte findest du die Beispieltexte. Klicke in ein Textfeld und ersetze den Inhalt durch deinen Namen oder deine Hausnummer. Die Vorschau übernimmt deine Eingabe.',target:'.c-text-card textarea',kind:'text'},
  {title:'Text anklicken und verschieben',text:'Klicke oder tippe in der Vorschau auf deinen Text. Halte ihn fest und ziehe ihn an die gewünschte Stelle. Mit Rückgängig kannst du einen Schritt zurückgehen. Die Klingel bleibt an ihrer festen Position.',target:'.stage-wrap',kind:'move'},
  {title:'Die Mitte finden',text:'Die gestrichelte senkrechte Linie zeigt dir die Mitte des Schilds. Verschiebe deinen Text so, dass seine Mitte auf dieser Linie liegt. Die waagerechte Linie zeigt die halbe Höhe. Unter Mittellinien und Ausrichtungshilfen anzeigen kannst du die Hilfen ein- oder ausblenden. Diese Hilfslinien werden nicht mitgraviert.',target:'[data-setting="guides"]',kind:'center'},
  {title:'Schrift, Größe und Motive',text:'Wähle zuerst den Text, den du gestalten möchtest. Unter Schriftarten siehst du die Schriftproben. Über Größe und Ausrichtung am Text kannst du weitere Einstellungen öffnen. Unter Motive findest du Symbole und Verzierungen zum Einfügen.',target:'.fk-font-library',kind:'font'},
  {title:'Prüfen und bestellen',text:'Prüfe deine Namen und die Hausnummer in der großen Vorschau. Wähle die passende Befestigung. Unten siehst du den Gesamtpreis einschließlich des Befestigungsaufpreises. Über In den Warenkorb kannst du deine Gestaltung bestellen. Die Lieferung erfolgt ohne Klingel.',target:'.fk-buy-button',kind:'cart'}
 ];
 function picture(kind){
  const plate='<rect x="31" y="12" width="126" height="216" rx="2" fill="#bfc6c5"/><rect x="39" y="20" width="110" height="200" fill="#242b2a"/><text x="94" y="55" text-anchor="middle" fill="white" font-size="10">Familie</text><text x="94" y="76" text-anchor="middle" fill="white" font-size="15">Mustermann</text><rect x="76" y="112" width="37" height="88" rx="5" fill="#111817" stroke="#858f8d"/><circle cx="94" cy="134" r="7" fill="#334946"/><circle cx="94" cy="181" r="10" fill="none" stroke="#8ab7a8"/>';
  const illustrations={
   design:'<rect x="197" y="40" width="55" height="68" rx="5" fill="#fff" stroke="#2a755b" stroke-width="3"/><rect x="270" y="40" width="55" height="68" rx="5" fill="#fff" stroke="#abb7ad"/><rect x="197" y="126" width="55" height="68" rx="5" fill="#fff" stroke="#abb7ad"/><rect x="270" y="126" width="55" height="68" rx="5" fill="#fff" stroke="#abb7ad"/><text x="224" y="80" text-anchor="middle" font-size="24">✓</text><text x="261" y="220" text-anchor="middle" font-size="14">Dein Lieblingsdesign</text>',
   text:'<text x="195" y="66" font-size="14">Deine Texte</text><rect x="186" y="80" width="153" height="45" rx="6" fill="white" stroke="#2a755b" stroke-width="2"/><text x="198" y="108" font-size="18">Mustermann</text><path d="M319 89v28" stroke="#2a755b" stroke-width="2"/><path d="M186 102H157" stroke="#2a755b" stroke-width="2"/><text x="195" y="164" font-size="14">Anklicken &amp; ersetzen</text>',
   move:'<rect x="46" y="60" width="96" height="25" fill="none" stroke="#7dd3b1" stroke-width="2"/><path d="M159 73h74m-10-8 10 8-10 8M196 36v74m-8-10 8 10 8-10" stroke="#2a755b" fill="none" stroke-width="3"/><text x="204" y="154" font-size="16">Festhalten</text><text x="204" y="178" font-size="16">und ziehen</text>',
   center:'<path d="M94 20v200M39 120h110" stroke="#80d5b9" stroke-width="2" stroke-dasharray="5 4"/><path d="M99 35h90" stroke="#2a755b" stroke-width="2"/><text x="198" y="39" font-size="16">Schildmitte</text><text x="190" y="110" font-size="15">← gleich →</text><text x="185" y="164" font-size="14">Nur Orientierung</text><text x="185" y="187" font-size="14">Keine Gravur</text>',
   font:'<rect x="182" y="35" width="158" height="55" rx="6" fill="#fff" stroke="#a5b4aa"/><text x="201" y="71" font-size="27">Aa</text><text x="262" y="70" font-size="25" font-family="Georgia,serif">Aa</text><text x="199" y="126" font-size="20">−</text><text x="236" y="126" font-size="15">Größe</text><text x="302" y="126" font-size="20">+</text><text x="205" y="192" font-size="40">♡</text><text x="273" y="187" font-size="34">⌂</text>',
   cart:'<text x="186" y="70" font-size="16">Deine Gestaltung</text><text x="186" y="100" font-size="16">✓ Name prüfen</text><text x="186" y="128" font-size="16">✓ Preis prüfen</text><rect x="179" y="151" width="166" height="45" rx="7" fill="#284b3e"/><text x="262" y="179" text-anchor="middle" fill="white" font-size="15">In den Warenkorb</text>'
  };
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 370 240" role="img" aria-label="'+steps.find(s=>s.kind===kind).title+' – schematische Anleitung"><g font-family="Arial,sans-serif" fill="#26382f">'+plate+illustrations[kind]+'</g></svg>';
 }
 let guide=null,frame=null,index=0,lastFocus=null;
 function openGuide(){stop();lastFocus=frame?.contentDocument?.querySelector('gravuru-configurator')?.shadowRoot?.activeElement||frame?.contentDocument?.activeElement||document.activeElement;if(!guide)createGuide();render();guide.showModal();guide.querySelector('[data-close]').focus();}
 function createGuide(){guide=document.createElement('dialog');guide.className='gv-voice-guide';guide.setAttribute('aria-labelledby','gv-guide-heading');guide.innerHTML='<div class="gv-voice-head"><div><p>Bild + Sprache · in deinem Tempo</p><h2 id="gv-guide-heading">So gestaltest du dein Schild</h2></div><button type="button" data-close aria-label="Erklärung schließen">✕</button></div><label class="gv-guide-select">Thema<select aria-label="Hilfethema wählen"></select></label><figure><div data-picture></div><figcaption>Vereinfachtes Beispiel · dein Entwurf bleibt unverändert</figcaption></figure><h3 data-title></h3><p class="gv-guide-copy"></p><div class="gv-voice-actions"><button type="button" class="gv-listen" aria-pressed="false">▶ Erklärung anhören</button><button type="button" data-show>Im Konfigurator zeigen</button></div><label class="gv-guide-slow"><input type="checkbox">Langsam vorlesen</label><small>Hörvorschau mit Computerstimme</small><p class="gv-voice-status" role="status"></p><nav class="gv-guide-nav" aria-label="Erklärungsschritte"><button type="button" data-prev>← Zurück</button><button type="button" data-next>Weiter →</button></nav><div class="gv-guide-support"><button type="button" data-contact>Weitere Hilfe / Kontakt</button></div>';
  document.body.append(guide);const select=guide.querySelector('select');steps.forEach((s,i)=>{const o=document.createElement('option');o.value=i;o.textContent=(i+1)+'. '+s.title;select.append(o);});select.addEventListener('change',()=>{index=Number(select.value);render();});guide.querySelector('[data-close]').onclick=()=>guide.close();guide.addEventListener('close',()=>{stop();lastFocus?.focus?.({preventScroll:true});});guide.querySelector('[data-prev]').onclick=()=>{index--;render();};guide.querySelector('[data-next]').onclick=()=>{index++;render();};guide.querySelector('.gv-listen').onclick=e=>narrate(steps[index].title+'. '+steps[index].text,e.currentTarget,guide.querySelector('[role=status]'),guide.querySelector('input').checked?0.78:0.94);guide.querySelector('input').onchange=stop;
  guide.querySelector('[data-contact]').onclick=()=>{guide.close();const chat=document.querySelector('shopify-chat');const opener=chat?.shadowRoot?.querySelector('button');if(opener){document.getElementById('gravuru-fk-dialog')?.close();opener.click();}else window.open('/pages/contact','_blank','noopener');};
  guide.querySelector('[data-show]').onclick=()=>{const doc=frame?.contentDocument,s=steps[index],root=doc?.querySelector('gravuru-configurator')?.shadowRoot||doc;let target=root?.querySelector(s.target);if(s.kind==='font')target=root?.querySelector('[aria-label="Alle Schriftarten"]')||target;if(s.kind==='center')target=root?.querySelector('input[type=checkbox][data-setting="guides"]')?.closest('.check-guide')||target;if(!target){guide.querySelector('[role=status]').textContent='Du findest diesen Bereich direkt in der Konfigurator-Übersicht.';return;}const sheet=doc.createElement('style');sheet.textContent='.gv-guide-highlight{outline:4px solid #2c9674!important;outline-offset:5px!important;scroll-margin:90px!important}';root.append(sheet);guide.close();target.scrollIntoView({block:'center',behavior:'instant'});target.classList.add('gv-guide-highlight');target.focus?.({preventScroll:true});setTimeout(()=>{target.classList.remove('gv-guide-highlight');sheet.remove();},6000);};
 }
 function render(){stop();const s=steps[index];guide.querySelector('select').value=index;guide.querySelector('[data-title]').textContent=(index+1)+' / '+steps.length+' · '+s.title;guide.querySelector('.gv-guide-copy').textContent=s.text;guide.querySelector('[data-picture]').innerHTML=picture(s.kind);guide.querySelector('[data-prev]').disabled=index===0;guide.querySelector('[data-next]').disabled=index===steps.length-1;guide.scrollTop=0;}
 function initFrame(){try{const doc=frame.contentDocument;if(!doc?.body||doc.body.dataset.gvVoiceBound)return;doc.body.dataset.gvVoiceBound='true';const style=doc.createElement('style');style.textContent='.gv-guide-highlight{outline:4px solid #2c9674!important;outline-offset:5px!important;scroll-margin:90px!important}';doc.head.append(style);doc.addEventListener('click',e=>{if(e.composedPath().some(node=>node.matches?.('.fk-chat-button'))){e.preventDefault();e.stopImmediatePropagation();openGuide();}},true);}catch{}}
 function init(){
  const row=document.querySelector('.gv-thumbnails'),source=document.querySelector('[data-gv-audio-src]');if(row&&source&&!source.dataset.gvAudioSrc&&!document.querySelector('.gv-voice-demo')){const demo=document.createElement('section');demo.className='gv-voice-demo';demo.setAttribute('aria-label','Hörprobe zum Produkt');demo.innerHTML='<h3>Dein Klingelschild – kurz erklärt</h3><small>Hörvorschau · Computerstimme</small><div class="gv-voice-actions"><button class="gv-listen" type="button" aria-pressed="false">▶ Hörprobe starten</button></div><p class="gv-voice-status" role="status"></p><details><summary>Text mitlesen</summary><p></p></details>';demo.querySelector('details p').textContent=source.textContent;demo.querySelector('button').onclick=e=>narrate(source.textContent,e.currentTarget,demo.querySelector('[role=status]'));row.after(demo);}
  const editor=document.getElementById('gravuru-fk-editor');if(editor&&editor!==frame){frame=editor;frame.addEventListener('load',initFrame);initFrame();const dialog=document.getElementById('gravuru-fk-dialog');dialog?.addEventListener('close',()=>{stop();if(guide?.open)guide.close();});new MutationObserver(()=>{if(dialog.open)stop();}).observe(dialog,{attributes:true,attributeFilter:['open']});}
 }
 new MutationObserver(init).observe(document.documentElement,{childList:true,subtree:true});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

(() => {
  if (window.GravuruMobileScrollV1) return;
  window.GravuruMobileScrollV1 = true;
  const css = `
    @media(max-width:767px){
      :host([data-gv-mobile-scroll]) .c-gallery{height:auto!important;max-height:none!important;min-height:0!important;overflow:visible!important;overscroll-behavior:auto!important;touch-action:pan-y pinch-zoom!important}
      :host([data-gv-mobile-scroll]) .plate-holder,:host([data-gv-mobile-scroll]) .scene{touch-action:pan-y pinch-zoom!important}
      :host([data-gv-mobile-scroll]) .scene [data-gv-touch-selected="true"],:host([data-gv-mobile-scroll]) .resize-handle,:host([data-gv-mobile-scroll]) .frame-rotate{touch-action:none!important}
      .gv-mobile-scroll-hint{display:block;margin:8px 0;color:#4d5359;font-size:12px;line-height:1.5;text-align:center}
    }
    @media(min-width:768px){.gv-mobile-scroll-hint{display:none}}
  `;
  function install(el) {
    const root = el.shadowRoot;
    if (!el.dataset.fkRelease || !root?.querySelector('.plate-holder') || el.dataset.gvMobileScroll) return false;
    el.dataset.gvMobileScroll = 'v1';
    const doc = el.ownerDocument, win = doc.defaultView;
    const mobile = win.matchMedia('(max-width:767px)');
    const style = doc.createElement('style');
    style.textContent = css;
    root.append(style);
    const hint = doc.createElement('p');
    hint.className = 'gv-mobile-scroll-hint';
    hint.textContent = 'Wischen zum Scrollen · Element antippen, dann verschieben';
    root.querySelector('.stage-wrap > .stage-bottom')?.after(hint);
    const gallery = root.querySelector('.c-gallery');
    const scrollHint = root.querySelector('.fk-scroll-hint');
    const oldHint = scrollHint?.textContent;
    const oldLabel = gallery?.getAttribute('aria-label');
    function refresh() {
      for (const node of root.querySelectorAll('.scene [data-object]')) {
        if (mobile.matches && node.dataset.object === el.state.selected) node.dataset.gvTouchSelected = 'true';
        else node.removeAttribute('data-gv-touch-selected');
      }
      if (scrollHint) scrollHint.textContent = mobile.matches ? 'Wähle dein Lieblingsdesign. Wische weiter, um alle Vorlagen zu sehen.' : oldHint;
      if (gallery) gallery.setAttribute('aria-label', mobile.matches ? 'Designübersicht' : oldLabel);
    }
    const render = el.render;
    el.render = function(...args) {
      const result = render.apply(this, args);
      refresh();
      return result;
    };
    let tap = null;
    root.addEventListener('pointerdown', event => {
      if (!mobile.matches || event.pointerType !== 'touch' || !event.target.closest('.plate-holder')) return;
      if (!event.isPrimary) { tap = null; return; }
      if (el.multiSelecting || event.target.closest('button,[data-resize]')) return;
      const item = event.target.closest('[data-object]');
      if (item?.dataset.object === el.state.selected) return;
      tap = {id:event.pointerId, object:item?.dataset.object || null, x:event.clientX, y:event.clientY};
      event.stopImmediatePropagation();
    }, true);
    root.addEventListener('pointermove', event => {
      if (!tap || event.pointerId !== tap.id) return;
      if (Math.hypot(event.clientX - tap.x, event.clientY - tap.y) > 9) tap = null;
    }, {capture:true, passive:true});
    root.addEventListener('pointerup', event => {
      if (!tap || event.pointerId !== tap.id) return;
      const selected = tap;
      tap = null;
      if (!mobile.matches || Math.hypot(event.clientX - selected.x, event.clientY - selected.y) > 9) return;
      event.stopImmediatePropagation();
      el.state.selected = selected.object;
      el.centerSuggestion = null;
      el.sync();
    }, true);
    root.addEventListener('pointercancel', () => { tap = null; }, {capture:true, passive:true});
    mobile.addEventListener('change', () => { tap = null; refresh(); });
    refresh();
    return true;
  }
  const frames = new WeakSet();
  function watchFrame(frame) {
    if (frames.has(frame)) return;
    frames.add(frame);
    function ready() {
      const doc = frame.contentDocument;
      if (!doc?.body || doc.body.dataset.gvMobileWatched) return;
      doc.body.dataset.gvMobileWatched = 'true';
      let stopped = false;
      const observer = new MutationObserver(tryInstall);
      function tryInstall() {
        const el = doc.querySelector('gravuru-configurator');
        if (!el) return;
        if (!stopped) observer.observe(el, {attributes:true, attributeFilter:['data-fk-release']});
        if (install(el)) { stopped = true; observer.disconnect(); }
        else if (el.shadowRoot && !stopped) observer.observe(el.shadowRoot, {childList:true, subtree:true});
      }
      observer.observe(doc.body, {childList:true, subtree:true});
      tryInstall();
      doc.defaultView.customElements.whenDefined('gravuru-configurator').then(tryInstall);
    }
    frame.addEventListener('load', ready);
    ready();
  }
  function init() {
    const frame = document.getElementById('gravuru-fk-editor');
    if (frame) watchFrame(frame);
  }
  new MutationObserver(init).observe(document.documentElement, {childList:true, subtree:true});
  init();
})();

(() => {
  const key = d => d.toISOString().slice(0,10);
  const plus = (d,n) => new Date(d.getTime()+n*86400000);
  function easter(y) {
    const a=y%19,b=Math.floor(y/100),c=y%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k)%7,m=Math.floor((a+11*h+22*l)/451),n=h+l-7*m+114;
    return new Date(Date.UTC(y,Math.floor(n/31)-1,n%31+1));
  }
  const holidayCache = new Map();
  function holidays(y) {
    if (!holidayCache.has(y)) {
      const dates=['01-01','05-01','10-03','11-01','12-25','12-26'].map(s=>y+'-'+s),e=easter(y);
      holidayCache.set(y,new Set(dates.concat([-2,1,39,50,60].map(n=>key(plus(e,n))))));
    }
    return holidayCache.get(y);
  }
  function workday(d) {return ![0,6].includes(d.getUTCDay())&&!holidays(d.getUTCFullYear()).has(key(d));}
  function status(now=new Date()) {
    const p=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Berlin',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(now).map(p=>[p.type,p.value]));
    const day=new Date(Date.UTC(+p.year,+p.month-1,+p.day)),seconds=13*3600-(+p.hour*3600 + +p.minute*60 + +p.second);
    if(workday(day)&&seconds>0)return {sameDay:true,date:key(day),seconds};
    let next=plus(day,1);while(!workday(next))next=plus(next,1);
    // Convert the next 13:00 Berlin deadline to UTC, including DST changes.
    const wall=next.getTime()+13*3600000;let deadline=wall;
    for(let i=0;i<2;i++){
      const parts=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Berlin',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date(deadline)).map(p=>[p.type,p.value]));
      const shown=Date.UTC(+parts.year,+parts.month-1,+parts.day,+parts.hour,+parts.minute,+parts.second);
      deadline+=wall-shown;
    }
    return {sameDay:false,date:key(next),seconds:Math.max(0,Math.floor((deadline-now.getTime())/1000))};
  }
  const api={status,workday,holidays};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else window.GravuruDispatchCalendar=api;
})();

(() => {
  function state(cart,productCents=4999){
    const actual=!!cart&&Number(cart.item_count)>0;
    const eligible=!cart?.currency||cart.currency==='EUR';
    const amount=Math.max(0,Math.round(actual?Number(cart.total_price)||0:productCents));
    return {actual,eligible,amount,remaining:Math.max(0,6900-amount),percent:Math.min(100,amount/69)};
  }
  if(typeof module!=='undefined'&&module.exports){module.exports={state};return;}
  window.GravuruShippingProgress={mount(box){
    const bar=document.createElement('div');bar.className='gv-shipping-progress';
    bar.innerHTML='<div class="gv-shipping-heading"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M2 5h12v12H2zM14 9h4l4 4v4h-3M14 17h1"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></svg><strong>Versandkostenfrei ab 69 €</strong></div><p><span data-gv-shipping-label></span> · <span data-gv-shipping-remaining></span></p><progress max="6900" value="4999" aria-label="Fortschritt zum kostenlosen Versand"></progress>';
    const priceNodes=Array.from(document.querySelectorAll('.product__block--price .f-price-item'));
    const visiblePrice=priceNodes.find(e=>e.getClientRects().length&&e.textContent.trim());
    const currentPrice=Math.round(Number((visiblePrice?.textContent||'').replace(/[^0-9,]/g,'').replace(',','.'))*100);
    box.append(bar);let cart=null,productCents=currentPrice>0?currentPrice:4999,busy=false,lastRead=0;
    const euro=n=>new Intl.NumberFormat('de-DE',{style:'currency',currency:'EUR'}).format(n/100);
    function render(){
      const s=state(cart,productCents);bar.hidden=!s.eligible;
      bar.querySelector('[data-gv-shipping-label]').textContent=(s.actual?'Im Warenkorb: ':'Mit diesem Schild: ')+euro(s.amount);
      const progress=bar.querySelector('progress');progress.value=Math.min(s.amount,6900);progress.setAttribute('aria-valuetext',euro(s.amount)+' von 69 Euro');
      bar.querySelector('[data-gv-shipping-remaining]').textContent=s.remaining?'noch '+euro(s.remaining):'Gratisversand erreicht';
    }
    async function refresh(force=false){
      if(busy||(!force&&Date.now()-lastRead<3000))return;busy=true;lastRead=Date.now();
      try{const r=await fetch((window.Shopify?.routes?.root||'/')+'cart.js',{credentials:'same-origin',cache:'no-store'});if(!r.ok)throw Error('cart');cart=await r.json();render();}catch{ /* Keep the clearly labelled product estimate or last known cart. */ }finally{busy=false;}
    }
    document.addEventListener('cart:updated',e=>{if(e.detail?.cart){cart=e.detail.cart;render();}else refresh(true);});
    document.addEventListener('product-ajax:added',()=>refresh(true));
    window.addEventListener('focus',()=>refresh());document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
    document.addEventListener('gravuru:price',e=>{if(Number.isFinite(e.detail?.cents)){productCents=e.detail.cents;render();}});
    render();refresh(true);
  }};
})();

window.GravuruConfiguratorPolishCSS=":host([data-gv-polish]) .dimension-x{bottom:-24px!important;height:8px!important;align-items:center!important}\n:host([data-gv-polish]) .dimension-x span{position:absolute!important;top:0!important;left:50%!important;transform:translate(-50%,-50%)!important;display:block!important;height:auto!important;line-height:16px!important;padding:0 8px!important;background:#fff!important;white-space:nowrap!important}\n:host([data-gv-polish]) .dimension-x{border-bottom:0!important;border-top:1px solid #a5b0a8!important}\n:host([data-gv-polish]) .stage-bottom{margin-top:3px!important;padding-top:0!important}\n:host([data-gv-polish]) .check-guide{display:flex!important;align-items:center!important;gap:8px!important;padding:6px 10px!important;background:#f6f8f6!important;border-color:#d5ddd6!important;min-height:38px!important}\n:host([data-gv-polish]) .check-guide label{display:flex!important;flex-direction:column!important;align-items:flex-start!important;line-height:1.35!important;font-size:12px!important;font-weight:500!important;min-height:0!important;cursor:pointer}\n:host([data-gv-polish]) .check-guide label strong{font:inherit;font-weight:600}\n:host([data-gv-polish]) .check-guide label span{display:block!important;font-size:11px;color:#53635a}\n:host([data-gv-polish]) .check-guide input{width:18px!important;height:18px!important;min-height:18px!important;flex:none!important}\n:host([data-gv-polish]) .guided-alignment{opacity:.65}\n:host([data-gv-polish]) .fk-font-heading h3{font-size:20px!important}\n:host([data-gv-polish]) .fk-live-preview .check-guide{padding:3px 8px!important;min-height:36px!important}\n@media(max-width:767px){\n :host([data-gv-polish]) .fk-buy-dock{padding:6px max(10px,env(safe-area-inset-right)) calc(6px + env(safe-area-inset-bottom)) max(10px,env(safe-area-inset-left))!important}\n :host([data-gv-polish]) .fk-buy-inner{grid-template-columns:minmax(0,1fr) 43px minmax(110px,auto) 36px!important;gap:5px 7px!important}\n :host([data-gv-polish]) .fk-price-area{grid-column:1!important;grid-row:1!important;gap:2px!important}\n :host([data-gv-polish]) .fk-price-area strong{font-size:19px!important}\n :host([data-gv-polish]) .fk-price-area span{grid-column:1 / -1;font-size:10px!important;line-height:1.25}\n :host([data-gv-polish]) .fk-price-area small{font-size:9px!important;line-height:1.25!important}\n :host([data-gv-polish]) .fk-quantity{grid-column:2!important;grid-row:1!important;font-size:9px!important}\n :host([data-gv-polish]) .fk-quantity input{width:43px!important;height:31px!important;min-height:31px!important;padding:4px!important;font-size:13px!important}\n :host([data-gv-polish]) .fk-buy-button{grid-column:3!important;grid-row:1!important;min-width:0!important;min-height:42px!important;height:42px!important;padding:7px 9px!important;font-size:12px!important;gap:4px!important}\n :host([data-gv-polish]) .fk-chat-button{grid-column:4!important;grid-row:1!important;width:36px!important;min-width:36px!important;height:38px!important;min-height:38px!important;padding:6px!important;font-size:19px!important}\n :host([data-gv-polish]) .fk-order-status{grid-column:1/-1!important;font-size:10px!important}\n :host([data-gv-polish]) .fk-buy-inner>[data-fk-breakdown]{grid-column:1/-1;font-size:10px;line-height:1.2;color:#53615a}\n}\n@media(max-width:360px){:host([data-gv-polish]) .fk-buy-inner{grid-template-columns:minmax(0,1fr) 38px 102px 32px!important;gap:4px!important}:host([data-gv-polish]) .fk-quantity input{width:38px!important}:host([data-gv-polish]) .fk-chat-button{width:32px!important;min-width:32px!important}:host([data-gv-polish]) .fk-buy-button{font-size:11px!important}}\n";
(() => {
  if(window.GravuruProductPolishV1)return;
  window.GravuruProductPolishV1=true;
  function productPolish(){
    const product=document.querySelector('product-info.section-main-product');
    if(!product||!document.querySelector('[data-gravuru-pdp]'))return;
    const title=product.querySelector('h1.product__title');
    if(title?.textContent.includes('V8P1AX11')&&!title.dataset.gvShort){title.dataset.gvShort='true';title.textContent='Klingelschild für AOSU Pro V8P1AX11';}
    const tax=product.querySelector('.product__tax');
    if(tax&&!tax.dataset.gvShort){tax.dataset.gvShort='true';tax.innerHTML='Inkl. MwSt. · zzgl. <a href="/policies/shipping-policy">Versand</a>';}
    const audio=product.querySelector('.gv-audio');
    if(audio&&!audio.dataset.gvClean){audio.dataset.gvClean='true';audio.querySelector('.gv-audio-heading').innerHTML='Kurz erklärt <span>Chris · KI-Stimme</span>';audio.querySelector('.gv-audio-row').append(audio.querySelector('time'));}
    const trust=Array.from(product.querySelectorAll('.product__info-wrapper .gv-assurance')).find(node=>!node.closest('[hidden]'));
    const existingDispatch=product.querySelector('.gv-dispatch');
    if(trust&&existingDispatch&&existingDispatch.previousElementSibling!==trust)trust.after(existingDispatch);
    if(trust&&!product.querySelector('.gv-dispatch')){
      const box=document.createElement('section');box.className='gv-dispatch';box.setAttribute('aria-label','Fertigung und Versand');
      box.innerHTML='<div class="gv-dispatch-head"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/></svg><strong data-gv-dispatch-title>Dein nächster Versand</strong></div><p class="gv-deadline-label"><span>Bestelle innerhalb von</span> <time data-gv-countdown></time></p>';
      trust.after(box);
      window.GravuruShippingProgress.mount(box);
      const info=document.createElement('details');info.className='gv-shipping-info';info.innerHTML='<summary>Versandinfos</summary><p>Bestellungen bis 13 Uhr werden am selben Werktag versendet. Mo–Fr nach deutscher Zeit, außer an NRW-Feiertagen. Voraussetzung: abgeschlossene Bestellung und geklärte Zahlung.</p><p>Versandkostenfrei ab 69 € für Lieferungen nach Deutschland. <a href="/policies/shipping-policy">Alle Versanddetails</a></p>';box.append(info);
      function update(){
        const s=window.GravuruDispatchCalendar.status();const heading=box.querySelector('[data-gv-dispatch-title]'),counter=box.querySelector('time');
        const label=new Intl.DateTimeFormat('de-DE',{timeZone:'UTC',weekday:'long',day:'2-digit',month:'2-digit'}).format(new Date(s.date+'T12:00:00Z'));
        heading.textContent=s.sameDay?'Versand noch heute':'Versand am '+label;
        const days=Math.floor(s.seconds/86400),hours=Math.floor(s.seconds/3600)%24,minutes=Math.floor(s.seconds/60)%60,seconds=s.seconds%60;
        counter.textContent=(days?days+' T. ':'')+String(hours).padStart(2,'0')+':'+String(minutes).padStart(2,'0')+':'+String(seconds).padStart(2,'0');
        counter.setAttribute('aria-label',(days?days+' Tage, ':'')+hours+' Stunden, '+minutes+' Minuten und '+seconds+' Sekunden bis zum Bestellschluss für Versand '+(s.sameDay?'heute':label));
      }
      update();const interval=setInterval(()=>{if(!box.isConnected){clearInterval(interval);return;}if(!document.hidden)update();},1000);document.addEventListener('visibilitychange',()=>{if(!document.hidden&&box.isConnected)update();});
    }
  }
  function editorPolish(el){
    if(!el.dataset.fkRelease||el.dataset.gvPolish||!el.shadowRoot?.querySelector('.fk-buy-dock'))return false;
    el.dataset.gvPolish='v1';const root=el.shadowRoot,doc=el.ownerDocument,$=s=>root.querySelector(s);
    const style=doc.createElement('style');style.textContent=window.GravuruConfiguratorPolishCSS;root.append(style);
    const guides=$('[data-setting="guides"]');guides.checked=false;guides.defaultChecked=false;
    guides.setAttribute('aria-label','Hilfslinien zum Ausrichten anzeigen');
    guides.closest('.check-guide').querySelector('label').innerHTML='<strong>Hilfslinien zum Ausrichten</strong><span>Anzeigen</span>';
    $('.fk-font-heading h3').textContent='Wähle deine Schriftart';
    $('.fk-font-section > p').textContent='Wähle zuerst deinen Text, dann die passende Schrift.';
    const ideas=$('[data-bestsellers]');if(ideas){ideas.open=true;ideas.querySelector('summary').textContent='Unsere Motivempfehlungen';}
    const motifTitle=$('.fk-motif-step .step-heading>span:nth-child(2)');if(motifTitle?.firstChild)motifTitle.firstChild.textContent='Wähle dein Motiv';
    const breakdown=$('[data-fk-breakdown]');$('.fk-buy-inner').append(breakdown);
    const sync=el.sync;
    el.sync=function(...args){const result=sync.apply(this,args);if((this.state.fkMounting||'K00')==='K00')$('[data-fk-mount-note]').textContent='Lieferung ohne Befestigungsmaterial und ohne zusätzliche Wandmontage-Bohrungen.';return result;};
    const total=$('[data-fk-total]');
    function reportPrice(){const cents=Math.round(Number((total?.textContent||'').replace(/[^0-9,]/g,'').replace(',','.'))*100);if(cents>0)document.dispatchEvent(new CustomEvent('gravuru:price',{detail:{cents}}));}
    if(total){new MutationObserver(reportPrice).observe(total,{childList:true,subtree:true,characterData:true});reportPrice();}
    el.sync();return true;
  }
  const frames=new WeakSet();
  function watch(frame){
    if(frames.has(frame))return;frames.add(frame);
    function ready(){
      const doc=frame.contentDocument;if(!doc?.body||doc.body.dataset.gvPolishWatched)return;doc.body.dataset.gvPolishWatched='true';let done=false;
      const observer=new MutationObserver(attempt);
      function attempt(){if(done)return;const el=doc.querySelector('gravuru-configurator');if(!el)return;observer.observe(el,{attributes:true,attributeFilter:['data-fk-release']});if(el.shadowRoot)observer.observe(el.shadowRoot,{childList:true,subtree:true});if(editorPolish(el)){done=true;observer.disconnect();}}
      observer.observe(doc.body,{childList:true,subtree:true});attempt();doc.defaultView.customElements.whenDefined('gravuru-configurator').then(attempt);
    }
    frame.addEventListener('load',ready);ready();
  }
  function init(){productPolish();const frame=document.getElementById('gravuru-fk-editor');if(frame)watch(frame);}
  new MutationObserver(init).observe(document.documentElement,{childList:true,subtree:true});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
