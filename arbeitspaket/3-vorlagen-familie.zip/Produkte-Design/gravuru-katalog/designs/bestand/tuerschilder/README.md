# Bestandsdesigns Tuerschilder – aus dem Server-Bestand extrahiert

1763 Designs (über Größen und Materialien zusammengefasst), gelesen aus den Corel-Bögen (`[CDR]`) und Konfigurator-Paketen auf `V:\Produkte\Gedenktafeln`. Je Design ein Ordner `Zielgruppe/Unterkategorie/<Schlüssel>/` mit `design.svg` (Text bleibt Text, Motive als Pfade, Maße in mm), `design.json` (Texte, Schriften, Lage, Varianten, Kategorie) und `preview.png`. UV-Designs aus Paketen tragen zusätzlich `product.json` und die Ebenen (`Bild_*.png`, `*.svg`).

**Kategorien sind Vorschläge aus den Texten** – Korrektur in [`TUERSCHILDER-DESIGNS.xlsx`](TUERSCHILDER-DESIGNS.xlsx) (gelbe Spalten), Übersichtsbögen je Kategorie in `_uebersicht/`.

| Zielgruppe | Unterkategorie | Designs |
| --- | --- | --- |
| Allgemein | Allgemein | 220 |
| Familie | Familie | 1379 |
| Familie | Willkommen | 13 |
| Hinweis | Bitte und Verbot | 17 |
| Hinweis | Privat und Eingang | 35 |
| Sprüche | Spruch | 31 |
| Tiere | Hund | 6 |
| Tiere | Kleintier | 7 |
| offen | offen | 55 |

| Reihe | Designs |
| --- | --- |
| TO-A · Gravur Acryl Oval | 73 |
| TAE-A · Gravur Acryl Abgerundete Ecken | 73 |
| TR1-A · Gravur Acryl | 73 |
| TR2-A · Gravur Acryl | 73 |
| TO-V2A · Gravur Edelstahl Oval | 73 |
| TAE-V2A · Gravur Edelstahl Abgerundete Ecken | 73 |
| TR1-V2A · Gravur Edelstahl | 73 |
| TR2-V2A · Gravur Edelstahl | 73 |
| TO-KS · Gravur Kunststoff Oval | 73 |
| TQ-KS · Gravur Kunststoff Quadrat | 73 |
| TR1-KS · Gravur Kunststoff | 73 |
| TR2-KS · Gravur Kunststoff | 73 |
| TQ-V2A · Gravur Edelstahl | 71 |
| TQ-A · Gravur Acryl | 61 |
| TQ-H · Gravur Holz | 61 |
| TRE-S · Gravur Schiefer | 61 |
| TQ-S · Gravur Schiefer | 61 |
| TAS-V2A · Gravur Edelstahl Abgerundete Seiten | 59 |
| TRE-AV2A · Gravur Acryl + Edelstahl | 58 |
| TRE-V2A · Gravur Edelstahl | 58 |
| TRE-A · Gravur Acryl | 57 |
| TRE-KS · Gravur Kunststoff | 57 |
| TAS-A · Gravur Acryl Abgerundete Seiten | 56 |
| TRE-H · Gravur Holz | 56 |
| TOUV-A · UV Acryl Oval | 30 |
| TAE-KS · Gravur Kunststoff Abgerundete Ecken | 17 |
| TAS-KS · Gravur Kunststoff Abgerundete Seiten | 17 |
| TRE-A · Gravur Acryl Rechteck | 16 |
| TRE-KS · Gravur Kunststoff Abgerundete Ecken | 16 |
| TRE-V2A · Gravur Acryl + Edelstahl | 14 |
| TQ-A · Gravur Acryl Quadrat | 12 |
| TREUV-V2A · UV Edelstahl Rechteck | 11 |
| TREUV-A · UV Acryl | 8 |
| TQUV-A · UV Acryl Quadrat | 8 |
| TSUV-S · UV Schiefer | 7 |
| TSUV-V2A · UV Edelstahl Rechteck | 7 |
| TRUV-A · UV Acryl Rechteck | 3 |
| TQ-V2A · Gravur Edelstahl Quadrat | 2 |
| TRE-V2A · Gravur Edelstahl Abgerundete Ecken | 1 |
| TQ-H · UV Holz Quadrat | 1 |
| TRE-H · UV Holz Rechteck | 1 |

## Regeln

- Eigene Motive dieser Designs bleiben beim Design (keine Übernahme in `motive/`).
- Alte Größen sind nur dokumentiert (`sizesInStock`); welche Größen die Linie künftig hat, entscheidet der Nutzer.
- Texte sind Beispieltexte des Bestands (Kundenfelder im Konfigurator); Schriften sind die im Bestand verwendeten – Ersatz für nicht freigegebene Schriften folgt je Linie.
- Lücken: Designs ohne lesbaren Text (`offen`) stammen aus reinen Bildpaketen; dort hilft nur Sichtprüfung über `preview.png`.
